﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace API_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            API();

            //NewsAPI();


            Console.ReadLine();

        }


        public static void API()
        {
            WebClient web = new WebClient();

            //string result2 = web.DownloadString("https://finance.yahoo.com/quote/ABR-A/profile?p=ABR-A");

            //string result3 = web.DownloadString("https://news.google.com/search?q=iphone&hl=en-US&gl=US&ceid=US%3Aen");

            string result1 = web.DownloadString("https://www.forbes.com/sites/gordonkelly/2019/02/14/apple-new-iphone-8-7-upgrade-qualcomm-intel-iphone-xs-max-xr/#4610b8c55b67");

            var doc1 = new HtmlDocument();

            doc1.LoadHtml(result1);

            var mt1 = doc1.DocumentNode.Descendants().Where(m => Regex.Match(m.InnerHtml, @"article.body.container").Success).Last();
            var tmt1 = doc1.DocumentNode.SelectSingleNode("/html[1]/body[1]/app-root[1]/app[1]/stream[1]/page[1]/" +
                "page-standard[1]/div[2]/div[1]");

            //Console.WriteLine(mt1.Name + "\n\n" + mt1.InnerText);



            string result2 = web.DownloadString("https://www.cnet.com/news/apple-needs-the-iphone-se-2-right-now-heres-why/");

            var doc2 = new HtmlDocument();

            doc2.LoadHtml(result2);

            var mt2 = doc2.DocumentNode.Descendants().Where(m => Regex.Match(m.InnerHtml, @"article.body").Success).Last();
            var tmt2 = doc2.DocumentNode.SelectSingleNode("/html[1]/body[1]/app-root[1]/app[1]/stream[1]/page[1]/" +
                "page-standard[1]/div[2]/div[1]");

            //Console.WriteLine(mt2.Name + "\n\n" + mt2.InnerText);


            string result3 = web.DownloadString("https://www.news18.com/news/tech/amazon-apple-fest-discounts-on-iphone-x-xr-macbook-air-ipad-pro-and-more-2040333.html");

            var doc3 = new HtmlDocument();

            doc3.LoadHtml(result3);


            //var mt3 = doc3.DocumentNode.Descendants().Where(m => Regex.Match(m.InnerHtml, @"article-leader").Success).Last();
            //var tmt3 = doc3.DocumentNode.SelectSingleNode("/html[1]/body[1]/app-root[1]/app[1]/stream[1]/page[1]/" +
            //"page-standard[1]/div[2]/div[1]");

            //Console.WriteLine(mt3.Name + "\n\n" + mt3.InnerText);


            foreach (var at in doc3.DocumentNode.Descendants())
            {
                if (at.HasAttributes)
                {
                    if (at.GetAttributeValue("class", "champ") == "article-sbox")
                    {
                        //Console.WriteLine(at.Name + " " + " " + at.Value + " " + at.OwnerNode);
                        Console.WriteLine(at.Name + "\n" + at.InnerText);
                    }

                }
            }



            HtmlNodeCollection feve2 = new HtmlNodeCollection(doc2.DocumentNode);



            //foreach(var item in doc2.DocumentNode.SelectNodes("/html[1]/body[1]/app-root[1]/app[1]/stream[1]/page[1]/" +
            //    "page-standard[1]/div[2]/div[1]/article-body-container[1]/div[1]/div[1]"))
            //{
            //    if (item.InnerText.Contains("While we had an inkling"))
            //    {
            //        Console.WriteLine("Path - " + item.XPath + "\n" +
            //            "Orig  Name - " + item.OriginalName + "\n" + "Name - " + item.Name + "\n" + item.InnerText);
            //    }

            //}





            //foreach (var m in tmt.Attributes)
            //{
            //    Console.WriteLine(m.Name + " " + m.Value);
            //}

            //foreach(var m in mt)
            //{
            //    foreach(var o in m.Attributes)
            //    {
            //        if(o.Name == "class" && o.Value.Contains("body"))
            //        {
            //            Console.WriteLine(o.Name + " " + o.Value);
            //        }


            //    }

            //}




            //MatchCollection match = Regex.Matches("He said--decisively--that the time--whatever time it was--had come.", @"--(.+?)-");

            //foreach (Match m in match)
            //{
            //    Console.WriteLine(m.Result("($1)"));
            //}

            //var feve3 = doc2.GetElementbyId("YDC-Col1").Descendants(1)
            //    .First().SelectNodes("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]" +
            //    "/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div/div/div/div/table/tbody/tr")
            //                    .Where(s => s.InnerText.Contains("Shares Outstanding 5")).ToList();

            //foreach (var item in feve2)
            //{
            //    Console.WriteLine(item.InnerText.Split(new string[] { @" 5" }, StringSplitOptions.None).Last());

            //}

            ////var feve3 = doc2.GetElementbyId("Col1-0-KeyStatistics-Proxy").Descendants(1).Where(s => s.InnerText.Contains("Shares Outstanding"))
            ////.First();

            //Console.WriteLine(feve2[0].InnerText.Split(new string[] { @" 5" }, StringSplitOptions.None).Last());



        }

        public static void NewsAPI()
        {
            Rootobject i = new Rootobject();

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            var url = "http://newsapi.org/v2/everything?" +
         "q=Apple&" +
         "from=2019-02-18&" +
         "sortBy=Relevance&" +
         "apiKey=eee080d779c54a61947a34da649e372b";

            var json = new WebClient().DownloadString(url);


            var obj = serializer.Deserialize<Rootobject>(json);


            foreach (var item in obj.articles)
            {
                Console.WriteLine("\nAuthor - {0} Title - {1}\n{3}\n URL - {2}", item.author, item.title, item.url, item.publishedAt);


            }

            //Console.WriteLine(obj.articles[19].url);

            var cont = new WebClient().DownloadString("http://eoddata.com/stockquote/NYSE/B.htm");

            //Console.WriteLine(cont);


            Console.ReadLine();

        }
    }
}
