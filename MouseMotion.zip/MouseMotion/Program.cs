﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.Diagnostics;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;




namespace MouseShift
{




    internal static class Program
    {




        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());

            try
            {
                using (Mouser mouser = new Mouser())
                {

                    DateTime start = DateTime.Now;

                    //Console.WriteLine("Duration to run? (Minutes):  "); // or Console.Write("Type any number:  "); to enter number in the same line
                   
                    //Console.WriteLine("Continuous Ellipse? (Y or N):  "); // or Console.Write("Type any number:  "); to enter number in the same line

                    //int x = Int32.Parse(Console.ReadLine());


                    //DateTime end = DateTime.Now.AddMinutes(x);

                    //double radius = 10.0d;

                    ////get the center of the circle we want to draw
                    //int startX = mouser.Position.X - (int)radius;
                    //int startY = mouser.Position.Y;

                    double io = 0;

                    mouser.MoveMouseInCircle(20, 20, 35);

                    mouser.Dispose();



                }
            }
            catch(Exception)
            {
                Console.WriteLine("wo wo");

            }
            finally
            {

            }
            //Application.Run(new MainForm());


            //while (DateTime.Now <= end)
            //{
            //    //iterate from 0 to 2PI (360 degrees)
            //    for (double i = 0.0d; i < Math.PI * 2.0d; i += 0.1d)
            //    {
            //        //convert polar coordinates to cartesian
            //        //io = i * Math.PI / 180;

            //        int xi = startX + (int)(radius * Math.Sin(i));
            //        int yi = startY + (int)(radius * Math.Cos(i));

            //        //angle_theta = i * Math.PI / 180;
            //        //glVertex2f(x + 50 * cos(angle_theta),
            //        //           y + 50 * sin(angle_theta));

            //        Console.WriteLine($"xi-{xi} yi-{yi} i-{i}");

            //        //set the new mouse position
            //        mouser.MoveCursor(xi, yi);

            //        //sleep for a bit
            //        System.Threading.Thread.Sleep(10);


            //    }

            //}
            //while (DateTime.Now <= end)
            //{
            //    System.Threading.Thread.Sleep(50);
            //    mouser.MoveCursor(1);
            //}
            int jojo = 00;


        }
    }



    public class Mouser : IDisposable
    {
        public Point Location { get; set; }
        public Size Size { get; set; }
        public Cursor Cursor { get; set; }
        public Point Position { get; set; }
        public Graphics Graphics { get; set; }

        public double angle = 0;

        //To detect redundant calls
        private bool _disposdedValue;

        //Instantiate a safeHandle instance
        private SafeHandle _safeHandle = new SafeFileHandle(IntPtr.Zero, true);

        //Public implementation of Dispose pattern callable by consumers
        public void Dispose() => Dispose(true);


        //This is a replacement for Cursor.Position in WinForms
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool SetCursorPos(int x, int y);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        public const int MOUSEEVENTF_LEFTDOWN = 0x02;
        public const int MOUSEEVENTF_LEFTUP = 0x04;
        public const int MOUSEEVENTF_MOVE = 0x01;



        public Mouser()
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);

            //this.Position = new Point(Cursor.Position.X, Cursor.Position.Y);
        }


        //Protected implementation of Dispose pattern
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposdedValue)
            {
                if (disposing)
                {
                    _safeHandle.Dispose();
                }

                _disposdedValue = true;

            }



        }



        //This simulates a left mouse click
        public static void LeftMouseClick(int xpos, int ypos)
        {
            SetCursorPos(xpos, ypos);
            mouse_event(MOUSEEVENTF_LEFTDOWN, xpos, ypos, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, xpos, ypos, 0, 0);
        }



        /// <summary>
        /// Moves the cursor in a circular motion
        /// </summary>
        /// <param name="r">The radius of the circular motion</param>
        /// <param name="degInc"></param>
        /// <param name="speed">How fast the cursor moves in a circular motion</param>
        /// <param name="start">The angle to start from</param>
        public void MoveMouseInCircle(int r = 10, int degInc = 5, int speed = 0, string start = "top")
        {
            int widthW = Console.WindowWidth;
            
            int widthH = Console.WindowHeight;



            double radPerDeg = 3.14159265359 / 180;

            int startX = Cursor.Position.X;
            int startY = Cursor.Position.Y;

            //Console.WriteLine($"x-{Cursor.Position.X} y-{Cursor.Position.Y}");

            Console.WriteLine("Duration to run? (Minutes):  "); // or Console.Write("Type any number:  "); to enter number in the same line
            
            int x = Int32.Parse(Console.ReadLine());

            while (x == null)
            {
                continue;
            }

            Console.WriteLine("Continuous Circular motion? (Y or N):  "); // or Console.Write("Type any number:  "); to enter number in the same line
            
            string isContinuousEllipse = Console.ReadLine();



            DateTime end = DateTime.Now.AddMinutes(x);

            int pMin = 0;

            int breakPoint = 0;

            switch (start)
            {

                case "top":
                    angle = 0;

                    startY += r;
                    break;

                case "right":
                    angle = 90 * radPerDeg;

                    startX -= r;
                    break;

                case "bottom":
                    angle = 180 * radPerDeg;

                    startY -= r;
                    break;

                case "left":
                    angle = 270 * radPerDeg;

                    startX += r;
                    break;

            }


            while (DateTime.Now <= end)
            {
                //iterate from 0 to 2PI (360 degrees)
                //for (double i = 0.0d; i < Math.PI * 2.0d; i += 0.1d)
                //{
                //convert polar coordinates to cartesian
                //io = i * Math.PI / 180;


                if (Console.KeyAvailable && Console.ReadKey(true).Key == ConsoleKey.Escape)
                {
                    break;
                }


                PrintTime.Start();

                //convert polar coordinates to cartesian
                angle += degInc * radPerDeg;


                int xi = Position.X + (int)(r * Math.Sin(angle));
                int yi = Position.Y + (int)(r * Math.Cos(angle));

                //angle_theta = i * Math.PI / 180;
                //glVertex2f(x + 50 * cos(angle_theta),
                //           y + 50 * sin(angle_theta));

                //Console.WriteLine($"xi-{xi} yi-{yi} angle-{angle} degin -{degInc} radPer-{radPerDeg}");

                //Console.WriteLine($"key-{Console.KeyAvailable.ToString()}");

                if (isContinuousEllipse.ToLower() == "y")
                {
                    //set the new mouse position
                    this.MoveCursor(xi, yi);
                }


                //sleep for a bit
                System.Threading.Thread.Sleep(speed);

                if (DateTime.Now.Second == 52)
                {
                    //mouse_event(MOUSEEVENTF_LEFTDOWN, xi, yi, 0, 0);
                    ////System.Threading.Thread.Sleep(1);
                    //mouse_event(MOUSEEVENTF_LEFTUP, xi, yi, 0, 0);
                    mouse_event(MOUSEEVENTF_MOVE, xi, yi, 0, 0);
                    breakPoint--;

                }

                //Console.WriteLine($"Seconds-{DateTime.Now.Second}");


                PrintTime.Stop();



                //}

            }

        }

        //        loop, % 360 / degInc

        //{
        //            angle += degInc * radPerDeg

        //    MouseMove, cx + r * Sin(angle), cy - r * Cos(angle)

        //    Sleep, speed

        //}


        public void MoveCursor(int x, int y)
        {
            // Set the Current cursor, move the cursor's Position,
            // and set its clipping rectangle to the form. 

            //this.Cursor = new Cursor(Cursor.Current.Handle);

            //PaintEventArgs paintEventArgs = new PaintEventArgs();

            //Console.WriteLine($"Px-{Cursor.Position.X} Py-{Cursor.Position.Y}");

            Cursor.Position = new Point(Cursor.Position.X + x, Cursor.Position.Y + y);

            //Console.WriteLine($"Px2-{Cursor.Position.X} Py2-{Cursor.Position.Y}");

            Cursor.Clip = new Rectangle(this.Location, this.Size);

        }




    }


    public static class PrintTime
    {

        public static Stopwatch StopWatch { get; set; }

        static PrintTime()
        {
            StopWatch = new Stopwatch();

        }

        public static void Start()
        {

            PrintTime.StopWatch.Start();
        }
        public static void Stop()
        {

            StopWatch.Stop();
            // Get the elapsed time as a TimeSpan value.
            TimeSpan ts = StopWatch.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);

            //Console.WriteLine($"Completed | RunTime - {elapsedTime} CurrentTime - {DateTime.Now}");

        }


    }

    public class MainForm : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components;
        private ArrayList myPts = new ArrayList();

        public MainForm()
        {
            InitializeComponent();
            CenterToScreen();
            this.Text = "click on me";
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Text = "Form1";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);

        }
        //static void Main()
        //{
        //    Application.Run(new MainForm());
        //}

        private void MainForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Graphics g = Graphics.FromHwnd(this.Handle);

            // Add to points collection.
            myPts.Add(new Point(e.X, e.Y));
            Invalidate();
        }

        private void MainForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            foreach (Point p in myPts)
                g.DrawEllipse(new Pen(Color.Green), p.X, p.Y, 10, 10);
        }
    }
}



//#Persistent

//SetTimer, MoveMouse, 3000
//SetTimer, SendText, 300000
//return

//MoveMouse:
//	MoveMouseInCircle(200, 15)
//return

//SendText:
//	SendInput, / play skyblock
//{ Enter}
//Sleep, 10000

//    SendInput, / WARP island; no Enter?
//	; don 't see what waiting another 10 seconds here is supposed to accomplish. what follows it?
//return





