SELECT *
FROM MCOREDB.refcode.MFGCompanyCode

SELECT *
FROM MCOREDB.refcode.AgreementType


SELECT dtArchive, COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_ISSUER
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive


SELECT *
FROM mcoredb_archive.refdata.MCO_BB_ISSUER
WHERE DTARCHIVE = '20190322'

SELECT dtArchive ,COUNT(*)

--DELETE
FROM mcoredb_archive.refdata.MCO_BB_PS_EQUITY
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive
ORDER BY dtArchive

SELECT dtArchive--,dtTimestamp
,COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_BULK_EQUITY
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive--, dtTimestamp
ORDER BY dtArchive

SELECT dtArchive--,dtTimestamp
,COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_EQUITY
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive--, dtTimestamp
ORDER BY dtArchive



SELECT dtArchive--,sSourceFile
,COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_PS_FIXED_INCOME
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive--, sSourceFile

SELECT dtArchive, COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_PS_MORTGAGE
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive

SELECT dtArchive, COUNT(*)
FROM mcoredb_archive.stage.MFI_ADP_TRANSACTION
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive

SELECT dtArchive, COUNT(*)
FROM mcoredb_archive.refdata.MFI_ADP_INSTRUMENT
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive

SELECT dtArchive, COUNT(*)
FROM mcoredb_archive.STAGE.MFD_BB_CHEAPEST
where dtArchive >= '20190311'-- IN ( '20190321' ,'20190322')
group by dtArchive


select *
FROM mcoredb_archive.STAGE.MFD_BB_CHEAPEST
where dtarchive = '20190322'

select *
from mcoredb_archive.STAGE.MFD_BB_CHEAPEST
where dtarchive = '20190321'



SELECT dtArchive, sSourceFile,COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_PS_PX
where dtArchive IN ( '20190321' ,'20190322')
group by dtArchive, sSourceFile

SELECT *
FROM mcoredb_archive.refdata.MCO_BB_PS_PX
WHERE dtArchive = '20190322'

SELECT sSourceFile,COUNT(*)
FROM mcoredb_archive.refdata.MCO_BB_PS_MORTGAGE
WHERE dtArchive = '20190322'
GROUP BY sSourceFile


select ID_BB_COMPANY,dtArchive, *--,count(*)
from mcoredb_archive.refdata.MCO_BB_ISSUER
where dtArchive IN ( '20190321' ,'20190322')
group by ID_BB_COMPANY,dtArchive
order by ID_BB_COMPANY