use mcoredb
DECLARE @T1 TABLE ([EM TABLE NAME] VARCHAR(50), [ROWS AFFECTED] INT)
--declare @dt datetime = '2019-01-18 07:20:11.570'
declare @jobdt date = '20190320'


declare @ignoreuser bit = 0
declare @user AS NVARCHAR(100) = '%'
declare @ds int = (	SELECT	DataSourceID
					FROM	mcoredb..DataSource		d
					JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
					WHERE	sSourceName				= 'Murex'
					AND		sEntityCode				= 'MCM')

DECLARE @t TABLE (DATA VARCHAR(20), [MCDB (Count)] NUMERIC(24,8), [MUREX (Count)] NUMERIC(24,8))

---OIS_PV
----------------------------------------------------------
INSERT @t 
select 'PVs (OIS)',(select sum(dPresentValueT0)				--numeric(18,6)
from (
	SELECT
		trn.dPresentValueT0	--,xTrn.sRef,DATS.sSourceName
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
	where	xtrn.DataSourceID	= @ds
	and		trn.dtProcess		= @jobdt						)q) ,
	(select sum(ISNULL(M_CASH_NONF, 0)+ ISNULL(M_MV_NONFIN, 0)+ ISNULL(M_PV_EFFECT, 0))				--numeric(19,2)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_TRADE_REP 
where dtArchive	= @jobdt 
and M_H_DATA_LB = 'EOD'
and M_H_NB_MZ	in (SELECT	xtrn.sRef
					FROM	mcoredb..OTCTransactionDaily	trn
					LEFT JOIN mcoredb..XRefOTCTransaction	xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
					where	xtrn.DataSourceID	= @ds
					and		trn.dtProcess		= @jobdt))

---------------------------------------------------------
---CSA_PV
----------------------------------------------------------
INSERT @t 
select 'PVs (CSA)',(select sum(dPresentValueT0CSA)				--numeric(18,6)
from (
	SELECT
		trn.dPresentValueT0CSA		--,xTrn.sRef,DATS.sSourceName
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
	where	xtrn.DataSourceID	= @ds
	and		trn.dtProcess		= @jobdt						)q) ,
	(select sum(ISNULL(M_CASH_NONF, 0)+ ISNULL(M_MV_NONFIN, 0)+ ISNULL(M_PV_EFFECT, 0))				--numeric(19,2)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_TRADE_REP 
where dtArchive	= @jobdt 
and M_H_DATA_LB = 'EOD_CSA'
and M_H_NB_MZ	in (SELECT	xtrn.sRef
					FROM	mcoredb..OTCTransactionDaily	trn
					LEFT JOIN mcoredb..XRefOTCTransaction	xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
					where	xtrn.DataSourceID	= @ds
					and		trn.dtProcess		= @jobdt))

---------------------------------------------------------


--DECLARE @dt5 datetime = '20180718'
INSERT @t 
select 'Notionals',(select sum(dNotional)			 		--numeric(29,8)
from (
	SELECT		--trn.dPresentValueT0,xtrn.sRef
		trn.dNotional
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
       JOIN mcoredb..OTCTransaction                                OTC   on            trn.TransactionID                 = OTC.TransactionID
       where  xtrn.DataSourceID    = @ds
       and (OTC.sDescription not in ('COLVA','TOTXVA') or OTC.sDescription  is NULL)

	and		trn.dtProcess		= @jobdt						)q),
	(select sum(Notional)					--numeric(19,2)/numeric(24,8)
from (
	select	case when M_CNT_TYPO = 'Total Return Swap BD' then M_TP_NOMINAL else M_TP_AVQTY2 end		Notional
	from	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP 
	where	dtArchive	= @jobdt
	and		M_H_NB_MZ	in (SELECT		xtrn.sRef
							FROM		mcoredb..OTCTransactionDaily	trn
							LEFT JOIN	mcoredb..XRefOTCTransaction		xtrn	on	trn.TransactionID		= xtrn.TransactionID
																				and	xtrn.XRefOTCTradeTypeID	= 1
							where		xtrn.DataSourceID    = @ds
							and			trn.dtProcess        = @jobdt))q)

-------------------------------------------------------------------
INSERT @t 
SELECT  'Trades', (select count(*)
FROM [mcoredb].[dbo].[OTCTransactionDaily] Trn
Join [mcoredb].[dbo].[XRefOTCTransaction] xTrn on Trn.TransactionID = xTrn.TransactionID and xTrn.XRefOTCTradeTypeID = 1
JOIN mcoredb..OTCTransaction OTC   on            trn.TransactionID                 = OTC.TransactionID
JOIN DataSource DATS ON DATS.DataSourceID = tRN.DataSourceID
LEFT JOIN LookupCodes LKP on LKP.CodeID = TRN.TradeStatusID
where xTrn.DataSourceID =@ds
and (LKP.sCodeValue <> 'PURGED' or LKP.sCodeValue is null)
and (OTC.sDescription not in ('COLVA','TOTXVA') or OTC.sDescription  is NULL)
and  Trn.dtProcess = @jobdt),
(SELECT count(*) 
FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP WHERE dtarchive = @jobdt and M_TP_PFOLIO not in ('PGA', 'STB_DRAFT','LBC_DRAFT')
and (
(M_TRN_FMLY = 'IRD' and M_TRN_GRP  not in ('BOND','LFUT','OPT','SFUT','SWFUT','REPO'))
or 
M_CNT_TYPO = 'Treasury Lock'
or
(M_TRN_FMLY = 'CURR' and M_TRN_GRP  not in ('FUT')) 
or (M_TRN_FMLY in ('SCF','CRD')))  )
---------------------------------------------------------------------


SELECT DATA,
	[MCDB (Count)],
	[MUREX (Count)],
	CASE	WHEN [MUREX (Count)] = [MCDB (Count)] THEN 'PASSED'
			WHEN [MUREX (Count)] != [MCDB (Count)] THEN 'FAILED'
	END AS STATUS
FROM @t


---MUREX
SELECT M_TP_PFOLIO,*
FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP WHERE dtarchive = @jobdt and M_TP_PFOLIO not in ('PGA', 'STB_DRAFT','LBC_DRAFT')
and (
(M_TRN_FMLY = 'IRD' and M_TRN_GRP  not in ('BOND','LFUT','OPT','SFUT','SWFUT','REPO'))
or 
M_CNT_TYPO = 'Treasury Lock'
or
(M_TRN_FMLY = 'CURR' and M_TRN_GRP  not in ('FUT')) 
or (M_TRN_FMLY in ('SCF','CRD')))  and M_H_NB_MZ not in 


---MCDB
(select xtrn.sRef
FROM [mcoredb].[dbo].[OTCTransactionDaily] Trn
Join [mcoredb].[dbo].[XRefOTCTransaction] xTrn on Trn.TransactionID = xTrn.TransactionID and xTrn.XRefOTCTradeTypeID = 1
JOIN mcoredb..OTCTransaction OTC   on            trn.TransactionID                 = OTC.TransactionID
JOIN DataSource DATS ON DATS.DataSourceID = tRN.DataSourceID
LEFT JOIN LookupCodes LKP on LKP.CodeID = TRN.TradeStatusID
where xTrn.DataSourceID =@ds
and (LKP.sCodeValue <> 'PURGED' or LKP.sCodeValue is null)
and (OTC.sDescription not in ('COLVA','TOTXVA') or OTC.sDescription  is NULL)
and  Trn.dtProcess = @jobdt)


--select *
--from mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP
--where dtArchive = '20190306' and M_TRN_FMLY like '%ird%'