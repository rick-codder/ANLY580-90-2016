"SET NOCOUNT ON;

DECLARE @rowsAffected AS INT;
DECLARE @recordCount AS INT;
DECLARE @dayOfWeek AS INT;

SET @rowsAffected = 1;
SET @recordCount = (SELECT COUNT(*) FROM stage.MDR_MUREX_DM_TRN_TRADE_REP   WHERE dtArchive ='" +  (DT_STR,12,1252)@[User::dtReporting] + "');
SET @dayOfWeek = (SELECT DATEPART(DW,GETDATE()));

 IF @recordCount > 0
	BEGIN
		WHILE @rowsAffected > 0
		BEGIN
		
			BEGIN TRANSACTION;
		
		DELETE TOP (10000) FROM stage.MDR_MUREX_DM_TRN_TRADE_REP
		WHERE dtArchive = '" + (DT_STR,12,1252)@[User::dtReporting] +"'
		
		 SET @rowsAffected = @@ROWCOUNT;
		
			COMMIT TRANSACTION;
			--PRINT 'Restartability DELETE'
		END

	END;

SET @rowsAffected = 1;
	--PRINT CONVERT(varchar(1100),@rowsAffected) + '...HERE'

 IF @dayOfWeek = 7 OR @dayOfWeek = 1
	BEGIN
		WHILE @rowsAffected > 0
		BEGIN
		
			BEGIN TRANSACTION;
		
		DELETE TOP (10000) FROM stage.MDR_MUREX_DM_TRN_TRADE_REP
		WHERE dtArchive < GETDATE() - " + (DT_STR,4,1252)@[User::iRetention] + "
		
		 SET @rowsAffected = @@ROWCOUNT;
		
			COMMIT TRANSACTION;
			--PRINT 'Retention DELETE'
		END

	END;"