

SELECT xtp.DataSourceID,T.ParentTransactionID,TP.ParentTransactionID--,XTP.TransactionID--,*--COUNT(*)
FROM	mcoredb..OTCTransaction									t (READUNCOMMITTED)
JOIN	mcoredb..XRefOTCTransaction								xt	ON	xt.TransactionID		= t.TransactionID
																	--AND	xt.XRefOTCTradeTypeID	= 1
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		m	ON	m.M_H_NB_MZ				= xt.sRef
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s	ON	s.M_NB					= m.M_NB
JOIN	mcoredb..XRefOTCTransaction								xtp	WITH(INDEX(IX_XRefOTCTransaction_sRef)) 
																	ON	xtp.sRef				= CASE
																									WHEN m.M_TP_INT = 'N'
																									THEN CONVERT(VARCHAR, s.M_CREATOR)
																									WHEN m.M_TP_INT = 'Y'
																									THEN CASE m.M_TP_BUY
																											WHEN 'B' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_1'
																											WHEN 'S' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_2'
																											END
																									END
																								--AND xtp.XRefOTCTradeTypeID		= 1
JOIN	mcoredb..OTCTransaction									tp	
																	WITH(INDEX(IX_OTCTransaction_DataSourceId)) 
																	ON	tp.TransactionID		= xtp.TransactionID
JOIN	mcoredb..DataSource										mds	ON	mds.DataSourceID		= xt.DataSourceID
																	AND	mds.sSourceName			= 'Murex'
WHERE	xt.DataSourceID			= t.DataSourceID
AND		tp.DataSourceID			= t.DataSourceID
--AND		CONVERT(varchar(18),xtp.DataSourceID)		= CONVERT(varchar(18),t.DataSourceID)
AND		CONVERT(numeric(18,0),xtp.DataSourceID)		= CONVERT(numeric(18,0),t.DataSourceID)
--AND		xtp.DataSourceID		= t.DataSourceID
AND		m.dtArchive				= '20190208'
AND		s.dtArchive				= '20190208' --OPTION (RECOMPILE)
--ORDER BY LG DESC



SELECT xtp.DataSourceID,
T.ParentTransactionID,TP.ParentTransactionID,XTP.TransactionID--,*--COUNT(*)
FROM	mcoredb..OTCTransaction									t
JOIN	#XrefOTC							xt	ON	xt.TransactionID		= t.TransactionID
																	--AND	xt.XRefOTCTradeTypeID	= 1
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		m	ON	m.M_H_NB_MZ				= xt.sRef
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s	ON	s.M_NB					= m.M_NB
JOIN	#XrefOTC												xtp	ON	xtp.sRef				= CASE
																									WHEN m.M_TP_INT = 'N'
																									THEN CONVERT(VARCHAR, s.M_CREATOR)
																									WHEN m.M_TP_INT = 'Y'
																									THEN CASE m.M_TP_BUY
																											WHEN 'B' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_1'
																											WHEN 'S' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_2'
																											END
																									END
																								--AND xtp.XRefOTCTradeTypeID		= 1
JOIN	mcoredb..OTCTransaction										tp	ON	tp.TransactionID		= xtp.TransactionID
JOIN	mcoredb..DataSource										mds	ON	mds.DataSourceID		= xt.DataSourceID
																	AND	mds.sSourceName			= 'Murex'
WHERE	xt.DataSourceID			= t.DataSourceID
AND		tp.DataSourceID			= t.DataSourceID
--AND		CONVERT(varchar(18),xtp.DataSourceID)		= CONVERT(varchar(18),t.DataSourceID)
AND		CONVERT(numeric(18,0),xtp.DataSourceID)		= CONVERT(numeric(18,0),t.DataSourceID)
--AND		xtp.DataSourceID		= t.DataSourceID
AND		m.dtArchive				= '20190212'
AND		s.dtArchive				= '20190212' --OPTION (RECOMPILE)
--ORDER BY LG DESC

--CREATE TABLE #XrefOTC
--(


--SELECT * INTO #XrefOTC
--FROM XRefOTCTransaction
--WHERE XRefOTCTradeTypeID = 1

--SELECT *
--FROM INFORMATION_SCHEMA.COLUMNS
--WHERE COLUMN_NAME LIKE '%TRADETY%'

--SELECT *
--FROM #XrefOTC