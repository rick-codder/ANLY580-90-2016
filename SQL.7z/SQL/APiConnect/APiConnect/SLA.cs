﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;


namespace APiConnect
{
    public partial class Program
    {
        static String SLA;

        static feed SLAobj;

        static string pLoad_STD = "<?xml version='1.0' encoding='UTF-8'?>" +
"<entry xmlns='http://purl.org/atom/ns#'>" +
    "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
        "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" + "<queryCondition>adhoc='N' AND " +
"(parentname = 'Standardize Murex Collaterals' OR parentname = 'Standardize Murex Ref Data' OR parentname = 'Standardize Murex Transactions and Legs' OR parentname = 'Standardize Murex Schedules' OR  parentname = 'Standardize Murex Risk' OR (parentname = 'Standardize Murex trades to MCDB' AND childrencount=0)) "
             + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
        "<orderBy></orderBy>" +
        "<firstRow></firstRow>" +
        "<numRows></numRows>" +
        "<changedOnly></changedOnly>" +
        "<expandAll></expandAll>" +
        "<nodeList></nodeList>" +
        "<queryDate></queryDate>" +
    "</tes:JobRun.getList>" +
"</entry>";

        static string pLoad_STG = "<?xml version='1.0' encoding='UTF-8'?>" +
"<entry xmlns='http://purl.org/atom/ns#'>" +
"<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
    "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" + "<queryCondition>adhoc='N' AND " +
"(parentname = 'Stage Murex Collateral' OR jobname = 'Stage Murex Ref Data' OR parentname = 'Stage Murex Transactions' OR parentname = 'Stage Murex Schedules' OR  parentname = 'Stage Murex Risk' OR  jobname = 'Stage Murex Market Data' OR  jobname = 'Stage Murex PnL') "
         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
    "<orderBy></orderBy>" +
    "<firstRow></firstRow>" +
    "<numRows></numRows>" +
    "<changedOnly></changedOnly>" +
    "<expandAll></expandAll>" +
    "<nodeList></nodeList>" +
    "<queryDate></queryDate>" +
"</tes:JobRun.getList>" +
"</entry>";


        static string SLA_STD = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SLA_STANDARDIZED.xml";

        static string SLA_STG = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SLA_STAGING.xml";

        static DictionaryEXT<string, List<string>> collateralData = new DictionaryEXT<string, List<string>>();


        public static async void SLAProcessing()
        {
            try
            {
                DateTime startTime = System.DateTime.Now;

                Console.WriteLine("Now posting and retrieving xml response....\n");

                string cl_std = await TidalPostURL<string>(pLoad_STD, SLA_STD);

                string cl_stg = await TidalPostURL<string>(pLoad_STG, SLA_STG);

                Console.WriteLine(cl_std);

                Console.WriteLine(cl_stg);

                Console.WriteLine("Now deserializing....\n");
                Deserialize_SLA(SLA_STD);

                Deserialize_SLA(SLA_STG);


                DateTime EndTime = DateTime.Now;
                int rem = 0;
                double RunTime = (EndTime - startTime).TotalSeconds <= 60 ? (EndTime - startTime).TotalSeconds : Math.DivRem((int)(EndTime - startTime).TotalSeconds, 60, out rem);



                tTimer.Stop();

                if ((EndTime - startTime).TotalSeconds <= 60)
                {
                    Console.WriteLine("Done!.... in {0}secs", RunTime);
                }
                else
                {
                    Console.WriteLine("Done!.... in {0}mins {1}secs", RunTime, rem);
                }
            }
            finally
            {

            }

        }


        public static void Deserialize_SLA(string filePath)
        {

            Console.WriteLine("Reading serialized file now...");



            //BinaryFormatter bf = new BinaryFormatter();
            //byte[] b = System.Text.Encoding.UTF8.GetBytes(UrlPayload_STD);
            //MemoryStream ms = new MemoryStream(b);

            //instanc of the xmlserializer specifying type and namespace
            XmlSerializer serializer = new XmlSerializer(typeof(feed));


            //fielstream is needed to read the XML document
            FileStream fs = new FileStream(filePath, FileMode.Open);

            StreamReader sr = new StreamReader(fs);

            //Console.WriteLine(sr.ReadToEnd());




            XmlReader reader = XmlReader.Create(fs);

            //object variable of the type to be deserialized
            feed SLAobj;





            SLAobj = (feed)serializer.Deserialize(reader);


            fs.Close();


            DateTime[] dtList = new DateTime[12];
            int i = 0;
            int duration = 0;
            foreach (var item in SLAobj.entry.OrderBy((m) => m.jobrun.jobname))
            {

                Console.WriteLine("i is... {0}", i.ToString());
                duration += item.jobrun.duration;

                dtList[i] = item.jobrun.starttime;
                i++;
                dtList[i] = item.jobrun.endtime;
                i++;

                Console.WriteLine(
                "id - " + item.id + "...alias - " + item.jobrun.alias + ".....start time - " + item.jobrun.starttime + ".....end time - " + item.jobrun.endtime + ".....jobname - " + item.jobrun.jobname + "... DURATION - " + item.jobrun.duration + "... SLA - " + item.jobrun.expectedSLA + "... breach - " + item.jobrun.Breach
                //i.Description
                );

                SLA += "id - " + item.id + "...alias - " + item.jobrun.alias + ".....start time - " + item.jobrun.starttime + ".....end time - " + item.jobrun.endtime + ".....jobname - " + item.jobrun.jobname + "... DURATION - " + item.jobrun.duration + "... SLA - " + item.jobrun.expectedSLA + "... breach - " + item.jobrun.Breach + "\n";
            }


            File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SLAProcessing.csv", SLA);


        }

    }
}
