﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;

using System.Security.Cryptography.X509Certificates;

namespace APiConnect
{
    public partial class Program
    {
        static string environment = "prod";

        static string Pdate = "04/09";

        static string PdtParameter = "2019" + Pdate.Replace("/", "");

        static string PjobDateTidal = PdtParameter + "000000";

        static string PjobDate = PjobDateTidal.Substring(0, 4) + "/" + PjobDateTidal.Substring(4, 2) + "/" + PjobDateTidal.Substring(6, 2);

        static X509Certificate certDL;
        static Uri urlo;
        static NetworkCredential nc = new NetworkCredential("usi\\olayemiadejumo", "Junior12==00000");

        static string Pdatabase;

        static string PUrlPayload_STG;

        static string PUrlPayload_STD;

        static string databaseCollateral;

        static System.Timers.Timer tTimer;

        static Excel.Application MxlApp;

        static Excel.Workbook MxlWbk;

        static void Main(string[] args)
        {
            try
            {
                StartExcel();


                DateTime startTime = System.DateTime.Now;
                SetEnvironment(environment);

                SetTimer();


                
                //SQLToFile();

                //STDtest();

                //MUREXToMCDB.GetMailDetails("RE: Technical Recs", "technical");

                //System.Threading.Thread.Sleep(TimeSpan.FromMinutes(20.25));

                //MUREXToMCDB.RunAsync();

                SLAMain();


                //StartExcel();

                //SLAData();

                //SqlToExcelSLA();

                //CloseExcel();


                ////MxlApp.
                ////SLAProcessing();


                ////CopyPreviousDay();


                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {

                    p.Kill();

                }

                tTimer.Stop();

                //CloseExcel();


                Console.ReadLine();


            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException.Message);

            }
            finally
            {
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
                foreach (System.Diagnostics.Process p in process)
                {
                    try
                    {
                        p.Kill();

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"The finally error is {e.Message}");
                    }


                }

            }
        }


        public static void StartExcel()
        {

            MxlApp = new Excel.Application();

            //MxlWbk = MxlApp.Workbooks.Open(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\masterSheetFinalprd.xlsx");
        }

        public static void CloseExcel()
        {

            MxlWbk.Save();

            MxlWbk.Close();

            MxlApp.Quit();

            MxlApp.Quit();


        }

        public static void SetTimer()
        {
            tTimer = new System.Timers.Timer(1000);

            tTimer.Elapsed += TTimer_Elapsed;
            tTimer.AutoReset = true;
            tTimer.Enabled = true;

        }

        private static void TTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            Console.WriteLine("..{0}", e.SignalTime.ToLongTimeString().Replace("PM", ""));

        }


        public static void SetEnvironment(string environment)
        {

            switch (environment.ToLower())
            {
                case "sit":
                    urlo = new Uri("http://tesdevweb:8080/api/tes-6.2/post");
                    Pdatabase = "mcodsqmcdb";
                    databaseCollateral = "MCODSQMCDV.nyc.mizuhocap.com";
                    break;
                case "dev":
                    urlo = new Uri("http://tesdevweb:8080/api/tes-6.2/post");
                    Pdatabase = "mcodsqmcdb";
                    databaseCollateral = "MCODSQMCDV.nyc.mizuhocap.com";
                    break;
                case "uat":
                    urlo = new Uri("http://tidaluatweb:8080/api/tes-6.2/post");
                    Pdatabase = "mcousqmcdb";
                    databaseCollateral = "MCOUSQMCDV.nyc.mizuhocap.com";
                    MxlWbk = MxlApp.Workbooks.Open(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\masterSheetFinal.xlsx");
                    PUrlPayload_STG = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<entry xmlns='http://purl.org/atom/ns#'>" +
            "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
                "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" +
                            "<queryCondition>adhoc='N' AND " +
        "(parentname = 'Stage Murex Collateral' OR parentname = 'Stage Murex Market Data' OR parentname = 'Stage Murex Ref Data' OR parentname = 'Stage Murex Risk' OR parentname = 'Stage Murex Transactions' OR parentname = 'Stage Murex Market PnL') "
                         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
                "<orderBy></orderBy>" +
                "<firstRow></firstRow>" +
                "<numRows></numRows>" +
                "<changedOnly></changedOnly>" +
                "<expandAll></expandAll>" +
                "<nodeList></nodeList>" +
                "<queryDate></queryDate>" +
            "</tes:JobRun.getList>" +
        "</entry>";

                    PUrlPayload_STD = "<?xml version='1.0' encoding='UTF-8'?>" +
                    "<entry xmlns='http://purl.org/atom/ns#'>" +
                        "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
                            "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" +
                            "<queryCondition>adhoc='N' AND " +
        "(parentname = 'Standardize Murex Collaterals' OR parentname = 'Standardize Murex Ref Data' OR parentname = 'Standardize Murex Transactions and Legs' OR parentname = 'Standardize Murex Schedules' OR parentname = 'Standardize Murex Transactions - Risk'"
                         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
                            "<orderBy></orderBy>" +
                            "<firstRow></firstRow>" +
                            "<numRows></numRows>" +
                            "<changedOnly></changedOnly>" +
                            "<expandAll></expandAll>" +
                            "<nodeList></nodeList>" +
                            "<queryDate></queryDate>" +
                        "</tes:JobRun.getList>" +
                    "</entry>";
                    break;
                case "ci":
                    urlo = new Uri("http://tidaluatweb:8080/api/tes-6.2/post");
                    Pdatabase = "mcousqmcdb2";
                    databaseCollateral = "MCOUSQMCDV.nyc.mizuhocap.com";
                    break;
                case "prod":
                    urlo = new Uri("http://tidalprdweb:8080/api/tes-6.2/post");
                    Pdatabase = "mcopsqmcdb";
                    databaseCollateral = "MCOPSQMCDV.nyc.mizuhocap.com";
                    MxlWbk = MxlApp.Workbooks.Open(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\masterSheetFinalprd.xlsx");
                    PUrlPayload_STG = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<entry xmlns='http://purl.org/atom/ns#'>" +
            "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
                "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" +
                            "<queryCondition>adhoc='N' AND " +
        "(parentname = 'Stage Murex Collateral' OR parentname = 'Stage Murex Market Data' OR parentname = 'Stage Murex Ref Data' OR parentname = 'Stage Murex Risk' OR parentname = 'Stage Murex Transactions' OR parentname = 'Stage Murex Market PnL') "
                         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
                "<orderBy></orderBy>" +
                "<firstRow></firstRow>" +
                "<numRows></numRows>" +
                "<changedOnly></changedOnly>" +
                "<expandAll></expandAll>" +
                "<nodeList></nodeList>" +
                "<queryDate></queryDate>" +
            "</tes:JobRun.getList>" +
        "</entry>";

                    PUrlPayload_STD = "<?xml version='1.0' encoding='UTF-8'?>" +
                    "<entry xmlns='http://purl.org/atom/ns#'>" +
                        "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
                            "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" +
                            "<queryCondition>adhoc='N' AND " +
        "(parentname = 'Standardize Murex Collaterals' OR parentname = 'Standardize Murex Ref Data' OR parentname = 'Standardize Murex Transactions and Legs' OR parentname = 'Standardize Murex Schedules' OR parentname = 'Standardize Murex Risk' OR (parentname = 'Standardize Murex trades to MCDB' AND childrencount=0)) "
                         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
                            "<orderBy></orderBy>" +
                            "<firstRow></firstRow>" +
                            "<numRows></numRows>" +
                            "<changedOnly></changedOnly>" +
                            "<expandAll></expandAll>" +
                            "<nodeList></nodeList>" +
                            "<queryDate></queryDate>" +
                        "</tes:JobRun.getList>" +
                    "</entry>";
                    break;
            }

        }
    }
}