CREATE TABLE TX_IDs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	Action			NVARCHAR(10)
	,TransactionID	NUMERIC(18,0) NOT NULL	--will put PK here in a few steps
	,M_H_NB_MZ		CHAR(12)
	,M_NB_EXT		NUMERIC(18,0)	--M_H_ALT_ID	CHAR(20)
	,M_USI_ID		CHAR(52)
	,M_USI_NS		CHAR(10)
	,M_BETA_ID		CHAR(10)
	,M_CCP_TRN_ID	CHAR(14)
	,M_TRN_FMLY		CHAR(5)
	,M_CNT_ORG		NUMERIC(10,0)
	,bLive			BIT
)

select *
from TX_IDs