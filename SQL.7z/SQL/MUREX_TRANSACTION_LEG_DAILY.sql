USE [mcoredb]
GO
/****** Object:  StoredProcedure [stage].[spMDR_MUREX_TRANSACTION_LEG_DAILY]    Script Date: 3/21/2019 6:56:08 PM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--ALTER PROC [stage].[spMDR_MUREX_TRANSACTION_LEG_DAILY]
--	@dt					DATE
--	,@Leg0DailyInsertCount	INT OUT
--	,@Leg0DailyUpdateCount	INT OUT
--	,@Leg1DailyInsertCount	INT OUT
--	,@Leg1DailyUpdateCount	INT OUT
/*TO EXECUTE:
	DECLARE @dt						DATE = '20181114'
	DECLARE @Leg0DailyInsertCount	INT
	DECLARE @Leg0DailyUpdateCount	INT
	DECLARE @Leg1DailyInsertCount	INT
	DECLARE @Leg1DailyUpdateCount	INT
	EXEC stage.spMDR_MUREX_TRANSACTION_LEG_DAILY					@dt, @Leg0DailyInsertCount OUT, @Leg0DailyUpdateCount OUT, @Leg1DailyInsertCount OUT, @Leg1DailyUpdateCount OUT 
	PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 0 INSERT count: '	+ CONVERT(VARCHAR, @Leg0DailyInsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 0 UPDATE count: '	+ CONVERT(VARCHAR, @Leg0DailyUpdateCount)
	PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 1 INSERT count: '	+ CONVERT(VARCHAR, @Leg1DailyInsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 1 UPDATE count: '	+ CONVERT(VARCHAR, @Leg1DailyUpdateCount)
*/
--AS
/*************************************************************************************************************
    Name               :     spMDR_MUREX_TRANSACTION_LEG_DAILY
    Author             :     Dave Marks
    Date		       :     03/05/2019
    Description        :     Process status, notional and present value for Murex trades day over day into dbo.IRDTransactionLegDaily
	References         :     databases: mcoredb, mcoredb_archive
    Parameters         :     @dt, @Leg0InsertCount OUT, @Leg0UpdateCount OUT, @Leg1InsertCount OUT, @Leg1UpdateCount OUT

    Date               	Developer               	Modified
--------------------------------------------------------------------------------------------------------------
	3/18/2019			Dave Marks					Removed references to mcoredb to allow reference validation
	3/19/2019			Dave Marks					Updated dNotional per Thiru
*************************************************************************************************************/

DECLARE @dt					DATE = '20190329'
DECLARE @Leg0DailyInsertCount	INT
DECLARE @Leg0DailyUpdateCount	INT
DECLARE @Leg1DailyInsertCount	INT
DECLARE @Leg1DailyUpdateCount	INT
DECLARE @start						DATETIME		= GETDATE()
DECLARE @debug						BIT				= 1
DECLARE @MSG						VARCHAR(1000)
DECLARE @OUTPUT						VARCHAR(MAX)	= ''

DECLARE @TRDREFTYPE_PRIMARY_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
														FROM	refcode.OTCXRefTradeRefType
														WHERE	sName					= 'Primary ID')
DECLARE @IRD_DAILY_PV_EVTTYPE_ID	NUMERIC(18,0)	= (	SELECT	CodeID
														FROM	dbo.LookupCodes
														WHERE	sCategory				= 'IRD Event Type'
														AND		sCodeValue				= 'IRD Daily PV')
SET NOCOUNT ON
IF OBJECT_ID('tempdb..#LEGID') IS NOT NULL
	DROP TABLE #LEGID
CREATE TABLE #LEGID	(	--SELECT * FROM #LEGID
	TransactionID		NUMERIC(18,0)		PRIMARY KEY
	,Leg0ID	NUMERIC(18,0)
	,Leg1ID	NUMERIC(18,0)
)
INSERT		#LEGID	--select * from #LEGID --order by 
SELECT		TransactionID
			,MIN(TransactionLegID) Leg0ID
			,MAX(TransactionLegID) Leg1ID
FROM		dbo.IRDTransactionLeg
GROUP BY	TransactionID
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #LEGID.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--REPLACE JOINS TO ALL DM TABLES W/TEMP TABLES	&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
IF OBJECT_ID('tempdb..#sch') IS NOT NULL
	DROP TABLE #sch
SELECT * INTO #sch FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
WHERE dtArchive = @dt
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #sch.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#t') IS NOT NULL
	DROP TABLE #t
SELECT * INTO #t FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP
WHERE dtArchive = @dt

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #t.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--------------------------------------------------------------------------------------------
--CLUSTERED INDEX FOR IMPROVED READS
--------------------------------------------------------------------------------------------
CREATE CLUSTERED INDEX [IX_M_H_NB_MZ_TRADE] ON #T(M_H_NB_MZ)
CREATE INDEX [IX_M_TRN_GRP] ON #T(M_TRN_GRP)

--CREATE NONCLUSTERED INDEX [IX_TRADE] ON #T ([M_TRN_GRP])
--INCLUDE ([M_H_NB_MZ],[M_TP_QTYEQ],[M_TP_STATUS2],[M_H_DATA_DT2],[M_TP_AVQTY2],[M_TP_NOMINAL],[M_TP_RTINPC1],[M_TP_NOMCUR],[M_CNT_TYPO])
--WHERE M_TRN_GRP IN ('IRS','ASWP','CS','OSWP','RTRN','SWFUT', 'FRA')
--GO

IF OBJECT_ID('TEMPDB..#OTCDAILY') IS NOT NULL
DROP TABLE #OTCDAILY

SELECT * INTO #OTCDAILY from dbo.OTCTransactionDaily where dtProcess = '20190329'--@dt

CREATE INDEX [IX_OTCDAILY] ON #OTCDAILY(TransactionID)
--------------------------------------------------------------------------------------------

IF OBJECT_ID('tempdb..#pl') IS NOT NULL
	DROP TABLE #pl
SELECT * INTO #pl FROM mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
WHERE dtArchive = @dt
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #pl.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

--%%%%%%%%%%%%%		#SCHED0		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
IF OBJECT_ID('tempdb..#SCHED0') IS NOT NULL
	DROP TABLE #SCHED0
CREATE TABLE #SCHED0	(	--SELECT count(*) FROM #SCHED0		SELECT * FROM #SCHED0 where m_dt_caprem0 is null
	M_H_NB_MZ		CHAR(12)		PRIMARY KEY
	,M_DT_OAMT0		NUMERIC(21,4)
	,M_DT_PAYMNT0	DATETIME
	,NextResetRate	NUMERIC(21,8)
	,LastResetRate	NUMERIC(21,8)
	,M_DT_CAPREM0	NUMERIC(21,4)
)
INSERT #SCHED0	--select * from #SCHED0 --order by
SELECT
	s1.M_H_NB_MZ
	,s2.M_DT_OAMT0
	,s2.M_DT_PAYMNT0
	,s2.M_DT_FWDPR0
	,s0.M_DT_FWDPR0
	,s1.M_DT_CAPREM0
FROM		#sch					s1
LEFT JOIN	#sch					s2	ON	s2.M_H_PERID_ID			= s1.M_H_PERID_ID + 1
										AND	s2.M_H_NB_MZ			= s1.M_H_NB_MZ
										AND	s2.M_DT_LEG0			= 0
										AND s2.M_DT_PHASE			= s1.M_DT_PHASE
										AND s2.M_DT_FLWTYP4			= 'INT'
LEFT JOIN	#sch					s0	ON	s0.M_H_PERID_ID			= s2.M_H_PERID_ID - 1
										AND	s0.M_H_NB_MZ			= s2.M_H_NB_MZ
										AND	s0.M_DT_LEG0			= 0
										AND s0.M_DT_PHASE			= s2.M_DT_PHASE
										AND s0.M_DT_FLWTYP4			= 'INT'
WHERE	s1.M_DT_LEG0	= 0
AND		s1.M_DT_CURFLG	= 'Y'
AND		s1.M_DT_FLOWNAT	= 'INT'

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #SCHED0.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--%%%%%%%%%%%%%		#SCHED1		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
IF OBJECT_ID('tempdb..#SCHED1') IS NOT NULL
	DROP TABLE #SCHED1
CREATE TABLE #SCHED1	(	--SELECT * FROM #SCHED1
	M_H_NB_MZ		CHAR(12)		PRIMARY KEY
	,M_DT_OAMT0		NUMERIC(21,4)
	,M_DT_PAYMNT0	DATETIME
	,NextResetRate	NUMERIC(21,8)
	,LastResetRate	NUMERIC(21,8)
	,M_DT_CAPREM0	NUMERIC(21,4)
)
INSERT #SCHED1	--select * from #SCHED0 --order by 
SELECT
	s1.M_H_NB_MZ
	,s2.M_DT_OAMT0
	,s2.M_DT_PAYMNT0
	,s2.M_DT_FWDPR0
	,s0.M_DT_FWDPR0
	,s1.M_DT_CAPREM0
FROM		#sch					s1
LEFT JOIN	#sch					s2	ON	s2.M_H_PERID_ID			= s1.M_H_PERID_ID + 1
										AND	s2.M_H_NB_MZ			= s1.M_H_NB_MZ
										AND	s2.M_DT_LEG0			= 1
										AND s2.M_DT_PHASE			= s1.M_DT_PHASE
										AND s2.M_DT_FLWTYP4			= 'INT'
LEFT JOIN	#sch					s0	ON	s0.M_H_PERID_ID			= s2.M_H_PERID_ID - 1
										AND	s0.M_H_NB_MZ			= s2.M_H_NB_MZ
										AND	s0.M_DT_LEG0			= 1
										AND s0.M_DT_PHASE			= s2.M_DT_PHASE
										AND s0.M_DT_FLWTYP4			= 'INT'
WHERE	s1.M_DT_LEG0	= 1
AND		s1.M_DT_CURFLG	= 'Y'
AND		s1.M_DT_FLOWNAT	= 'INT'

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #SCHED1.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#ACTIONs') IS NOT NULL
	DROP TABLE #ACTIONs
CREATE TABLE #ACTIONs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	Action			NVARCHAR(10)
)

IF OBJECT_ID('tempdb..#NONDELIV_SWP0') IS NOT NULL
	DROP TABLE #NONDELIV_SWP0
CREATE TABLE #NONDELIV_SWP0 (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	M_H_NB_MZ	CHAR(12)
	,dPV		NUMERIC(19,2)
	,dPVCSA		NUMERIC(19,2)
	,PRIMARY KEY (M_H_NB_MZ,dPV,dPVCSA)
)
INSERT		#NONDELIV_SWP0
SELECT		m.M_H_NB_MZ
			,ISNULL(pl.M_MV_FMV2, 0) + ISNULL(pl.M_MV_FFP2, 0)
			,ISNULL(plc.M_MV_FMV2, 0) + ISNULL(plc.M_MV_FFP2, 0)
FROM		#t						m
LEFT JOIN	#pl						pl	ON	pl.M_H_NB_MZ		= m.M_H_NB_MZ
										AND	pl.M_MV_LEG			= 0
										AND	pl.M_H_DATA_LB		= 'EOD'
										AND	(pl.M_MV_FMV2		<> 0
											OR pl.M_MV_FFP2		<> 0)
LEFT JOIN	#pl						plc	ON	plc.M_H_NB_MZ		= m.M_H_NB_MZ
										AND	plc.M_MV_LEG		= 0
										AND	plc.M_H_DATA_LB		= 'EOD_CSA'
										AND	(plc.M_MV_FMV2		<> 0
											OR pl.M_MV_FFP2		<> 0)
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #NONDELIV_SWP0.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--INSERT MUREX TRADE LEGS INTO IRDTransactionDailyLeg %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--LEG 0, ALWAYS THE LESSER OF THE TWO TransactionLegID's
	--SELECT --for GROUP BY below
	--	TransactionLegID,			M_H_DATA_DT2
	--FROM (
IF OBJECT_ID('tempdb..#leg0') IS NOT NULL
	DROP TABLE #leg0
SELECT	--tl.TransactionLegID, m.M_H_DATA_DT2, *
	tl.TransactionLegID,						@IRD_DAILY_PV_EVTTYPE_ID
													TransactionEventTypeID,					m.M_H_DATA_DT2
																								dtTransactionEvent,							CASE
																																				WHEN	M_CNT_TYPO			= 'Total Return Swap BD'	THEN	ABS(m.M_TP_NOMINAL)
																																				WHEN	m.M_TRN_GRP			= 'CS'					
																																				AND		sch.M_DT_CAPREM0	IS NOT NULL					THEN	sch.M_DT_CAPREM0
																																				WHEN	m.M_TRN_GRP			= 'CS'					
																																				AND		sch.M_DT_CAPREM0	IS NULL
																																				AND		m.M_TP_STATUS2		<> 'DEAD'
																																				AND		m.M_TP_RTINPC0		<> m.M_TP_NOMCUR			THEN	ABS(m.M_TP_QTYEQ)
																																				ELSE															ABS(m.M_TP_AVQTY2)
																																				END dNotional,
	ISNULL(plu.dPV, 0) dPV,						ISNULL(plu.dPVCSA, 0) dPVCSA,				sch.M_DT_OAMT0 dNextPayment,					sch.M_DT_PAYMNT0 dtNextPayment,
	NULL sRollDay,								tl.dFixedRate,								sch.LastResetRate dLastResetRate,				sch.NextResetRate dNextResetRate,
	tl.dFloatingSpread,							tl.FloatingIndexID,							t.dtMaturity
INTO	#leg0	--select count(*) from #leg0	select * from #leg1 where dNotional is null
FROM	dbo.OTCTransaction										t
JOIN	dbo.DataSource											ds	ON	ds.DataSourceID			= t.DataSourceID
																	AND	ds.sSourceName			= 'Murex'
JOIN	dbo.IRDTransactionLeg									tl	ON	tl.TransactionID		= t.TransactionID
JOIN	#LEGID													g	ON	g.TransactionID			= t.TransactionID
																	AND	g.Leg0ID				= tl.TransactionLegID
JOIN	dbo.XRefOTCTransaction									x	ON	x.TransactionID			= t.TransactionID
																	AND	x.DataSourceID			= t.DataSourceID
																	AND	x.XRefOTCTradeTypeID	= @TRDREFTYPE_PRIMARY_ID
JOIN	#t														m	ON	RTRIM(m.M_H_NB_MZ)		= x.sRef
JOIN	#OTCDAILY												td	ON	td.TransactionID		= t.TransactionID
																	AND	td.dtProcess			= m.M_H_DATA_DT2
LEFT JOIN #NONDELIV_SWP0										plu	ON	plu.M_H_NB_MZ			= m.M_H_NB_MZ
LEFT JOIN #SCHED0												sch	ON	sch.M_H_NB_MZ			= m.M_H_NB_MZ
--)I
--GROUP BY TransactionLegID,M_H_DATA_DT2
--HAVING COUNT(*)>1
--order by TransactionLegID,M_H_DATA_DT2
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #leg0.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

CREATE INDEX IX_LEG0_TXLEGID_DTTXEVT ON #leg0(TransactionLegID, dtTransactionEvent)

MERGE dbo.IRDTransactionLegDaily									TGT
USING #leg0															SRC	ON	SRC.TransactionLegID	= TGT.TransactionLegID
																		AND	SRC.dtTransactionEvent	= TGT.dtTransactionEvent
WHEN NOT MATCHED THEN
	INSERT
		(TransactionLegID,							TransactionEventTypeID,						dtTransactionEvent,								dNotional,
		dPV,										dPVCSA,										dNextPayment,									dtNextPayment,
		sRollDay,									dFixedRate,									dLastResetRate,									dNextResetRate,
		dFloatingSpread,							FloatingIndexID,							dtMaturity)
	VALUES
		(TransactionLegID,							TransactionEventTypeID,						dtTransactionEvent,								dNotional,
		dPV,										dPVCSA,										dNextPayment,									dtNextPayment,
		sRollDay,									dFixedRate,									dLastResetRate,									dNextResetRate,
		dFloatingSpread,							FloatingIndexID,							dtMaturity)
WHEN MATCHED THEN
	UPDATE SET 
		TransactionEventTypeID		= SRC.TransactionEventTypeID
		,dNotional					= SRC.dNotional
		,dPV						= SRC.dPV
		,dPVCSA						= SRC.dPVCSA
		,dNextPayment				= SRC.dNextPayment
		,dtNextPayment				= SRC.dtNextPayment
		,sRollDay					= SRC.sRollDay
		,dFixedRate					= SRC.dFixedRate
		,dLastResetRate				= SRC.dLastResetRate
		,dNextResetRate				= SRC.dNextResetRate
		,dFloatingSpread			= SRC.dFloatingSpread
		,FloatingIndexID			= SRC.FloatingIndexID
		,dtMaturity					= SRC.dtMaturity
OUTPUT
	$action
INTO #ACTIONs;
SET @Leg0DailyInsertCount = (SELECT COUNT(*) FROM #ACTIONs WHERE Action = 'INSERT')
SET @Leg0DailyUpdateCount = (SELECT COUNT(*) FROM #ACTIONs WHERE Action = 'UPDATE')
INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('spMDR_MUREX_TRANSACTION_LEG_DAILY MERGE LEG 0 INSERT count: '	+ CONVERT(VARCHAR, @Leg0DailyInsertCount))
INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('spMDR_MUREX_TRANSACTION_LEG_DAILY MERGE LEG 0 UPDATE count: '	+ CONVERT(VARCHAR, @Leg0DailyUpdateCount))
PRINT 'Timer after Leg 0 MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--PRINT '@Leg0DailyInsertCount = ' + CONVERT(VARCHAR, @Leg0DailyInsertCount)
--PRINT '@Leg0DailyUpdateCount = ' + CONVERT(VARCHAR, @Leg0DailyUpdateCount)

DELETE #ACTIONs

IF OBJECT_ID('tempdb..#NONDELIV_SWP1') IS NOT NULL
	DROP TABLE #NONDELIV_SWP1
CREATE TABLE #NONDELIV_SWP1 (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	M_H_NB_MZ	CHAR(12)
	,dPV		NUMERIC(19,2)
	,dPVCSA		NUMERIC(19,2)
	,PRIMARY KEY (M_H_NB_MZ,dPV,dPVCSA)
)
INSERT		#NONDELIV_SWP1
SELECT		m.M_H_NB_MZ
			,ISNULL(pl.M_MV_FMV2, 0) + ISNULL(pl.M_MV_FFP2, 0)
			,ISNULL(plc.M_MV_FMV2, 0) + ISNULL(plc.M_MV_FFP2, 0)
FROM		#t						m
LEFT JOIN	#pl						pl	ON	pl.M_H_NB_MZ		= m.M_H_NB_MZ
										AND	pl.M_MV_LEG			= 1
										AND	pl.M_H_DATA_LB		= 'EOD'
										AND	(pl.M_MV_FMV2		<> 0
											OR pl.M_MV_FFP2		<> 0)
LEFT JOIN	#pl						plc	ON	plc.M_H_NB_MZ		= m.M_H_NB_MZ
										AND	plc.M_MV_LEG		= 1
										AND	plc.M_H_DATA_LB		= 'EOD_CSA'
										AND	(plc.M_MV_FMV2		<> 0
											OR pl.M_MV_FFP2		<> 0)

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #NONDELIV_SWP1.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--LEG 1

--FROM	dbo.OTCTransaction											t
--JOIN	dbo.DataSource												ds	ON	ds.DataSourceID			= t.DataSourceID
--																		AND	ds.sSourceName			= 'Murex'
--JOIN	dbo.IRDTransactionLeg										tl	ON	tl.TransactionID		= t.TransactionID
--JOIN	#LEGID														g	ON	g.TransactionID			= t.TransactionID
--																		AND	g.Leg1ID				= tl.TransactionLegID
--JOIN	dbo.XRefOTCTransaction										x	ON	x.TransactionID			= t.TransactionID
--																		AND	x.DataSourceID			= t.DataSourceID
--																		AND	x.XRefOTCTradeTypeID	= 1
--JOIN	#t															m	ON	m.M_H_NB_MZ				= x.sRef
--JOIN	dbo.OTCTransactionDaily										td	ON	td.TransactionID		= t.TransactionID
--																		AND	td.dtProcess			= m.M_H_DATA_DT2



IF OBJECT_ID('tempdb..#leg1') IS NOT NULL
	DROP TABLE #leg1
SELECT
	tl.TransactionLegID,						1988
													TransactionEventTypeID,					m.M_H_DATA_DT2
																								dtTransactionEvent,							CASE
																																				WHEN	M_CNT_TYPO			= 'Total Return Swap BD'	THEN	ABS(m.M_TP_NOMINAL)
																																				WHEN	m.M_TRN_GRP			= 'CS'					
																																				AND		sch.M_DT_CAPREM0	IS NOT NULL					THEN	sch.M_DT_CAPREM0
																																				WHEN	m.M_TRN_GRP			= 'CS'					
																																				AND		sch.M_DT_CAPREM0	IS NULL
																																				AND		m.M_TP_STATUS2		<> 'DEAD'
																																				AND		m.M_TP_RTINPC1		<> m.M_TP_NOMCUR			THEN	ABS(m.M_TP_QTYEQ)
																																				ELSE															ABS(m.M_TP_AVQTY2)
																																				END dNotional,
	ISNULL(plu.dPV, 0) dPV,						ISNULL(plu.dPVCSA, 0) dPVCSA,				sch.M_DT_OAMT0 dNextPayment,					sch.M_DT_PAYMNT0 dtNextPayment,
	NULL sRollDay,								tl.dFixedRate,								sch.LastResetRate dLastResetRate,				sch.NextResetRate dNextResetRate,
	tl.dFloatingSpread,							tl.FloatingIndexID,							t.dtMaturity
	--select *
INTO #leg1
FROM	dbo.OTCTransaction											t
JOIN	dbo.DataSource												ds	ON	ds.DataSourceID			= t.DataSourceID
																		AND	ds.sSourceName			= 'Murex'
JOIN	dbo.IRDTransactionLeg										tl	ON	tl.TransactionID		= t.TransactionID
JOIN	#LEGID														g	ON	g.TransactionID			= t.TransactionID
																		AND	g.Leg1ID				= tl.TransactionLegID
JOIN	dbo.XRefOTCTransaction										x	ON	x.TransactionID			= t.TransactionID
																		AND	x.DataSourceID			= t.DataSourceID
																		AND	x.XRefOTCTradeTypeID	= 1
JOIN	#t															m	ON	m.M_H_NB_MZ				= x.sRef
JOIN	#OTCDAILY													td	ON	td.TransactionID		= t.TransactionID
																		AND	td.dtProcess			= m.M_H_DATA_DT2
LEFT JOIN #NONDELIV_SWP1											plu	ON	plu.M_H_NB_MZ			= m.M_H_NB_MZ
LEFT JOIN #SCHED1													sch	ON	sch.M_H_NB_MZ			= m.M_H_NB_MZ
WHERE	m.M_TRN_GRP			IN ('IRS','ASWP','CS','OSWP','RTRN','SWFUT', 'FRA') --OPTION(RECOMPILE)

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #leg1.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

CREATE INDEX IX_LEG1_TXLEGID_DTTXEVT ON #leg1(TransactionLegID, dtTransactionEvent)

MERGE dbo.IRDTransactionLegDaily									TGT
USING #leg1															SRC	ON	SRC.TransactionLegID	= TGT.TransactionLegID
																		AND	SRC.dtTransactionEvent	= TGT.dtTransactionEvent
WHEN NOT MATCHED THEN
	INSERT
		(TransactionLegID,							TransactionEventTypeID,						dtTransactionEvent,								dNotional,
		dPV,										dPVCSA,										dNextPayment,									dtNextPayment,
		sRollDay,									dFixedRate,									dLastResetRate,									dNextResetRate,
		dFloatingSpread,							FloatingIndexID,							dtMaturity)
	VALUES
		(TransactionLegID,							TransactionEventTypeID,						dtTransactionEvent,								dNotional,
		dPV,										dPVCSA,										dNextPayment,									dtNextPayment,
		sRollDay,									dFixedRate,									dLastResetRate,									dNextResetRate,
		dFloatingSpread,							FloatingIndexID,							dtMaturity)
WHEN MATCHED THEN
	UPDATE SET 
		TransactionEventTypeID		= SRC.TransactionEventTypeID
		,dNotional					= SRC.dNotional
		,dPV						= SRC.dPV
		,dPVCSA						= SRC.dPVCSA
		,dNextPayment				= SRC.dNextPayment
		,dtNextPayment				= SRC.dtNextPayment
		,sRollDay					= SRC.sRollDay
		,dFixedRate					= SRC.dFixedRate
		,dLastResetRate				= SRC.dLastResetRate
		,dNextResetRate				= SRC.dNextResetRate
		,dFloatingSpread			= SRC.dFloatingSpread
		,FloatingIndexID			= SRC.FloatingIndexID
		,dtMaturity					= SRC.dtMaturity
OUTPUT
	$action
INTO #ACTIONs;
SET @Leg1DailyInsertCount = (SELECT COUNT(*) FROM #ACTIONs WHERE Action = 'INSERT')
SET @Leg1DailyUpdateCount = (SELECT COUNT(*) FROM #ACTIONs WHERE Action = 'UPDATE')
INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('spMDR_MUREX_TRANSACTION_LEG_DAILY MERGE LEG 1 INSERT count: '	+ CONVERT(VARCHAR, @Leg1DailyInsertCount))
INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('spMDR_MUREX_TRANSACTION_LEG_DAILY MERGE LEG 1 UPDATE count: '	+ CONVERT(VARCHAR, @Leg1DailyUpdateCount))
PRINT 'Timer after Leg 1 MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--PRINT '@Leg1InsertCount = ' + CONVERT(VARCHAR, @Leg1InsertCount)
--PRINT '@Leg1UpdateCount = ' + CONVERT(VARCHAR, @Leg1UpdateCount)
PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 0 INSERT count: '	+ CONVERT(VARCHAR, @Leg0DailyInsertCount)
PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 0 UPDATE count: '	+ CONVERT(VARCHAR, @Leg0DailyUpdateCount)
PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 1 INSERT count: '	+ CONVERT(VARCHAR, @Leg1DailyInsertCount)
PRINT 'spMDR_MUREX_TRANSACTION_LEG_DAILY LEG 1 UPDATE count: '	+ CONVERT(VARCHAR, @Leg1DailyUpdateCount)
