--CREATE VIEW 
--AS
select --COUNT(PTY.sValue), 
T.sName,
xps.sRef[AP-REF]
, xp.sRef [M-REF]
, pt.sName [MasterAbsoluteParent]
, p.sName Parent
, A.sName [Account]
, A.sLongName [AccountNameLong]
, pt.PartyID [MasterAccountID]
, P.PartyID [ParentAccountID]
, A.AccountID [SubAccountID]
, dl.sCertificateStatus
from party p

--update xps 
--set sRef = p.sFirst
--from Party p
inner join dbo.Account a on p.partyid = a.partyid
inner join dbo.XRefAccount xa on a.AccountID=xa.AccountID
inner join dbo.Relationship r on r.SubPartyID=a.PartyID and r.RelationshipTypeID = (select RelationshipTypeID from dbo.RelationshipType where coSubRole='Client' and coSuperRole='Client' and coRelationshipType='Functional' and coFunctionalContext='Credit')
inner join dbo.Relationship ra on ra.SubPartyID=a.PartyID and ra.RelationshipTypeID = (select RelationshipTypeID from dbo.RelationshipType where coSubRole='Client' and coSuperRole='Client' and coRelationshipType='Functional' and coFunctionalContext='Compliance')
join dbo.XRefParty xp on xp.PartyID=r.SuperPartyID
join dbo.XRefParty xps on xps.PartyID=ra.SuperPartyID
inner join dbo.Party pt on pt.PartyID = r.SuperPartyID
LEFT JOIN [app].[CoreDomain_PartyProperty] PTY ON PTY.PartyID = PT.PartyID
LEFT JOIN [mcoredb].[app].[CoreDomain_PartyPropertyType] T ON PTY.PropertyTypeID = T.ID 
join mcoredb_archive.extract.MCO_DEALOGIC_QIB_CERTIFICATE dl on dl.sAccountNumber = xp.sRef
--FOR XML AUTO, ROOT ('TSAUpload')
--WHERE T.sName = 'CERTIFICATE_QIB' --AND
--P.sName = '1832 ASSET MANAGEMENT L.P.'  
--Pt.SNAME = 'ABU DHABI INVESTMENT AUTHORITY'
--where P.PartyID  = 247594 --xa.sRef='200-010382'
--GROUP BY 
--xps.sRef
--, xp.sRef 
--, pt.sName 
--, p.sName 
--, A.sName 
--, A.sLongName 
--, P.PartyID 
--, A.AccountID 
--, A.ParentID
--, A.bActive
--ORDER BY A.sName ASC
--WHERE PT.PartyID IN (

----SELECT R.SuperPartyID,R.SubPartyID,PA.sName MASTER,PA.coPartyType,PP.sName PARENT,*
----FROM XRefParty P
----JOIN PARTY PP ON PP.PartyID = P.PartyID
----JOIN Relationship R ON R.SubPartyID = P.PartyID
----JOIN PARTY PA ON PA.PartyID = R.SuperPartyID
----WHERE sRef = 'M005895' OR sRef = 'AP100320'

--SELECT PTY.PARTYID--P.sName,*
--FROM [app].[CoreDomain_PartyProperty] PTY 
--INNER JOIN [mcoredb].[app].[CoreDomain_PartyPropertyType] T ON PTY.PropertyTypeID = T.ID 
----INNER JOIN PARTY P ON P.PartyID = PTY.PartyID
--WHERE T.sName = 'CERTIFICATE_QIB' --AND


--)


