IF OBJECT_ID('tempdb..#Mx_DL_SLA_Tracker') IS NOT NULL
Drop Table #Mx_DL_SLA_Tracker;

Create Table #Mx_DL_SLA_Tracker
(
SLA_Days SmallInt,
SLA_Time Time,
Tracking_Item Varchar(500),
Tidal_Job_ID Varchar(500),
Tidal_Job_Group Varchar(1000),
Tidal_Job_Status Varchar(100),
Job_End_Time Datetime,
SLA_Breach_In_Mins Int
);

--Declare @Date Datetime = '3/27/2019';

Insert Into #Mx_DL_SLA_Tracker(SLA_Days, SLA_Time, Tracking_Item, Tidal_Job_Group)
select 0 As SLA_Days, '15:30' as SLA_Time, 'MCDB to Mx (Official FX Rates)', '\Derivatives\MCDB to Murex\FX Rates' UNION
select 0 As SLA_Days, '18:30' as SLA_Time, 'Mx (Market Data Valuations)', '\Derivatives\Murex\Daily EOD Begin\013 Market Data Extracts\100 PS_MD_FG_FXD DataMart Extract' UNION
select 0 As SLA_Days, '16:30' as SLA_Time, 'Mx (Market Data Valuations)', '\Derivatives\Murex\Daily EOD Report Date Roll\015 Market Data Extracts\140 PS_MD_SEC_PRC DataMart Extract' UNION
select 0 As SLA_Days, '16:30' as SLA_Time, 'Mx (Flash PnL)', '\Derivatives\Murex Intraday\Intraday Flash PL and Trade Reports\010 PS_PL_TRADE_FPL Pre EOD Flash PL' UNION
select 0 As SLA_Days, '17:00' as SLA_Time, 'Mx to MCDB Ref Data (Market Data Valuations)', '\Derivatives\Murex to MCDB\Stage Murex DataMart to mcoredb_work\stage murex Market Data' UNION
select 0 As SLA_Days, '17:00' as SLA_Time, 'Sharepoint (Flash PnL)', '' UNION
select 0 As SLA_Days, '18:00' as SLA_Time, 'Mx Corporate Market Data (Corporate Credit, FX & IR Rates, Jacobians)', '\Corporate\Market Data\Murex' UNION
select 0 As SLA_Days, '19:00' as SLA_Time, 'EPE Quarterly Stress Testing', '\Corporate\EPE\600 Gamma EPE\300 Quarterly EPE Stress Testing' UNION
select 0 As SLA_Days, '19:30' as SLA_Time, 'EPE Monthly Stress Testing', '\Corporate\EPE\600 Gamma EPE\200 Monthly EPE Stress Testing' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Deals & PV)', '\Derivatives\Murex\Daily EOD Core Extracts\010 Economics Extracts' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Cashflow)', '\Derivatives\Murex\Daily EOD Reports and Extracts\030 Core Extracts\007 PS_OPS_FIX DataMart Extract' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Cashflow)', '\Derivatives\Murex\Daily EOD Core Extracts\500 EOD Core File Extracts\301 Core CF2 File Extracts' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Cashflow)', '\Derivatives\Murex\Daily EOD Core Extracts\500 EOD Core File Extracts\303 Core SCHDL2 File Extracts' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Collateral)', '\Derivatives\Murex\Daily EOD Collateral\025 Collateral Dependent Extracts' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Collateral)', '\Derivatives\Murex\Daily EOD Collateral\015 Collateral Processing' UNION
select 0 As SLA_Days, '20:00' as SLA_Time, 'Mx Deal Extract (Xeno Portfolio)', '\Derivatives\Murex\Daily EOD Core Extracts\010 Economics Extracts\140 PS_INF_XENO Xenormorph Report' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Deals)', '\Derivatives\Murex to MCDB\Stage Murex DataMart to mcoredb_work\stage murex Ref Data' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Deals)', '\Derivatives\Murex to MCDB\Stage Murex DataMart to mcoredb_work\stage murex Transactions' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Deals)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Ref Data' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Deals & PV)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Transactions and Legs' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Cashflow)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Schedules' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Collateral)', '\Derivatives\Murex to MCDB\Stage Murex DataMart to mcoredb_work\stage murex Collateral' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'Mx to MCDB (Collateral)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Collaterals' UNION
select 0 As SLA_Days, '22:00' as SLA_Time, 'MCM EPE Extracts', '\Corporate\EPE\600 Gamma EPE\010 MCM Extracts' UNION
select 0 As SLA_Days, '23:00' as SLA_Time, 'EPE MacE Flows', '\Corporate\EPE\600 Gamma EPE\020 MCDB � MacE Flows' UNION
select 0 As SLA_Days, '23:30' as SLA_Time, 'EPE MacE Calculation', '\Corporate\EPE\600 Gamma EPE\100 MacE Daily Calculation' UNION
select 1 As SLA_Days, '00:00' as SLA_Time, 'Mx to MCDB (Risk Sensitivies)', '\Derivatives\Murex\Daily EOD Reports and Extracts\040 Risk Sensitivities Data Extracts' UNION
select 1 As SLA_Days, '00:00' as SLA_Time, 'Mx to MCDB (Risk Sensitivies)', '\Derivatives\Murex\Daily EOD Reports and Extracts\500 EOD File Extracts\400 Risk Sensitivity PS_RSK_DV01 File Extracts' UNION
select 1 As SLA_Days, '00:00' as SLA_Time, 'Mx to MCDB (Risk Sensitivies)', '\Derivatives\Murex to MCDB\Stage Murex Datamart to mcoredb_work\Stage Murex Risk' UNION
select 1 As SLA_Days, '00:00' as SLA_Time, 'Mx to MCDB (Risk Sensitivies)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Transactions - Risk' UNION
select 1 As SLA_Days, '01:00' as SLA_Time, 'Risk DW / MRPT / MCM Risk DB (Deals & Sensitivities)', '\Corporate\Risk Cube\500 Pre Positions - MCM' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (VaR(SIMM, GMR))', '\Derivatives\Murex\Daily EOD Risk\500 Risk Dependent Extracts\040 SIMM VAR Data Extracts\020 PS_RSK_SIMM_CL DataMart Extract' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (VaR(SIMM, GMR))', '\Derivatives\Murex\Daily EOD Front Office\054 Data Mart Extracts Post Hard Close\020 PS_PL_TRADE_DLY Datamart Extract' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (VaR(SIMM, GMR))', '\Derivatives\Murex\Daily EOD Reports and Extracts\030 Core Extracts\090 PS_PL_PLVAR_SCN DataMart Extract' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (VaR(SIMM, GMR))', '\Derivatives\Murex\Daily EOD Reports and Extracts\030 Core Extracts\170 PS_PL_PASTCASH DataMart Extract' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (RBPL)', '\Derivatives\Murex\Daily EOD Risk\190 Back Testing' UNION
select 1 As SLA_Days, '03:00' as SLA_Time, 'Mx Risk (RBPL)', '\Derivatives\Murex\Daily EOD Risk\500 Risk Dependent Extracts\010 RBPL Data Extracts' UNION
select 1 As SLA_Days, '04:00' as SLA_Time, 'MCDB/Risk DW/Risk DB (RBPL)', '\Derivatives\Murex to MCDB\Stage Murex DataMart to mcoredb_work\Stage Murex PnL' UNION
select 1 As SLA_Days, '04:00' as SLA_Time, 'MCDB/Risk DW/Risk DB (RBPL)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex Transactions - Risk\400 Run SSIS - Murex P&L' UNION
select 1 As SLA_Days, '04:00' as SLA_Time, 'MCDB/Risk DW/Risk DB (RBPL)', '\Derivatives\Murex to MCDB\Standardize Murex Trades to MCDB\Standardize Murex RBPL' UNION
select 1 As SLA_Days, '04:00' as SLA_Time, 'MCDB/Risk DW/Risk DB (VaR (SIMM, GMR), PnL, Sensitivities)', '\Corporate\Risk Cube\700 Post Positions - MCM' UNION
select 1 As SLA_Days, '06:00' as SLA_Time, 'MCDB/Risk DW (XVA Taylor VaR)', '' UNION
select 1 As SLA_Days, '06:00' as SLA_Time, 'MCDB/Risk DW (XVA RBPL)', '' UNION
select 1 As SLA_Days, '06:00' as SLA_Time, 'MCDB/Risk DW (XVA Clean PnL)', '' UNION
select 1 As SLA_Days, '06:00' as SLA_Time, 'MCDB/Risk DW (XVA Sensitivites)', ''


Update st
Set st.Job_End_Time = jr.jobrun_lstchgtm
,st.Tidal_Job_Status = sm.strmst_desc
,st.Tidal_Job_ID = jr.jobrun_id
from 
#Mx_DL_SLA_Tracker st
Inner Join jobmst jm ON jm.jobmst_prntname + '\' + jm.jobmst_name = st.Tidal_Job_Group
inner join jobrun jr on jm.jobmst_id = jr.jobmst_id
inner join strmst sm on jr.jobrun_status = sm.strmst_id
where jr.jobrun_proddt = @Date
and sm.strmst_type = 7;


With CTE_SLA_Tracker As
(
	Select (DATEADD(D, st.SLA_Days, @Date) + st.SLA_Time) As SLA_DateTime, Tracking_Item, Tidal_Job_Group, Job_End_Time
	From #Mx_DL_SLA_Tracker st
)

Update st
Set st.SLA_Breach_In_Mins = (Case When cst.Job_End_Time > cst.SLA_DateTime Then DATEDIFF(MI, cst.SLA_DateTime, cst.Job_End_Time) Else 0 End)
From #Mx_DL_SLA_Tracker st
Inner Join CTE_SLA_Tracker cst ON st.Tidal_Job_Group = cst.Tidal_Job_Group

;WITH CTE AS (
Select Row_Number() Over(Order by (DATEADD(D, SLA_Days, @Date) + SLA_Time))  As [SI NO]
, CAST(@Date As Date) As [TIDAL JOB DATE]
, (DATEADD(D, SLA_Days, @Date) + SLA_Time) As [SLA]
, Tracking_Item AS [TRACKED]
, Tidal_Job_ID AS [TIDAL JOB ID]
, Tidal_Job_Group AS [TIDAL JOB GROUP]
, Tidal_Job_Status AS [TIDAL JOB STATUS]
, IIF(Tidal_Job_Status = 'Waiting On Children',NULL ,Job_End_Time) AS [JOB END TIME]
, SLA_Breach_In_Mins AS [SLA BREACH]
--,H.jobrun_id AS H
--,H.jobrun_duration
--,H1.jobrun_id AS H1--COUNT(JR.jobrun_id) AS [CHILD COUNT ID]
--,H1.jobrun_duration
--,H2.jobrun_id AS H2
--,H2.jobrun_duration
--,H3.jobrun_id AS H3
--,H3.jobrun_duration
--,H4.jobrun_id AS H4
--,H4.jobrun_duration
,COUNT(COALESCE(H4.jobrun_id,H3.jobrun_id,H2.jobrun_id,H1.jobrun_id,H.jobrun_id)) AS [CHILD COUNT ID]
,SUM(COALESCE(H4.jobrun_duration,H3.jobrun_duration,H2.jobrun_duration,H1.jobrun_duration,H.jobrun_duration)) AS [MERGED DURATION]
--,H5.jobrun_id AS H5
--,H5.jobrun_duration
From #Mx_DL_SLA_Tracker MX
LEFT JOIN jobrun H ON MX.Tidal_Job_ID = H.jobrun_id
LEFT JOIN jobrun H1 ON H.jobrun_id = H1.jobrun_prntid --IIF( jobrun_id > 0, JR.jobrun_prntid. JR.JOB)
LEFT JOIN jobrun H2 ON H1.jobrun_id = H2.jobrun_prntid
LEFT JOIN jobrun H3 ON H2.jobrun_id = H3.jobrun_prntid
LEFT JOIN jobrun H4 ON H3.jobrun_id = H4.jobrun_prntid
--LEFT JOIN jobrun H5 ON H4.jobrun_id = H5.jobrun_prntid
--where Tidal_Job_Group LIKE '%400%'
--WHERE Tidal_Job_ID = 31439767
GROUP BY SLA_Days,Tracking_Item, SLA_Time, Tidal_Job_ID, Tidal_Job_Group, Tidal_Job_Status, Job_End_Time, SLA_Breach_In_Mins--, JR.jobrun_id
--Order By SLA;
)
SELECT
		 [SI NO]
		,ISNULL([TIDAL JOB ID],'') AS [TIDAL JOB ID]
		,ISNULL([TIDAL JOB DATE],'') AS [TIDAL JOB DATE]
		,ISNULL(SLA,'') AS SLA
		,ISNULL(TRACKED,'') AS TRACKED
		,ISNULL([TIDAL JOB GROUP],'') AS [TIDAL JOB GROUP]
		,ISNULL([TIDAL JOB STATUS],'') AS [TIDAL JOB STATUS]
		,IIF([JOB END TIME]='1900-01-01 00:00:00.000','',ISNULL([JOB END TIME],'')) AS [JOB END TIME]
	  --,ISNULL([CHILD COUNT ID],'')
		,ISNULL(CONVERT(varchar(100),(MAX([SLA BREACH])  / 60)) + 'hrs ' + CONVERT(varchar(100),(MAX([SLA BREACH]) % 60)) + 'mins ','') AS [SLA BREACH]
		,ISNULL(CONVERT(varchar(100),(SUM([MERGED DURATION]) / 60)) + 'mins ' + CONVERT(varchar(100),(SUM([MERGED DURATION]) % 60)) + 'secs ' ,'') AS [JOB DURATION]
From CTE MX
--LEFT JOIN jobrun JR ON MX.[TIDAL JOB ID] = (CASE WHEN [CHILD COUNT ID] > 0 THEN JR.jobrun_prntid ELSE JR.jobrun_id END) --IIF( jobrun_id > 0, JR.jobrun_prntid. JR.JOB)
--WHERE [TIDAL JOB GROUP] like '%700%'--Tidal_Job_ID = 31439767
GROUP BY [SI NO]
		,[TIDAL JOB DATE]
		,[TIDAL JOB ID]
		,SLA
		,TRACKED
		,[TIDAL JOB GROUP]
		,[TIDAL JOB STATUS]
		,[JOB END TIME]
		--,[CHILD COUNT ID]
Order By SLA;


Drop Table #Mx_DL_SLA_Tracker;



/*
select jobrun_stachgtm, jobrun_lstchgtm, jobrun_esttime, jobrun_time, jobrun_fromtm, jobrun_untiltm, * from jobrun where jobrun_proddt = '3/5/2019' and jobmst_id = 32275;
select jobrun_stachgtm, jobrun_lstchgtm, jobrun_esttime, jobrun_time, jobrun_fromtm, jobrun_untiltm, * from jobrun where jobrun_proddt = '3/5/2019' and jobmst_id = 34094;
select * from jobmst where jobmst_alias = '52275';
*/


--SELECT --CONVERT(datetime2,JR.jobrun_time,101),JR.jobrun_time, 
--jm.jobmst_name AS [JOB NAME]
--,RTRIM(SM.strmst_desc) AS [JOB STATUS]
--,CONVERT(varchar(100),(jr.jobrun_duration / 60)) + 'mins ' + CONVERT(varchar(100),(jr.jobrun_duration) % 60) + 'secs ' AS [JOB DURATION], *
----, MAX(JR.jobrun_time)
--FROM jobrun JR 
--JOIN jobmst JM ON JR.jobmst_id = JM.jobmst_id
--JOIN strmst sm on jr.jobrun_status = sm.strmst_id
--WHERE JR.jobrun_prntid = 31623445-- 31555879 --31555885 31555876
--and sm.strmst_type = 7
----GROUP BY jobrun_id, JR.jobrun_time
--ORDER BY [JOB DURATION] desc

--SELECT B.jobrun_proddt,MAX(B.jobrun_lstchgtm)  JOB_END_TIME
--FROM jobmst A
--JOIN jobrun B ON A.jobmst_id = B.jobmst_id
--WHERE jobmst_name LIKE '%400 RUN SSIS - MUREX%' AND B.jobrun_proddt > '20190312'
--GROUP BY B.jobrun_proddt