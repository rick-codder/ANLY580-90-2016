--SELECT * 
--FROM OTCTransaction OTC 
--JOIN mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP T ON T.
--WHERE dtTimestamp > '20181103' AND sUser = 'USI\olayemiadejumo';


--CREATE TABLE TX_IDs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
--	Action			NVARCHAR(10)
--	,TransactionID	NUMERIC(18,0) NOT NULL	--will put PK here in a few steps
--	,M_H_NB_MZ		CHAR(12)
--	,M_NB_EXT		NUMERIC(18,0)	--M_H_ALT_ID	CHAR(20)
--	,M_USI_ID		CHAR(52)
--	,M_USI_NS		CHAR(10)
--	,M_BETA_ID		CHAR(10)
--	,M_CCP_TRN_ID	CHAR(14)
--	,M_TRN_FMLY		CHAR(5)
--	,M_CNT_ORG		NUMERIC(10,0)
--	,bLive			BIT
--)

--select *
--from TX_IDs


--insert #TX_IDs (TransactionID, M_H_NB_MZ)
;WITH CTE AS (
select otc.TransactionID TransactionID , sRef M_H_NB_MZ
from OTCTransaction otc
join XRefOTCTransaction                 
x on x.DataSourceID = otc.DataSourceID
     and x.TransactionID = otc.TransactionID
     and x.XRefOTCTradeTypeID = 1 --@TRDREFTYPE_PRIMARY_ID
     and x.dtTimestamp > '20181103 17:00:00'
     and otc.dtTimestamp > '20181103 17:00:00'
	 AND otc.sUser = 'USI\_zssis_ci'
     AND X.sUser = 'USI\_zssis_ci'
     and otc.DataSourceID = 199
join mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP  t              
on t.M_H_NB_MZ = sRef
AND T.dtArchive = '20181031'

)
--WHERE OTC.TransactionID = 831042


--SELECT *--COUNT(*)
--FROM XRefOTCTransaction
--WHERE sUser = 'USI\olayemiadejumo' AND dtTimestamp > '20181103'
--AND DataSourceID = 199 AND XRefOTCTradeTypeID = 1

--SELECT *
--FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
--WHERE sUser = 'USI\olayemiadejumo' AND dtArchive = '20181029' AND M_H_NB_MZ ='20844'   

SELECT SCH.M_DT_LEG0,SCH.M_H_NB_MZ,SCH.M_H_PERID_ID,SCH.M_DT_PHASE,*
	FROM  CTE														n
	JOIN		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		t		ON	n.M_H_NB_MZ				= t.M_H_NB_MZ
																				AND	t.dtArchive				= '20181029'
	JOIN		mcoredb..OTCTransaction									otc		ON	otc.TransactionID		= n.TransactionID
		LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP		sch		ON	sch.M_H_NB_MZ			= t.M_H_NB_MZ
																				AND	sch.M_DT_LEG0			= 0
																				AND	sch.M_H_PERID_ID		= 0
																				AND	sch.M_DT_PHASE			= 0
																				AND	sch.dtArchive			= '20181029'    
	WHERE OTC.TransactionID = 831042


	select   *
from mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
WHERE (M_H_DATA_DT2 = '20181029' )
AND (M_H_DATA_LB = 'EOD' ) AND  M_H_NB_MZ = '20844'
