CREATE TABLE EXTRACT.[MCO_DEALOGIC_QIB_CERTIFICATE]
(
	dtArchive date NULL,
	iCertificate int NOT NULL,
	sAccountNumber varchar(100) NOT NULL,
	sClientName varchar(200) NULL,
	bCertificateBlanketStatus bit NOT NULL,
	sCertificateStatus char(1) NOT NULL,
	sCertificateStatusDesc AS CASE	WHEN sCertificateStatus = 'Y' THEN 'Yes'
									WHEN sCertificateStatus = 'N' THEN 'No'
									WHEN sCertificateStatus = 'U' THEN 'Unable to Obtain'
									WHEN sCertificateStatus = 'X' THEN 'Exempt'
							END,
	dtCertificateExpirationDate datetime NULL,
	dtCertificateUploadDate datetime NULL,
	dtCertificateModifiedDate datetime NULL,
	sParentAccountNumber varchar(100) NULL,
	sDataSource varchar(100) NOT NULL,
	sWebServiceInterface varchar(200) NOT NULL,
	dtTimestamp datetime NOT NULL DEFAULT(GETDATE()),
	sUser varchar(100) NULL DEFAULT(SUSER_SNAME()),
	iDelta int NOT NULL,
	[DEALOGIC_QIB_CERTIFICATE_PK] int IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
 CONSTRAINT [PK_[MCO_DEALOGIC_QIB_CERTIFICATE] PRIMARY KEY CLUSTERED 
(
	[DEALOGIC_QIB_CERTIFICATE_PK] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX IX_MCO_DEALOGIC_QIB_CERTIFICATE_dtArchive on EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE (dtArchive ASC);
GO


SELECT * 
FROM Extract.MCO_DEALOGIC_QIB_CERTIFICATE;