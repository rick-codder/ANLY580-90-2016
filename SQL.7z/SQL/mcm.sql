use mcoredb
DECLARE @T1 TABLE ([EM TABLE NAME] VARCHAR(50), [ROWS AFFECTED] INT)
--declare @dt datetime = '20181005 9:42:00'
--declare @jobdt date = '20181004'
declare @ignoreuser bit = 0
declare @ds int = (	SELECT	DataSourceID
					FROM	mcoredb..DataSource		d
					JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
					WHERE	sSourceName				= 'Murex'
					AND		sEntityCode				= 'MCM')
use mcoredb
--DECLARE @dt4 DATE = '2018-08-07'
--GMI (IGNORE "MSUSA")
SELECT
	e.sEntityCode
	,ds.sSourceName
	,COUNT(*)			Count
FROM TradeTransaction	tt
JOIN DataSource			ds	ON	ds.DataSourceID		= tt.DataSourceID
JOIN refcode.Entity		e	ON	e.EntityID			= ds.EntityID
JOIN Account			a	ON	a.AccountID			= tt.CptyAccountID
JOIN XRefParty			xp	ON	xp.PartyID			= a.PartyID
							AND	xp.sRef				= '0MCMC'
WHERE	tt.dtProcess	= @jobdt
--AND		ds.sSourceName	= 'GMI'
GROUP BY
	e.sEntityCode
	,ds.sSourceName
--IMPACT
SELECT
	e.sEntityCode
	,ds.sSourceName
	,COUNT(*)			Count
FROM TradeTransaction	tt
JOIN DataSource			ds	ON	ds.DataSourceID		= tt.DataSourceID
JOIN refcode.Entity		e	ON	e.EntityID			= ds.EntityID
--JOIN Account			a	ON	a.AccountID			= tt.CptyAccountID
--JOIN XRefParty			xp	ON	xp.PartyID			= a.PartyID
--							AND	xp.sRef				= '0MCMC'
WHERE	tt.dtProcess	= @jobdt
AND		ds.sSourceName	= 'Impact'
GROUP BY
	e.sEntityCode
	,ds.sSourceName