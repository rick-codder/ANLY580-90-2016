USE [mcoredb]
GO

--/****** Object:  StoredProcedure [stage].[spMDR_MUREX_TRANSACTION]    Script Date: 10/25/2018 5:45:25 PM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE PROC [stage].[spMDR_MUREX_TRANSACTION]
--	@dt					DATE
--	,@InsertCount		INT OUT
--	,@UpdateCount		INT OUT
--	,@DeleteCount		INT OUT
--	,@Leg0InsertCount	INT OUT
--	,@Leg1InsertCount	INT OUT
--	,@Leg0UpdateCount	INT OUT
--	,@Leg1UpdateCount	INT OUT
/*TO EXECUTE:
	DECLARE @dt					DATE = '20180824'
	DECLARE @TxInsertCount		INT
	DECLARE @TxUpdateCount		INT
	DECLARE @TxDeleteCount		INT
	DECLARE @Leg0InsertCount	INT
	DECLARE @Leg1InsertCount	INT
	DECLARE @Leg0UpdateCount	INT
	DECLARE @Leg1UpdateCount	INT
	EXEC stage.spMDR_MUREX_TRANSACTION						@dt, @TxInsertCount OUT, @TxUpdateCount OUT, @TxDeleteCount OUT, @Leg0InsertCount OUT, @Leg1InsertCount OUT, @Leg0UpdateCount OUT, @Leg1UpdateCount OUT
	PRINT 'spMDR_MUREX_TRANSACTION Insert count: '			+ CONVERT(VARCHAR, @TxInsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION Update count: '			+ CONVERT(VARCHAR, @TxUpdateCount)
	PRINT 'spMDR_MUREX_TRANSACTION LEG 0 Insert count: '	+ CONVERT(VARCHAR, @Leg0InsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION LEG 1 Insert count: '	+ CONVERT(VARCHAR, @Leg1InsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION LEG 0 Update count: '	+ CONVERT(VARCHAR, @Leg0UpdateCount)
	PRINT 'spMDR_MUREX_TRANSACTION LEG 1 Update count: '	+ CONVERT(VARCHAR, @Leg1UpdateCount)
*/
--AS

DECLARE @dt			DATE = '20181026'
	,@InsertCount		INT
	,@UpdateCount		INT
	,@DeleteCount		INT
	,@Leg0InsertCount	INT
	,@Leg1InsertCount	INT
	,@Leg0UpdateCount	INT
	,@Leg1UpdateCount	INT
DECLARE @start					DATETIME		= GETDATE()
DECLARE @debug					BIT				= 1
DECLARE @MSG					VARCHAR(1000)
DECLARE @OUTPUT					VARCHAR(MAX)	= ''

SET @MSG = '--------------------------------------------------------------------------------------------'
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Business date parameter = ' + CONVERT(VARCHAR, @dt)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Server name = ' + @@SERVERNAME
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @tmpLeg0InsertCount		INT
DECLARE @tmpLeg1InsertCount		INT
DECLARE @tmpLeg0UpdateCount		INT
DECLARE @tmpLeg1UpdateCount		INT
DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Murex'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_APOLLO	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Apollo'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_MARKIT	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Markit'
													AND		sEntityCode				= 'MSUSA')
DECLARE @TRDREFTYPE_PRIMARY_ID	NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Primary ID')
DECLARE @TRDREFTYPE_USI_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'USI ID')
DECLARE @TRDREFTYPE_CCP_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'CCP ID')
DECLARE @TRDREFTYPE_LINK_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Linked Trade ID')
DECLARE @TRADEBOOK_REL_ID		NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Organizational'
													AND		coFunctionalContext		= 'Core'
													AND		coSubFunctionalContext	= 'Trade Book')
DECLARE @CP_REL_ID				NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Functional'
													AND		coFunctionalContext		= 'Credit'
													AND		coSuperRole				= 'Executing Broker'
													AND		coSubRole				= 'Client')
DECLARE @LEGACY_FRA_ID			NUMERIC(18,0)	= (	SELECT RiskInstrumentTypeID
													FROM	mcoredb..vwRiskProductType
													WHERE	sRiskInstrumentType		= 'FRA'
													AND		sRiskProductType		= 'Forward Rate Agreement'
													AND		sRiskAssetClass			= 'Fixed Income Derivatives')
DECLARE @FOLLOWING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Following')
DECLARE @PRECEDING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Preceding')
DECLARE @MOD_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Modified')
DECLARE @REG_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Regular')
DECLARE @BusDayRuleMurexBridge	TABLE			(MxDesc VARCHAR(50), BusDayRuleModifierID NUMERIC(18,0), BusDayRuleConventionID NUMERIC(18,0))
INSERT	@BusDayRuleMurexBridge
VALUES
	('Previous',			@PRECEDING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Next',				@FOLLOWING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Modified following',	@FOLLOWING_BDRMOD_ID, @MOD_BDRCONV_ID),
	('Modified preceding',	@PRECEDING_BDRMOD_ID, @MOD_BDRCONV_ID)
SET @MSG = 'Business Day Rule Codes inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @cof_typos				TABLE			(M_TRN_FMLY CHAR(5),	M_TRN_GRP CHAR(5),	M_TRN_TYPE CHAR(5),	sTypo VARCHAR(10))
INSERT @cof_typos
VALUES
	('IRD',		'LN_BR',	'',			'Depo')
	,('CURR',	'FXD',		'SWLEG',	'Fx Swap')
	,('SCF',	'SCF',		'SCF',		'SCF')
	,('IRD',	'IRS',		'',			'IRS')
	,('CURR',	'FXD',		'FXD',		'Spot')
	,('IRD',	'FRA',		'',			'FRA')
	,('CRD',	'CDS',		'',			'CDS')
	,('CRD',	'CRDI',		'',			'CDS Index')

--DECLARE @RoundingFuncBridge	TABLE			(MxDesc VARCHAR(50), sDescription VARCHAR(50))
--INSERT	@RoundingFuncBridge
--VALUES
--	('None',		NULL),
--	('Nearest',		'Nearest'),
--	('By excess',	'Round'),
--	('By default',	'RoundDown'),
--	('Currency',	NULL)
--SET @MSG = 'Rounding functions inserted.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @callables				TABLE			(TYPO CHAR(21) PRIMARY KEY CLUSTERED)
INSERT @callables
VALUES
	('IRS Callable')
	,('Rev Floater Callable')
	,('IR CapFloor Callable')
	,('IR CapFl Call CMS')
	,('IR CapFl Call CMS SP')
	,('IRS Callable CMS')
	,('IRS Callable CMS SP')
	,('IRS ZC Call CMS')
	,('IRS ZC Call CMS SP')
	,('IRS ZC Callable')
	,('Range Call CMS')
	,('Range Call CMS SP')
	,('Range Callable')
	,('Rev Flt Call CMS')
	,('Rev Flt Call CMS SP')

IF OBJECT_ID('tempdb..#TX_IDs') IS NOT NULL
	DROP TABLE #TX_IDs --select * from #tx_ids
CREATE TABLE #TX_IDs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	Action			NVARCHAR(10)
	,TransactionID	NUMERIC(18,0) NOT NULL	--will put PK here in a few steps
	,M_H_NB_MZ		CHAR(12)
	,M_NB_EXT		NUMERIC(18,0)	--M_H_ALT_ID	CHAR(20)
	,M_USI_ID		CHAR(52)
	,M_USI_NS		CHAR(10)
	,M_BETA_ID		CHAR(10)
	,M_CCP_TRN_ID	CHAR(14)
	,M_TRN_FMLY		CHAR(5)
	,M_CNT_ORG		NUMERIC(10,0)
	,bLive			BIT
)

IF OBJECT_ID('tempdb..#ACTIONS') IS NOT NULL
	DROP TABLE #ACTIONS
CREATE TABLE #ACTIONS (			--table to retain whether each IRDTxLeg was an insert or update, just for total counts
	Action			NVARCHAR(10)
)
IF OBJECT_ID('tempdb..#TRADEBOOK') IS NOT NULL
	DROP TABLE #TRADEBOOK
CREATE TABLE #TRADEBOOK	(	--select count(*) FROM #TRADEBOOK
	sRef		VARCHAR(20)		PRIMARY KEY
	,AccountID	NUMERIC(18,0)
)
INSERT #TRADEBOOK	--select count(*) from #tradebook order by sref
SELECT	RTRIM(LTRIM(xa.sRef)) sRef, a.AccountID
FROM	mcoredb..Account										a
JOIN	mcoredb..XRefAccount									xa	ON	xa.AccountID			= a.AccountID
JOIN	mcoredb..Party											p	ON	p.PartyID				= a.PartyID
JOIN	mcoredb..LookupCodes									ps	ON	ps.CodeID				= p.StatusID
JOIN	mcoredb..Relationship									tbr	ON	tbr.SubPartyID			= p.PartyID
WHERE	xa.DataSourceID			= @DATASOURCE_ID_MUREX
AND		p.coPartyType			= 'Internal Unit'
AND		ps.sCodeValue			= 'Active'
AND		tbr.RelationshipTypeID	= @TRADEBOOK_REL_ID --47
--order by sRef

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #TRADEBOOK.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#AFFILIATE') IS NOT NULL
	DROP TABLE #AFFILIATE
CREATE TABLE #AFFILIATE	(	--select count(*) FROM #AFFILIATE
	sRef		VARCHAR(20)		PRIMARY KEY
	--,AccountID	NUMERIC(18,0)
)
INSERT #AFFILIATE	--select count(*) from #AFFILIATE order by sref
SELECT DISTINCT xa.sRef
FROM	Credit				c
JOIN	LookupCodes			lc	ON	lc.CodeID				= c.AffiliateID
JOIN	Relationship		r	ON	r.SuperPartyID			= c.PartyID
JOIN	Party				p	ON	p.PartyID				= r.SubPartyID
JOIN	Account				a	ON	a.PartyID				= p.PartyID
JOIN	XRefAccount			xa	ON	xa.AccountID			= a.AccountID
JOIN	RelationshipType	rt	ON	rt.RelationshipTypeID	= r.RelationshipTypeID
WHERE	xa.DataSourceID			= @DATASOURCE_ID_MUREX
AND		rt.coFunctionalContext	= 'Credit'
AND		rt.coRelationshipType	= 'Functional'
AND     lc.sCodeValue			= 'Yes'
AND		lc.sCategory			= 'Affiliate'
--order by sRef

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #AFFILIATE.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#CONTRACT') IS NOT NULL
	DROP TABLE #CONTRACT
CREATE TABLE #CONTRACT (	--select count(*) FROM #CONTRACT ORDER BY M_CONTRACT
	M_CONTRACT	NUMERIC(10,0)
	,M_TP_CNTRP	CHAR(35)
	,PRIMARY KEY CLUSTERED (M_CONTRACT, M_TP_CNTRP) -- PK MUST BE BOTH IF ADDED	--CONSTRAINT [PK_#CONTRACT] 
)
INSERT #CONTRACT
SELECT		t.M_CONTRACT, RTRIM(t.M_TP_CNTRP) M_TP_CNTRP
FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP	t
JOIN		mcoredb..XRefLookup									xl	ON	xl.sRef					= t.M_CNT_TYPO
JOIN		mcoredb..LookupCodes								pt	ON	pt.CodeID				= xl.LookupCodeID
WHERE		xl.DataSourceID	= @DATASOURCE_ID_MUREX
--AND		pt.sCategory	= 'Product Type'		--not necessary
AND			t.dtArchive		= @dt
GROUP BY	t.M_CONTRACT, t.M_TP_CNTRP

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CONTRACT.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#COUNTERPARTY') IS NOT NULL
	DROP TABLE #COUNTERPARTY
CREATE TABLE #COUNTERPARTY (
	M_DSP_LBL	CHAR(35)	NOT NULL
	,M_CODE		CHAR(10)
	,AccountID	NUMERIC(18,0)
)
INSERT #COUNTERPARTY
SELECT	--sRef--*
	LTRIM(RTRIM(cp.M_DSP_LBL)) M_DSP_LBL
	,M_CODE
	,xa.AccountID
FROM	mcoredb..XRefAccount								xa
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_REF_CNTP_REP		cp	ON	cp.M_CODE		= xa.sRef
																AND	xa.DataSourceID	= @DATASOURCE_ID_MUREX
WHERE	cp.dtArchive	= @dt
--ORDER BY 1
ALTER TABLE #COUNTERPARTY ADD PRIMARY KEY (M_DSP_LBL)

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #COUNTERPARTY.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#CLEARING_HOUSES') IS NOT NULL
	DROP TABLE #CLEARING_HOUSES
CREATE TABLE #CLEARING_HOUSES (
	sName	VARCHAR(50)	PRIMARY KEY
)
INSERT #CLEARING_HOUSES
VALUES
	('CITIGROUP CME CLEARING BROKER ACCT')
	,('LONDON CLEARING HOUSE')
	,('MSUSA ICE CLEARING BROKER ACCOUNT')
	,('LCH AFFILIATES CLEARING')
	,('MHBK, TKY JSC CLEARING BROKER ACCT')
	,('LCH CCP')
	,('CME CCP')
	,('JSCC CCP')
	,('ICE US CCP')
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CLEARING_HOUSES.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @TRADEENDCODES TABLE (CodeID	NUMERIC(18,0))
INSERT @TRADEENDCODES
SELECT	CodeID
FROM	mcoredb..LookupCodes
WHERE	sCategory = 'OTC Trade Status'
AND		sCodeValue IN ('CANCELED','EXPIRED','EXERCISED','MATURED','TERMINATED')

SET @MSG = '@TRADEENDCODES inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

/*
TRUNCATE ALL 5 COLLAT TABLES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

####################################################################################################
FIRST:
	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	DECLARE @DATASOURCE_ID_APOLLO	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource
														WHERE	sSourceName				= 'Apollo')
	delete x
	from mcoredb..OTCTransaction		t
	join mcoredb..XRefOTCTransaction	x on x.TransactionID = t.TransactionID
	where	--x.DataSourceID = @DATASOURCE_ID_APOLLO
	--and 
	t.DataSourceID = @DATASOURCE_ID_MUREX
THEN:
	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	DECLARE @MINTRANID NUMERIC(18,0) = 2340000
	DECLARE @MAXTRANID NUMERIC(18,0) = 2418161
	DECLARE @TRANID NUMERIC(18,0) = @MINTRANID
	WHILE @TRANID < @MAXTRANID
	BEGIN
		DELETE s
		--select count(*), min(t.transactionid) mintran, max(t.transactionid) maxtran	--2225666	2418161
		from mcoredb..IRDPaymentSchedule	s
		join mcoredb..OTCTransaction		t	on t.transactionid = s.TransactionID
		where t.datasourceid = 239--@DATASOURCE_ID_MUREX
		--and t.transactionid between @TRANID and @TRANID + 10000
		and t.transactionid between 2400000 and 2418161
		SET @TRANID = @TRANID + 10000
		SELECT '@TRANID = ' + CONVERT(VARCHAR, @TRANID)
		PRINT '@TRANID = ' + CONVERT(VARCHAR, @TRANID)
	END
THEN:
	!!! RUN EXEC sp_fkeys 'OTCTransaction' FIRST IN ORDER TO DETERMINE IF THERE ARE OTHER TABLES KEYED ON dbo.OTCTransaction!!
	CASCADES:
		CancelSchedule
		CDSTransaction
		EquityDerivative
		FXDerivative
		FXPaymentSchedule
		IRDNonLinear
		IRDTransactionLeg
		OTCTransactionDaily
		OTCTransactionValuation
		TLock
		XRefOTCTransaction

	!!! RUN THIS TO SEE IF THERE ARE ANY NEW TRIGGERS TO DISABLE PRIOR TO DELETE (REENABLE AFTER DELETE!!!)
		select t.name, fk.name, tr.* 
		from sys.tables			t
		join sys.foreign_keys	fk	on fk.referenced_object_id	= t.object_id
		join sys.triggers		tr	on tr.parent_id				= fk.parent_object_id
		join sys.trigger_events	te	on te.object_id				= tr.object_id
		where	t.name			= 'otctransaction'
		and		te.type_desc	= 'DELETE'



	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	--THESE ARE KEYED ON mcoredb..FXDerivative:

	DELETE FS FROM mcoredb..FixingSchedule FS JOIN mcoredb..FXDerivative FX ON FX.FXDerivativeID = FS.FXDerivativeID JOIN mcoredb..OTCTransaction	T	ON T.TransactionID = FX.OTCTransactionID WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX

	DELETE FT FROM mcoredb..FXTransactionDaily FT JOIN mcoredb..FXDerivative	FD	ON FT.FXDerivativeID = FD.FXDerivativeID 
		JOIN mcoredb..OTCTransaction	T	ON T.TransactionID = FD.OTCTransactionID	WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX

	--THESE ARE CASCADE DELETES, BUT IT MAY BE FASTER TO DO THEM MANUALLY FIRST:

	DELETE CS FROM mcoredb..CancelSchedule			CS JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = CS.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE CD FROM mcoredb..CDSTransaction			CD JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = CD.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE ED FROM mcoredb..EquityDerivative		ED JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = ED.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE FX FROM mcoredb..FXDerivative			FX JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = FX.OTCTransactionID	WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE FP FROM mcoredb..FXPaymentSchedule		FP JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = FP.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE NL FROM mcoredb..IRDNonLinear			NL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = NL.OTCTransactionID	WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE TL FROM mcoredb..IRDTransactionLeg		TL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TL.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX

	DISABLE TRIGGER tr_UDOTCTransactionDaily ON  mcoredb..OTCTransactionDaily
	DELETE TD FROM mcoredb..OTCTransactionDaily		TD JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TD.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	ENABLE TRIGGER tr_UDOTCTransactionDaily ON  mcoredb..OTCTransactionDaily

	DISABLE TRIGGER tr_UDOTCTransactionValuation ON  mcoredb..OTCTransactionValuation
	DELETE TV FROM mcoredb..OTCTransactionValuation	TV JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TV.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	ENABLE TRIGGER tr_UDOTCTransactionValuation ON  mcoredb..OTCTransactionValuation

	DELETE TL FROM mcoredb..TLock					TL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TL.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	DELETE XR FROM mcoredb..XRefOTCTransaction		XR JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = XR.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX

	DISABLE TRIGGER delOTCTransaction_BK ON  mcoredb..OTCTransaction
	DELETE mcoredb..OTCTransaction WHERE DataSourceID = 239--@DATASOURCE_ID_MUREX	-- CASCADES TO XRefOTCTransaction, TLock
	ENABLE TRIGGER delOTCTransaction_BK ON  mcoredb..OTCTransaction
*/

SET @MSG = 'DECLARATIONS AND TEMP INSERTS FINISHED
'
IF @debug = 1 
BEGIN
	WAITFOR DELAY '00:00:00.001'	--Otherwise Declarations message can appear in the same millisecond as the #AGREEMENTS message and the log switches them
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
END
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

SET NOCOUNT OFF
MERGE mcoredb..OTCTransaction										TGT
USING (
	SELECT	-- * --xt.TransactionID, count(*)
		pt.CodeID ProdTypeID,						@DATASOURCE_ID_MUREX DataSourceID,														CASE t.M_TP_INT 
																																				WHEN 'Y' THEN tbi.AccountID 
																																				ELSE cp.AccountID END CP_ID,							tb.AccountID TradeBookID,
	--ts.sCodeValue,
	--t.M_TP_STATUS2,
	--t.M_AMD_STS2,
	--ev.M_H_EVENT,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 1----------------------------------------------------
		ts.CodeID TradeStatusID,					CASE	WHEN t.M_TP_STATUS2 IN ('LIVE','MKT_OP') THEN 1 ELSE 0 END Active,				CASE t.M_TP_INT WHEN 'Y' THEN 1 ELSE 0 END Internal,		t.M_TP_DTETRN,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 2----------------------------------------------------
		CASE
		WHEN t.M_CNT_TYPO	= 'Fwd Start Van FXD'
					THEN	t.M_TP_DTEFXGL
		WHEN t.M_CNT_TYPO	IN ('Avg Rate Fwd FXD','Average Asian FXD')
					THEN	t.M_TP_DTEFXGF
		WHEN t.M_TRN_FMLY	= 'CURR'
					THEN	t.M_TP_DTEEXP
		WHEN t.M_TRN_FMLY	= 'SCF'
					THEN	t.M_TP_DTETRN
		WHEN t.M_CNT_TYPO	= 'Treasury Lock'
					THEN	t.M_TP_DTETRN
		ELSE				t.M_TP_RTSD0
		END					dtEffective,			t.M_TP_DTEEXP dtMaturity,																CASE
																																			WHEN	t.M_TRN_FMLY <> 'CURR'
																																			AND		t.M_TP_RTMAT0 IS NULL
																																			THEN	t.M_TP_RTMAT1
																																			WHEN	t.M_TRN_FMLY IN ('CURR', 'SCF')
																																			THEN	t.M_TP_DTEEXP
																																			ELSE	t.M_TP_RTMAT0 END dtUnadjustedMaturity,				t.M_TP_NOMCUR sCurrency,
		CASE
		WHEN t.M_TRN_FMLY = 'SCF'
		THEN CASE t.M_TP_RTPR0
				WHEN 'P' THEN -t.M_TP_NOMINAL
				WHEN 'R' THEN t.M_TP_NOMINAL
				END
		ELSE t.M_TP_NOMINAL END dNotional,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 3----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATE)
							dtCleared,				CASE
													WHEN	ch.sName		IS NOT NULL
													THEN	cpc.AccountID
													WHEN	t.M_TP_STATUS2	= 'MKT_OP'
													AND		t.M_AMD_STS2	= 'OA' 
													AND		ev.M_H_EVENT	IN ('Counterpart assignment'
																				,'Counterpart amendment (FULL)') 
													THEN	cpo.AccountID	
													END									OriginalCPAccountID,								NULL ParentTransactionID,									CASE	WHEN ch.sName IS NOT NULL
																																																				THEN 1 ELSE 0 END Cleared,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 4----------------------------------------------------
		udf.M_CLR_BR sClearingBroker,				rpt.CodeID RiskProductTypeID,															NULL ClearingBrokerID,										NULL OriginatorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 5----------------------------------------------------
		t.M_PACKAGE sStrategy,						CASE
													WHEN agr.M_SIMM_AGR IS NULL THEN 0
													ELSE
														CASE agr.M_SIMM_AGR
															WHEN 'No SIMM agreement' 
															THEN 0 ELSE 1 END
														END						bSIMMEligible,												ag.AgreementID CollateralAgreementID,						CASE
																																																		WHEN t.M_TP_PFOLIO
																																																			IN ('ATD','ETD','HTD','ITD','STD','MIZS','MTB')
																																																		OR	aff.sRef IS NOT NULL
																																																			THEN 1 ELSE 0 END bAffiliate,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 6----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATE)
					dtClearingTimestamp,			TRY_PARSE(udf.M_CONF_TS AS DATE) dtConfirmationTimestamp,								TRY_PARSE(udf.M_EXEC_TS AS DATE) dtExecutionTimestamp,		CONVERT(NUMERIC, t.M_CONTRACT) ContractKey,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 7----------------------------------------------------
		t.M_CNT_VS2 ContractVersion,				ISNULL(t.M_CNTLEVTAD2, t.M_TP_DTESYS)  dtModification,									t.M_TP_TRADER sTrader,										IIF(s.M_MB_ID = 'Y', 1, 0) bMutualBreak,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 8----------------------------------------------------
		term.MAX_M_BKMANDEFFD
			dtMutualMandatoryTermination,			IIF(t.M_CNT_TYPO IN (SELECT TYPO FROM @callables),
															cb.CallableByID, NULL)	CancellableByID,										os.OptionStyleID CancelTypeID,								bt.OptionStyleID BreakTypeID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 9----------------------------------------------------
		oct.CollateralizationTypeID
			OurCollateralizationTypeID,				cct.CollateralizationTypeID CtpCollateralizationTypeID,									udf.M_EXEC_TYPE sExecutionVenue,							CASE
																																																		WHEN	t.M_CNTLIMPL2 <> ''
																																																		THEN	t.M_CNTLIMPL2
																																																		WHEN	t.M_CNTLIMPL2 = ''
																																																		AND		t.M_CNTLEVTL2 <> t.M_CNT_EVTL
																																																		THEN	t.M_CNTLEVTL2 END sLastEventName,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 10---------------------------------------------------
		t.M_INSTRUMENT sMXGeneratorLabel,			brk.AccountID BrokerAccountID,															IIF(t.M_CNT_TYPO = 'COF', 1, 0) bCOF,
		--------------------------------------------------------------------COLUMNS FOR #TX_IDs ONLY---------------------------------------------------------------------------------------------------------
		t.M_H_NB_MZ,								xt.TransactionID,																		t.M_NB_EXT,	/*M_H_ALT_ID,*/									ec.CodeID,
		t.M_H_DATA_DT2,								LEFT(udf.M_USI_ID, 50) M_USI_ID,														LEFT(udf.M_BETA_ID, 50) M_BETA_ID,							udf.M_USI_NS M_USI_NS,
		udf.M_CCP_TRN_ID,							t.M_TRN_FMLY,																			t.M_CNT_ORG
--into #otc --select m_h_alt_id, * from #otc
	FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP					t
	LEFT JOIN	@cof_typos															cof		ON	cof.M_TRN_FMLY				= t.M_TRN_FMLY
																							AND	cof.M_TRN_GRP				= t.M_TRN_GRP
																							AND	cof.M_TRN_TYPE				= t.M_TRN_TYPE
	JOIN		mcoredb..XRefLookup													xl		ON	RTRIM(LTRIM(xl.sRef))		= IIF(t.M_CNT_TYPO <> 'COF', RTRIM(LTRIM(t.M_CNT_TYPO)), cof.sTypo)
																							AND	xl.DataSourceID				= @DATASOURCE_ID_MUREX
																							AND	t.dtArchive					= @dt
	JOIN		mcoredb..LookupCodes												pt		ON	pt.CodeID					= xl.LookupCodeID
																							AND	pt.sCategory				= 'Product Type'
																							AND	pt.ParentID					IS NOT NULL	--THIS REMOVES THE PARENT 'SCF' PT BUT LEAVES THE CHILD
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP				s		ON	s.M_NB						= t.M_NB
																							AND	s.dtArchive					= @dt
	LEFT JOIN (
		SELECT		M_H_NB_MZ, MAX(M_BKMANDEFFD) MAX_M_BKMANDEFFD
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_EXE_SCHDL_REP
		WHERE		dtArchive	= @dt
		AND			M_TP_BREAK	= 'Y'
		GROUP BY	M_H_NB_MZ
	)																				term	ON	term.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.CallableBy											cb		ON	cb.sName					= t.M_TP_CANCBY
	LEFT JOIN	#CLEARING_HOUSES													ch		ON	ch.sName					= t.M_TP_CNTRP
	LEFT JOIN (
		SELECT	xlr.sRef, lc.CodeID
		FROM	mcoredb..XRefLookup		xlr
		JOIN	mcoredb..LookupCodes	lc	ON	lc.CodeID = xlr.LookupCodeID
		WHERE	xlr.DataSourceID		= @DATASOURCE_ID_MUREX
		AND		lc.sCategory			= 'Risk Product Type'
		AND		lc.bActive				= 1
		AND		lc.CodeID				<> @LEGACY_FRA_ID
	)																				rpt		ON	rpt.sRef					= t.M_CNT_TYPO
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_UDF_DEAL_REP					udf		ON	udf.M_UDF_REF				= t.M_UDF_REF2
																							AND	udf.dtArchive				= @dt
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP				agr		ON	agr.M_TRADE_NB				= t.M_NB
																							AND	agr.dtArchive				= @dt
	LEFT JOIN	mcoredb..Agreement													ag		ON	ag.sLegalName				= agr.M_NETTING_KEY
	LEFT JOIN (
		SELECT	M_IDENTITY
				,e.M_H_NB_MZ
				,M_H_EVENT
				,M_H_DATA_DT2
		FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP						e
		CROSS APPLY (	SELECT	MAX(M_IDENTITY) MAX_ID, M_H_NB_MZ
						FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
						WHERE	M_H_NB_MZ	= e.M_H_NB_MZ
						AND		dtArchive	= @dt
						GROUP BY M_H_NB_MZ
					) g
		WHERE	M_IDENTITY = MAX_ID
		AND		e.dtArchive	= @dt

		)																			ev		ON	ev.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN (
		SELECT	CodeID, sCodeValue
		FROM	mcoredb..LookupCodes
		WHERE	sCategory = 'OTC Trade Status'
	)																				ts		ON	ts.sCodeValue				= CASE
																																WHEN			t.M_TP_STATUS2		IN ('MKT_OP','LIVE')			THEN 'ACTIVE'
																																WHEN			t.M_TP_STATUS2		= 'DEAD'						THEN
																																	CASE
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		= 'Restructure'					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		IN ('Cancel and reissue'
																																										,'Counterpart amendment (FULL)'
																																										,'Portfolio modification'
																																										,'Allocation')				THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Expiry'						THEN 'EXPIRED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Exercise','Knock')			THEN 'EXERCISED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Unwind'
																																		AND		t.M_H_DATA_DT2		< t.M_TP_DTEEXP					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Counterpart assignment'
																																										,'Step out'
																																										,'Portfolio assignment'
																																										,'Netting')					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		(t.M_TRN_GRP		= 'FRA'
																																				AND t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR 
																																				ev.M_H_EVENT		NOT IN ('Counterpart assignment'
																																											,'Step out')
																																				AND t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				)													THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2		NOT IN ('CA','CL','NA')
																																		AND
																																				(t.M_TRN_GRP		= 'FRA'
																																				AND	t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	<> 'CURR'
																																				AND	t.M_TP_RTMAT0	IS NULL
																																				AND	t.M_TP_RTMAT1	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	= 'CURR'
																																				AND	t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				OR	t.M_TP_RTMAT0	<= t.M_H_DATA_DT2
																																				)													THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2			= 'CL'						THEN 'TERMINATED'
																																		ELSE															 'CANCELED'
																																	END
																																END
	LEFT JOIN	@TRADEENDCODES														ec		ON	ec.CodeID							= ts.CodeID
	LEFT JOIN	#CONTRACT															ct		ON	ct.M_CONTRACT						= LTRIM(RTRIM(t.M_TP_ROOTCNT))
																							AND	ct.M_TP_CNTRP						= LTRIM(RTRIM(t.M_TP_CNTRP))
	JOIN		#TRADEBOOK															tb		ON	tb.sRef								= LTRIM(RTRIM(t.M_TP_PFOLIO))
	LEFT JOIN	#COUNTERPARTY														cp		ON	cp.M_DSP_LBL						= LTRIM(RTRIM(t.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	#TRADEBOOK															tbi		ON	tbi.sRef							= LTRIM(RTRIM(t.M_TP_CNTRP))		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
	LEFT JOIN	#COUNTERPARTY														cpo		ON	cpo.M_DSP_LBL						= LTRIM(RTRIM(ct.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	#COUNTERPARTY														cpc		ON	cpc.M_DSP_LBL						= LTRIM(RTRIM(udf.M_BILAT_CTPY))	--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	mcoredb..XRefOTCTransaction											xt		ON	xt.sRef								= LTRIM(RTRIM(t.M_H_NB_MZ))
																							AND	xt.DataSourceID						= @DATASOURCE_ID_MUREX
																							AND xt.XRefOTCTradeTypeID				= @TRDREFTYPE_PRIMARY_ID
	LEFT JOIN	#AFFILIATE															aff		ON	aff.sRef							= cp.M_CODE		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
	LEFT JOIN	(
		SELECT		M_H_NB_MZ, MAX(M_V_DATE)	MAX_M_V_DATE
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
		WHERE		dtArchive	= @dt
		GROUP BY	M_H_NB_MZ
	)																				mods	ON	mods.M_H_NB_MZ						= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.OptionStyle											os		ON	os.sName					= CASE
																																WHEN	t.M_CNT_TYPO	IN (SELECT TYPO FROM @callables)
																																THEN	CASE t.M_TP_AE
																																		WHEN 'E' THEN 'European'
																																		WHEN 'A' THEN 'American'
																																		WHEN 'B' THEN 'Bermudan' END
																																END
	LEFT JOIN	mcoredb.refcode.OptionStyle											bt		ON	bt.sName					= CASE
																																WHEN	s.M_MB_ID = 'Y'
																																THEN	CASE s.M_MB_BRKMODE
																																		WHEN '0' THEN 'Bermudan'
																																		WHEN '1' THEN 'European' END
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								oct	ON	oct.sName						= CASE		udf.M_COL_TP_OUR
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								cct	ON	cct.sName						= CASE		udf.M_COL_TP_CTP
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	#COUNTERPARTY														brk	ON	brk.M_DSP_LBL					= LTRIM(RTRIM(t.M_TP_BROLBL0))
--where xt.TransactionID in (1670912,1671178)
--group by xt.TransactionID
--having count(*)>1
	)																		SRC		ON	SRC.TransactionID					= TGT.TransactionID
WHEN NOT MATCHED THEN
	INSERT
		(ProductTypeID,							DataSourceID,																			CPAccountID,												TradingAccountID,
		TradeStatusID,							bActive,																				bInternal,													dtTrade,
		dtEffective,							dtMaturity,																				dtUnadjustedMaturity,										sCurrency,
		dNotional,
		dtCleared,								OriginalCPAccountID,																	ParentTransactionID,										bCleared,
		sClearingBroker,						RiskProductTypeID,																		ClearingBrokerID,											OriginatorID,
		sStrategy,								bSIMMEligible,																			CollateralAgreementID,										bAffiliate,
		dtClearingTimestamp,					dtConfirmationTimestamp,																dtExecutionTimestamp,										ContractKey,
		ContractVersion,						dtModification,																			sTrader,													bMutualBreak,
		dtMutualMandatoryTermination,			CancellableByID,																		CancelTypeID,												BreakTypeID,
		OurCollateralizationTypeID,				CtpCollateralizationTypeID,																sExecutionVenue,											sLastEventName,
		sMXGeneratorLabel,						BrokerAccountID,																		bCOF)
	VALUES
		(ProdTypeID,							DataSourceID,																			CP_ID,														TradeBookID,
		TradeStatusID,							Active,																					Internal,													M_TP_DTETRN,
		dtEffective,							dtMaturity,																				dtUnadjustedMaturity,										sCurrency,
		dNotional,
		dtCleared,								OriginalCPAccountID,																	ParentTransactionID,										Cleared,
		sClearingBroker,						RiskProductTypeID,																		ClearingBrokerID,											OriginatorID,
		sStrategy,								bSIMMEligible,																			CollateralAgreementID,										bAffiliate,
		dtClearingTimestamp,					dtConfirmationTimestamp,																dtExecutionTimestamp,										ContractKey,
		ContractVersion,						dtModification,																			sTrader,													bMutualBreak,
		dtMutualMandatoryTermination,			CancellableByID,																		CancelTypeID,												BreakTypeID,
		OurCollateralizationTypeID,				CtpCollateralizationTypeID,																sExecutionVenue,											sLastEventName,
		sMXGeneratorLabel,						BrokerAccountID,																		bCOF)
WHEN MATCHED THEN
	UPDATE SET 
		ProductTypeID					= IIF(SRC.CodeID IS NULL, SRC.ProdTypeID					, TGT.ProductTypeID)
		,DataSourceID					= IIF(SRC.CodeID IS NULL, SRC.DataSourceID					, TGT.DataSourceID)
		,CPAccountID					= IIF(SRC.CodeID IS NULL, SRC.CP_ID							, TGT.CPAccountID)
		,TradingAccountID				= IIF(SRC.CodeID IS NULL, SRC.TradeBookID					, TGT.TradingAccountID)
		,TradeStatusID					= IIF(SRC.CodeID	IS NOT NULL 
											AND TGT.bActive	= 0
																, TGT.TradeStatusID					, SRC.TradeStatusID)
		,bActive						= SRC.Active
		,bInternal						= IIF(SRC.CodeID IS NULL, SRC.Internal						, TGT.bInternal)
		,dtTrade						= IIF(SRC.CodeID IS NULL, SRC.M_TP_DTETRN					, TGT.dtTrade)
		,dtEffective					= IIF(SRC.CodeID IS NULL, SRC.dtEffective					, TGT.dtEffective)
		,dtMaturity						= IIF(SRC.CodeID IS NULL, SRC.dtMaturity					, TGT.dtMaturity)
		,dtUnadjustedMaturity			= IIF(SRC.CodeID IS NULL, SRC.dtUnadjustedMaturity			, TGT.dtUnadjustedMaturity)
		,sCurrency						= IIF(SRC.CodeID IS NULL, SRC.sCurrency						, TGT.sCurrency)
		,dNotional						= IIF(SRC.CodeID IS NULL, SRC.dNotional						, TGT.dNotional)
		,dtCleared						= IIF(SRC.CodeID IS NULL, SRC.dtCleared						, TGT.dtCleared)
		,OriginalCPAccountID			= IIF(SRC.CodeID IS NULL, SRC.OriginalCPAccountID			, TGT.OriginalCPAccountID)
		,ParentTransactionID			= IIF(SRC.CodeID IS NULL, SRC.ParentTransactionID			, TGT.ParentTransactionID)
		,bCleared						= IIF(SRC.CodeID IS NULL, SRC.Cleared						, TGT.bCleared)
		,sClearingBroker				= IIF(SRC.CodeID IS NULL, SRC.sClearingBroker				, TGT.sClearingBroker)
		,RiskProductTypeID				= IIF(SRC.CodeID IS NULL, SRC.RiskProductTypeID				, TGT.RiskProductTypeID)
		,ClearingBrokerID				= IIF(SRC.CodeID IS NULL, SRC.ClearingBrokerID				, TGT.ClearingBrokerID)
		,OriginatorID					= IIF(SRC.CodeID IS NULL, SRC.OriginatorID					, TGT.OriginatorID)
		,sStrategy						= IIF(SRC.CodeID IS NULL, SRC.sStrategy						, TGT.sStrategy)
		,bSIMMEligible					= IIF(SRC.CodeID IS NULL, SRC.bSIMMEligible					, TGT.bSIMMEligible)
		,CollateralAgreementID			= IIF(SRC.CodeID IS NULL, SRC.CollateralAgreementID			, TGT.CollateralAgreementID)
		,bAffiliate						= IIF(SRC.CodeID IS NULL, SRC.bAffiliate					, TGT.bAffiliate)
		,dtClearingTimestamp			= IIF(SRC.CodeID IS NULL, SRC.dtClearingTimestamp			, TGT.dtClearingTimestamp)
		,dtConfirmationTimestamp		= IIF(SRC.CodeID IS NULL, SRC.dtConfirmationTimestamp		, TGT.dtConfirmationTimestamp)
		,dtExecutionTimestamp			= IIF(SRC.CodeID IS NULL, SRC.dtExecutionTimestamp			, TGT.dtExecutionTimestamp)
		,ContractKey					= IIF(SRC.CodeID IS NULL, SRC.ContractKey					, TGT.ContractKey)
		,ContractVersion				= SRC.ContractVersion
		,dtModification					= CASE
											WHEN TGT.bActive = SRC.Active AND TGT.bActive = 1 THEN SRC.dtModification 
											WHEN TGT.bActive = SRC.Active AND TGT.bActive = 0 THEN TGT.dtModification
											ELSE SRC.M_H_DATA_DT2 END
		,sTrader						= IIF(SRC.CodeID IS NULL, SRC.sTrader						, TGT.sTrader)
		,bMutualBreak					= IIF(SRC.CodeID IS NULL, SRC.bMutualBreak					, TGT.bMutualBreak)
		,dtMutualMandatoryTermination	= IIF(SRC.CodeID IS NULL, SRC.dtMutualMandatoryTermination	, TGT.dtMutualMandatoryTermination)
		,CancellableByID				= IIF(SRC.CodeID IS NULL, SRC.CancellableByID				, TGT.CancellableByID)
		,CancelTypeID					= IIF(SRC.CodeID IS NULL, SRC.CancelTypeID					, TGT.CancelTypeID)
		,BreakTypeID					= IIF(SRC.CodeID IS NULL, SRC.BreakTypeID					, TGT.BreakTypeID)
		,OurCollateralizationTypeID		= IIF(SRC.CodeID IS NULL, SRC.OurCollateralizationTypeID	, TGT.OurCollateralizationTypeID)
		,CtpCollateralizationTypeID		= IIF(SRC.CodeID IS NULL, SRC.CtpCollateralizationTypeID	, TGT.CtpCollateralizationTypeID)
		,sExecutionVenue				= IIF(SRC.CodeID IS NULL, SRC.sExecutionVenue				, TGT.sExecutionVenue)
		,sLastEventName					= IIF(SRC.CodeID IS NULL, SRC.sLastEventName				, TGT.sLastEventName)
		,sMXGeneratorLabel				= IIF(SRC.CodeID IS NULL, SRC.sMXGeneratorLabel				, TGT.sMXGeneratorLabel)
		,BrokerAccountID				= IIF(SRC.CodeID IS NULL, SRC.BrokerAccountID				, TGT.BrokerAccountID)
		,bCOF							= IIF(SRC.CodeID IS NULL, SRC.bCOF							, TGT.bCOF)

OUTPUT	--SAVE UPSERTED IDs IN @TX_IDs TABLE VAR
	$action, inserted.TransactionID, SRC.M_H_NB_MZ, SRC.M_NB_EXT/*M_H_ALT_ID*/, 
			SRC.M_USI_ID, SRC.M_USI_NS, SRC.M_BETA_ID, SRC.M_CCP_TRN_ID, SRC.M_TRN_FMLY, SRC.M_CNT_ORG, IIF(SRC.CodeID IS NULL, 1, 0)	-- = bLive
INTO #TX_IDs;
SET @InsertCount = (SELECT COUNT(*) FROM #TX_IDs WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #TX_IDs WHERE Action = 'UPDATE')

SET @MSG = 'Finished trade MERGE: @InsertCount = ' + CONVERT(VARCHAR, @InsertCount) + ', @UpdateCount = ' + CONVERT(VARCHAR, @UpdateCount)
				+ ', Total rows affected = ' + CONVERT(VARCHAR, @InsertCount + @UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG

SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer @Finish MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer @Finish MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

ALTER TABLE #TX_IDs ADD PRIMARY KEY (TransactionID)
CREATE NONCLUSTERED INDEX [IX_#TX_IDs_M_H_NB_MZ] ON #TX_IDs
(
	M_H_NB_MZ
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--select*from #TX_IDs where TransactionID=1761157

SET @MSG = 'Added PK to #TX_IDs'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--	NOT SURE WHY UNIQUE CONSTRAINT WAS ADDED, NO FURTHER ROWS INSERTED OR UPDATED BEYOND THIS POINT
--IF OBJECT_ID('UQ_#TX_IDs_M_H_NB_MZ') IS NOT NULL AND OBJECT_ID('#TX_IDs') IS NOT NULL
--BEGIN
--	ALTER TABLE #TX_IDs
--	DROP CONSTRAINT UQ_#TX_IDs_M_H_NB_MZ
--END
--ALTER TABLE #TX_IDs ADD CONSTRAINT UQ_#TX_IDs_M_H_NB_MZ UNIQUE (M_H_NB_MZ)
--SET @MSG = 'Added unique constraint to #TX_IDs.M_H_NB_MZ'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer to create PK and index on #TX_IDs:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer to create PK and index on #TX_IDs:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

--UPDATE BUSINESS KEY
UPDATE	o
SET		sBusinessKey = dbo.fnBusinessKey(o.TransactionID, 'O')
FROM	XRefOTCTransaction				x
JOIN	OTCTransaction					o	ON	o.TransactionID				= x.TransactionID
											AND o.DataSourceID				= @DATASOURCE_ID_MUREX
											AND x.XRefOTCTradeTypeID		= @TRDREFTYPE_PRIMARY_ID
JOIN	refcode.OTCXRefTradeRefType		rt	ON	rt.OTCXRefTradeRefTypeID	= x.XRefOTCTradeTypeID
WHERE	rt.sName	= 'Primary ID'
AND		o.sBusinessKey IS NULL

SET @MSG = 'Updated sBusinessKey in dbo.OTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IF OBJECT_ID('tempdb..#XREF_MERGE') IS NOT NULL
	DROP TABLE #XREF_MERGE
CREATE TABLE #XREF_MERGE (
	Action			NVARCHAR(10)
)

MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for M_H_NB_MZ
USING (
	SELECT
		TransactionID				TransactionID
		,@DATASOURCE_ID_MUREX		DataSourceID
		,RTRIM(M_H_NB_MZ)			sRef
		,@TRDREFTYPE_PRIMARY_ID		XRefOTCTradeTypeID
		,bLive						bLive						
	FROM #TX_IDs																			--WHERE Action = 'INSERT'
)									SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
										AND	SRC.DataSourceID		= TGT.DataSourceID
										AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for M_NB_EXT/DEAL_REF		--was M_H_ALT_ID
USING (
	SELECT
		TransactionID							TransactionID
		,@DATASOURCE_ID_APOLLO					DataSourceID
		,CONVERT(VARCHAR(50), a.DEAL_NUMBER)	sRef		--M_NB_EXT = DEAL_REF -> DEAL_NUMBER gets inserted into sRef
		,@TRDREFTYPE_PRIMARY_ID					XRefOTCTradeTypeID
		,bLive									bLive
	FROM #TX_IDs										t									--WHERE Action = 'INSERT'
	JOIN mcoredb.stage.MDR_APOLLO_DEAL_REF_LOOKUP		a	ON	a.DEAL_REF = t.M_NB_EXT
	WHERE M_NB_EXT IS NOT NULL AND M_NB_EXT > 0
	--M_H_ALT_ID NOT IN('', '0')
)									SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
										AND	SRC.DataSourceID		= TGT.DataSourceID
										AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= SRC.sRef	--IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' APOLLO rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' APOLLO rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for M_USI_NS + M_USI_ID
USING (
	SELECT
		TransactionID							TransactionID
		,@DATASOURCE_ID_MUREX					DataSourceID
		,RTRIM(M_USI_NS) + RTRIM(M_USI_ID)		sRef
		,@TRDREFTYPE_USI_ID						XRefOTCTradeTypeID
		,bLive									bLive						
	FROM #TX_IDs																			--WHERE Action = 'INSERT'
	WHERE	M_USI_ID IS NOT NULL
	AND		RTRIM(M_USI_ID) <> ''
	AND		M_USI_NS IS NOT NULL
	AND		RTRIM(M_USI_NS) <> ''
)									SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
										AND	SRC.DataSourceID		= TGT.DataSourceID
										AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX USI rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX USI rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for M_BETA_ID
USING (
	SELECT
		TransactionID				TransactionID
		,@DATASOURCE_ID_MARKIT		DataSourceID
		,RTRIM(M_BETA_ID)			sRef
		,@TRDREFTYPE_PRIMARY_ID		XRefOTCTradeTypeID
		,bLive						bLive						
	FROM #TX_IDs																			--WHERE Action = 'INSERT'
	WHERE	M_BETA_ID IS NOT NULL
	AND		RTRIM(M_BETA_ID) <> ''
	AND		M_TRN_FMLY = 'IRD'
)									SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
										AND	SRC.DataSourceID		= TGT.DataSourceID
										AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX BETA rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX BETA rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE
--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for CCP_ID
USING (
	SELECT
		TransactionID				TransactionID
		,@DATASOURCE_ID_MUREX		DataSourceID
		,RTRIM(M_CCP_TRN_ID)		sRef
		,@TRDREFTYPE_CCP_ID			XRefOTCTradeTypeID
		,bLive						bLive						
	FROM #TX_IDs																			--WHERE Action = 'INSERT'
	WHERE	M_CCP_TRN_ID		IS NOT NULL
	AND		RTRIM(M_CCP_TRN_ID)	<> ''
)									SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
										AND	SRC.DataSourceID		= TGT.DataSourceID
										AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX CCP rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX CCP rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
MERGE mcoredb..XRefOTCTransaction	TGT				--XRef entry for ORIGINAL MUREX CONTRACT ID
USING (
	SELECT
		TransactionID					TransactionID
		,@DATASOURCE_ID_MUREX			DataSourceID
		,CONVERT(VARCHAR, M_CNT_ORG)	sRef
		,@TRDREFTYPE_LINK_ID			XRefOTCTradeTypeID
		,bLive							bLive						
	FROM #TX_IDs																				--WHERE Action = 'INSERT'
)										SRC	ON	SRC.TransactionID		= TGT.TransactionID		--SRC.[Action] = 'UPDATE' --don't think we need to worry about Action value
											AND	SRC.DataSourceID		= TGT.DataSourceID
											AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action INTO #XREF_MERGE;
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')

SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX CONTRACT ID rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX CONTRACT ID rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
TRUNCATE TABLE #XREF_MERGE



--###################################################################################################################################################################################################################################################

--UPDATE mcoredb..OTCTransaction
--SET ParentTransactionID = NULL
--WHERE DataSourceID = 239

--DECLARE @dt					DATE = '20180704'
--DECLARE @DATASOURCE_ID_MUREX INT = 239
UPDATE	t
SET		t.ParentTransactionID	= tp.TransactionID
FROM	mcoredb..OTCTransaction									t
JOIN	mcoredb..XRefOTCTransaction								xt	ON	xt.TransactionID	= t.TransactionID
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		m	ON	m.M_H_NB_MZ			= xt.sRef
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s	ON	s.M_NB				= m.M_NB
JOIN	mcoredb..XRefOTCTransaction								xtp	ON	xtp.sRef			= CASE
																								WHEN m.M_TP_INT = 'N'
																								THEN CONVERT(VARCHAR, s.M_CREATOR)
																								WHEN m.M_TP_INT = 'Y'
																								THEN CASE m.M_TP_BUY
																										WHEN 'B' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_1'
																										WHEN 'S' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_2'
																										END
																								END
JOIN	mcoredb..OTCTransaction									tp	ON	tp.TransactionID	= xtp.TransactionID
WHERE	t.DataSourceID			= @DATASOURCE_ID_MUREX
AND		xt.DataSourceID			= @DATASOURCE_ID_MUREX
AND		tp.DataSourceID			= @DATASOURCE_ID_MUREX
AND		xtp.DataSourceID		= @DATASOURCE_ID_MUREX
AND		m.dtArchive				= @dt
AND		s.dtArchive				= @dt

SET @MSG = 'Updated OTCTransaction ParentTransactionIDs.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



DECLARE @STRIKETYPOLIST	TABLE	(StrikeType VARCHAR(21))	--matches M_CNT_TYPO char(21)
INSERT	@STRIKETYPOLIST
VALUES
	('IR CapFl Call CMS'),
	('IR CapFl Call CMS sp'),
	('IR CapFloor Callable'),
	('IRS Cap Floor'),
	('IRS Cap Floor CMS'),
	('IRS Cap Floor CMS sp')
SET @MSG = 'Inserted @STRIKETYPOLIST values.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @MUREXPAYOUTTYPE	TABLE	(MXID NUMERIC(2,0), MxPayoutType VARCHAR(50))	--matches s.M_LN_PAYOUT & refcode.PayOutType sName
INSERT	@MUREXPAYOUTTYPE
VALUES
	(1,		'Cap')
	,(2,	'Floor')
	,(3,	'Collar')
	,(4,	'Capped rate')
	,(5,	'Floored rate')
	,(6,	'Collared rate')
	,(7,	'Strangle')
	,(9,	'Straddle')
	,(11,	'Cap spread')
	,(13,	'Floor spread')
SET @MSG = 'Inserted @MUREXPAYOUTTYPE values.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)


--PRINT 'Timer after INSERT Apollo in XRefOTCTransaction:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer after INSERT Apollo in XRefOTCTransaction:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

--MERGE MUREX TRADE LEGS INTO IRDTransactionLeg %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

--LEG 0 MERGE, ALWAYS THE LESSER OF THE TWO TransactionLegID's
--SET NOCOUNT ON

MERGE mcoredb..IRDTransactionLeg								TGT
USING (
	SELECT --*
	--n.TransactionID
	----,n.M_H_NB_MZ
	--,CASE t.M_TP_CMLDIR0 WHEN 'PAY' THEN 1 ELSE 0 END
	--,COUNT(*)

		n.TransactionID,															CASE
																						WHEN t.M_TRN_GRP <> 'CF'
																						THEN
																							CASE t.M_TP_CMLDIR0 WHEN 'PAY' THEN 1 ELSE 0 END
																						ELSE 0
																					END bPay,																		CASE t.M_TP_CMLNAT0
																																										WHEN 'FIX'
																																										THEN 1 ELSE 0 END bFixed,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 1----------------------------------------------------
		CASE
		WHEN	t.M_TRN_GRP		= 'CS'
		AND		t.M_TP_RTINPC0	<> t.M_TP_NOMCUR
		THEN	t.M_TP_QTYEQ
		ELSE	t.M_TP_NOMINAL
		END												dNotional,					CASE
																					WHEN t.M_TRN_GRP = 'CS'
																					THEN t.M_TP_RTINPC0
																					ELSE t.M_TP_NOMCUR END sCurrency,												xl.LookupCodeID DayCountID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 2--------------------------------------------------------
		tu.CodeID PayFreqTermID /*TU=D,M*/,											CASE
																					WHEN RTRIM(t.M_TP_RTMFRP0) = '0Y' THEN
																						SUBSTRING(LTRIM(t.M_TP_RTDSC0), 1,
																							CHARINDEX(' ', LTRIM(t.M_TP_RTDSC0)) - 2) --' 12M IM ' => '12'
																					WHEN t.M_TP_RTMFRP0 = '0od' THEN NULL
																					WHEN t.M_TP_RTMFRP0 LIKE '[0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP0, 1, 1)
																					WHEN t.M_TP_RTMFRP0 LIKE '[0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP0, 1, 2)
																					WHEN t.M_TP_RTMFRP0 LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP0, 1, 3)
																					END iPayFreqPeriod,																CASE t.M_TP_CMLNAT0
																																									WHEN 'FIX'
																																									THEN IIF(ABS(t.M_TP_RTMRTE0) > 999.999999, 
																																													NULL, t.M_TP_RTMRTE0) END dFixedRate,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 3--------------------------------------------------------
		fl.FloatingIndexID,															CASE
																					WHEN RTRIM(t.M_TP_RTMFRC0) = '0Y' THEN
																						SUBSTRING(LTRIM(t.M_TP_RTDSC0), 1,
																							CHARINDEX(' ', LTRIM(t.M_TP_RTDSC0)) - 2) --' 12M IM ' => '12'
																					WHEN t.M_TP_RTMFRC0 = '0od' THEN NULL
																					WHEN t.M_TP_RTMFRC0 LIKE '[0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC0, 1, 1)
																					WHEN t.M_TP_RTMFRC0 LIKE '[0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC0, 1, 2)
																					WHEN t.M_TP_RTMFRC0 LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC0, 1, 3)
																					END iFloatingIndexPeriod,														fit.CodeID FloatingIndexTermID/*TU=D,M*/,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 4--------------------------------------------------------
		t.M_TP_RTMMRG0 dFloatingSpread,												t.M_TP_RTFFIX0 dFirstResetRate,													bus.BusDayRuleModifierID BusDayRuleModifierID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 5--------------------------------------------------------
		bus.BusDayRuleConventionID BusDayRuleConventionID,							t.M_TP_RTMCLC0 sBusDayRuleCalendar,												IIF(gd.M_ROLLCONV0 = 'Indifferent', 0, 1) BusDayAdjust,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 6--------------------------------------------------------
		NULL RoundFunctionID,														NULL iRoundDigit,																CASE t.M_TP_RTPAYM0
																																									WHEN 'In arrears'
																																									THEN 1 ELSE 0 END bArrear,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 7--------------------------------------------------------
		--gd.M_ROLL_DATE0 sRollDay,													
		t.M_TP_RTMCLF0 sResetCalendarConv,											t.M_TP_RTRFCT0 dRateFactor,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 8--------------------------------------------------------
		t.M_TP_RTCUR0 sPaymentCurrency,												bt.BarrierTypeID,																t.M_TP_OBAR1 dBarrierLevel,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 9-------------------------------------------------------
		CASE t.M_TP_RTRNG02
		WHEN 'NO'	THEN 0 
		WHEN 'YES'	THEN 1 END bRangeApplicable,									s.M_INDEXED0 bFXReset,															IIF(t.M_CNT_TYPO IN ('Treasury Lock','Total Return Swap BD'),
																																											t.M_TP_YIELD, NULL) dYield,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 10-------------------------------------------------------
		/*IIF(t.M_CNT_TYPO IN ('Treasury Lock','Total Return Swap BD'),
									t.M_H_CLEAN, NULL)*/ NULL dCleanPrice,			IIF(t.M_CNT_TYPO IN ('Treasury Lock','Total Return Swap BD'),
																												t.M_H_DIRTY, NULL) dDirtyPrice,						CASE s.M_INDEXED0 WHEN 1 THEN s.M_IND_LAB END
																																																	sFXResetIndex,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 11-------------------------------------------------------
		cm.CompoundingMethodID,														CASE WHEN sto.StrikeType IS NOT NULL THEN
																						s.M_LN_STRIKE0 END dStrike1,												CASE WHEN sto.StrikeType IS NOT NULL THEN
																																													s.M_LN_SEC_K0 END dStrike2,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 12-------------------------------------------------------
		CASE WHEN sto.StrikeType IS NOT NULL THEN st.StrikeTypeID END
														StrikeTypeID,				CASE
																					WHEN sch.M_DT_UPFIX0 = 'Y' THEN 0
																					WHEN sch.M_DT_UPFIX0 = 'N' THEN 1 END bFixingArrear,							i.IssueID IssueID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 13-------------------------------------------------------
		t.M_TP_RTDSC0 sScheduleGeneratorLabel,										t.M_PLIRECRV02 sEstimationCurve,												t.M_PLIRDCRV02 sDiscountingCurve,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 14-------------------------------------------------------
		sita1.StubIndexTenorID InArrears1StubIndexTenorID,							sita2.StubIndexTenorID InArrears2StubIndexTenorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 15-------------------------------------------------------
		sitf1.StubIndexTenorID Front1StubIndexTenorID,								sitf2.StubIndexTenorID Front2StubIndexTenorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 16-------------------------------------------------------
		ec.CodeID
		--select count(*)
	FROM  #TX_IDs														n
	JOIN		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		t		ON	n.M_H_NB_MZ				= t.M_H_NB_MZ
																				AND	t.dtArchive				= @dt
	JOIN		mcoredb..OTCTransaction									otc		ON	otc.TransactionID		= n.TransactionID
	LEFT JOIN	mcoredb..XRefLookup										xl		ON	xl.sRef					= t.M_TP_RTMCNV0	--DayCount
																				AND	xl.DataSourceID			= @DATASOURCE_ID_MUREX
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_GEN_DT_REP		gd		ON	gd.M_NB					= t.M_NB
																				AND	gd.dtArchive			= @dt
	LEFT JOIN	@BusDayRuleMurexBridge									bus		ON	bus.MxDesc				= gd.M_ROLLCONV0
	LEFT JOIN	mcoredb.refcode.FloatingIndex							fl		ON	fl.sName				= t.M_TP_RTMNDD0
	LEFT JOIN	mcoredb..Issue											i		ON	i.sIsin					= t.M_TP_SECCOD
	LEFT JOIN	mcoredb..LookupCodes									tu		ON	tu.sCodeValue			= CASE
																												WHEN RTRIM(t.M_TP_RTMFRP0) = '0Y' THEN
																													SUBSTRING(LTRIM(t.M_TP_RTDSC0),
																														CHARINDEX(' ', LTRIM(t.M_TP_RTDSC0)) - 1, 1) --' 12M IM ' => 'M'
																												WHEN RTRIM(t.M_TP_RTMFRP0) = '0od' THEN 'ZC'
																												WHEN RTRIM(t.M_TP_RTMFRP0) LIKE '[A-Z]%' THEN
																													RTRIM(t.M_TP_RTMFRP0)
																												WHEN RTRIM(t.M_TP_RTMFRP0) LIKE '[0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP0)
																															,LEN(RTRIM(t.M_TP_RTMFRP0)) - 1)
																												WHEN RTRIM(t.M_TP_RTMFRP0) LIKE '[0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP0)
																															,LEN(RTRIM(t.M_TP_RTMFRP0)) - 2)
																												WHEN RTRIM(t.M_TP_RTMFRP0) LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP0)
																															,LEN(RTRIM(t.M_TP_RTMFRP0)) - 3)
																												END	--D/M/OD/Q/W/Y/ZC
																				AND	tu.sCategory			= 'Tenor Unit'
	LEFT JOIN	mcoredb..LookupCodes									fit		ON	fit.sCodeValue			= CASE
																												WHEN RTRIM(t.M_TP_RTMFRC0) = '0Y' THEN
																													SUBSTRING(LTRIM(t.M_TP_RTDSC0),
																														CHARINDEX(' ', LTRIM(t.M_TP_RTDSC0)) - 1, 1) --' 12M IM ' => 'M'
																												WHEN RTRIM(t.M_TP_RTMFRC0) = '0od' THEN 'ZC'
																												WHEN RTRIM(t.M_TP_RTMFRC0) LIKE '[A-Z]%' THEN
																													RTRIM(t.M_TP_RTMFRC0)
																												WHEN RTRIM(t.M_TP_RTMFRC0) LIKE '[0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC0)
																															,LEN(RTRIM(t.M_TP_RTMFRC0)) - 1)
																												WHEN RTRIM(t.M_TP_RTMFRC0) LIKE '[0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC0)
																															,LEN(RTRIM(t.M_TP_RTMFRC0)) - 2)
																												WHEN RTRIM(t.M_TP_RTMFRC0) LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC0)
																															,LEN(RTRIM(t.M_TP_RTMFRC0)) - 3)
																												END	--D/M/OD/Q/W/Y/ZC
																				AND	fit.sCategory			= 'Tenor Unit'
	LEFT JOIN	mcoredb.refcode.BarrierType								bt		ON	bt.sName				= t.M_TP_OBARTYP
	LEFT JOIN	mcoredb.refcode.CompoundingMethod						cm		ON	cm.sName				= CASE t.M_TP_RTCMP0
																												WHEN 'No compounding'	THEN 'None'
																												WHEN '(I+M) at I'		THEN 'Flat'
																												WHEN '(I+M) at (I+M)'	THEN 'Straight'
																												WHEN '(I at I) + M'		THEN 'SpreadExclusive'
																												END
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s		ON	s.M_NB					= t.M_NB
																				AND	s.dtArchive				= @dt
	LEFT JOIN	@TRADEENDCODES											ec		ON	ec.CodeID				= otc.TradeStatusID
	LEFT JOIN	@STRIKETYPOLIST											sto		ON	sto.StrikeType			= t.M_CNT_TYPO
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP		sch		ON	sch.M_H_NB_MZ			= t.M_H_NB_MZ
																				AND	sch.M_DT_LEG0			= 0
																				AND	sch.M_H_PERID_ID		= 0
																				AND	sch.M_DT_PHASE			= 0
																				AND	sch.dtArchive			= @dt
--where n.TransactionID=1761157 
	LEFT JOIN	@MUREXPAYOUTTYPE										po		ON	po.MXID					= s.M_LN_PAYOUT0
	LEFT JOIN	mcoredb.refcode.StrikeType								st		ON	st.sName				= po.MxPayoutType
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sita1	ON	sita1.sName				= t.M_TP_RTBSFI0
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sita2	ON	sita2.sName				= t.M_TP_RTBSSI0
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sitf1	ON	sitf1.sName				= t.M_TP_RTFSFI0
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sitf2	ON	sitf2.sName				= t.M_TP_RTFSSI0
	WHERE		(t.M_TRN_GRP			IN ('IRS','ASWP','CS','OSWP','FRA','CF','CD','RTRN','SWFUT','LN_BR')
				OR	t.M_TRN_GRP			= 'BOND'
					AND t.M_TRN_TYPE	= 'LOCK')
--and n.TransactionID=1761157
--group by n.TransactionID,
--	--n.M_H_NB_MZ,
--	CASE t.M_TP_CMLDIR0 WHEN 'PAY' THEN 1 ELSE 0 END
--HAVING COUNT(*)>1
--ORDER by	n.TransactionID
)																		SRC		ON	SRC.TransactionID		= TGT.TransactionID
																				AND	SRC.bPay				= TGT.bPay
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID,																bPay,																			bFixed,
		dNotional,																	sCurrency,																		DayCountID,--30/360 etc.
		PayFreqTermID/*TU=D,M*/,													iPayFreqPeriod,																	dFixedRate,
		FloatingIndexID,															iFloatingIndexPeriod,															FloatingIndexTermID/*TU=D,M*/,
		dFloatingSpread,															dFirstResetRate,																BusDayRuleModifierID,
		BusDayRuleConventionID,														sBusDayRuleCalendar,															BusDayAdjust,
		RoundFunctionID,															iRoundDigit,																	bArrear,
		--sRollDay,																	
		sResetCalendarConv,																dRateFactor,
		sPaymentCurrency,															BarrierTypeID,																	dBarrierLevel,
		bRangeApplicable,															bFXReset,																		dYield,
		dCleanPrice,																dDirtyPrice,																	sFXResetIndex,
		CompoundingMethodID,														dStrike1,																		dStrike2,
		StrikeTypeID,																bFixingArrear,																	IssueID,
		sScheduleGeneratorLabel,													sEstimationCurve,																sDiscountingCurve,
		InArrears1StubIndexTenorID,													InArrears2StubIndexTenorID,
		Front1StubIndexTenorID,														Front2StubIndexTenorID)
	VALUES
		(TransactionID,																bPay,																			bFixed,
		dNotional,																	sCurrency,																		DayCountID,--30/360 etc.
		PayFreqTermID/*TU=D,M*/,													iPayFreqPeriod,																	dFixedRate,
		FloatingIndexID,															iFloatingIndexPeriod,															FloatingIndexTermID/*TU=D,M*/,
		dFloatingSpread,															dFirstResetRate,																BusDayRuleModifierID,
		BusDayRuleConventionID,														sBusDayRuleCalendar,															BusDayAdjust,
		RoundFunctionID,															iRoundDigit,																	bArrear,
		--sRollDay,																	
		sResetCalendarConv,																dRateFactor,
		sPaymentCurrency,															BarrierTypeID,																	dBarrierLevel,
		bRangeApplicable,															bFXReset,																		dYield,
		dCleanPrice,																dDirtyPrice,																	sFXResetIndex,
		CompoundingMethodID,														dStrike1,																		dStrike2,
		StrikeTypeID,																bFixingArrear,																	IssueID,
		sScheduleGeneratorLabel,													sEstimationCurve,																sDiscountingCurve,
		InArrears1StubIndexTenorID,													InArrears2StubIndexTenorID,
		Front1StubIndexTenorID,														Front2StubIndexTenorID)
WHEN MATCHED THEN
	UPDATE SET
		bFixed						= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFixed						ELSE TGT.bFixed END
		,dNotional					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dNotional					ELSE TGT.dNotional END
		,sCurrency					= CASE WHEN SRC.CodeID IS NULL THEN SRC.sCurrency					ELSE TGT.sCurrency END
		,DayCountID					= CASE WHEN SRC.CodeID IS NULL THEN SRC.DayCountID					ELSE TGT.DayCountID END
		,PayFreqTermID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.PayFreqTermID				ELSE TGT.PayFreqTermID END
		,iPayFreqPeriod				= CASE WHEN SRC.CodeID IS NULL THEN SRC.iPayFreqPeriod				ELSE TGT.iPayFreqPeriod END
		,dFixedRate					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFixedRate					ELSE TGT.dFixedRate END
		,FloatingIndexID			= CASE WHEN SRC.CodeID IS NULL THEN SRC.FloatingIndexID				ELSE TGT.FloatingIndexID END
		,iFloatingIndexPeriod		= CASE WHEN SRC.CodeID IS NULL THEN SRC.iFloatingIndexPeriod		ELSE TGT.iFloatingIndexPeriod END
		,FloatingIndexTermID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.FloatingIndexTermID			ELSE TGT.FloatingIndexTermID END
		,dFloatingSpread			= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFloatingSpread				ELSE TGT.dFloatingSpread END
		,dFirstResetRate			= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFirstResetRate				ELSE TGT.dFirstResetRate END
		,BusDayRuleModifierID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayRuleModifierID		ELSE TGT.BusDayRuleModifierID END
		,BusDayRuleConventionID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayRuleConventionID		ELSE TGT.BusDayRuleConventionID END
		,sBusDayRuleCalendar		= CASE WHEN SRC.CodeID IS NULL THEN SRC.sBusDayRuleCalendar			ELSE TGT.sBusDayRuleCalendar END
		,BusDayAdjust				= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayAdjust				ELSE TGT.BusDayAdjust END
		,RoundFunctionID			= CASE WHEN SRC.CodeID IS NULL THEN SRC.RoundFunctionID				ELSE TGT.RoundFunctionID END
		,iRoundDigit				= CASE WHEN SRC.CodeID IS NULL THEN SRC.iRoundDigit					ELSE TGT.iRoundDigit END
		,bArrear					= CASE WHEN SRC.CodeID IS NULL THEN SRC.bArrear						ELSE TGT.bArrear END
--		,sRollDay					= CASE WHEN SRC.CodeID IS NULL THEN SRC.sRollDay					ELSE TGT.sRollDay END
		,sResetCalendarConv			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sResetCalendarConv			ELSE TGT.sResetCalendarConv END
		,dRateFactor				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dRateFactor					ELSE TGT.dRateFactor END
		,sPaymentCurrency			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sPaymentCurrency			ELSE TGT.sPaymentCurrency END
		,BarrierTypeID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.BarrierTypeID				ELSE TGT.BarrierTypeID END
		,dBarrierLevel				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dBarrierLevel				ELSE TGT.dBarrierLevel END
		,bRangeApplicable			= CASE WHEN SRC.CodeID IS NULL THEN SRC.bRangeApplicable			ELSE TGT.bRangeApplicable END
		,bFXReset					= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFXReset					ELSE TGT.bFXReset END
		,dYield						= CASE WHEN SRC.CodeID IS NULL THEN SRC.dYield						ELSE TGT.dYield END
		,dCleanPrice				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dCleanPrice					ELSE TGT.dCleanPrice END
		,dDirtyPrice				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dDirtyPrice					ELSE TGT.dDirtyPrice END
		,sFXResetIndex				= CASE WHEN SRC.CodeID IS NULL THEN SRC.sFXResetIndex				ELSE TGT.sFXResetIndex END
		,CompoundingMethodID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.CompoundingMethodID			ELSE TGT.CompoundingMethodID END
		,dStrike1					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dStrike1					ELSE TGT.dStrike1 END
		,dStrike2					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dStrike2					ELSE TGT.dStrike2 END
		,StrikeTypeID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.StrikeTypeID				ELSE TGT.StrikeTypeID END
		,bFixingArrear				= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFixingArrear				ELSE TGT.bFixingArrear END
		,IssueID					= CASE WHEN SRC.CodeID IS NULL THEN SRC.IssueID						ELSE TGT.IssueID END
		,sScheduleGeneratorLabel	= CASE WHEN SRC.CodeID IS NULL THEN SRC.sScheduleGeneratorLabel		ELSE TGT.sScheduleGeneratorLabel END
		,sEstimationCurve			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sEstimationCurve			ELSE TGT.sEstimationCurve END
		,sDiscountingCurve			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sDiscountingCurve			ELSE TGT.sDiscountingCurve END
		,InArrears1StubIndexTenorID	= CASE WHEN SRC.CodeID IS NULL THEN SRC.InArrears1StubIndexTenorID	ELSE TGT.InArrears1StubIndexTenorID END
		,InArrears2StubIndexTenorID	= CASE WHEN SRC.CodeID IS NULL THEN SRC.InArrears2StubIndexTenorID	ELSE TGT.InArrears2StubIndexTenorID END
		,Front1StubIndexTenorID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.Front1StubIndexTenorID		ELSE TGT.Front1StubIndexTenorID END
		,Front2StubIndexTenorID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.Front2StubIndexTenorID		ELSE TGT.Front2StubIndexTenorID END
OUTPUT
	$action
INTO #ACTIONS;

SET @tmpLeg0InsertCount = (SELECT COUNT(*) FROM #ACTIONS WHERE Action = 'insert')
SET @MSG = '@Leg0InsertCount = ' + CONVERT(VARCHAR, @tmpLeg0InsertCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)


SET @tmpLeg0UpdateCount = (SELECT COUNT(*) FROM #ACTIONS WHERE Action = 'Update')
SET @MSG = '@Leg0UpdateCount = ' + CONVERT(VARCHAR, @tmpLeg0UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

SET @MSG = 'Total rows affected = ' + CONVERT(VARCHAR, @tmpLeg0InsertCount + @tmpLeg0UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DELETE #ACTIONS

--PRINT 'Timer after INSERT Leg 0:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer after INSERT Leg 0:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

--LEG 1 MERGE #################################################################################################################################
MERGE mcoredb..IRDTransactionLeg								TGT
USING (
	SELECT --*
--n.TransactionID, 
----n.M_H_NB_MZ,
--CASE t.M_TP_CMLDIR0 WHEN 'PAY' THEN 1 ELSE 0 END bPay
--,COUNT(*)

		n.TransactionID,															CASE t.M_TP_CMLDIR1 WHEN 'PAY' THEN 1 ELSE 0 END bPay,							CASE t.M_TP_CMLNAT1
																																										WHEN 'FIX'
																																										THEN 1 ELSE 0 END bFixed,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 1----------------------------------------------------
		CASE
		WHEN	t.M_TRN_GRP		= 'CS'
		AND		M_TP_RTINPC1	<> M_TP_NOMCUR
		THEN	M_TP_QTYEQ
		ELSE	t.M_TP_NOMINAL
		END												dNotional,					CASE
																					WHEN t.M_TRN_GRP = 'CS'
																					THEN t.M_TP_RTINPC1
																					ELSE t.M_TP_NOMCUR END sCurrency,												xl.LookupCodeID DayCountID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 2--------------------------------------------------------
		tu.CodeID PayFreqTermID /*TU=D,M*/,											CASE
																					WHEN RTRIM(t.M_TP_RTMFRP1) = '0Y' THEN
																						SUBSTRING(LTRIM(t.M_TP_RTDSC1), 1,
																							CHARINDEX(' ', LTRIM(t.M_TP_RTDSC1)) - 2) --' 12M IM ' => '12'
																					WHEN t.M_TP_RTMFRP1 = '0od' THEN NULL
																					WHEN t.M_TP_RTMFRP1 LIKE '[0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP1, 1, 1)
																					WHEN t.M_TP_RTMFRP1 LIKE '[0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP1, 1, 2)
																					WHEN t.M_TP_RTMFRP1 LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRP1, 1, 3)
																					END iPayFreqPeriod,																CASE t.M_TP_CMLNAT1
																																									WHEN 'FIX'
																																									THEN IIF(ABS(t.M_TP_RTMRTE1) > 999.999999, 
																																													NULL, t.M_TP_RTMRTE1) END  dFixedRate,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 3--------------------------------------------------------
		fl.FloatingIndexID,															CASE
																					WHEN RTRIM(t.M_TP_RTMFRC1) = '0Y' THEN
																						SUBSTRING(LTRIM(t.M_TP_RTDSC1), 1,
																							CHARINDEX(' ', LTRIM(t.M_TP_RTDSC1)) - 2) --' 12M IM ' => '12'
																					WHEN t.M_TP_RTMFRC1 = '0od' THEN NULL
																					WHEN t.M_TP_RTMFRC1 LIKE '[0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC1, 1, 1)
																					WHEN t.M_TP_RTMFRC1 LIKE '[0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC1, 1, 2)
																					WHEN t.M_TP_RTMFRC1 LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																						SUBSTRING(t.M_TP_RTMFRC1, 1, 3)
																					END iFloatingIndexPeriod,								fit.CodeID FloatingIndexTermID/*TU=D,M*/,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 4--------------------------------------------------------
		t.M_TP_RTMMRG1 dFloatingSpread,												t.M_TP_RTFFIX1 dFirstResetRate,													bus.BusDayRuleModifierID BusDayRuleModifierID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 5--------------------------------------------------------
		bus.BusDayRuleConventionID BusDayRuleConventionID,							t.M_TP_RTMCLC1 sBusDayRuleCalendar,												IIF(gd.M_ROLLCONV1 = 'Indifferent', 0, 1) BusDayAdjust,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 6--------------------------------------------------------
		NULL RoundFunctionID,														NULL iRoundDigit,																CASE t.M_TP_RTPAYM1
																																									WHEN 'In arrears'
																																									THEN 1 ELSE 0 END bArrear,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 7--------------------------------------------------------
		--gd.M_ROLL_DATE1 sRollDay,													
		t.M_TP_RTMCLF1 sResetCalendarConv,											t.M_TP_RTRFCT1 dRateFactor,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 8--------------------------------------------------------
		t.M_TP_RTCUR1 sPaymentCurrency,												bt.BarrierTypeID,																t.M_TP_OBAR1 dBarrierLevel,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 9--------------------------------------------------------
		CASE t.M_TP_RTRNG12
			WHEN 'NO'	THEN 0 
			WHEN 'YES'	THEN 1 END bRangeApplicable,								s.M_INDEXED1 bFXReset,															CASE s.M_INDEXED1 WHEN 1 THEN s.M_IND_LAB END
																																																sFXResetIndex,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 10-------------------------------------------------------
		cm.CompoundingMethodID,														CASE WHEN sto.StrikeType IS NOT NULL THEN
																						s.M_LN_STRIKE1 END dStrike1,												CASE WHEN sto.StrikeType IS NOT NULL THEN
																																										s.M_LN_SEC_K1 END dStrike2,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 11-------------------------------------------------------
		CASE WHEN sto.StrikeType IS NOT NULL THEN st.StrikeTypeID END
												StrikeTypeID,						CASE
																					WHEN sch.M_DT_UPFIX0 = 'Y' THEN 0
																					WHEN sch.M_DT_UPFIX0 = 'N' THEN 1 END bFixingArrear,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 12-------------------------------------------------------
		t.M_TP_RTDSC1 sScheduleGeneratorLabel,										t.M_PLIRECRV12 sEstimationCurve,												t.M_PLIRDCRV12 sDiscountingCurve,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 13-------------------------------------------------------
		sita1.StubIndexTenorID InArrears1StubIndexTenorID,							sita2.StubIndexTenorID InArrears2StubIndexTenorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 14-------------------------------------------------------
		sitf1.StubIndexTenorID Front1StubIndexTenorID,								sitf2.StubIndexTenorID Front2StubIndexTenorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 15-------------------------------------------------------
		ec.CodeID
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 16-------------------------------------------------------
		--select count(*)
	FROM #TX_IDs														n
	JOIN		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		t		ON	n.M_H_NB_MZ				= t.M_H_NB_MZ
																				AND	t.dtArchive				= @dt
	JOIN		mcoredb..OTCTransaction									otc		ON	otc.TransactionID		= n.TransactionID
	LEFT JOIN	mcoredb..XRefLookup										xl		ON	xl.sRef					= t.M_TP_RTMCNV1	--DayCount
																				AND	xl.DataSourceID			= @DATASOURCE_ID_MUREX
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_GEN_DT_REP		gd		ON	gd.M_NB					= t.M_NB
																				AND	gd.dtArchive			= @dt
	LEFT JOIN	@BusDayRuleMurexBridge									bus		ON	bus.MxDesc				= gd.M_ROLLCONV1
	LEFT JOIN	mcoredb.refcode.FloatingIndex							fl		ON	fl.sName				= t.M_TP_RTMNDD1

	LEFT JOIN	mcoredb..LookupCodes									tu		ON	tu.sCodeValue			= CASE
																												WHEN RTRIM(t.M_TP_RTMFRP1) = '0Y' THEN
																													SUBSTRING(LTRIM(t.M_TP_RTDSC1), CHARINDEX(' ', LTRIM(t.M_TP_RTDSC1)) - 1, 1) --' 12M IMM ' => 'M'
																												WHEN RTRIM(t.M_TP_RTMFRP1) = '0od' THEN 'ZC'
																												WHEN RTRIM(t.M_TP_RTMFRP1) LIKE '[A-Z]%' THEN
																													RTRIM(t.M_TP_RTMFRP1)
																												WHEN RTRIM(t.M_TP_RTMFRP1) LIKE '[0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP1)
																															,LEN(RTRIM(t.M_TP_RTMFRP1)) - 1)
																												WHEN RTRIM(t.M_TP_RTMFRP1) LIKE '[0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP1)
																															,LEN(RTRIM(t.M_TP_RTMFRP1)) - 2)
																												WHEN RTRIM(t.M_TP_RTMFRP1) LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRP1)
																															,LEN(RTRIM(t.M_TP_RTMFRP1)) - 3)
																												END	--D/M/OD/Q/W/Y/ZC
																				AND	tu.sCategory			= 'Tenor Unit'
	LEFT JOIN	mcoredb..LookupCodes									fit		ON	fit.sCodeValue			= CASE
																												WHEN RTRIM(t.M_TP_RTMFRC1) = '0Y' THEN
																													SUBSTRING(LTRIM(t.M_TP_RTDSC1), CHARINDEX(' ', LTRIM(t.M_TP_RTDSC1)) - 1, 1) --' 12M IMM ' => 'M'
																												WHEN RTRIM(t.M_TP_RTMFRC1) = '0od' THEN 'ZC'
																												WHEN RTRIM(t.M_TP_RTMFRC1) LIKE '[A-Z]%' THEN
																													RTRIM(t.M_TP_RTMFRC1)
																												WHEN RTRIM(t.M_TP_RTMFRC1) LIKE '[0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC1)
																															,LEN(RTRIM(t.M_TP_RTMFRC1)) - 1)
																												WHEN RTRIM(t.M_TP_RTMFRC1) LIKE '[0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC1)
																															,LEN(RTRIM(t.M_TP_RTMFRC1)) - 2)
																												WHEN RTRIM(t.M_TP_RTMFRC1) LIKE '[0-9][0-9][0-9][A-Z]%' THEN
																													RIGHT(RTRIM(t.M_TP_RTMFRC1)
																															,LEN(RTRIM(t.M_TP_RTMFRC1)) - 3)
																												END	--D/M/OD/Q/W/Y/ZC
																				AND	fit.sCategory			= 'Tenor Unit'
	LEFT JOIN	mcoredb.refcode.BarrierType								bt		ON	bt.sName				= t.M_TP_OBARTYP
	LEFT JOIN	mcoredb.refcode.CompoundingMethod						cm		ON	cm.sName				= CASE t.M_TP_RTCMP1
																												WHEN 'No compounding'	THEN 'None'
																												WHEN '(I+M) at I'		THEN 'Flat'
																												WHEN '(I+M) at (I+M)'	THEN 'Straight'
																												WHEN '(I at I) + M'		THEN 'SpreadExclusive'
																												END
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s		ON	s.M_NB					= t.M_NB
																				AND	s.dtArchive				= @dt
	LEFT JOIN	@TRADEENDCODES											ec		ON	ec.CodeID				= otc.TradeStatusID
	LEFT JOIN	@STRIKETYPOLIST											sto		ON	sto.StrikeType			= t.M_CNT_TYPO
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP		sch		ON	sch.M_H_NB_MZ			= t.M_H_NB_MZ
																				AND	sch.M_DT_LEG0			= 1
																				AND	sch.M_H_PERID_ID		= 0
																				AND	sch.M_DT_PHASE			= 0
																				AND	sch.dtArchive			= @dt
	LEFT JOIN	@MUREXPAYOUTTYPE										po		ON	po.MXID					= s.M_LN_PAYOUT1
	LEFT JOIN	mcoredb.refcode.StrikeType								st		ON	st.sName				= po.MxPayoutType
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sita1	ON	sita1.sName				= t.M_TP_RTBSFI1
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sita2	ON	sita2.sName				= t.M_TP_RTBSSI2
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sitf1	ON	sitf1.sName				= t.M_TP_RTFSFI1
	LEFT JOIN	mcoredb.refcode.StubIndexTenor							sitf2	ON	sitf2.sName				= t.M_TP_RTFSSI2
	WHERE	t.M_TRN_GRP	IN ('IRS','ASWP','CS','OSWP','RTRN','SWFUT', 'FRA')	--not 'CF','CD'
--group by n.TransactionID, 
----n.M_H_NB_MZ,
--CASE t.M_TP_CMLDIR0 WHEN 'PAY' THEN 1 ELSE 0 END
--HAVING COUNT(*)>1
--ORDER by	n.TransactionID
)																		SRC		ON	SRC.TransactionID		= TGT.TransactionID
																				AND	SRC.bPay				= TGT.bPay
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID,																bPay,																			bFixed,
		dNotional,																	sCurrency,																		DayCountID,--30/360 etc.
		PayFreqTermID/*TU=D,M*/,													iPayFreqPeriod,																	dFixedRate,
		FloatingIndexID,															iFloatingIndexPeriod,															FloatingIndexTermID/*TU=D,M*/,
		dFloatingSpread,															dFirstResetRate,																BusDayRuleModifierID,
		BusDayRuleConventionID,														sBusDayRuleCalendar,															BusDayAdjust,
		RoundFunctionID,															iRoundDigit,																	bArrear,
		--sRollDay,																	
		sResetCalendarConv,																dRateFactor,
		sPaymentCurrency,															BarrierTypeID,																	dBarrierLevel,
		bRangeApplicable,															bFXReset,																		sFXResetIndex,
		CompoundingMethodID,														dStrike1,																		dStrike2,
		StrikeTypeID,																bFixingArrear,
		sScheduleGeneratorLabel,													sEstimationCurve,																sDiscountingCurve,
		InArrears1StubIndexTenorID,													InArrears2StubIndexTenorID,
		Front1StubIndexTenorID,														Front2StubIndexTenorID)
	VALUES
		(TransactionID,																bPay,																			bFixed,
		dNotional,																	sCurrency,																		DayCountID,--30/360 etc.
		PayFreqTermID/*TU=D,M*/,													iPayFreqPeriod,																	dFixedRate,
		FloatingIndexID,															iFloatingIndexPeriod,															FloatingIndexTermID/*TU=D,M*/,
		dFloatingSpread,															dFirstResetRate,																BusDayRuleModifierID,
		BusDayRuleConventionID,														sBusDayRuleCalendar,															BusDayAdjust,
		RoundFunctionID,															iRoundDigit,																	bArrear,
		--sRollDay,																	
		sResetCalendarConv,																dRateFactor,
		sPaymentCurrency,															BarrierTypeID,																	dBarrierLevel,
		bRangeApplicable,															bFXReset,																		sFXResetIndex,
		CompoundingMethodID,														dStrike1,																		dStrike2,
		StrikeTypeID,																bFixingArrear,
		sScheduleGeneratorLabel,													sEstimationCurve,																sDiscountingCurve,
		InArrears1StubIndexTenorID,													InArrears2StubIndexTenorID,
		Front1StubIndexTenorID,														Front2StubIndexTenorID)
WHEN MATCHED THEN
	UPDATE SET
		bFixed						= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFixed						ELSE TGT.bFixed END
		,dNotional					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dNotional					ELSE TGT.dNotional END
		,sCurrency					= CASE WHEN SRC.CodeID IS NULL THEN SRC.sCurrency					ELSE TGT.sCurrency END
		,DayCountID					= CASE WHEN SRC.CodeID IS NULL THEN SRC.DayCountID					ELSE TGT.DayCountID END
		,PayFreqTermID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.PayFreqTermID				ELSE TGT.PayFreqTermID END
		,iPayFreqPeriod				= CASE WHEN SRC.CodeID IS NULL THEN SRC.iPayFreqPeriod				ELSE TGT.iPayFreqPeriod END
		,dFixedRate					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFixedRate					ELSE TGT.dFixedRate END
		,FloatingIndexID			= CASE WHEN SRC.CodeID IS NULL THEN SRC.FloatingIndexID				ELSE TGT.FloatingIndexID END
		,iFloatingIndexPeriod		= CASE WHEN SRC.CodeID IS NULL THEN SRC.iFloatingIndexPeriod		ELSE TGT.iFloatingIndexPeriod END
		,FloatingIndexTermID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.FloatingIndexTermID			ELSE TGT.FloatingIndexTermID END
		,dFloatingSpread			= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFloatingSpread				ELSE TGT.dFloatingSpread END
		,dFirstResetRate			= CASE WHEN SRC.CodeID IS NULL THEN SRC.dFirstResetRate				ELSE TGT.dFirstResetRate END
		,BusDayRuleModifierID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayRuleModifierID		ELSE TGT.BusDayRuleModifierID END
		,BusDayRuleConventionID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayRuleConventionID		ELSE TGT.BusDayRuleConventionID END
		,sBusDayRuleCalendar		= CASE WHEN SRC.CodeID IS NULL THEN SRC.sBusDayRuleCalendar			ELSE TGT.sBusDayRuleCalendar END
		,BusDayAdjust				= CASE WHEN SRC.CodeID IS NULL THEN SRC.BusDayAdjust				ELSE TGT.BusDayAdjust END
		,RoundFunctionID			= CASE WHEN SRC.CodeID IS NULL THEN SRC.RoundFunctionID				ELSE TGT.RoundFunctionID END
		,iRoundDigit				= CASE WHEN SRC.CodeID IS NULL THEN SRC.iRoundDigit					ELSE TGT.iRoundDigit END
		,bArrear					= CASE WHEN SRC.CodeID IS NULL THEN SRC.bArrear						ELSE TGT.bArrear END
--		,sRollDay					= CASE WHEN SRC.CodeID IS NULL THEN SRC.sRollDay					ELSE TGT.sRollDay END
		,sResetCalendarConv			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sResetCalendarConv			ELSE TGT.sResetCalendarConv END
		,dRateFactor				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dRateFactor					ELSE TGT.dRateFactor END
		,sPaymentCurrency			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sPaymentCurrency			ELSE TGT.sPaymentCurrency END
		,BarrierTypeID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.BarrierTypeID				ELSE TGT.BarrierTypeID END
		,dBarrierLevel				= CASE WHEN SRC.CodeID IS NULL THEN SRC.dBarrierLevel				ELSE TGT.dBarrierLevel END
		,bRangeApplicable			= CASE WHEN SRC.CodeID IS NULL THEN SRC.bRangeApplicable			ELSE TGT.bRangeApplicable END
		,bFXReset					= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFXReset					ELSE TGT.bFXReset END
		,sFXResetIndex				= CASE WHEN SRC.CodeID IS NULL THEN SRC.sFXResetIndex				ELSE TGT.sFXResetIndex END
		,CompoundingMethodID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.CompoundingMethodID			ELSE TGT.CompoundingMethodID END
		,dStrike1					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dStrike1					ELSE TGT.dStrike1 END
		,dStrike2					= CASE WHEN SRC.CodeID IS NULL THEN SRC.dStrike2					ELSE TGT.dStrike2 END
		,StrikeTypeID				= CASE WHEN SRC.CodeID IS NULL THEN SRC.StrikeTypeID				ELSE TGT.StrikeTypeID END
		,bFixingArrear				= CASE WHEN SRC.CodeID IS NULL THEN SRC.bFixingArrear				ELSE TGT.bFixingArrear END
		,sScheduleGeneratorLabel	= CASE WHEN SRC.CodeID IS NULL THEN SRC.sScheduleGeneratorLabel		ELSE TGT.sScheduleGeneratorLabel END
		,sEstimationCurve			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sEstimationCurve			ELSE TGT.sEstimationCurve END
		,sDiscountingCurve			= CASE WHEN SRC.CodeID IS NULL THEN SRC.sDiscountingCurve			ELSE TGT.sDiscountingCurve END
		,InArrears1StubIndexTenorID	= CASE WHEN SRC.CodeID IS NULL THEN SRC.InArrears1StubIndexTenorID	ELSE TGT.InArrears1StubIndexTenorID END
		,InArrears2StubIndexTenorID	= CASE WHEN SRC.CodeID IS NULL THEN SRC.InArrears2StubIndexTenorID	ELSE TGT.InArrears2StubIndexTenorID END
		,Front1StubIndexTenorID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.Front1StubIndexTenorID		ELSE TGT.Front1StubIndexTenorID END
		,Front2StubIndexTenorID		= CASE WHEN SRC.CodeID IS NULL THEN SRC.Front2StubIndexTenorID		ELSE TGT.Front2StubIndexTenorID END
OUTPUT
	$action
INTO #ACTIONS;	--select * from #actions

SET @tmpLeg1InsertCount = (SELECT COUNT(*) FROM #ACTIONS WHERE Action = 'Insert')
SET @MSG = '@Leg1InsertCount = ' + CONVERT(VARCHAR, @tmpLeg1InsertCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

SET @tmpLeg1UpdateCount = (SELECT COUNT(*) FROM #ACTIONS WHERE Action = 'Update')
SET @MSG = '@Leg1UpdateCount = ' + CONVERT(VARCHAR, @tmpLeg1UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

SET @MSG = 'Total rows affected = ' + CONVERT(VARCHAR, @tmpLeg1InsertCount + @tmpLeg1UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer after INSERT Leg 1:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer after INSERT Leg 1:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

UPDATE t --UPDATE OR ADD TRADE DESCRIPTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SET	sDescription = LEFT('IRS '
	+ CASE WHEN l0.bPay = 1 THEN 'Pay ' ELSE 'Receive ' END
	+ CASE
		WHEN l0.bFixed = 1 THEN 'Fixed '  + CONVERT(VARCHAR, l0.dFixedRate)
		ELSE 'Floating ' + CONVERT(VARCHAR, l0.iFloatingIndexPeriod) + tu0.sCodeValue + ' ' + ISNULL(fl0.sCodeValue, '') --maybe should let NULLs propagate here to avoid degeneracy: "IRS Pay Fixed Receive Floating"
			+ CASE WHEN	l0.dFloatingSpread IS NULL OR l0.dFloatingSpread = 0 THEN '' ELSE
				CASE WHEN l0.dFloatingSpread > 0 THEN '+' ELSE '' END + CONVERT(VARCHAR,l0.dFloatingSpread)
				END
		END
	+ ' ' --==================================================
	+ CASE WHEN l1.bPay = 1 THEN 'Pay ' ELSE 'Receive ' END
	+ CASE
		WHEN l1.bFixed = 1 THEN 'Fixed '  + CONVERT(VARCHAR, l1.dFixedRate)
		ELSE 'Floating ' + CONVERT(VARCHAR, l1.iFloatingIndexPeriod) + tu1.sCodeValue + ' ' + ISNULL(fl1.sCodeValue, '')
			+ CASE WHEN	l1.dFloatingSpread IS NULL OR l1.dFloatingSpread = 0 THEN '' ELSE
				CASE WHEN l1.dFloatingSpread > 0 THEN '+' ELSE '' END + CONVERT(VARCHAR,l1.dFloatingSpread)
				END
		END, 100)
FROM		mcoredb..OTCTransaction			t
JOIN
(
	SELECT
		t.TransactionID
		,MIN(TransactionLegID) Leg0ID
		,MAX(TransactionLegID) Leg1ID
	FROM	#TX_IDs							t
	JOIN	mcoredb..IRDTransactionLeg		tl	ON	tl.TransactionID	= t.TransactionID
	GROUP BY t.TransactionID
)											g	ON	g.TransactionID		= t.TransactionID
JOIN		mcoredb..IRDTransactionLeg		l0	ON	l0.TransactionLegID	= g.Leg0ID
JOIN		mcoredb..IRDTransactionLeg		l1	ON	l1.TransactionLegID	= g.Leg1ID
LEFT JOIN	mcoredb..LookupCodes			tu0	ON	tu0.CodeID			= l0.FloatingIndexTermID
LEFT JOIN	mcoredb..LookupCodes			tu1	ON	tu1.CodeID			= l1.FloatingIndexTermID
LEFT JOIN	mcoredb..LookupCodes			fl0	ON	fl0.CodeID			= l0.FloatingIndexID
LEFT JOIN	mcoredb..LookupCodes			fl1	ON	fl1.CodeID			= l1.FloatingIndexID

DECLARE @TradeDescUpdateCount INT = @@ROWCOUNT
SET @MSG = '@TradeDescUpdateCount = ' + CONVERT(VARCHAR, @TradeDescUpdateCount )
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

SET @MSG = 'spMDR_MUREX_TRANSACTION done.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer after adding Trade descriptions (conclusion):  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer after adding Trade descriptions (conclusion):  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

SET @Leg0InsertCount = @tmpLeg0InsertCount
SET @Leg1InsertCount = @tmpLeg1InsertCount
SET @Leg0UpdateCount = @tmpLeg0UpdateCount
SET @Leg1UpdateCount = @tmpLeg1UpdateCount
SET @MSG = 'Done.'
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

;IF @debug = 0	-- @debug = 0 in Tidal, so that the Success flag is set and Completed Normally results; the THROW results in the entire @OUTPUT param being reproduced in the Tidal output page for review.
	THROW 50000, 'DTSER_SUCCESS', 0
--else don't throw, prevents add'l PRINT statements from firing

GO


