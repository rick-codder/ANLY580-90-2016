/*
Missing Index Details from SQLQuery28.sql - mcodsqmcdb.mcoredb (USI\olayemiadejumo (283))
The Query Processor estimates that implementing the following index could improve the query cost by 13.3744%.
*/

/*
USE [mcoredb_archive]
GO

--DROP INDEX [MDR_MUREX_DM_TRN_TRADE_REP_NCI_1] ON [mcoredb_archive].[stage].[MDR_MUREX_DM_TRN_TRADE_REP]

CREATE NONCLUSTERED INDEX [MDR_MUREX_DM_TRN_TRADE_REP_NCI_1]
ON [stage].[MDR_MUREX_DM_TRN_TRADE_REP] ([dtArchive])
INCLUDE ([M_CNTLEVTL2],[M_AMD_STS2],[M_CNT_ORG],[M_CNT_EVTL],[M_CNTLIMPL2],[M_CNTLEVTAD2],[M_TP_INT],[M_TP_RTPR0],[M_H_NB_MZ],[M_H_DATA_DT2],
[M_TP_DTEFXGF],[M_TP_DTEFXGL],[M_TP_DTEEXP],[M_TP_RTMAT0],[M_TP_RTSD0],[M_TRN_FMLY],[M_TP_TRADER],[M_TP_STATUS2],[M_PACKAGE],[M_NB_EXT],[M_NB],
[M_INSTRUMENT],[M_TP_AE],[M_CONTRACT],[M_TP_NOMCUR],[M_TP_DTETRN],[M_TP_DTESYS],[M_TP_CNTRP],[M_TP_NOMINAL],[M_UDF_REF2],[M_TRN_TYPE],[M_TRN_GRP],
[M_TP_RTMAT1],[M_TP_ROOTCNT],[M_TP_PFOLIO],[M_TP_BROLBL0],[M_CNT_VS2],[M_CNT_TYPO],[M_TP_CANCBY])
GO

*/


/*
Missing Index Details from SQLQuery28.sql - mcodsqmcdb.mcoredb (USI\olayemiadejumo (283))
The Query Processor estimates that implementing the following index could improve the query cost by 95.9629%.
*/

/*
USE [mcoredb_archive]
GO

--DROP INDEX [MDR_MUREX_DM_REF_CNTP_REP_NCI_1] ON [mcoredb_archive].[stage].[MDR_MUREX_DM_REF_CNTP_REP]

CREATE NONCLUSTERED INDEX [MDR_MUREX_DM_REF_CNTP_REP_NCI_1]
ON [stage].[MDR_MUREX_DM_REF_CNTP_REP] ([dtArchive])
INCLUDE ([M_DSP_LBL],[M_CODE])
GO
*/


/*
Missing Index Details from SQLQuery28.sql - mcodsqmcdb.mcoredb (USI\olayemiadejumo (283))
The Query Processor estimates that implementing the following index could improve the query cost by 95.5253%.
*/

/*
USE [mcoredb_archive]
GO

--DROP INDEX [MDR_MUREX_DM_TRN_TRADE_REP_NCI_2] ON [mcoredb_archive].[stage].[MDR_MUREX_DM_TRN_TRADE_REP]

CREATE NONCLUSTERED INDEX [MDR_MUREX_DM_TRN_TRADE_REP_NCI_2]
ON [stage].[MDR_MUREX_DM_TRN_TRADE_REP] ([dtArchive])
INCLUDE ([M_CONTRACT],[M_TP_CNTRP],[M_CNT_TYPO])
GO
*/
