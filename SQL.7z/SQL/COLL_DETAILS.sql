-- DEAL_COLLATERAL_DETAIL 

DECLARE @dtProcess DATE = '20181005'

DECLARE @MurexDatasourceID NUMERIC(18,0)
SELECT @MurexDatasourceID = DatasourceID FROM dbo.DataSource ds JOIN refcode.Entity e ON e.EntityID = ds.EntityID WHERE ds.sSourceName = 'Murex' AND e.sEntityCode = 'MCM' 


SELECT distinct csa.sLegalName
,c.sIssueCurrency + ' ' + lc.sCodeValue AS sProductID 
,case when c.bPledgedIn = 1 then 'Posted' else 'Held' END AS sPostDirection 
,i.sCusip 
,c.dNotional   
,p.dPrice 
,ci.dCumulativeInterest 
,c.dCollateralValue 
,c.dHaircut 
,(c.dCollateralValue * c.dHaircut) AS dAdjustedPV 
,CASE st.sTypeName	WHEN 'CSA Non-Reg VM' THEN 'VM_Non_Reg'
					WHEN 'CSA Reg VM' THEN CASE WHEN RT.sName = 'IA' THEN 'IA_Non_Reg' 
												WHEN RT.sName = 'VM' THEN 'VM_Reg' 
					END  
					WHEN 'CSA Non-Reg IM' THEN 'IM_Non_Reg'
					WHEN 'CSA Reg IM Post' THEN 'IM_Reg_Post'
					WHEN 'CSA Reg IM Collect' THEN 'IM_Reg_Collect'
					WHEN 'CSA Reg Collect' THEN 'CSA Reg Collect'
					WHEN 'CSA Reg Post' THEN 'CSA Reg Post'
END
AS sCSAType 
, csa.TEMP_sApolloContractRef AS sAgreementRef 

,c.dtProcess 

, TODATETIMEOFFSET(c.dtTimestamp,DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtTimestamp  
, TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtModifiedETL 
, USER_NAME() AS sModifiedByETL 
FROM mcoredb.dbo.Agreement a
inner join dbo.AgreementRelationship ar on ar.SuperAgreementID = a.AgreementID
inner join dbo.Agreement csa on ar.SubAgreementID = csa.AgreementID
inner join dbo.Collateral c on c.AgreementID = csa.AgreementID 
inner join dbo.issue i on c.IssueID = i.IssueID 
inner join dbo.LookupCodes lc on lc.CodeID = i.ProductTypeID
inner join refcode.AgreementSubType st on st.AgreementSubTypeID = csa.AgreementSubTypeID
inner join dbo.Position p on p.IssueID = i.IssueID 
 left join refcode.MarginRequirementType  rt  on c.MarginRequirementTypeID = rt.MarginRequirementTypeID
inner join dbo.CollateralInterest ci on ci.AgreementID = c.AgreementID and c.dNotional = ci.dCollateralBalance
JOIN refcode.CollateralStatus cs ON cs.CollateralStatusID = c.CollateralStatusID 
 left join DataSource  ds1  on ds1.DataSourceID = p.DataSourceID  and ds1.sSourceName = 'Impact'

WHERE c.dtProcess =  @dtProcess
AND p.dtPosition = c.dtProcess
AND ci.dtProcess = c.dtProcess
AND ci.dtCalcEnd = c.dtProcess
AND c.DataSourceID = @MurexDatasourceID 
--AND C.dNotional = 
AND cs.sName != 'Pending'
AND csa.TEMP_sApolloContractRef = '22750002'


	--[CSA_ID] ASC,
	--[PRODUCT_ID] ASC,
	--[ISSUE_ID] ASC,
	--[POST_DIRECTION] ASC,
	--[COLL_DATE] ASC


--sAgreementRef, sProductID, sCusip, sPostedDirection, 
 
--select rt.MarginRequirementTypeID,rt.sName,col.*  from Collateral  col  
--left join agreement agr  on agr.AgreementID = col.AgreementID
--left join dbo.AgreementRelationship ar on ar.SuperAgreementID = agr.AgreementID
--left join issue  iss on iss.IssueID = col.IssueID
--left join refcode.MarginRequirementType  rt  on col.MarginRequirementTypeID = rt.MarginRequirementTypeID
--inner join refcode.AgreementSubType st on st.AgreementSubTypeID = agr.AgreementSubTypeID
--inner join dbo.Position p on p.IssueID = iss.IssueID 
--left join DataSource  ds1  on ds1.DataSourceID = p.DataSourceID  and ds1.sSourceName = 'Impact'
--JOIN refcode.CollateralStatus cs ON cs.CollateralStatusID = col.CollateralStatusID 
----inner join dbo.CollateralInterest ci on ci.AgreementID = col.AgreementID  -- uncomment this
--inner join dbo.LookupCodes lc on lc.CodeID = iss.ProductTypeID
--where col.dtProcess = @dtProcess
----and col.IssueID = 6114450
--and agr.TEMP_sApolloContractRef = '22750002'
--AND p.dtPosition = col.dtProcess 
--AND ci.dtProcess = @dtProcess
--AND ci.dtCalcEnd = @dtProcess



--select rt.MarginRequirementTypeID,rt.sName,
--col.* ,ci.* from Collateral  col  
--left join agreement agr  on agr.AgreementID = col.AgreementID
--left join issue  iss on iss.IssueID = col.IssueID
--left join refcode.MarginRequirementType  rt  on col.MarginRequirementTypeID = rt.MarginRequirementTypeID
--inner join dbo.Position p on p.IssueID = iss.IssueID 
--left join DataSource  ds1  on ds1.DataSourceID = p.DataSourceID  and ds1.sSourceName = 'Impact'
--inner join dbo.CollateralInterest ci on ci.AgreementID = col.AgreementID  -- uncomment this
--where col.dtProcess = '10/15/2018'
----and col.IssueID = 6114450
--and agr.TEMP_sApolloContractRef = '22750002'
--AND p.dtPosition = col.dtProcess 
--AND ci.dtProcess = '10/15/2018'
--AND ci.dtCalcEnd ='10/15/2018'
 
--select *  from CollateralInterest  ci 
--left join agreement agr on agr.AgreementID = ci.AgreementID

--where ci.dtProcess = '10/9/2018'
--and ci.dtCalcEnd = '10/9/2018'
--and agr.TEMP_sApolloContractRef = '22750002'
 
