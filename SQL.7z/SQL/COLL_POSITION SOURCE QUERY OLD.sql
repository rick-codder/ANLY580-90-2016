declare @dtProcess date = ? 

select 

c.CollateralID 
, c.dCollateralValue 
, c.dHaircut  
, c.dNotional as dCollateralQuantity 
, CONVERT(NUMERIC(18,0), agr.Temp_sApolloContractRef) AgreementID
, agr.sLegalName AS sAgreementLegalName
, i.IssueID 
, i.sName AS sSecurityName 
, i.sCusip 
, i.sIsin 
, i.fAmountIssued 
, i.fAmountOutstanding 
, i.sSecurity 
, i.sTradeCurrency 
,c.sIssueCurrency
, l.scodevalue as sBloombergSector 
, isr.sLegalName AS sIssuerLegalName 
, isr.sCountryDomicile 
, pt.sProduct 
, pt.sProductType 
, pt.sProductSubType 
, er.dExchangeRate 
, er.dtExchangeRate 
,agsub.sTypeName
,CASE	WHEN agsub.sTypeName = 'CSA Non-Reg VM' THEN 'Variation'
		WHEN agsub.sTypeName = 'CSA Reg VM' THEN 'Variation'
		WHEN agsub.sTypeName = 'CSA Non-Reg IM' THEN 'LockUp'
		WHEN agsub.sTypeName = 'CSA Reg IM Collect' THEN 'LookUp'
		WHEN agsub.sTypeName = 'CSA Reg IM Post' THEN 'LookUp'
		WHEN agsub.sTypeName = 'CSA Reg Collect' THEN 'Variation'
		WHEN agsub.sTypeName = 'CSA Reg Post' THEN 'Variation'
 END as sCollateralMarginType
, TODATETIMEOFFSET(c.dtTimestamp,DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtTimestamp  
, TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtModifiedETL 
, USER_NAME() AS sModifiedByETL 

from 
Collateral c 
left join Issue i on c.IssueID = i.IssueID 
left join vwProductType pt on i.ProductTypeID = pt.ProductTypeId
left join Issuer  isr on i.IssuerID = isr.IssuerID
left join ExchangeRate er on  er.sISOCodeFrom = i.sTradeCurrency and er.sIsoCodeTo = 'USD' and er.dtExchangeRate = @dtProcess
left join Agreement agr on c.AgreementID = agr.AgreementID and TRY_PARSE(agr.TEMP_sApolloContractRef AS NUMERIC(18,0)) IS NOT NULL
left join PartyAgreement pa on agr.AgreementID = pa.AgreementID
LEFT JOIN refcode.AgreementSubType agsub on agsub.AgreementSubTypeID = agr.AgreementSubTypeID
LEFT join LookupCodes l on l.sCategory = 'Bloomberg Sector'  and l.CodeID = isr.IndustrySectorID

where c.dtProcess = @dtProcess

order by c.CollateralID