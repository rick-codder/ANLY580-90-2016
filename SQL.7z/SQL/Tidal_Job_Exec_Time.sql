
Declare @dtAsOf Date = '3/7/2019';
--Declare @Job_Group Varchar(500) = '\derivatives\murex\';
--Declare @Job_Group Varchar(500) = '\derivatives\murex to mcdb\';
Declare @DEP_SLA datetime = DATEADD(HH, 20, cast(@dtAsOf as datetime)); -- SLA is 8 PM
Declare @PRIMARY_SLA datetime = DATEADD(HH, 22, cast(@dtAsOf as datetime)); -- SLA is 10 PM

     
With CTE_PrimaryJobs As (	                            
	Select  
	j.jobmst_id p_job_id, j.jobmst_name + '[' + j.jobmst_prntname + ']' as p_job_name, jr.jobrun_id as p_job_run_id, jr.jobrun_proddt as p_job_schedule_date, s.strmst_desc as p_job_status,  jr.jobrun_launchtm as p_job_start_time, 
	jr.jobrun_stachgtm as p_job_end_time, cast(jr.jobrun_deps as xml) as p_job_dependencies, 
	 isnull(jr.jobrun_duration,0) as p_job_run_duration_secs, jr.jobrun_reruns as p_job_rerun_count, case when jr.jobrun_reruns > 1 Then 1 else 0 end as p_job_Is_Multi_Run 
	From jobmst j With(nolock)  
	inner join jobrun jr on j.jobmst_id = jr.jobmst_id  
	inner join strmst s on jr.jobrun_status = s.strmst_id  
	inner join jobdtl jd on j.jobdtl_id = jd.jobdtl_id  
	Where jobmst_active = 'Y'  
	and j.jobmst_type in (2)  -- only jobs, not job groups
	and jobmst_prntname is not null  
	and jr.jobrun_proddt = @dtAsOf
	and s.strmst_type = 7  -- job status type
	--and jd.jobdtl_cmd like '%ssis%' 
	and (
			j.jobmst_prntname like '\derivatives\murex\%' 
			OR j.jobmst_prntname like '\derivatives\murex to mcdb\%' 
			OR j.jobmst_prntname like '\Corporate\Market Data\Murex\%' 
			OR j.jobmst_prntname like '\Corporate\EPE\600 Gamma EPE\%'
			OR j.jobmst_prntname like '\Corporate\Risk\Risk Portfolio\Mizuho Capital Markets\%'
			OR j.jobmst_prntname like '\Corporate\Risk Cube\500 Pre Positions - MCM\%'
			OR j.jobmst_prntname like '\Corporate\Risk Cube\600 Mizuho Capital Markets\%'
			OR j.jobmst_prntname like '\Corporate\Risk Cube\700 Post Positions - MCM\%'
			)
)
,

CTE_DependentJobs As (
	select jd.*, T.c.value('.', 'int') as dep_job_id
	from CTE_PrimaryJobs jd
	cross apply p_job_dependencies.nodes('jobrundeps/dep/jobid') T(c)
)

/*
select distinct jm.jobmst_prntname + '\' + jm.jobmst_name as dep_job_name, jobmst_type
from CTE_DependentJobs dj
inner join jobmst jm on dj.dep_job_id = jm.jobmst_id
order by jm.jobmst_prntname + '\' + jm.jobmst_name
*/


select cast(dj.p_job_schedule_date as Date) as p_job_schedule_date, 
dj.p_job_name,
--case when p_job_start_time > @PRIMARY_SLA Then DATEDIFF(MI, @PRIMARY_SLA, dj.p_job_start_time) Else 0 End as p_SLA_breach_mins,
jm.jobmst_name + '[' + jm.jobmst_prntname + ']' as dep_job_name,
--case when jr.jobrun_time > @DEP_SLA Then DATEDIFF(MI, @DEP_SLA, jr.jobrun_time) Else 0 End as dep_SLA_breach_mins,
dj.p_job_id, dj.p_job_run_id, dj.p_job_run_duration_secs, dj.p_job_start_time, dj.p_job_end_time, rtrim(dj.p_job_status) as p_job_status, dj.p_job_rerun_count,
dj.dep_job_id, jr.jobrun_id as dep_job_run_id, isnull(jr.jobrun_duration,0) as dep_job_run_duration_secs, jr.jobrun_time as dep_job_start_time, jr.jobrun_stachgtm as dep_job_end_time,
rtrim(s.strmst_desc) as dep_job_status, jr.jobrun_reruns as dep_job_rerun_count
from CTE_DependentJobs dj
inner join jobmst jm on dj.dep_job_id = jm.jobmst_id
inner join jobrun jr on jm.jobmst_id = jr.jobmst_id  
inner join strmst s on jr.jobrun_status = s.strmst_id  
inner join jobdtl jd on jm.jobdtl_id = jd.jobdtl_id  
where jr.jobrun_proddt = @dtAsOf
and s.strmst_type = 7
Order By jm.jobmst_prntname;