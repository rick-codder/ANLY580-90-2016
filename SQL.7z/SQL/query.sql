DROP TABLE stage.MCO_DEALOGIC_QIB_CERTIFICATE;
CREATE TABLE stage.[MCO_DEALOGIC_QIB_CERTIFICATE]
(
	dtArchive date NULL,
	iCertificate int NOT NULL,
	sAccountNumber varchar(100) NOT NULL,
	sClientName varchar(200) NULL,
	bCertificateBlanketStatus bit NOT NULL,
	sCertificateStatus char(1) NOT NULL,
	sCertificateStatusDesc AS CASE	WHEN sCertificateStatus = 'Y' THEN 'Yes'
									WHEN sCertificateStatus = 'N' THEN 'No'
									WHEN sCertificateStatus = 'U' THEN 'Unable to Obtain'
									WHEN sCertificateStatus = 'X' THEN 'Exempt'
							END,
	dtCertificateExpirationDate datetime NULL,
	dtCertificateUploadDate datetime NULL,
	dtCertificateModifiedDate datetime NULL,
	sParentAccountNumber varchar(100) NULL,
	sDataSource varchar(100) NOT NULL,
	sWebServiceInterface varchar(200) NOT NULL,
	dtTimestamp datetime NOT NULL DEFAULT(GETDATE()),
	sUser varchar(100) NULL DEFAULT(SUSER_SNAME()),
	iDelta int NOT NULL

);
GO

CREATE CLUSTERED INDEX IX_MCO_DEALOGIC_QIB_CERTIFICATE_dtArchive on stage.MCO_DEALOGIC_QIB_CERTIFICATE (dtArchive ASC);
GO



SELECT *
FROM mcoredb_archive.STAGE.MCO_DEALOGIC_QIB_CERTIFICATE;



SELECT *
FROM INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME LIKE '%DTARCH%' --OR COLUMN_NAME LIKE '%TIMES%'
ORDER BY DATA_TYPE;



SELECT  --year(T.create_date),
--		count(S.name),
C.name,T.name, IX.name,IX.type_desc,s.name,is_nullable ,* --,II.*
FROM SYS.all_columns C
JOIN sys.tables T ON C.object_id = T.object_id
JOIN sys.index_columns I ON I.object_id = C.object_id
JOIN SYS.indexes IX ON IX.object_id = T.object_id
JOIN SYS.schemas S ON S.schema_id = T.schema_id
--JOIN INFORMATION_SCHEMA.COLUMNS II ON II.TABLE_NAME = T.name
WHERE C.name LIKE '%DTARCHIVE%' --AND II.COLUMN_NAME = 'dtArchive' 
AND IX.type_desc = 'CLUSTERED' 
AND S.name = 'EXTRACT'
--and t.name = 'MCO_BB_PS_BANK_LOAN'
GROUP BY C.name
	,T.name
	,year(T.create_date)
	, S.name
	, IX.name,IX.type_desc
ORDER BY year(T.create_date) DESC



select *
from
sys.tables T 
JOIN SYS.schemas S ON S.schema_id = T.schema_id
JOIN SYS.COLUMNS C ON C.object_id = T.object_id
where t.name = 'MCO_BB_PS_BANK_LOAN'




