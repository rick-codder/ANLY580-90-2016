USE [mcoredb]
--GO
/****** Object:  StoredProcedure [stage].[spMDR_MUREX_TRANSACTION]    Script Date: 2/12/2019 6:23:59 PM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--ALTER PROC [stage].[spMDR_MUREX_TRANSACTION]
--	@dt					DATE
--	,@InsertCount		INT OUT
--	,@UpdateCount		INT OUT
--	,@DeleteCount		INT OUT
--WITH RECOMPILE
/*TO EXECUTE:
	DECLARE @dt					DATE = '20181226'
	DECLARE @TxInsertCount		INT
	DECLARE @TxUpdateCount		INT
	DECLARE @TxDeleteCount		INT
	EXEC stage.spMDR_MUREX_TRANSACTION					@dt, @TxInsertCount OUT, @TxUpdateCount OUT, @TxDeleteCount OUT
	PRINT 'spMDR_MUREX_TRANSACTION Insert count: '		+ CONVERT(VARCHAR, @TxInsertCount)
	PRINT 'spMDR_MUREX_TRANSACTION Update count: '		+ CONVERT(VARCHAR, @TxUpdateCount)
*/
--AS

--ALTER INDEX ALL ON Extract.vwXRefOTCTransaction DISABLE

--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		WHERE DTARCHIVE < GETDATE() - 90 
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	WHERE DTARCHIVE < GETDATE() - 90 
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_EXE_SCHDL_REP	WHERE DTARCHIVE < GETDATE() - 90 
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_UDF_DEAL_REP		WHERE DTARCHIVE < GETDATE() - 90 
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP	WHERE DTARCHIVE < GETDATE() - 90 
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP			WHERE DTARCHIVE < GETDATE() - 90 



--ALTER INDEX ALL ON Extract.vwXRefOTCTransaction DISABLE


DECLARE @dt			DATE = '20190219'
	,@InsertCount		INT
	,@UpdateCount		INT
	,@DeleteCount		INT
DECLARE @start					DATETIME		= GETDATE()
DECLARE @debug					BIT				= 1
DECLARE @MSG					VARCHAR(1000)
DECLARE @OUTPUT					VARCHAR(MAX)	= ''
DECLARE @ERROR_NUMBER			INTEGER
DECLARE @ERROR_SEVERITY			INTEGER
DECLARE @ERROR_STATE			INTEGER
DECLARE @ERROR_LINE				INTEGER
DECLARE @ERROR_MESSAGE			NVARCHAR(4000)
DECLARE @caught					BIT				= 0

SET @MSG = '--------------------------------------------------------------------------------------------'
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Business date parameter = ' + CONVERT(VARCHAR, @dt)
SET NOCOUNT ON
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Server name = ' + @@SERVERNAME
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Murex'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_APOLLO	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Apollo'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_MARKIT	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Markit'
													AND		sEntityCode				= 'MSUSA')
DECLARE @TRADE_STAT_ID_PURGED	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	ParentID				IS NULL
													AND		sCategory				= 'OTC Trade Status'
													AND		sCodeValue				= 'PURGED')
DECLARE @TRDREFTYPE_PRIMARY_ID	NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Primary ID')
DECLARE @TRDREFTYPE_USI_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'USI ID')
DECLARE @TRDREFTYPE_CCP_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'CCP ID')
DECLARE @TRDREFTYPE_LINK_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Linked Trade ID')
DECLARE @TRADEBOOK_REL_ID		NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Organizational'
													AND		coFunctionalContext		= 'Core'
													AND		coSubFunctionalContext	= 'Trade Book')
DECLARE @CP_REL_ID				NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Functional'
													AND		coFunctionalContext		= 'Credit'
													AND		coSuperRole				= 'Executing Broker'
													AND		coSubRole				= 'Client')
DECLARE @LEGACY_FRA_ID			NUMERIC(18,0)	= (	SELECT RiskInstrumentTypeID
													FROM	mcoredb..vwRiskProductType
													WHERE	sRiskInstrumentType		= 'FRA'
													AND		sRiskProductType		= 'Forward Rate Agreement'
													AND		sRiskAssetClass			= 'Fixed Income Derivatives')
DECLARE @FOLLOWING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Following')
DECLARE @PRECEDING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Preceding')
DECLARE @MOD_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Modified')
DECLARE @REG_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Regular')
DECLARE @BusDayRuleMurexBridge	TABLE			(MxDesc VARCHAR(50), BusDayRuleModifierID NUMERIC(18,0), BusDayRuleConventionID NUMERIC(18,0))
INSERT	@BusDayRuleMurexBridge
VALUES
	('Previous',			@PRECEDING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Next',				@FOLLOWING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Modified following',	@FOLLOWING_BDRMOD_ID, @MOD_BDRCONV_ID),
	('Modified preceding',	@PRECEDING_BDRMOD_ID, @MOD_BDRCONV_ID)
SET @MSG = 'Business Day Rule Codes inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @cof_typos				TABLE			(M_TRN_FMLY CHAR(5),	M_TRN_GRP CHAR(5),	M_TRN_TYPE CHAR(5),	sTypo VARCHAR(10))
INSERT @cof_typos
VALUES
	('IRD',		'LN_BR',	'',			'Depo')
	,('CURR',	'FXD',		'SWLEG',	'Fx Swap')
	,('SCF',	'SCF',		'SCF',		'SCF')
	,('IRD',	'IRS',		'',			'IRS')
	,('CURR',	'FXD',		'FXD',		'Spot')
	,('IRD',	'FRA',		'',			'FRA')
	,('CRD',	'CDS',		'',			'CDS')
	,('CRD',	'CRDI',		'',			'CDS Index')
SET @MSG = 'COF Typos inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)


--DECLARE @RoundingFuncBridge	TABLE			(MxDesc VARCHAR(50), sDescription VARCHAR(50))
--INSERT	@RoundingFuncBridge
--VALUES
--	('None',		NULL),
--	('Nearest',		'Nearest'),
--	('By excess',	'Round'),
--	('By default',	'RoundDown'),
--	('Currency',	NULL)
--SET @MSG = 'Rounding functions inserted.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @callables				TABLE			(TYPO CHAR(21) PRIMARY KEY CLUSTERED)
INSERT @callables
VALUES
	('IRS Callable')
	,('Rev Floater Callable')
	,('IR CapFloor Callable')
	,('IR CapFl Call CMS')
	,('IR CapFl Call CMS SP')
	,('IRS Callable CMS')
	,('IRS Callable CMS SP')
	,('IRS ZC Call CMS')
	,('IRS ZC Call CMS SP')
	,('IRS ZC Callable')
	,('Range Call CMS')
	,('Range Call CMS SP')
	,('Range Callable')
	,('Rev Flt Call CMS')
	,('Rev Flt Call CMS SP')
SET @MSG = 'Callables inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#TX_IDs') IS NOT NULL
	DROP TABLE #TX_IDs --select * from #tx_ids
CREATE TABLE #TX_IDs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
	Action				NVARCHAR(10)
	,TransactionID		NUMERIC(18,0) NOT NULL	--will put PK here in a few steps
	,M_H_NB_MZ			CHAR(12)
	,M_NB_EXT			NUMERIC(18,0)	--M_H_ALT_ID	CHAR(20)
	,M_USI_ID			CHAR(52)
	,M_USI_NS			CHAR(10)
	,M_BETA_ID			CHAR(10)
	,M_CCP_TRN_ID		CHAR(14)
	,M_TRN_FMLY			CHAR(5)
	,M_CNT_ORG			NUMERIC(10,0)
	,bLive				BIT
	,DataSourceID		INT
)

IF OBJECT_ID('tempdb..#TRADEBOOK') IS NOT NULL
	DROP TABLE #TRADEBOOK
CREATE TABLE #TRADEBOOK	(	--select count(*) FROM #TRADEBOOK
	sRef			VARCHAR(20)
	,DataSourceID	NUMERIC(18,0)
	,AccountID		NUMERIC(18,0)
	,PRIMARY KEY (sRef, DataSourceID)
)
INSERT #TRADEBOOK	--select count(*) from #tradebook order by sref
SELECT	RTRIM(LTRIM(xa.sRef)) sRef, mds.DataSourceID, a.AccountID
FROM	mcoredb..Account										a
JOIN	mcoredb..XRefAccount									xa	ON	xa.AccountID			= a.AccountID
JOIN	mcoredb..Party											p	ON	p.PartyID				= a.PartyID
JOIN	mcoredb..LookupCodes									ps	ON	ps.CodeID				= p.StatusID
JOIN	mcoredb..Relationship									tbr	ON	tbr.SubPartyID			= p.PartyID
JOIN	mcoredb..DataSource										mds	ON	mds.DataSourceID		= xa.DataSourceID
																	AND	mds.sSourceName			= 'Murex'
WHERE	p.coPartyType			= 'Internal Unit'
AND		ps.sCodeValue			= 'Active'
AND		tbr.RelationshipTypeID	= @TRADEBOOK_REL_ID --47
--order by sRef

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #TRADEBOOK.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#AFFILIATE') IS NOT NULL
	DROP TABLE #AFFILIATE
CREATE TABLE #AFFILIATE	(	--select count(*) FROM #AFFILIATE
	sRef		VARCHAR(20)		PRIMARY KEY
	--,AccountID	NUMERIC(18,0)
)
INSERT #AFFILIATE	--select count(*) from #AFFILIATE order by sref
SELECT DISTINCT xa.sRef
FROM	Credit				c
JOIN	LookupCodes			lc	ON	lc.CodeID				= c.AffiliateID
JOIN	Relationship		r	ON	r.SuperPartyID			= c.PartyID
JOIN	Party				p	ON	p.PartyID				= r.SubPartyID
JOIN	Account				a	ON	a.PartyID				= p.PartyID
JOIN	XRefAccount			xa	ON	xa.AccountID			= a.AccountID
JOIN	RelationshipType	rt	ON	rt.RelationshipTypeID	= r.RelationshipTypeID
JOIN	mcoredb..DataSource	mds	ON	mds.DataSourceID		= xa.DataSourceID
								AND	mds.sSourceName			= 'Murex'
WHERE	rt.coFunctionalContext	= 'Credit'
AND		rt.coRelationshipType	= 'Functional'
AND     lc.sCodeValue			= 'Yes'
AND		lc.sCategory			= 'Affiliate'
--order by sRef

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #AFFILIATE.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#CONTRACT') IS NOT NULL
	DROP TABLE #CONTRACT
CREATE TABLE #CONTRACT (	--select count(*) FROM #CONTRACT ORDER BY M_CONTRACT
	M_CONTRACT	NUMERIC(10,0)
	,M_TP_CNTRP	CHAR(35)
	,PRIMARY KEY CLUSTERED (M_CONTRACT, M_TP_CNTRP) -- PK MUST BE BOTH IF ADDED	--CONSTRAINT [PK_#CONTRACT] 
)
INSERT #CONTRACT -- select count (*) from #CONTRACT
SELECT		t.M_CONTRACT, RTRIM(t.M_TP_CNTRP) M_TP_CNTRP
FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP	t
JOIN		mcoredb..XRefLookup									xl	ON	xl.sRef					= t.M_CNT_TYPO
JOIN		mcoredb..LookupCodes								pt	ON	pt.CodeID				= xl.LookupCodeID
JOIN		mcoredb..DataSource									mds	ON	mds.DataSourceID		= xl.DataSourceID
																	AND	mds.sSourceName			= 'Murex'
--AND		pt.sCategory	= 'Product Type'		--not necessary
WHERE		t.dtArchive		= @dt
GROUP BY	t.M_CONTRACT, t.M_TP_CNTRP

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CONTRACT.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#COUNTERPARTY') IS NOT NULL
	DROP TABLE #COUNTERPARTY
CREATE TABLE #COUNTERPARTY (
	M_DSP_LBL	CHAR(35)	NOT NULL
	,M_CODE		CHAR(10)
	,AccountID	NUMERIC(18,0)
	,DataSourceID	NUMERIC(18,0) NOT NULL
)
INSERT #COUNTERPARTY
SELECT	--sRef--*
	LTRIM(RTRIM(cp.M_DSP_LBL)) M_DSP_LBL
	,M_CODE
	,xa.AccountID
	,xa.DataSourceID
FROM	mcoredb..XRefAccount								xa
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_REF_CNTP_REP		cp	ON	cp.M_CODE				= xa.sRef
JOIN	mcoredb..DataSource									mds	ON	mds.DataSourceID		= xa.DataSourceID
																AND	mds.sSourceName			= 'Murex'
WHERE	cp.dtArchive	= @dt
--ORDER BY 1
SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #COUNTERPARTY.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

ALTER TABLE #COUNTERPARTY ADD PRIMARY KEY (M_DSP_LBL, DataSourceID)

IF OBJECT_ID('tempdb..#CLEARING_HOUSES') IS NOT NULL
	DROP TABLE #CLEARING_HOUSES
CREATE TABLE #CLEARING_HOUSES (
	sName	VARCHAR(50)	PRIMARY KEY
)
INSERT	#CLEARING_HOUSES
SELECT	DISTINCT a.sName
FROM	mcoredb..Credit			c
JOIN	mcoredb..Relationship	r	ON	r.SuperPartyID		= c.PartyID
JOIN	mcoredb..Party			p	ON	p.PartyID			= r.SubPartyID
JOIN	mcoredb..Account		a	ON	a.PartyID			= p.PartyID
JOIN	mcoredb..LookupCodes	lu	ON	lu.CodeID			= a.IndustryTypeID
JOIN	mcoredb..XRefAccount	xa	ON	xa.AccountID		= a.AccountID
JOIN	mcoredb..DataSource		mds	ON	mds.DataSourceID	= xa.DataSourceID
									AND	mds.sSourceName		= 'Murex'
WHERE	lu.sCodeValue	= 'Clearing Corporations/QCCs'

SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CLEARING_HOUSES.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @TRADEENDCODES TABLE (CodeID	NUMERIC(18,0))
INSERT @TRADEENDCODES
SELECT	CodeID
FROM	mcoredb..LookupCodes
WHERE	sCategory = 'OTC Trade Status'
AND		sCodeValue IN ('CANCELED','EXPIRED','EXERCISED','MATURED','TERMINATED')


--SELECT TransactionID,DataSourceID,sRef,XRefOTCTradeTypeID INTO #XrefOTC
--FROM XRefOTCTransaction
--WHERE XRefOTCTradeTypeID = 1

SET @MSG = '@TRADEENDCODES inserted.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

/*
####################################################################################################
FIRST:
	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	DECLARE @DATASOURCE_ID_APOLLO	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource
														WHERE	sSourceName				= 'Apollo')
	delete x
	from mcoredb..OTCTransaction		t
	join mcoredb..XRefOTCTransaction	x on x.TransactionID = t.TransactionID
	where	--x.DataSourceID = @DATASOURCE_ID_APOLLO
	--and 
	t.DataSourceID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from XRefOTCTransaction',  @@ROWCOUNT)

THEN:
	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	DECLARE @MINTRANID NUMERIC(18,0) = 2418537
	DECLARE @MAXTRANID NUMERIC(18,0) = 2643492
	DECLARE @TRANID NUMERIC(18,0) = @MINTRANID
	WHILE @TRANID < @MAXTRANID
	BEGIN
		DELETE s
		--select count(*), min(t.transactionid) mintran, max(t.transactionid) maxtran	--2418537	2643492
		from mcoredb..IRDPaymentSchedule	s
		join mcoredb..OTCTransaction		t	on t.transactionid = s.TransactionID
		where t.datasourceid = @DATASOURCE_ID_MUREX
		and t.transactionid between @TRANID and @TRANID + 10000
		--and t.transactionid between 2400000 and 2418161
		SET @TRANID = @TRANID + 10000
		SELECT '@TRANID = ', @TRANID
		--PRINT '@TRANID = ' + CONVERT(VARCHAR, @TRANID)
		INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('@TRANID', @TRANID)
	END
THEN:
	!!! RUN EXEC sp_fkeys 'OTCTransaction' FIRST IN ORDER TO DETERMINE IF THERE ARE OTHER TABLES KEYED ON dbo.OTCTransaction!!
	CASCADES:
		CancelSchedule
		CDSTransaction
		EquityDerivative
		FXDerivative
		FXPaymentSchedule
		IRDNonLinear
		IRDTransactionLeg
		OTCTransactionDaily <== NOT THIS ANY LONGER
		OTCTransactionValuation
		TLock
		XRefOTCTransaction

	!!! RUN THIS TO SEE IF THERE ARE ANY NEW TRIGGERS TO DISABLE PRIOR TO DELETE (REENABLE AFTER DELETE!!!)
		select t.name, fk.name, tr.* 
		from sys.tables			t
		join sys.foreign_keys	fk	on fk.referenced_object_id	= t.object_id
		join sys.triggers		tr	on tr.parent_id				= fk.parent_object_id
		join sys.trigger_events	te	on te.object_id				= tr.object_id
		where	t.name			= 'otctransaction'
		and		te.type_desc	= 'DELETE'

	DISABLE TRIGGER delOTCTransaction_BK on OTCTransaction
	DISABLE TRIGGER tr_UDOTCTransactionValuation on OTCTransactionValuation

	DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
														FROM	mcoredb..DataSource		d
														JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
														WHERE	sSourceName				= 'Murex'
														AND		sEntityCode				= 'MCM')
	--THESE ARE KEYED ON mcoredb..FXDerivative:

	DELETE FS FROM mcoredb..FixingSchedule FS JOIN mcoredb..FXDerivative FX ON FX.FXDerivativeID = FS.FXDerivativeID JOIN mcoredb..OTCTransaction	T	ON T.TransactionID = FX.OTCTransactionID WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from FixingSchedule',  @@ROWCOUNT)

	DELETE FT FROM mcoredb..FXTransactionDaily FT JOIN mcoredb..FXDerivative	FD	ON FT.FXDerivativeID = FD.FXDerivativeID 
		JOIN mcoredb..OTCTransaction	T	ON T.TransactionID = FD.OTCTransactionID	WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from FXTransactionDaily',  @@ROWCOUNT)

	--THESE ARE CASCADE DELETES, BUT IT MAY BE FASTER TO DO THEM MANUALLY FIRST:

	DELETE CS FROM mcoredb..CancelSchedule						CS JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = CS.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from CancelSchedule',  @@ROWCOUNT)

	DELETE CD FROM mcoredb..CDSTransaction						CD JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = CD.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from CDSTransaction',  @@ROWCOUNT)

	DELETE EDFS FROM mcoredb..EquityDerivativeFixingSchedule	EDFS JOIN 
					mcoredb..EquityDerivative					ED	ON ED.EquityDerivativeID	= EDFS.EquityDerivativeID	JOIN 
					mcoredb..OTCTransaction						T	ON T.TransactionID			= ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from EquityDerivativeFixingSchedule',  @@ROWCOUNT)

	DELETE AFS FROM mcoredb..AveragingFixingSchedule			AFS JOIN
					mcoredb..EquityDerivative					ED	ON ED.EquityDerivativeID	= AFS.EquityDerivativeID	JOIN
					mcoredb..OTCTransaction						T	ON T.TransactionID			= ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from AveragingFixingSchedule',  @@ROWCOUNT)

	DELETE OTS FROM mcoredb..ObservationTerminationSchedule		OTS JOIN
					mcoredb..EquityDerivative					ED	ON ED.EquityDerivativeID	= OTS.EquityDerivativeID	JOIN
					mcoredb..OTCTransaction						T	ON T.TransactionID			= ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from ObservationTerminationSchedule',  @@ROWCOUNT)

	DELETE BS FROM mcoredb..BarrierSchedule						BS JOIN
					mcoredb..EquityDerivative					ED	ON ED.EquityDerivativeID	= BS.EquityDerivativeID		JOIN
					mcoredb..OTCTransaction						T	ON T.TransactionID			= ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from BarrierSchedule',  @@ROWCOUNT)

	DELETE ARS FROM mcoredb..AutoCallRedemptionSchedule			ARS JOIN
					mcoredb..EquityDerivative					ED	ON ED.EquityDerivativeID	= ARS.EquityDerivativeID		JOIN
					mcoredb..OTCTransaction						T	ON T.TransactionID			= ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from AutoCallRedemptionSchedule',  @@ROWCOUNT)

	DELETE ED FROM mcoredb..EquityDerivative					ED JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = ED.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from EquityDerivative',  @@ROWCOUNT)

	DELETE FX FROM mcoredb..FXDerivative						FX JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = FX.OTCTransactionID	WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from FXDerivative',  @@ROWCOUNT)

	DELETE FP FROM mcoredb..FXPaymentSchedule					FP JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = FP.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from FXPaymentSchedule',  @@ROWCOUNT)

	DELETE NL FROM mcoredb..IRDNonLinear						NL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = NL.OTCTransactionID	WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from IRDNonLinear',  @@ROWCOUNT)

	DELETE TL FROM mcoredb..IRDTransactionLeg					TL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TL.TransactionID		WHERE T.DATASOURCEID = @DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from IRDTransactionLeg',  @@ROWCOUNT)

	DISABLE TRIGGER tr_UDOTCTransactionDaily ON  mcoredb..OTCTransactionDaily
	DELETE TD FROM mcoredb..OTCTransactionDaily					TD JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TD.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from OTCTransactionDaily',  @@ROWCOUNT)
	ENABLE TRIGGER tr_UDOTCTransactionDaily ON  mcoredb..OTCTransactionDaily

	DISABLE TRIGGER tr_UDOTCTransactionValuation ON  mcoredb..OTCTransactionValuation
	DELETE TV FROM mcoredb..OTCTransactionValuation				TV JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TV.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from OTCTransactionValuation',  @@ROWCOUNT)
	ENABLE TRIGGER tr_UDOTCTransactionValuation ON  mcoredb..OTCTransactionValuation

	DELETE TL FROM mcoredb..TLock								TL JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = TL.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from TLock',  @@ROWCOUNT)

	DELETE XR FROM mcoredb..XRefOTCTransaction					XR JOIN mcoredb..OTCTransaction		T	ON T.TransactionID = XR.TransactionID		WHERE T.DATASOURCEID = 239--@DATASOURCE_ID_MUREX
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from XRefOTCTransaction',  @@ROWCOUNT)

	DISABLE TRIGGER delOTCTransaction_BK ON  mcoredb..OTCTransaction
	DELETE mcoredb..OTCTransaction WHERE DataSourceID = 239--@DATASOURCE_ID_MUREX	-- CASCADES TO XRefOTCTransaction, TLock
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP, VAL) VALUES ('Rows deleted from OTCTransaction',  @@ROWCOUNT)
	ENABLE TRIGGER delOTCTransaction_BK ON  mcoredb..OTCTransaction

	ENABLE TRIGGER tr_UDOTCTransactionValuation on OTCTransactionValuation

*/


SET @MSG = 'DECLARATIONS AND TEMP INSERTS FINISHED
'
IF @debug = 1 
BEGIN
	WAITFOR DELAY '00:00:00.001'	--Otherwise Declarations message can appear in the same millisecond as the #AGREEMENTS message and the log switches them
	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
END
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#OTC') IS NOT NULL
DROP TABLE tempdb..#OTC

	SELECT	-- * --xt.TransactionID, count(*)
		pt.CodeID ProdTypeID,						mds.DataSourceID DataSourceID,														CASE t.M_TP_INT 
																																				WHEN 'Y' THEN tbi.AccountID 
																																				ELSE cp.AccountID END CP_ID,							tb.AccountID TradeBookID,
	--ts.sCodeValue,
	--t.M_TP_STATUS2,
	--t.M_AMD_STS2,
	--ev.M_H_EVENT,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 1----------------------------------------------------
		ts.CodeID TradeStatusID,					IIF(t.M_TP_STATUS2 IN ('LIVE','MKT_OP'), 1, 0) Active,									CASE t.M_TP_INT WHEN 'Y' THEN 1 ELSE 0 END Internal,		t.M_TP_DTETRN,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 2----------------------------------------------------
		CASE
		WHEN t.M_CNT_TYPO	= 'Fwd Start Van FXD'
					THEN	t.M_TP_DTEFXGL
		WHEN t.M_CNT_TYPO	IN ('Avg Rate Fwd FXD','Average Asian FXD')
					THEN	t.M_TP_DTEFXGF
		WHEN t.M_TRN_FMLY	= 'CURR'
					THEN	t.M_TP_DTEEXP
		WHEN t.M_TRN_FMLY	= 'SCF'
					THEN	t.M_TP_DTETRN
		WHEN t.M_CNT_TYPO	= 'Treasury Lock'
					THEN	t.M_TP_DTETRN

		ELSE	
			CASE t.M_CNT_TYPO
			WHEN 'ASR EQD'				THEN	flx.M_REF_DATE
			WHEN 'VWAP Plus EQD'		THEN	flx.M_REF_DATE
			WHEN 'Forward EQD'			THEN	t.M_TP_DTETRN
			WHEN 'Accr Strike Fwd EQD'	THEN	t.M_TP_DTEFXGF
			WHEN 'Amort Strike Fwd EQD'	THEN	t.M_TP_DTEFXGF
			WHEN 'Vanilla Option EQD'	THEN	t.M_TP_DTETRN
			WHEN 'Composite Option EQD'	THEN	t.M_TP_DTETRN
			WHEN 'Quanto Option EQD'	THEN	t.M_TP_DTETRN
			WHEN 'Asian Option EQD'		THEN
				CASE	
				WHEN exo.M_ASIAN_STY = 'A-K'
										THEN	t.M_TP_DTETRN
				ELSE							ao.FirstFixingDate
				END
			WHEN 'Autocall EQD'			THEN	t.M_TP_DTETRN
			WHEN 'Warrant EQD'			THEN	t.M_TP_DTETRN
			WHEN 'Total Return Swap EQ'	THEN	t.M_TP_DTEFXGF
			WHEN 'Price Return Swap EQ'	THEN	t.M_TP_DTEFXGF
			WHEN 'ETO EQD'				THEN	t.M_TP_DTETRN
			WHEN 'Equity future'		THEN	t.M_TP_DTETRN
			WHEN 'Equity'				THEN	t.M_TP_DTETRN
			WHEN 'ADR'					THEN	t.M_TP_DTETRN
			WHEN 'ETF'					THEN	t.M_TP_DTETRN
			WHEN 'FWD Start Option EQD'	THEN
				CASE exo.M_FWDS_KEY
				WHEN 0					THEN	t.M_TP_DTETRN	
				ELSE							exo.M_FWD_S_DTE
				END
			WHEN 'Barrier Option EQD'	THEN
				CASE exo.M_FWDS_KEY
				WHEN 0					THEN	t.M_TP_DTETRN	
				ELSE							exo.M_FWD_S_DTE
				END
			ELSE								t.M_TP_RTSD0
			END
		END					dtEffective,
													t.M_TP_DTEEXP dtMaturity,																CASE
																																			WHEN	t.M_TRN_FMLY <> 'CURR'
																																			AND		t.M_TP_RTMAT0 IS NULL
																																			THEN	t.M_TP_RTMAT1
																																			WHEN	t.M_TRN_FMLY IN ('CURR', 'SCF')
																																			THEN	t.M_TP_DTEEXP
																																			ELSE	t.M_TP_RTMAT0 END dtUnadjustedMaturity,				t.M_TP_NOMCUR sCurrency,

		CASE
		WHEN t.M_TRN_FMLY = 'SCF'
		THEN CASE t.M_TP_RTPR0
				WHEN 'P' THEN -t.M_TP_NOMINAL
				WHEN 'R' THEN t.M_TP_NOMINAL
				END
		ELSE CASE t.M_CNT_TYPO
			WHEN 'ASR EQD'			THEN COALESCE(flx.M_NOTIONAL, 0)
			WHEN 'VWAP Plus EQD'	THEN COALESCE(flx.M_NOTIONAL, 0)
			ELSE ABS(t.M_TP_NOMINAL)
			END
		END					dNotional,

		--------------------------------------------------------------------------------------------------------------------------------------------ROW 3----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATE)
							dtCleared,				CASE
													WHEN	ch.sName		IS NOT NULL
													THEN	cpc.AccountID
													WHEN	t.M_TP_STATUS2	= 'MKT_OP'
													AND		t.M_AMD_STS2	= 'OA' 
													AND		ev.M_H_EVENT	IN ('Counterpart assignment'
																				,'Counterpart amendment (FULL)') 
													THEN	cpo.AccountID	
													END									OriginalCPAccountID,								NULL ParentTransactionID,									CASE	WHEN ch.sName IS NOT NULL
																																																				THEN 1 ELSE 0 END Cleared,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 4----------------------------------------------------
		udf.M_CLR_BR sClearingBroker,				rpt.CodeID RiskProductTypeID,															NULL ClearingBrokerID,										NULL OriginatorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 5----------------------------------------------------
		t.M_PACKAGE sStrategy,						CASE
													WHEN agr.M_SIMM_AGR IS NULL THEN 0
													ELSE
														CASE agr.M_SIMM_AGR
															WHEN 'No SIMM agreement' 
															THEN 0 ELSE 1 END
														END						bSIMMEligible,												ag.AgreementID CollateralAgreementID,						CASE
																																																		WHEN t.M_TP_PFOLIO
																																																			IN ('ATD','ETD','HTD','ITD','STD','MIZS','MTB')
																																																		OR	aff.sRef IS NOT NULL
																																																			THEN 1 ELSE 0 END bAffiliate,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 6----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATE)
					dtClearingTimestamp,			TRY_PARSE(udf.M_CONF_TS AS DATE) dtConfirmationTimestamp,								TRY_PARSE(udf.M_EXEC_TS AS DATE) dtExecutionTimestamp,		CONVERT(NUMERIC, t.M_CONTRACT) ContractKey,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 7----------------------------------------------------
		t.M_CNT_VS2 ContractVersion,				ISNULL(t.M_CNTLEVTAD2, t.M_TP_DTESYS)  dtModification,									t.M_TP_TRADER sTrader,										IIF(s.M_MB_ID = 'Y', 1, 0) bMutualBreak,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 8----------------------------------------------------
		term.MAX_M_BKMANDEFFD
			dtMutualMandatoryTermination,			IIF(t.M_CNT_TYPO IN (SELECT TYPO FROM @callables),
															cb.CallableByID, NULL)	CancellableByID,										os.OptionStyleID CancelTypeID,								bt.OptionStyleID BreakTypeID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 9----------------------------------------------------
		oct.CollateralizationTypeID
			OurCollateralizationTypeID,				cct.CollateralizationTypeID CtpCollateralizationTypeID,									udf.M_EXEC_TYPE sExecutionVenue,							CASE
																																																		WHEN	t.M_CNTLIMPL2 <> ''
																																																		THEN	t.M_CNTLIMPL2
																																																		WHEN	t.M_CNTLIMPL2 = ''
																																																		AND		t.M_CNTLEVTL2 <> t.M_CNT_EVTL
																																																		THEN	t.M_CNTLEVTL2 END sLastEventName,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 10---------------------------------------------------
		t.M_INSTRUMENT sMXGeneratorLabel,			brk.AccountID BrokerAccountID,															IIF(t.M_CNT_TYPO = 'COF', 1, 0) bCOF,						t.M_TP_DTEFLWL dtLastCashflow,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 11---------------------------------------------------
		udf.M_AFF_BIL_BK sAffiliateBillingBook,		udf.M_EXEC_LEI sExecutionVenueLEI,
		--------------------------------------------------------------------COLUMNS FOR #TX_IDs ONLY---------------------------------------------------------------------------------------------------------
		t.M_H_NB_MZ,								xt.TransactionID,																		t.M_NB_EXT,	/*M_H_ALT_ID,*/									ec.CodeID,
		t.M_H_DATA_DT2,								LEFT(udf.M_USI_ID, 50) M_USI_ID,														LEFT(udf.M_BETA_ID, 50) M_BETA_ID,							udf.M_USI_NS M_USI_NS,
		udf.M_CCP_TRN_ID,							t.M_TRN_FMLY,																			t.M_CNT_ORG
	INTO #OTC
	FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP					t
	JOIN		mcoredb.refcode.Entity												ent		ON	ent.sEntityCode				= RTRIM(t.M_TP_LENTDSP)
	JOIN		mcoredb..DataSource													mds		ON	mds.EntityID				= ent.EntityID
																							AND	mds.sSourceName				= 'Murex'
	LEFT JOIN	@cof_typos															cof		ON	cof.M_TRN_FMLY				= t.M_TRN_FMLY
																							AND	cof.M_TRN_GRP				= t.M_TRN_GRP
																							AND	cof.M_TRN_TYPE				= t.M_TRN_TYPE
	JOIN		mcoredb..XRefLookup													xl		ON	RTRIM(LTRIM(xl.sRef))		= IIF(t.M_CNT_TYPO NOT IN ('COF','SCF-Man. Adjustment'), RTRIM(LTRIM(t.M_CNT_TYPO)), cof.sTypo)
																							AND	xl.DataSourceID				= @DATASOURCE_ID_MUREX
																							AND	t.dtArchive					= @dt
	JOIN		mcoredb..LookupCodes												pt		ON	pt.CodeID					= xl.LookupCodeID
																							AND	pt.sCategory				= 'Product Type'
																							AND	pt.ParentID					IS NOT NULL	--THIS REMOVES THE PARENT 'SCF' PT BUT LEAVES THE CHILD
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP				s
																							ON	s.M_NB						= t.M_NB
																							AND	s.dtArchive					= @dt
	LEFT JOIN (
		SELECT		M_H_NB_MZ, MAX(M_BKMANDEFFD) MAX_M_BKMANDEFFD
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_EXE_SCHDL_REP
		WHERE		dtArchive	= @dt
		AND			M_TP_BREAK	= 'Y'
		GROUP BY	M_H_NB_MZ
	)																				term	ON	term.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.CallableBy											cb		ON	cb.sName					= t.M_TP_CANCBY
	LEFT JOIN	#CLEARING_HOUSES													ch		ON	ch.sName					= t.M_TP_CNTRP
	LEFT JOIN (
		SELECT	xlr.sRef, lc.CodeID
		FROM	mcoredb..XRefLookup		xlr
		JOIN	mcoredb..LookupCodes	lc	ON	lc.CodeID = xlr.LookupCodeID
		WHERE	xlr.DataSourceID		= @DATASOURCE_ID_MUREX
		AND		lc.sCategory			= 'Risk Product Type'
		AND		lc.bActive				= 1
		AND		lc.CodeID				<> @LEGACY_FRA_ID
	)																				rpt		ON	RTRIM(LTRIM(rpt.sRef))		= IIF(t.M_CNT_TYPO NOT IN ('COF','SCF-Man. Adjustment'), RTRIM(LTRIM(t.M_CNT_TYPO)), cof.sTypo)
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_UDF_DEAL_REP					udf		ON	udf.M_UDF_REF				= t.M_UDF_REF2
																							AND	udf.dtArchive				= @dt
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP				agr		ON	agr.M_TRADE_NB				= t.M_NB
																							AND	agr.dtArchive				= @dt
	LEFT JOIN	mcoredb..Agreement													ag		ON	ag.sLegalName				= agr.M_NETTING_KEY
	LEFT JOIN (
		SELECT	M_IDENTITY
				,e.M_H_NB_MZ
				,M_H_EVENT
				,M_H_DATA_DT2
		FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP						e
		CROSS APPLY (	SELECT	MAX(M_IDENTITY) MAX_ID, M_H_NB_MZ
						FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
						WHERE	M_H_NB_MZ	= e.M_H_NB_MZ
						AND		dtArchive	= @dt
						GROUP BY M_H_NB_MZ
					) g
		WHERE	M_IDENTITY = MAX_ID
		AND		e.dtArchive	= @dt

		)																			ev		ON	ev.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN (
		SELECT	CodeID, sCodeValue
		FROM	mcoredb..LookupCodes
		WHERE	sCategory = 'OTC Trade Status'
	)																				ts		ON	ts.sCodeValue				= CASE
																																WHEN			t.M_TP_STATUS2		IN ('MKT_OP','LIVE')				THEN 'ACTIVE'
																																WHEN			t.M_TP_STATUS2		= 'DEAD'							THEN
																																	CASE
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		= 'Restructure'						THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		IN ('Cancel and reissue'
																																										,'Counterpart amendment (FULL)'
																																										,'Portfolio modification')		THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		IN ('NA','CA')
																																		AND		t.M_CNTLIMPL2		= 'Allocation'						THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		= 'CA'
																																		AND		t.M_CNTLIMPL2		= 'Cancel'							THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		IN ('CA','NA')
																																		AND		t.M_CNTLIMPL2		= ''								THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Expiry'							THEN 'EXPIRED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Exercise'
																																										,'Knock'
																																										,'Exercise Cancellable Trade')	THEN 'EXERCISED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Unwind'							THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Counterpart assignment'
																																										,'Step out'
																																										,'Portfolio assignment'
																																										,'Netting')						THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		(t.M_TRN_GRP		= 'FRA'
																																				AND t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR 
																																				ev.M_H_EVENT		NOT IN ('Counterpart assignment'
																																											,'Step out')
																																				AND t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				)														THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= ''								THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2		NOT IN ('CA','CL','NA')
																																		AND
																																				(t.M_TRN_GRP		= 'FRA'
																																				AND	t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	<> 'CURR'
																																				AND	t.M_TP_RTMAT0	IS NULL
																																				AND	t.M_TP_RTMAT1	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	= 'CURR'
																																				AND	t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				OR	t.M_TP_RTMAT0	<= t.M_H_DATA_DT2
																																				)														THEN 'MATURED'
																																		ELSE																 'CANCELED'
																																	END
																																END
	LEFT JOIN	@TRADEENDCODES														ec		ON	ec.CodeID							= ts.CodeID
	LEFT JOIN	#CONTRACT															ct		ON	ct.M_CONTRACT						= LTRIM(RTRIM(t.M_TP_ROOTCNT))
																							AND	ct.M_TP_CNTRP						= LTRIM(RTRIM(t.M_TP_CNTRP))
	JOIN		#TRADEBOOK															tb		ON	tb.sRef								= LTRIM(RTRIM(t.M_TP_PFOLIO))
																							AND	tb.DataSourceID						= mds.DataSourceID
	LEFT JOIN	#COUNTERPARTY														cp		ON	cp.M_DSP_LBL						= LTRIM(RTRIM(t.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
																							AND	cp.DataSourceID						= mds.DataSourceID
	LEFT JOIN	#TRADEBOOK															tbi		ON	tbi.sRef							= LTRIM(RTRIM(t.M_TP_CNTRP))		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
																							AND	tbi.DataSourceID					= mds.DataSourceID
	LEFT JOIN	#COUNTERPARTY														cpo		ON	cpo.M_DSP_LBL						= LTRIM(RTRIM(ct.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
																							AND	cpo.DataSourceID					= mds.DataSourceID
	LEFT JOIN	#COUNTERPARTY														cpc		ON	cpc.M_DSP_LBL						= LTRIM(RTRIM(udf.M_BILAT_CTPY))	--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
																							AND	cpc.DataSourceID					= mds.DataSourceID
	LEFT JOIN	mcoredb..XRefOTCTransaction											xt		ON	xt.sRef								= LTRIM(RTRIM(t.M_H_NB_MZ))
																							AND	xt.DataSourceID						= mds.DataSourceID
																							AND xt.XRefOTCTradeTypeID				= @TRDREFTYPE_PRIMARY_ID
	LEFT JOIN	#AFFILIATE															aff		ON	aff.sRef							= cp.M_CODE		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
	LEFT JOIN	(
		SELECT		M_H_NB_MZ, MAX(M_V_DATE)	MAX_M_V_DATE
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
		WHERE		dtArchive	= @dt
		GROUP BY	M_H_NB_MZ
	)																				mods	ON	mods.M_H_NB_MZ						= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.OptionStyle											os		ON	os.sName					= CASE
																																WHEN	t.M_CNT_TYPO	IN (SELECT TYPO FROM @callables)
																																THEN	CASE t.M_TP_AE
																																		WHEN 'E' THEN 'European'
																																		WHEN 'A' THEN 'American'
																																		WHEN 'B' THEN 'Bermudan' END
																																END
	LEFT JOIN	mcoredb.refcode.OptionStyle											bt		ON	bt.sName					= CASE
																																WHEN	s.M_MB_ID = 'Y'
																																THEN	CASE s.M_MB_BRKMODE
																																		WHEN '0' THEN 'Bermudan'
																																		WHEN '1' THEN 'European' END
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								oct	ON	oct.sName						= CASE		udf.M_COL_TP_OUR
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								cct	ON	cct.sName						= CASE		udf.M_COL_TP_CTP
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	#COUNTERPARTY														brk	ON	brk.M_DSP_LBL					= LTRIM(RTRIM(udf.M_BROKER))		--was t.M_TP_BROLBL0
																						AND	brk.DataSourceID				= mds.DataSourceID

	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_EQDFLEX_REP					flx ON	flx.M_NB						= t.M_NB
																						AND	flx.dtArchive					= t.dtArchive	
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_EQDEXOT_REP 					exo	ON	exo.M_NB						= t.M_NB
																						AND	exo.dtArchive					= t.dtArchive
	LEFT JOIN (
		SELECT M_NB, MIN(M_DATES) FirstFixingDate
		FROM mcoredb_archive.stage.MDR_MUREX_DM_EQD_AO_FIX_REP 
		WHERE dtArchive = @dt
		GROUP by M_NB
	)																				ao	ON	ao.M_NB							= t.M_NB OPTION(RECOMPILE)
--group by xt.TransactionID
--having count(*)>1

CREATE CLUSTERED INDEX [IX_#OTC_TXIDS] ON #OTC 
(TransactionID)

IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('#OTC TEMP TABLE CREATED')

SET NOCOUNT OFF
--BEGIN TRANSACTION	--If the OTCTransaction MERGE succeeds, but the XRefOTCTransaction MERGE fails, it all has to be rolled back
--BEGIN TRY
MERGE mcoredb..OTCTransaction				 WITH (TABLOCK)			TGT  
USING #OTC															SRC	ON	SRC.TransactionID				= TGT.TransactionID
WHEN MATCHED THEN
	UPDATE SET
		ProductTypeID					= IIF(SRC.CodeID IS NULL, SRC.ProdTypeID					, TGT.ProductTypeID)
		,DataSourceID					= IIF(SRC.CodeID IS NULL, SRC.DataSourceID					, TGT.DataSourceID)
		,CPAccountID					= SRC.CP_ID
		,TradingAccountID				= SRC.TradeBookID
		,TradeStatusID					= IIF(SRC.CodeID			IS NOT NULL 
											AND TGT.bActive			= 0
											AND	TGT.TradeStatusID	IS NOT NULL
																, TGT.TradeStatusID					, SRC.TradeStatusID)
		,bActive						= SRC.Active
		,bInternal						= IIF(SRC.CodeID IS NULL, SRC.Internal						, TGT.bInternal)
		,dtTrade						= SRC.M_TP_DTETRN
		,dtEffective					= SRC.dtEffective
		,dtMaturity						= SRC.dtMaturity
		,dtUnadjustedMaturity			= SRC.dtUnadjustedMaturity
		,sCurrency						= IIF(SRC.CodeID IS NULL, SRC.sCurrency						, TGT.sCurrency)
		,dNotional						= IIF(SRC.CodeID IS NULL, SRC.dNotional						, TGT.dNotional)
		,dtCleared						= IIF(SRC.CodeID IS NULL, SRC.dtCleared						, TGT.dtCleared)
		,OriginalCPAccountID			= SRC.OriginalCPAccountID
		,ParentTransactionID			= IIF(SRC.CodeID IS NULL, SRC.ParentTransactionID			, TGT.ParentTransactionID)
		,bCleared						= IIF(SRC.CodeID IS NULL, SRC.Cleared						, TGT.bCleared)
		,sClearingBroker				= IIF(SRC.CodeID IS NULL, SRC.sClearingBroker				, TGT.sClearingBroker)
		,RiskProductTypeID				= SRC.RiskProductTypeID
		,ClearingBrokerID				= IIF(SRC.CodeID IS NULL, SRC.ClearingBrokerID				, TGT.ClearingBrokerID)
		,OriginatorID					= IIF(SRC.CodeID IS NULL, SRC.OriginatorID					, TGT.OriginatorID)
		,sStrategy						= IIF(SRC.CodeID IS NULL, SRC.sStrategy						, TGT.sStrategy)
		,bSIMMEligible					= IIF(SRC.CodeID IS NULL, SRC.bSIMMEligible					, TGT.bSIMMEligible)
		,CollateralAgreementID			= IIF(SRC.CodeID IS NULL, SRC.CollateralAgreementID			, TGT.CollateralAgreementID)
		,bAffiliate						= IIF(SRC.CodeID IS NULL, SRC.bAffiliate					, TGT.bAffiliate)
		,dtClearingTimestamp			= IIF(SRC.CodeID IS NULL, SRC.dtClearingTimestamp			, TGT.dtClearingTimestamp)
		,dtConfirmationTimestamp		= IIF(SRC.CodeID IS NULL, SRC.dtConfirmationTimestamp		, TGT.dtConfirmationTimestamp)
		,dtExecutionTimestamp			= IIF(SRC.CodeID IS NULL, SRC.dtExecutionTimestamp			, TGT.dtExecutionTimestamp)
		,ContractKey					= IIF(SRC.CodeID IS NULL, SRC.ContractKey					, TGT.ContractKey)
		,ContractVersion				= SRC.ContractVersion
		,dtModification					= CASE
											WHEN TGT.bActive = SRC.Active AND TGT.bActive = 1 THEN SRC.dtModification 
											WHEN TGT.bActive = SRC.Active AND TGT.bActive = 0 THEN TGT.dtModification
											ELSE SRC.M_H_DATA_DT2 END
		,sTrader						= IIF(SRC.CodeID IS NULL, SRC.sTrader						, TGT.sTrader)
		,bMutualBreak					= IIF(SRC.CodeID IS NULL, SRC.bMutualBreak					, TGT.bMutualBreak)
		,dtMutualMandatoryTermination	= IIF(SRC.CodeID IS NULL, SRC.dtMutualMandatoryTermination	, TGT.dtMutualMandatoryTermination)
		,CancellableByID				= IIF(SRC.CodeID IS NULL, SRC.CancellableByID				, TGT.CancellableByID)
		,CancelTypeID					= IIF(SRC.CodeID IS NULL, SRC.CancelTypeID					, TGT.CancelTypeID)
		,BreakTypeID					= IIF(SRC.CodeID IS NULL, SRC.BreakTypeID					, TGT.BreakTypeID)
		,OurCollateralizationTypeID		= IIF(SRC.CodeID IS NULL, SRC.OurCollateralizationTypeID	, TGT.OurCollateralizationTypeID)
		,CtpCollateralizationTypeID		= IIF(SRC.CodeID IS NULL, SRC.CtpCollateralizationTypeID	, TGT.CtpCollateralizationTypeID)
		,sExecutionVenue				= IIF(SRC.CodeID IS NULL, SRC.sExecutionVenue				, TGT.sExecutionVenue)
		,sLastEventName					= SRC.sLastEventName
		,sMXGeneratorLabel				= IIF(SRC.CodeID IS NULL, SRC.sMXGeneratorLabel				, TGT.sMXGeneratorLabel)
		,BrokerAccountID				= IIF(SRC.CodeID IS NULL, SRC.BrokerAccountID				, TGT.BrokerAccountID)
		,bCOF							= IIF(SRC.CodeID IS NULL, SRC.bCOF							, TGT.bCOF)
		,dtLastCashflow					= SRC.dtLastCashflow
		,sAffiliateBillingBook			= IIF(SRC.CodeID IS NULL, SRC.sAffiliateBillingBook			, TGT.sAffiliateBillingBook)
WHEN NOT MATCHED THEN
	INSERT
		(ProductTypeID,							DataSourceID,																			CPAccountID,												TradingAccountID,
		TradeStatusID,							bActive,																				bInternal,													dtTrade,
		dtEffective,							dtMaturity,																				dtUnadjustedMaturity,										sCurrency,
		dNotional,
		dtCleared,								OriginalCPAccountID,																	ParentTransactionID,										bCleared,
		sClearingBroker,						RiskProductTypeID,																		ClearingBrokerID,											OriginatorID,
		sStrategy,								bSIMMEligible,																			CollateralAgreementID,										bAffiliate,
		dtClearingTimestamp,					dtConfirmationTimestamp,																dtExecutionTimestamp,										ContractKey,
		ContractVersion,						dtModification,																			sTrader,													bMutualBreak,
		dtMutualMandatoryTermination,			CancellableByID,																		CancelTypeID,												BreakTypeID,
		OurCollateralizationTypeID,				CtpCollateralizationTypeID,																sExecutionVenue,											sLastEventName,
		sMXGeneratorLabel,						BrokerAccountID,																		bCOF,														dtLastCashflow,
		sAffiliateBillingBook)
	VALUES
		(ProdTypeID,							DataSourceID,																			CP_ID,														TradeBookID,
		TradeStatusID,							Active,																					Internal,													M_TP_DTETRN,
		dtEffective,							dtMaturity,																				dtUnadjustedMaturity,										sCurrency,
		dNotional,
		dtCleared,								OriginalCPAccountID,																	ParentTransactionID,										Cleared,
		sClearingBroker,						RiskProductTypeID,																		ClearingBrokerID,											OriginatorID,
		sStrategy,								bSIMMEligible,																			CollateralAgreementID,										bAffiliate,
		dtClearingTimestamp,					dtConfirmationTimestamp,																dtExecutionTimestamp,										ContractKey,
		ContractVersion,						dtModification,																			sTrader,													bMutualBreak,
		dtMutualMandatoryTermination,			CancellableByID,																		CancelTypeID,												BreakTypeID,
		OurCollateralizationTypeID,				CtpCollateralizationTypeID,																sExecutionVenue,											sLastEventName,
		sMXGeneratorLabel,						BrokerAccountID,																		bCOF,														dtLastCashflow,
		sAffiliateBillingBook)
WHEN NOT MATCHED BY SOURCE
	AND TGT.DataSourceID				IN (SELECT DataSourceID
											FROM mcoredb..DataSource
											WHERE sSourceName = 'Murex')
	AND TGT.TradeStatusID				<> @TRADE_STAT_ID_PURGED
	AND	TGT.sDescription				<> 'COLVA'
	THEN UPDATE SET
		TradeStatusID					= @TRADE_STAT_ID_PURGED
OUTPUT	--SAVE UPSERTED IDs IN #TX_IDs
	$action, inserted.TransactionID, SRC.M_H_NB_MZ, SRC.M_NB_EXT/*M_H_ALT_ID*/, 
			SRC.M_USI_ID, SRC.M_USI_NS, SRC.M_BETA_ID, SRC.M_CCP_TRN_ID, SRC.M_TRN_FMLY, SRC.M_CNT_ORG, IIF(SRC.CodeID IS NULL, 1, 0)	-- = bLive
			,SRC.DataSourceID
INTO #TX_IDs OPTION(RECOMPILE);
SET @InsertCount = (SELECT COUNT(*) FROM #TX_IDs WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #TX_IDs WHERE Action = 'UPDATE')

SET @MSG = 'Finished trade MERGE: @InsertCount = ' + CONVERT(VARCHAR, @InsertCount) + ', @UpdateCount = ' + CONVERT(VARCHAR, @UpdateCount)
				+ ', Total rows affected = ' + CONVERT(VARCHAR, @InsertCount + @UpdateCount)
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG

SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer @Finish MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer @Finish MERGE:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)

ALTER TABLE #TX_IDs ADD PRIMARY KEY (TransactionID)
CREATE NONCLUSTERED INDEX [IX_#TX_IDs_M_H_NB_MZ] ON #TX_IDs
(
	M_H_NB_MZ
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
--select*from #TX_IDs where TransactionID=1761157

SET @MSG = 'Added PK to #TX_IDs'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--	NOT SURE WHY UNIQUE CONSTRAINT WAS ADDED, NO FURTHER ROWS INSERTED OR UPDATED BEYOND THIS POINT
--IF OBJECT_ID('UQ_#TX_IDs_M_H_NB_MZ') IS NOT NULL AND OBJECT_ID('#TX_IDs') IS NOT NULL
--BEGIN
--	ALTER TABLE #TX_IDs
--	DROP CONSTRAINT UQ_#TX_IDs_M_H_NB_MZ
--END
--ALTER TABLE #TX_IDs ADD CONSTRAINT UQ_#TX_IDs_M_H_NB_MZ UNIQUE (M_H_NB_MZ)
--SET @MSG = 'Added unique constraint to #TX_IDs.M_H_NB_MZ'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--PRINT 'Timer to create PK and index on #TX_IDs:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE()))
--INSERT stage.MDR_MUREX__PROGRESS VALUES('Timer to create PK and index on #TX_IDs:  ' + CONVERT(VARCHAR, DATEDIFF(ms, @start, GETDATE())), DEFAULT)


--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IF OBJECT_ID('tempdb..#XREF_MERGE') IS NOT NULL
	DROP TABLE #XREF_MERGE
CREATE TABLE #XREF_MERGE (
	Action					NVARCHAR(10)
	,DataSourceID			NUMERIC(18,0)
	,XRefOTCTradeTypeID		NUMERIC(18,0)
)

MERGE mcoredb..XRefOTCTransaction	 WITH (TABLOCK)	TGT
USING (
	SELECT										--M_H_NB_MZ
		TransactionID							TransactionID
		,DataSourceID							DataSourceID
		,RTRIM(M_H_NB_MZ)						sRef
		,@TRDREFTYPE_PRIMARY_ID					XRefOTCTradeTypeID
		,bLive									bLive
	FROM #TX_IDs
	WHERE DataSourceID IS NOT NULL

	UNION										--M_NB_EXT/DEAL_REF		--was M_H_ALT_ID
	SELECT
		TransactionID
		,@DATASOURCE_ID_APOLLO
		,CONVERT(VARCHAR(50), a.DEAL_NUMBER)	--M_NB_EXT = DEAL_REF -> DEAL_NUMBER gets inserted into sRef
		,@TRDREFTYPE_PRIMARY_ID
		,bLive
	FROM #TX_IDs										t									--WHERE Action = 'INSERT'
	JOIN mcoredb.stage.MDR_APOLLO_DEAL_REF_LOOKUP		a	ON	a.DEAL_REF = t.M_NB_EXT
	WHERE	M_NB_EXT			IS NOT NULL
	AND		M_NB_EXT			> 0
	AND		DataSourceID		IS NOT NULL

	UNION										--M_USI_NS + M_USI_ID
	SELECT
		TransactionID
		,DataSourceID
		,CONVERT(VARCHAR(50), RTRIM(ISNULL(M_USI_NS, '')) + RTRIM(M_USI_ID))
		,@TRDREFTYPE_USI_ID
		,bLive
	FROM #TX_IDs
	WHERE	M_USI_ID			IS NOT NULL
	AND		RTRIM(M_USI_ID)		<> ''
	AND		DataSourceID		IS NOT NULL

	UNION										--M_BETA_ID
	SELECT
		TransactionID
		,@DATASOURCE_ID_MARKIT
		,RTRIM(M_BETA_ID)
		,@TRDREFTYPE_PRIMARY_ID
		,bLive
	FROM #TX_IDs
	WHERE	M_BETA_ID			IS NOT NULL
	AND		RTRIM(M_BETA_ID)	<> ''
	AND		M_TRN_FMLY			= 'IRD'
	AND		DataSourceID		IS NOT NULL

	UNION										--CCP_ID
	SELECT
		TransactionID
		,DataSourceID
		,RTRIM(M_CCP_TRN_ID)
		,@TRDREFTYPE_CCP_ID
		,bLive
	FROM #TX_IDs
	WHERE	M_CCP_TRN_ID		IS NOT NULL
	AND		RTRIM(M_CCP_TRN_ID)	<> ''
	AND		DataSourceID		IS NOT NULL

	UNION										--ORIGINAL MUREX CONTRACT ID
	SELECT
		TransactionID
		,DataSourceID
		,CONVERT(VARCHAR, M_CNT_ORG)
		,@TRDREFTYPE_LINK_ID
		,bLive
	FROM #TX_IDs
	WHERE DataSourceID			IS NOT NULL
)														SRC	ON	SRC.TransactionID		= TGT.TransactionID
															AND	SRC.DataSourceID		= TGT.DataSourceID
															AND	SRC.XRefOTCTradeTypeID	= TGT.XRefOTCTradeTypeID
WHEN NOT MATCHED THEN
	INSERT
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
	VALUES
		(TransactionID, DataSourceID, sRef, XRefOTCTradeTypeID)
WHEN MATCHED THEN
	UPDATE SET
		sRef				= IIF(SRC.bLive = 1, SRC.sRef, TGT.sRef)
OUTPUT $action, SRC.DataSourceID, SRC.XRefOTCTradeTypeID INTO #XREF_MERGE OPTION(RECOMPILE);
SET @InsertCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'INSERT')
SET @UpdateCount = (SELECT COUNT(*) FROM #XREF_MERGE WHERE Action = 'UPDATE')


SET @MSG = 'Inserted ' + CONVERT(VARCHAR, @InsertCount) + ' MUREX rows into XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)
SET @MSG = 'Updated ' + CONVERT(VARCHAR, @UpdateCount) + ' MUREX rows in XRefOTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

IF OBJECT_ID('tempdb..#XrefOTC2') IS NOT NULL
DROP TABLE tempdb..#XrefOTC2

SELECT TransactionID,DataSourceID,sRef,XRefOTCTradeTypeID INTO #XrefOTC2
FROM XRefOTCTransaction
--UPDATE BUSINESS KEY
UPDATE	o
SET		sBusinessKey = dbo.fnBusinessKey(o.TransactionID, 'O')
FROM	#XrefOTC2				x
JOIN	OTCTransaction					o	ON	o.TransactionID				= x.TransactionID
											AND o.DataSourceID				= x.DataSourceID
											AND x.XRefOTCTradeTypeID		= @TRDREFTYPE_PRIMARY_ID
JOIN	refcode.OTCXRefTradeRefType		rt	ON	rt.OTCXRefTradeRefTypeID	= x.XRefOTCTradeTypeID
JOIN	mcoredb..DataSource				mds	ON	mds.DataSourceID			= o.DataSourceID
											AND	mds.sSourceName				= 'Murex'
WHERE	rt.sName	= 'Primary ID'
AND		o.sBusinessKey IS NULL OPTION(RECOMPILE)

SET @MSG = 'Updated sBusinessKey in dbo.OTCTransaction'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)


--UPDATE PARENT TransactionID
UPDATE	t
SET		t.ParentTransactionID	= tp.TransactionID
FROM	mcoredb..OTCTransaction									t 
JOIN	mcoredb..#XrefOTC2								xt	ON	xt.TransactionID		= t.TransactionID
																	AND	xt.XRefOTCTradeTypeID	= @TRDREFTYPE_PRIMARY_ID
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP		m	ON	m.M_H_NB_MZ				= xt.sRef
																	AND		m.dtArchive				= @dt
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP	s	ON	s.M_NB					= m.M_NB
																	AND		s.dtArchive				= @dt
JOIN	mcoredb..#XrefOTC2								xtp	ON	xtp.sRef				= CASE
																									WHEN m.M_TP_INT = 'N'
																									THEN CONVERT(VARCHAR, s.M_CREATOR)
																									WHEN m.M_TP_INT = 'Y'
																									THEN CASE m.M_TP_BUY
																											WHEN 'B' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_1'
																											WHEN 'S' THEN CONVERT(VARCHAR, s.M_CREATOR) + '_2'
																											END
																									END
																								AND xtp.XRefOTCTradeTypeID		= @TRDREFTYPE_PRIMARY_ID
JOIN	mcoredb..OTCTransaction									tp	ON	tp.TransactionID		= xtp.TransactionID
JOIN	mcoredb..DataSource										mds	ON	mds.DataSourceID		= xt.DataSourceID
																	AND	mds.sSourceName			= 'Murex'
WHERE	xt.DataSourceID			= t.DataSourceID
AND		tp.DataSourceID			= t.DataSourceID
AND		xtp.DataSourceID		= t.DataSourceID OPTION (RECOMPILE)



--END	TRY
--BEGIN CATCH
--	SET @caught = 1
--	SET @ERROR_NUMBER	= ERROR_NUMBER()
--	SET @ERROR_SEVERITY	= ERROR_SEVERITY()
--	SET @ERROR_STATE	= ERROR_STATE()
--	SET @ERROR_LINE		= ERROR_LINE()
--	SET @ERROR_MESSAGE	= ERROR_MESSAGE()
--    IF @@TRANCOUNT > 0  
--        ROLLBACK TRANSACTION
--END CATCH
--IF @@TRANCOUNT > 0  
--    COMMIT TRANSACTION
--IF @caught = 1
--BEGIN
--	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('ERROR_NUMBER() = '	+ CONVERT(VARCHAR, @ERROR_NUMBER))			--int
--	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('ERROR_SEVERITY() = '	+ CONVERT(VARCHAR, @ERROR_SEVERITY))		--int
--	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('ERROR_STATE() = '		+ CONVERT(VARCHAR, @ERROR_STATE))			--int
--	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES ('ERROR_LINE() = '		+ CONVERT(VARCHAR, @ERROR_LINE))			--int
--	INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@ERROR_MESSAGE);													--nvarchar(4000) --'ERROR_MESSAGE():  '	+ 
--	THROW 51000, 'The record does not exist.', 1
--END

SET @MSG = 'Updated OTCTransaction ParentTransactionIDs.'
IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SET @MSG = 'Done.'
PRINT @MSG
SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

;IF @debug = 0	-- @debug = 0 in Tidal, so that the Success flag is set and Completed Normally results; the THROW results in the entire @OUTPUT param being reproduced in the Tidal output page for review.
	THROW 50000, 'DTSER_SUCCESS', 0
--else don't throw, prevents add'l PRINT statements from firing


--ALTER INDEX [UX_vwXRefOTCTransaction] ON [Extract].[vwXRefOTCTransaction] REBUILD PARTITION = ALL WITH (PAD_INDEX = ON, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
--ALTER INDEX ALL ON Extract.vwXRefOTCTransaction REBUILD




