

SELECT *
FROM mcoredb.DBO.Account A
JOIN MCOREDB.DBO.Party P ON P.PartyID = CONVERT(INT,A.PartyID)


SELECT *
FROM mcoredb.DBO.Account A
JOIN MCOREDB.DBO.Party P ON P.PartyID = A.PartyID