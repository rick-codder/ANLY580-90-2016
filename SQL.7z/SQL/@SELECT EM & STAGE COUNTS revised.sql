use mcoredb
DECLARE @T1 TABLE ([EM TABLE NAME] VARCHAR(50), [ROWS AFFECTED] INT)
--declare @dt datetime = '2018-11-19 20:14:11.570'
--declare @jobdt date = '20181116'


declare @ignoreuser bit = 0
declare @user AS NVARCHAR(100) = '%'
declare @ds int = (	SELECT	DataSourceID
					FROM	mcoredb..DataSource		d
					JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
					WHERE	sSourceName				= 'Murex'
					AND		sEntityCode				= 'MCM')
INSERT @T1
VALUES
('OTCTransaction',			(SELECT  count(*) from OTCTransaction
							where DataSourceID=@ds and sUser like @user and dtTimestamp > @dt))
,('IRDTransactionLeg',		(SELECT  count(*) from IRDTransactionLeg i
											join OTCTransaction t on i.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and (i.sUser like @user or @ignoreuser = 1) and i.dtTimestamp > @dt))
,('CDSTransaction',			(SELECT  count(*) from CDSTransaction i
											join OTCTransaction t on i.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('IRDNonLinear',			(SELECT  count(*) from IRDNonLinear i
											join OTCTransaction t on i.otcTransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('OTCTransactionDaily',	(SELECT  count(*) from OTCTransactionDaily i
											join OTCTransaction t on i.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('IRDTransactionLegDaily',	(SELECT  count(*) from IRDTransactionLegDaily i
											join IRDTransactionLeg l on i.TransactionLegID = l.TransactionLegID
											join OTCTransaction t on l.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('IRDRangeDetail',			(SELECT  count(*) from IRDRangeDetail i
											join IRDTransactionLeg l on i.TransactionLegID = l.TransactionLegID
											join OTCTransaction t on l.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and l.dtTimestamp > @dt))
,('CDSPaymentSchedule',		(SELECT  count(*) from CDSPaymentSchedule i
											join OTCTransaction t on i.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('FXPaymentSchedule',		(SELECT  count(*) from FXPaymentSchedule f
											join OTCTransaction t on t.TransactionID = f.TransactionID
							where t.DataSourceID=@ds and f.sUser like @user and f.dtTimestamp > @dt))
,('IRDPaymentSchedule',		(SELECT  count(*) from IRDPaymentSchedule i
											join OTCTransaction t on i.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('IRDNotionalSchedule',	(SELECT  count(*) from IRDNotionalSchedule i
											join IRDTransactionLeg l on i.TransactionLegID = l.TransactionLegID
											join OTCTransaction t on l.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('FXDerivative',			(SELECT  count(*) from FXDerivative i
											join OTCTransaction t on i.OTCTransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('FXTransactionDaily',		(SELECT  count(*) from FXTransactionDaily ft
											join FXDerivative fx on fx.FXDerivativeID = ft.FXDerivativeID
											join OTCTransaction t on t.TransactionID = fx.OTCTransactionID
							where t.DataSourceID=@ds and ft.sUser like @user and ft.dtTimestamp > @dt))
,('ExerciseSchedule',		(SELECT  count(*) from ExerciseSchedule i
											join IRDNonLinear n on i.IRDNonLinearID = n.IRDNonLinearID
											join OTCTransaction t on n.otcTransactionID = t.TransactionID
							where t.DataSourceID=@ds and i.sUser like @user and i.dtTimestamp > @dt))
,('CancelSchedule',			(SELECT  count(*) from CancelSchedule c
											join OTCTransaction t on c.TransactionID = t.TransactionID
							where t.DataSourceID=@ds and c.sUser like @user and c.dtTimestamp > @dt))
,('Collateral',				(SELECT  count(*) from Collateral
							where DataSourceID=@ds and sUser like @user and dtTimestamp > @dt))
,('CollateralExposure',		(SELECT  count(*) from CollateralExposure
							where DataSourceID=@ds and sUser like @user and dtTimestamp > @dt))
,('CollateralInterest',		(SELECT  count(*) from CollateralInterest
							where sUser like @user and dtTimestamp > @dt))
,('MarginCall',				(SELECT  count(*) from MarginCall
							where DataSourceID=@ds and sUser like @user and dtProcess = @jobdt))-- dtTimestamp > @dt))
,('CollateralAllocation',	(SELECT  count(*) from CollateralAllocation ca
											join MarginCall mc on mc.MarginCallID = ca.MarginCallID
							where mc.DataSourceID=@ds and ca.sUser like @user and (ca.dtTimestamp > @dt and mc.dtProcess = @jobdt) ))
,('FixingSchedule',			(SELECT  count(*) from FixingSchedule fs
											join FXDerivative fx on fx.FXDerivativeID = fs.FXDerivativeID
											join OTCTransaction t on t.TransactionID = fx.OTCTransactionID
							where t.DataSourceID=@ds and fs.sUser like @user and fs.dtTimestamp > @dt))
,('TLock',					(SELECT COUNT(*) from TLock tl
											join OTCTransaction t on t.TransactionID = tl.TransactionID
							where t.DataSourceID=@ds and tl.sUser like @user and tl.dtTimestamp > @dt))	
,('OTCTransactionValuation',					(SELECT COUNT(*) from OTCTransactionValuation t  
							where t.DataSourceID=@ds and t.sUser like @user and t.dtValuation = @jobdt))								
,('PositionValuation',					(SELECT COUNT(*) from PositionValuation t  
							where t.sUser like @user and t.dtTimestamp > @dt))							
,('TradeBookValuation',					(SELECT COUNT(*) from TradeBookValuation t  
							where t.DataSourceID=@ds and t.sUser like @user and t.dtValuation = @jobdt))														


							
							--SELECT  count(*) from TLock where sUser like '%david%' and dtTimestamp > '20180906 18:14:00'
select * from @t1

--select dtTimestamp,count(*)
--from OTCTransactionValuation
--group by dtTimestamp
--order by dtTimestamp desc

--declare @dt datetime = '20181003 12:00:00'
--declare @ds int = 239--199--
SELECT	lc.sCodeValue [Product Type], count(*) Count
FROM	mcoredb..OTCTransaction	t
JOIN	mcoredb..LookupCodes	lc	ON lc.CodeID = t.ProductTypeID
WHERE	t.DataSourceID = @ds
AND		t.sUser LIKE @user
AND		t.dtTimestamp > @dt
GROUP BY lc.sCodeValue
ORDER BY lc.sCodeValue

--UNSPECIFIED COUNTERPARTY COUNT
SELECT	'Unspecified Counterparties' AS Data, COUNT(*) [COUNTERPARTIES]
 FROM [mcoredb].[dbo].[OTCTransaction] Trn
 left join LookupCodes lkp on Trn.ProductTypeID = lkp.CodeID
 left join [mcoredb].[dbo].[XRefOTCTransaction] xTrn on Trn.TransactionID = xTrn.TransactionID and xTrn.XRefOTCTradeTypeID = 1
 LEFT JOIN DataSource DATS ON DATS.DataSourceID = Trn.DataSourceID
 where xTrn.DataSourceID = @ds
 and CPAccountID is null
 and Trn.bActive = 1 
 

--MUREX STAGING COUNTERPARTIES NOT IN MCDB
SELECT	M_CODE, M_DSP_LBL
FROM	mcoredb_archive.stage.MDR_MUREX_DM_REF_CNTP_REP
WHERE	dtArchive = @dt
AND		M_DSP_LBL IN (	SELECT	M_TP_CNTRP
						FROM	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP
						WHERE	dtArchive = @dt
						AND		M_H_NB_MZ IN (	SELECT	xTrn.sRef						Murex_Trade_Number
												FROM	mcoredb..OTCTransaction			Trn
												LEFT JOIN mcoredb..XRefOTCTransaction	xTrn	ON	Trn.TransactionID		= xTrn.TransactionID
																								AND	xTrn.XRefOTCTradeTypeID	= 1
												WHERE xTrn.DataSourceID	= @ds
												AND	CPAccountID			IS NULL
												AND	Trn.bActive			= 1
											)
						)


------------------------------------------------------------------------------------------------------------------------
use mcoredb_archive
--declare @jobdt datetime = '20180808'
DECLARE @T3 TABLE ([DATAMART TABLE NAME] VARCHAR(50), [ROWS AVAILABLE & STAGED] INT)
INSERT @T3
VALUES
('COL_EXC_ALLOC1_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_COL_EXC_ALLOC1_REP		WHERE dtArchive = @jobdt))
,('COL_EXC_MR1_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_COL_EXC_MR1_REP			WHERE dtArchive = @jobdt))
,('COL_INTERESTS1_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_COL_INTERESTS1_REP		WHERE dtArchive = @jobdt))
,('COL_INVENTORY1_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_COL_INVENTORY1_REP		WHERE dtArchive = @jobdt))
,('COL_MLC_EXPAGG1_REP',	(SELECT COUNT(*) FROM stage.mdr_murex_COL_MLC_EXPAGG1_REP		WHERE dtArchive = @jobdt))
,('DM_OPS_EVT_REP',			(SELECT COUNT(*) FROM stage.mdr_murex_DM_OPS_EVT_REP			WHERE dtArchive = @jobdt))	-- dtTimestamp > @dt2
,('DM_OPS_FIX_REP',			(SELECT COUNT(*) FROM stage.mdr_murex_DM_OPS_FIX_REP			WHERE dtArchive = @jobdt))
,('DM_PL_LEG_REP',			(SELECT COUNT(*) FROM stage.mdr_murex_DM_PL_LEG_REP				WHERE dtArchive = @jobdt))
,('DM_PL_TRADE_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_PL_TRADE_REP			WHERE dtArchive = @jobdt))
,('DM_REF_CDX_UDF_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_REF_CDX_UDF_REP		WHERE dtArchive = @jobdt))
,('DM_REF_CNTP_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_REF_CNTP_REP			WHERE dtArchive = @jobdt))
,('DM_RSK_DV01_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_RSK_DV01_REP			WHERE dtArchive = @jobdt))
,('DM_TRN_CF_REP',			(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_CF_REP				WHERE dtArchive = @jobdt))
,('DM_TRN_EXE_SCHDL_REP',	(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_EXE_SCHDL_REP		WHERE dtArchive = @jobdt))
,('DM_TRN_RANGE_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_RANGE_REP			WHERE dtArchive = @jobdt))
,('DM_TRN_SCHDL_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_SCHDL_REP			WHERE dtArchive = @jobdt))
,('DM_TRN_TRADE_REP',		(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_TRADE_REP			WHERE dtArchive = @jobdt))
,('DM_TRN_TRADE_SQL_REP',	(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_TRADE_SQL_REP		WHERE dtArchive = @jobdt))
,('DM_TRN_UDF_DEAL_REP',	(SELECT COUNT(*) FROM stage.mdr_murex_DM_TRN_UDF_DEAL_REP		WHERE dtArchive = @jobdt))
,('LRB_COL_AGR_ASGN_REP',	(SELECT COUNT(*) FROM stage.mdr_murex_LRB_COL_AGR_ASGN_REP		WHERE dtArchive = @jobdt))
,('DM_TRN_GEN_DT_REP',		(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_TRN_GEN_DT_REP			WHERE dtArchive = @jobdt))
,('DM_TRN_ALT_ID_REP',		(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_TRN_ALT_ID_REP			WHERE dtArchive = @jobdt))

,('DM_PL_COLRBPL_DT_REP', 	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_COLRBPL_DT_REP		WHERE dtArchive = @jobdt))
,('DM_PL_COLRBPL_MN_REP', 	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_COLRBPL_MN_REP		WHERE dtArchive = @jobdt))
,('DM_PL_PLVAR_SCN_REP',	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_PLVAR_SCN_REP		WHERE dtArchive = @jobdt))
,('DM_PL_RBPL_DT_REP',		(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_RBPL_DT_REP			WHERE dtArchive = @jobdt))
,('DM_PL_RBPL_MAIN_REP', 	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_RBPL_MAIN_REP 		WHERE dtArchive = @jobdt))
,('DM_PL_XVARBPL_DT_REP',	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_PL_XVARBPL_DT_REP		WHERE dtArchive = @jobdt))
,('DM_RSK_SIMM_CL_REP MRX',	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_RSK_SIMM_CL_REP MRX	WHERE dtArchive = @jobdt))
,('DM_RSK_FX_DELTA_REP',	(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_RSK_FX_DELTA_REP		WHERE dtArchive = @jobdt))
--,('DM_RSK_DV01_REP',		(SELECT COUNT(*) FROM stage.MDR_MUREX_DM_RSK_DV01_REP			WHERE dtArchive = @jobdt))
,('ERM_BT_1D_REP MRX',		(SELECT COUNT(*) FROM stage.MDR_MUREX_ERM_BT_1D_REP MRX			WHERE dtArchive = @jobdt))
,('ERM_BT_10D_REP MRX',		(SELECT COUNT(*) FROM stage.MDR_MUREX_ERM_BT_10D_REP MRX		WHERE dtArchive = @jobdt))



select * from @t3



SELECT M_CNT_TYPO TYPOLOGY, COUNT(*) COUNT
FROM stage.mdr_murex_DM_TRN_TRADE_REP
WHERE dtArchive = @jobdt
group by M_CNT_TYPO
order by M_CNT_TYPO

--Can you please only include MCM based Impact/GMI positions? Thx. (only Apollo, Murex & Impact)
use mcoredb
--DECLARE @dt4 DATE = '2018-08-07'
--GMI (IGNORE "MSUSA")
SELECT
	e.sEntityCode
	,ds.sSourceName
	,COUNT(*)			Count
FROM TradeTransaction	tt
JOIN DataSource			ds	ON	ds.DataSourceID		= tt.DataSourceID
JOIN refcode.Entity		e	ON	e.EntityID			= ds.EntityID
JOIN Account			a	ON	a.AccountID			= tt.CptyAccountID
JOIN XRefParty			xp	ON	xp.PartyID			= a.PartyID
							AND	xp.sRef				= '0MCMC'
WHERE	tt.dtProcess	= @jobdt
--AND		ds.sSourceName	= 'GMI'
GROUP BY
	e.sEntityCode
	,ds.sSourceName
--IMPACT
SELECT
	e.sEntityCode
	,ds.sSourceName
	,COUNT(*)			Count
FROM TradeTransaction	tt
JOIN DataSource			ds	ON	ds.DataSourceID		= tt.DataSourceID
JOIN refcode.Entity		e	ON	e.EntityID			= ds.EntityID
--JOIN Account			a	ON	a.AccountID			= tt.CptyAccountID
--JOIN XRefParty			xp	ON	xp.PartyID			= a.PartyID
--							AND	xp.sRef				= '0MCMC'
WHERE	tt.dtProcess	= @jobdt
AND		ds.sSourceName	= 'Impact'
GROUP BY
	e.sEntityCode
	,ds.sSourceName

---$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

--DECLARE @dt5 datetime = '20180807'
--declare @ds int = (	SELECT	DataSourceID
--					FROM	mcoredb..DataSource		d
--					JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
--					WHERE	sSourceName				= 'Murex'
--					AND		sEntityCode				= 'MCM')

DECLARE @t TABLE (DATA VARCHAR(20), [MCDB] NUMERIC(24,8), [MUREX] NUMERIC(24,8))

---PVs (OIS)
----------------------------------------------------------
INSERT @t 
select 'PVs (OIS)',(select sum(dPresentValueT0)				--numeric(18,6)
from (
	SELECT
		trn.dPresentValueT0	--,xTrn.sRef,DATS.sSourceName
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
	where	xtrn.DataSourceID	= @ds
	and		trn.dtProcess		= @jobdt						)q) ,
	(select sum(ISNULL(M_CASH_NONF, 0)+ ISNULL(M_MV_NONFIN, 0)+ ISNULL(M_PV_EFFECT, 0))				--numeric(19,2)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_TRADE_REP 
where dtArchive	= @jobdt 
and M_H_DATA_LB = 'EOD'
and M_H_NB_MZ	in (SELECT	xtrn.sRef
					FROM	mcoredb..OTCTransactionDaily	trn
					LEFT JOIN mcoredb..XRefOTCTransaction	xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
					where	xtrn.DataSourceID	= @ds
					and		trn.dtProcess		= @jobdt))

---------------------------------------------------------
---PVs (CSA)
----------------------------------------------------------
INSERT @t 
select 'PVs (CSA)',(select sum(dPresentValueT0CSA)				--numeric(18,6)
from (
	SELECT
		trn.dPresentValueT0CSA		--,xTrn.sRef,DATS.sSourceName
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
	where	xtrn.DataSourceID	= @ds
	and		trn.dtProcess		= @jobdt						)q) ,
	(select sum(ISNULL(M_CASH_NONF, 0)+ ISNULL(M_MV_NONFIN, 0)+ ISNULL(M_PV_EFFECT, 0))				--numeric(19,2)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_TRADE_REP 
where dtArchive	= @jobdt 
and M_H_DATA_LB = 'EOD_CSA'
and M_H_NB_MZ	in (SELECT	xtrn.sRef
					FROM	mcoredb..OTCTransactionDaily	trn
					LEFT JOIN mcoredb..XRefOTCTransaction	xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
					where	xtrn.DataSourceID	= @ds
					and		trn.dtProcess		= @jobdt))

---------------------------------------------------------
--Notionals
---------------------------------------------------------
--DECLARE @dt5 datetime = '20180718'
INSERT @t 
select 'Notionals',(select sum(dNotional)			 		--numeric(29,8)
from (
	SELECT		--trn.dPresentValueT0,xtrn.sRef
		trn.dNotional
	FROM mcoredb..OTCTransactionDaily						trn
	LEFT JOIN mcoredb..XRefOTCTransaction					xtrn	on	trn.TransactionID			= xtrn.TransactionID
																	and	xtrn.XRefOTCTradeTypeID		= 1
       JOIN mcoredb..OTCTransaction                                OTC   on            trn.TransactionID                 = OTC.TransactionID
       where  xtrn.DataSourceID    = @ds
       and (OTC.sDescription not in ('COLVA','TOTXVA') or OTC.sDescription  is NULL)

	and		trn.dtProcess		= @jobdt						)q),
	(select sum(Notional)					--numeric(19,2)/numeric(24,8)
from (
	select	case when M_CNT_TYPO = 'Total Return Swap BD' then M_TP_NOMINAL else M_TP_AVQTY2 end		Notional
	from	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP 
	where	dtArchive	= @jobdt
	and		M_H_NB_MZ	in (SELECT		xtrn.sRef
							FROM		mcoredb..OTCTransactionDaily	trn
							LEFT JOIN	mcoredb..XRefOTCTransaction		xtrn	on	trn.TransactionID		= xtrn.TransactionID
																				and	xtrn.XRefOTCTradeTypeID	= 1
							where		xtrn.DataSourceID    = @ds
							and			trn.dtProcess        = @jobdt))q)
---------------------------------------------------------------------
--Trades
-------------------------------------------------------------------
INSERT @t 
SELECT  'Trades', (select count(*)
FROM [mcoredb].[dbo].[OTCTransactionDaily] Trn
Join [mcoredb].[dbo].[XRefOTCTransaction] xTrn on Trn.TransactionID = xTrn.TransactionID and xTrn.XRefOTCTradeTypeID = 1
JOIN mcoredb..OTCTransaction OTC   on            trn.TransactionID                 = OTC.TransactionID
JOIN DataSource DATS ON DATS.DataSourceID = tRN.DataSourceID
LEFT JOIN LookupCodes LKP on LKP.CodeID = TRN.TradeStatusID
where xTrn.DataSourceID =@ds
and (LKP.sCodeValue <> 'PURGED' or LKP.sCodeValue is null)
and (OTC.sDescription not in ('COLVA','TOTXVA') or OTC.sDescription  is NULL)
and  Trn.dtProcess = @jobdt),
(SELECT count(*) 
FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP WHERE dtarchive = @jobdt and M_TP_PFOLIO not in ('PGA', 'STB_DRAFT','LBC_DRAFT')
and (
(M_TRN_FMLY = 'IRD' and M_TRN_GRP  not in ('BOND','LFUT','OPT','SFUT','SWFUT','REPO'))
or 
M_CNT_TYPO = 'Treasury Lock'
or
(M_TRN_FMLY = 'CURR' and M_TRN_GRP  not in ('FUT')) 
or (M_TRN_FMLY in ('SCF','CRD')))  )
---------------------------------------------------------------------


SELECT DATA,
	[MCDB],
	[MUREX],
	CASE	WHEN [MUREX] = [MCDB] THEN 'PASSED'
			WHEN [MUREX] != [MCDB] THEN 'FAILED'
	END AS STATUS
FROM @t


------------------------------------------------------------------------------------------------------------------------
use mcoredb_archive
--declare @jobdt datetime = '20180808'
DECLARE @T4 TABLE ([TABLE NAME] VARCHAR(50), [ROWS AVAILABLE & STAGED] INT)
INSERT @T4
VALUES
 ('MDR_MUREX_CF_VOL_REP',              	(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_CF_VOL_REP                  WHERE dtArchive = @jobdt))
,('MDR_MUREX_COLLATCATCURVEMAPPING',	(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_COLLATCATCURVEMAPPING		WHERE dtArchive = @jobdt))
,('MDR_MUREX_CR_RATING',				(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_CR_RATING					WHERE dtArchive = @jobdt))
,('MDR_MUREX_CR_SPREAD',				(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_CR_SPREAD					WHERE dtArchive = @jobdt))
,('MDR_MUREX_DM_REF_CNTP_REP',			(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_DM_REF_CNTP_REP				WHERE dtArchive = @jobdt))
,('MDR_MUREX_DM_RSK_CR_JTD_REP',		(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_DM_RSK_CR_JTD_REP			WHERE dtArchive = @jobdt))	-- dtTimestamp > @dt2
,('MDR_MUREX_FG_FX_REP',				(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_FG_FX_REP					WHERE dtArchive = @jobdt))
,('MDR_MUREX_FG_INDX',					(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_FG_INDX						WHERE dtArchive = @jobdt))
,('MDR_MUREX_FX_RATES',					(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_FX_RATES					WHERE dtArchive = @jobdt))
,('MDR_MUREX_FX_VOL_REP',				(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_FX_VOL_REP					WHERE dtArchive = @jobdt))
,('MDR_MUREX_IR_CURVE',					(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_IR_CURVE					WHERE dtArchive = @jobdt))
,('MDR_MUREX_JAC_DV01_HSC_REP',			(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_JAC_DV01_HSC_REP			WHERE dtArchive = @jobdt))
,('MDR_MUREX_JAC_DV01_PAR_REP',			(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_JAC_DV01_PAR_REP			WHERE dtArchive = @jobdt))
,('MDR_MUREX_JAC_DV01_ZERO_REP',		(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_JAC_DV01_ZERO_REP			WHERE dtArchive = @jobdt))
,('MDR_MUREX_JAC_FWD_RATES',			(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_JAC_FWD_RATES				WHERE dtArchive = @jobdt))
,('MDR_MUREX_SWAP_VOL_REP',				(SELECT COUNT(*) FROM REFDATA.MDR_MUREX_SWAP_VOL_REP				WHERE dtArchive = @jobdt))


select * from @t4
