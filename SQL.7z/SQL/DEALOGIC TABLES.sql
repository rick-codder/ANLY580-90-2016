SELECT *
FROM MCOREDB_ARCHIVE.stage.MCO_DEALOGIC_QIB_CERTIFICATE
GO

SELECT *
FROM MCOREDB_WORK.stage.MCO_DEALOGIC_QIB_CERTIFICATE
GO

SELECT *
FROM mcoredb_archive.extract.MCO_DEALOGIC_QIB_CERTIFICATE
--WHERE sAccountNumber NOT LIKE '%M%';
GO


SELECT C.sName,A.sAccountNumber,B.sRef,*
FROM mcoredb_archive.extract.MCO_DEALOGIC_QIB_CERTIFICATE A
JOIN XRefAccount B ON A.sAccountNumber = sRef
JOIN ACCOUNT C ON C.AccountID = B.AccountID
GO

SELECT A.sClientName,C.sName,C.sLongName,*
FROM MCOREDB_ARCHIVE.extract.MCO_DEALOGIC_QIB_CERTIFICATE A
JOIN XRefParty B ON A.sParentAccountNumber = REPLACE(B.sRef,'','')
JOIN PARTY C ON B.PartyID = C.PartyID


SELECT A.sClientName,C.sName,C.sLongName,C.AccountID,B.AccountID,A.sAccountNumber,B.sRef,*
FROM MCOREDB_ARCHIVE.extract.MCO_DEALOGIC_QIB_CERTIFICATE A
JOIN XRefAccount B ON A.sAccountNumber = REPLACE(B.sRef,'-','')
JOIN Account C ON B.AccountID = C.AccountID

WHERE sParentAccountNumber IN (
SELECT REPLACE(sRef,'-','') FROM XRefParty
)

DELETE FROM T

SELECT * FROM fn_my_permissions('cube.GLPurchaseOrderFact','OBJECT');
/*

DELETE FROM  MCOREDB_WORK.stage.MCO_DEALOGIC_QIB_CERTIFICATE;
DELETE FROM MCOREDB_ARCHIVE.stage.MCO_DEALOGIC_QIB_CERTIFICATE;
DELETE FROM MCOREDB_ARCHIVE.extract.MCO_DEALOGIC_QIB_CERTIFICATE;

*/

--SELECT DATEDIFF(MONTH,'20170801', GETDATE())
--FROM mcoredb_archive.stage.MCO_DEALOGIC_QIB_CERTIFICATE
--WHERE DATEDIFF(MONTH,'20170801', GETDATE()) < 10;

/*

update mcoredb_archive.STAGE.MCO_DEALOGIC_QIB_CERTIFICATE
set sClientName = 'test Joe Z'
where iCertificate = 322258;
go


*/


--SELECT	ISNULL(iDelta,0),iDelta
--		--,MIN(ISNULL(dtArchive,GETDATE())) 
--FROM STAGE.MCO_DEALOGIC_QIB_CERTIFICATE;
--GO


--SELECT B.PartyID, A.sClientName, A.sCertificateStatus
--FROM EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE A 
--RIGHT JOIN mcoredb.DBO.XRefParty B ON A.sAccountNumber = B.sRef

--SELECT *
--FROM mcoredb.DBO.XRefParty
--WHERE sRef IN (SELECT sAccountNumber FROM mcoredb_archive.EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE)

--SELECT PartyID,sValue,B.sDisplayName, *
--FROM mcoredb.APP.CoreDomain_PartyProperty A 
--JOIN mcoredb.APP.CoreDomain_PartyPropertyType B ON A.PropertyTypeID = B.ID
--WHERE B.sDisplayName = 'QIB';


--SELECT A.AccountID,sValue,B.sDisplayName
--FROM APP.CoreDomain_AccountProperty A 
--JOIN APP.CoreDomain_PartyPropertyType B ON A.PropertyTypeID = B.ID
--WHERE B.sDisplayName = 'QIB';


SELECT PartyID,sValue,B.sDisplayName
FROM APP.CoreDomain_PartyProperty A 
JOIN APP.CoreDomain_PartyPropertyType B ON A.PropertyTypeID = B.ID
WHERE B.sDisplayName = 'QIB';



SELECT sClientName,B.PartyID,C.sName,*
FROM mcoredb_archive.EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE A
JOIN mcoredb..XRefParty B ON A.sAccountNumber = B.sRef
JOIN mcoredb..Party C ON B.PartyID = C.PartyID
WHERE B.PartyID = 312390

SELECT *
FROM PARTY
WHERE PartyID = 312390

SELECT 
B.PartyID, 
A.sClientName,
A.sCertificateStatus,
A.dtCertificateExpirationDate
FROM mcoredb_archive.EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE A 
JOIN mcoredb.DBO.XRefParty B ON A.sAccountNumber = B.sRef
WHERE PartyID = 312390

