WITH    PO_DATA
          AS ( SELECT   SUBSTRING(CONVERT(VARCHAR, PO.ID) + '-'
                                  + CONVERT(VARCHAR, POGROUP.[ID]) + '-'
                                  + CONVERT(VARCHAR, POITEM.[ID]), 1, 50) AS sPurchaseOrderID , -- Used as unique identifier to cater for ETL MERGE
                        RTRIM(UPPER(REPLACE(REPLACE(POGROUP.sDivision, ' DIVISION', ''),
                                            ' GROUP', ''))) AS SDIVISION ,
                        sEl1Code ,
                        sEl4Code ,
                        sEl2Code ,		-- ELEMENT3DIMID LOOKUP
                        sVendorXref ,	-- ELEMENT3DIMID LOOKUP
                        POGROUP.sCostCenter ,	-- ELEMENT4DIMID LOOKUP
                        LTRIM(RTRIM(UPPER(POITEM.sProjectName))) sProjectName ,	-- LOOKUP
                        COALESCE(sBudgetKey,
                                 sFiscalYear + '-NotBudgeted-('
                                 + COALESCE(sElementName, 'UNSPECIFIED') + ')') AS SBUDGETKEY ,
                        POGROUP.PoID ,
                        PoItemGroupID ,
                        POITEM.ID ,
                        SUBSTRING(sTitle, 1, 15) sTitle ,
                        sDescription ,
                        SUBSTRING(sStatus, 1, 50) sStatus ,
                        dAmount ,
                        bPaid ,
                        sFormUrl ,
                        SUBSTRING(sPurchasedFor, 1, 50) sPurchasedFor ,
                        SUBSTRING(sItem, 1, 50) sItem ,
                        dQuantity ,
                        dUnitPrice ,
                        dItemTotal ,
                        dtStartDate ,
                        dtEndDate ,
                        sPoType ,
                        SUBSTRING(sFiscalYear, 1, 50) sFiscalYear ,
                        sProductID ,
                        CASE WHEN LEN(LTRIM(RTRIM(POITEM.sNotBudgetedComment))) = 0
                             THEN NULL
                             ELSE LTRIM(RTRIM(POITEM.sNotBudgetedComment))
                        END AS sNotBudgetedComment ,
                        CASE WHEN LEN(LTRIM(RTRIM(POITEM.sITDepartment))) = 0
                             THEN 'UNSPECIFIED'
                             WHEN POITEM.sITDepartment IS NULL
                             THEN 'UNSPECIFIED'
                             ELSE UPPER(LTRIM(RTRIM(POITEM.sITDepartment)))
                        END AS sITDepartment ,
                        sITDepartment AS ITD2,
						CASE 
							WHEN NULLIF(LTRIM(RTRIM(POGROUP.sAllocationEntity)),'') IS NULL AND CAST(POGROUP.sFiscalYear AS INT)<2017 THEN 'MSUSA' 
							WHEN NULLIF(LTRIM(RTRIM(POGROUP.sAllocationEntity)),'') IS NULL AND CAST(POGROUP.sFiscalYear AS INT)=2017 THEN NULL
							WHEN LTRIM(RTRIM(POGROUP.sAllocationEntity))='MCM' THEN 'MCMC'
							WHEN NULLIF(LTRIM(RTRIM(POGROUP.sAllocationEntity)),'') IS NOT NULL THEN POGROUP.sAllocationEntity
							ELSE POGROUP.sAllocationEntity
						END AS EntityDimCode
               FROM     mcoredb_work.stage.MCO_SHAREPOINT_PO PO
                        INNER JOIN mcoredb_work.stage.MCO_SHAREPOINT_PO_ITEM_GROUP POGROUP ON PO.ID = POGROUP.PoID
                        INNER JOIN mcoredb_work.stage.MCO_SHAREPOINT_PO_ITEM POITEM ON POITEM.PoItemGroupID = POGROUP.ID
                        LEFT JOIN ( --Returns a distinct list of divisions with codes - ensures changes to division names are dynamic
                                    SELECT DISTINCT
                                            sElementCode ,
                                            sElementName
                                    FROM    cube.GLElementDim ELEM1
                                            INNER JOIN cube.GLCompanyDim COMP ON COMP.CompanyDimID = ELEM1.CompanyDimID
                                    WHERE   iLevel = 1
                                            AND COMP.sCompanyCode = 'MSUSA'
                                  ) AS DIV_LIST ON DIV_LIST.sElementCode = POGROUP.sEl1Code
             ),
        MASTER_PO_INVOICE_LIST
          AS ( SELECT DISTINCT
                        PoTitle
               FROM     mcoredb_work.stage.MCO_SHAREPOINT_INVOICE_PO
             )
    SELECT  PO_DATA.* ,
            CASE WHEN ( MASTER_PO_INVOICE_LIST.PoTitle IS NULL ) THEN ( 0 )
                 ELSE ( 1 )
            END AS 'bInvoiced'
    FROM    PO_DATA
            LEFT JOIN MASTER_PO_INVOICE_LIST ON PO_DATA.sTitle = MASTER_PO_INVOICE_LIST.PoTitle
    WHERE   SUBSTRING(sTitle, 1, 4) NOT LIKE '%[a-Z]%';
--AND PO_DATA.sTitle = '20170124-10343'
--AND UPPER(LEN(LTRIM(rtrim(sITDepartment)))) > 0