select  SUBSTRING(CAG.sAgreementRef,0,11),
cag.sAgreementRef csaref,csa.AgreementID  CSAAgreementId,csa.sBaseCurrency,cag.sLegalName,
iag.AgreementID, iag.sAgreementRef isdaref ,ce.CreditEntityID ,csa.bIsActive,csa.dCtpThreshold,csa.dOurThreshold
from csa
left join agreement cag on cag.AgreementID = csa.AgreementID
join AgreementRelationship  agr on agr.SubAgreementID = csa.AgreementID
join Agreement iag on iag.AgreementID = agr.SuperAgreementID 

--get entity for isda mapped from csa id
join PartyAgreement  pag on pag.AgreementID = agr.SuperAgreementID
join credit c on pag.partyid = c.partyid
join party p  on p.partyid = c.PartyID
join CreditEntity ce on ce.creditid = c.creditid
join datasource ds on ds.datasourceid = c.DataSourceID and ds.ssourcename = 'CreditManager'
--CROSS APPLY 
JOIN ( SELECT * FROM [app].[fnAMPGetAgreementAttributeValues](NULL,NULL,'THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS') 
--WHERE [Agreement ID] = CAG.sAgreementRef
) d
--ON SUBSTRING(D.[Agreement ID],0,11) = CAG.sAgreementRef
ON D.[Agreement ID] = CAG.sAgreementRef
where (ce.sname <> ''  or ce.sname is not null)
and p.bactive =1  and csa.bIsActive = 1
AND CAG.sAgreementRef IN
(
'CSA0115651 ',
'CSA0115625 ',
'CSA0115681 ',
'CSA0115724 ',
'CSA0115649 ',
'CSA0115687 ',
'CSA0115563 ',
'CSA0115685 ',
'CSA0119776 ',
'CSA0119777 ',
'CSA0115552 ',
'CSA0115623 ',
'CSA0115559 ',
'CSA0115750 ',
'CSA0115579 ',
'CSA0119782 ',
'CSA0119783 ',
'CSA0119473 ',
'CSA0115207 ',
'CSA0114947 ',
'CSA0115005 ',
'CSA0115185 ',
'CSA0114956 ',
'CSA0114949 ',
'CSA0115110 ',
'CSA0114960 ',
'CSA0115032 ',
'CSA0115128 ',
'CSA0115122 ',
'CSA0115055 ',
'CSA0115216 ',
'CSA0115172 ',
'CSA0115011 ',
'CSA0114963 ',
'CSA0115073 ',
'CSA0114999 ',
'CSA0115180 ',
'CSA0114966 ',
'CSA0115163 ',
'CSA0115201 ',
'CSA0114969 ',
'CSA0115042 ',
'CSA0115254 ',
'CSA0115426 ',
'CSA0115430 ',
'CSA0115242 ',
'CSA0115283 ',
'CSA0115268 ',
'CSA0115460 ',
'CSA0115240 ',
'CSA0115270 ',
'CSA0115281 ',
'CSA0115441 ',
'CSA0115285 ',
'CSA0115447 ',
'CSA0115493 ',
'CSA0115507 ',
'CSA0115309 ',
'CSA0115386 ',
'CSA0115488 ',
'CSA0115265 ',
'CSA0115424 ',
'CSA0115433 ',
'CSA0115256 ',
'CSA0115500 ',
'CSA0115383 ',
'CSA0115470 ',
'CSA0115416 ',
'CSA0115513 ',
'CSA0116100 ',
'CSA0116142 ',
'CSA0116385 ',
'CSA0116137 ',
'CSA0116080 ',
'CSA0116083 ',
'CSA0116535 ',
'CSA0116027 ',
'CSA0118504 ',
'CSA0118759 ',
'CSA0118613'
)
--Arifs Stored Procedure for rating based AMOUNT



DECLARE @T NVARCHAR(100) = NULL
SELECT * FROM [app].[fnAMPGetAgreementAttributeValues](NULL,'CSA0118613','THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS')
ORDER BY Field


select t.* from
	(
SELECT * FROM [app].[fnAMPGetAgreementAttributeValues](NULL,NULL,'THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS')
		
	) temp
	pivot (max(Value)
	for Field in 
	(
	[Threshold and Margin Type],[Rating Based - S&P Rating],[Rating Based - Moody's Rating],[Rating Based - Fitch Rating],[Rating Based Amount - Mizuho],[Rating Based Amount - Counterparty]
	)
) t



CREATE TABLE #T(
DOCUMENTID VARCHAR(100),
AGREEMENTID VARCHAR(100),
PARENT_AGREEMENTID VARCHAR(100),
AGREEMENTTYPE VARCHAR(100),
AGREEMENTSUBTYPE VARCHAR(100),
IROW VARCHAR(100),
[Threshold and Margin Type] VARCHAR(100),
[Rating Based - S&P Rating] VARCHAR(100),
[Rating Based - Moody's Rating] VARCHAR(100),
[Rating Based - Fitch Rating] VARCHAR(100),
[Rating Based Amount - Mizuho] VARCHAR(100),
[Rating Based Amount - Counterparty] VARCHAR(100)

)

INSERT INTO #T 

--EXEC app.spAMP_GetAgreementRatingBasedMargin NULL,'CSA0115254'
--EXEC app.spAMP_GetAgreementRatingBasedMargin NULL,'CSA0115681'
EXEC app.spAMP_GetAgreementRatingBasedMargin NULL,'CSA0116027'


--select  
--cag.sAgreementRef csaref,csa.AgreementID  CSAAgreementId,csa.sBaseCurrency,cag.sLegalName,
--iag.AgreementID, iag.sAgreementRef isdaref ,ce.CreditEntityID ,csa.bIsActive,csa.dCtpThreshold,csa.dOurThreshold, D.*
--from csa
--left join agreement cag on cag.AgreementID = csa.AgreementID
--join AgreementRelationship  agr on agr.SubAgreementID = csa.AgreementID
--join Agreement iag on iag.AgreementID = agr.SuperAgreementID 

----get entity for isda mapped from csa id
--join PartyAgreement  pag on pag.AgreementID = agr.SuperAgreementID
--join credit c on pag.partyid = c.partyid
--join party p  on p.partyid = c.PartyID
--join CreditEntity ce on ce.creditid = c.creditid
--join datasource ds on ds.datasourceid = c.DataSourceID and ds.ssourcename = 'CreditManager'
----join [app].[fnAMPGetAgreementAttributeValues](NULL,NULL,'THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS') d
--JOIN 
--(

DECLARE @dt AS DATE = '20181123'

SELECT *
FROM
(

SELECT  [AGREEMENT ID]
		,CASE AGENCY_NAME WHEN 'Rating Based - S&P Rating' THEN 'S&P'
								WHEN 'Rating Based - Moody''s Rating' THEN 'Moodys'
								WHEN 'Rating Based - Fitch Rating' THEN 'Fitch'  END AS AGENCY_NAME
		,CASE AGENCY_NAME WHEN 'Rating Based - S&P Rating' THEN 2
								WHEN 'Rating Based - Moody''s Rating' THEN 3
								WHEN 'Rating Based - Fitch Rating' THEN 1  END AS AGENCY_ID
		,RATING
		,ORDINAL
		,sLegalName AS AGREEMENT_NAME
		,CASE bIsActive WHEN 1 THEN 'Active' ELSE NULL END AGREEMENT_STATUS
		,CASE MarginTerm_Type WHEN 'Rating Based Amount - Mizuho' THEN 'Prin'
								WHEN 'Rating Based Amount - Counterparty' THEN 'Cpty' END AS MARGINTERM_TYPE
		,CreditEntityID AS ENTITYID
		,CASE MarginTerm_Type WHEN 'Rating Based Amount - Mizuho' THEN dOurThreshold
								WHEN 'Rating Based Amount - Counterparty' THEN dCtpThreshold END AS THRESHOLD
		,'1' AS ISMTA_RATINGSBASED
		,'Long Term' AS DEBTSTRUCTURE
		,DELIVER_MINIMUM_TRANSFERAMOUNT
		,DELIVER_MINIMUM_TRANSFERAMOUNT AS RETURN_MINIMUM_TRANSFERAMOUNT
		,sBaseCurrency OVERRIDE_CURRENCY_CODE
		,'Daily' AS MARGINVALUATION_TIMINGTYPE
		,@dt  AS COB_DATE
		,CONVERT(VARCHAR(128),USER_NAME()) AS ETL_MODIFIEDBY 
		,CONVERT(datetime2,TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET()))) AS ETL_MODIFIEDTIME 
FROM
(
SELECT [AGREEMENT ID],DOCUMENTID,IROW,[Rating Based - S&P Rating],[Rating Based - Moody's Rating],[Rating Based - Fitch Rating],[Rating Based Amount - Mizuho]
		,[Rating Based Amount - Counterparty],sLegalName,bIsActive,CreditEntityID, dCtpThreshold,dOurThreshold,sBaseCurrency
FROM 
(
select t.* from
(
--SELECT * FROM [app].[fnAMPGetAgreementAttributeValues](NULL,NULL,'THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS')		
select d.*, SUBSTRING(CAG.sAgreementRef,0,11) sub,
cag.sAgreementRef csaref,csa.AgreementID  CSAAgreementId,csa.sBaseCurrency,cag.sLegalName,
iag.AgreementID, iag.sAgreementRef isdaref ,ce.CreditEntityID ,csa.bIsActive,csa.dCtpThreshold,csa.dOurThreshold
from csa
left join agreement cag on cag.AgreementID = csa.AgreementID
join AgreementRelationship  agr on agr.SubAgreementID = csa.AgreementID
join Agreement iag on iag.AgreementID = agr.SuperAgreementID 

--get entity for isda mapped from csa id
join PartyAgreement  pag on pag.AgreementID = agr.SuperAgreementID
join credit c on pag.partyid = c.partyid
join party p  on p.partyid = c.PartyID
join CreditEntity ce on ce.creditid = c.creditid
join datasource ds on ds.datasourceid = c.DataSourceID and ds.ssourcename = 'CreditManager'
--CROSS APPLY 
JOIN ( SELECT * FROM [app].[fnAMPGetAgreementAttributeValues](NULL,NULL,'THRESHOLDS', 'INDEPENDENTAMOUNTMTATHRESHOLD','THRESHOLDANDMARGINS') 
--WHERE [Agreement ID] = CAG.sAgreementRef
) d
ON SUBSTRING(D.[Agreement ID],0,11) = CAG.sAgreementRef
--ON D.[Agreement ID] = CAG.sAgreementRef
where (ce.sname <> ''  or ce.sname is not null)
and p.bactive =1  and csa.bIsActive = 1


) temp
pivot (max(Value)
for Field in 
(
[Threshold and Margin Type],[Rating Based - S&P Rating],[Rating Based - Moody's Rating],[Rating Based - Fitch Rating],[Rating Based Amount - Mizuho],[Rating Based Amount - Counterparty])
) t
) B
) P
UNPIVOT
(
RATING FOR AGENCY_NAME IN ([Rating Based - S&P Rating],[Rating Based - Moody's Rating],[Rating Based - Fitch Rating])
) AS UNP
UNPIVOT
(
Deliver_Minimum_TransferAmount FOR MarginTerm_Type IN ([Rating Based Amount - Mizuho],[Rating Based Amount - Counterparty])
) AS UN
UNPIVOT
(
ORDINAL FOR I IN (IROW)
) AS UN
)
D
--ON CAG.sAgreementRef = D.[Agreement ID]
--where (ce.sname <> ''  or ce.sname is not null)
--and p.bactive =1  and csa.bIsActive = 1


ORDER BY [AGREEMENT ID], AGENCY_NAME, MarginTerm_Type