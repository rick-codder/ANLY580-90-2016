DECLARE @dt DATE = ?
SELECT
ce.CreditEntityID AS ENTITYID,
CONVERT(NVARCHAR(1000),p.sname) AS ENTITYNAME,
2 AS AGENCYID,
CONVERT(NVARCHAR(1000),'S & P') as AGENCYNAME,
CONVERT(NVARCHAR(1000),ISNULL(sp.sCodeValue,'NR')) AS RATING,
CONVERT(NVARCHAR(1000),'') AS DEBTSTRUCTURE,
@dt  AS COB_DATE
, CONVERT(VARCHAR(128),USER_NAME()) AS sModifiedByETL 
, CONVERT(datetime2,TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET()))) AS dtModifiedETL 

FROM 
party P
INNER JOIN credit c on c.partyid = p.PartyID
INNER JOIN CreditEntity ce on ce.CreditID = c.CreditID
INNER JOIN XRefParty xp on  xp.PartyID = p.PartyID
LEFT JOIN LookupCodes sp on sp.CodeID = ce.SnPRatingID  and sp.sCategory = 'S&P Rating'
LEFT JOIN LookupCodes et  on et.CodeID = ce.CreditEntityTypeID  and et.sCategory = 'Credit Entity Type'
INNER JOIN datasource ds on ds.datasourceid = c.DataSourceID and ds.ssourcename = 'CreditManager'
where ce.sname is not null and ce.sname <> '' 
and p.bActive = 1

UNION	    

SELECT 
ce.CreditEntityID as ENTITYID,

CONVERT(NVARCHAR(1000),p.sname) AS ENTITYNAME,
3 as AGENCYID,
CONVERT(NVARCHAR(1000),'Moodys') as AGENCYNAME,
CONVERT(NVARCHAR(1000),ISNULL(md.sCodeValue,'NR')) AS RATING,
CONVERT(NVARCHAR(1000),'') AS DEBTSTRUCTURE,
@dt  as COB_DATE
, CONVERT(VARCHAR(128),USER_NAME()) AS sModifiedByETL 
, CONVERT(datetime2,TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET()))) AS dtModifiedETL 
FROM 
PARTY P
INNER JOIN credit c on c.partyid = p.PartyID
INNER JOIN CreditEntity ce on ce.CreditID = c.CreditID
INNER JOIN XRefParty xp on  xp.PartyID = p.PartyID
LEFT JOIN LookupCodes md on md.CodeID = ce.MoodyRatingID  and md.sCategory = 'Moody Rating'
LEFT JOIN LookupCodes et  on et.CodeID = ce.CreditEntityTypeID  and et.sCategory = 'Credit Entity Type'
INNER JOIN datasource ds on ds.datasourceid = c.DataSourceID and ds.ssourcename = 'CreditManager'
WHERE ce.sname is not null and ce.sname <> '' 
AND p.bActive = 1
ORDER BY ENTITYNAME