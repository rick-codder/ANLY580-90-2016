-- DEAL_COLLATERAL_DETAIL 

DECLARE @dtProcess DATE = '20180924'

DECLARE @MurexDatasourceID NUMERIC(18,0)
SELECT @MurexDatasourceID = DatasourceID FROM dbo.DataSource ds JOIN refcode.Entity e ON e.EntityID = ds.EntityID WHERE ds.sSourceName = 'Murex' AND e.sEntityCode = 'MCM' 


SELECT distinct csa.sLegalName 
,i.sTradeCurrency + ' ' + lc.sCodeValue AS sProductID 
,case when c.bPledgedIn = 1 then 'Posted' else 'Held' END AS sPostDirection 
,i.sCusip 
,c.dNotional   
,p.dPrice 
,ci.dCumulativeInterest 
,c.dCollateralValue 
,c.dHaircut 
,(c.dCollateralValue * c.dHaircut) AS dAdjustedPV 
,st.sTypeName AS sCSAType 
--,SUBSTRING(csa.sAgreementRef,4,LEN(csa.sAgreementRef)-3) AS sAgreementRef 
, csa.TEMP_sApolloContractRef AS sAgreementRef 

,c.dtProcess 

, TODATETIMEOFFSET(c.dtTimestamp,DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtTimestamp  
, TODATETIMEOFFSET(GETDATE(),DATEPART(TZOFFSET, SYSDATETIMEOFFSET())) AS dtModifiedETL 
, USER_NAME() AS sModifiedByETL 

FROM mcoredb.dbo.Agreement a
inner join dbo.AgreementRelationship ar on ar.SuperAgreementID = a.AgreementID
inner join dbo.Agreement csa on ar.SubAgreementID = csa.AgreementID
inner join dbo.Collateral c on c.AgreementID = csa.AgreementID 
inner join dbo.issue i on c.IssueID = i.IssueID 
inner join dbo.LookupCodes lc on lc.CodeID = i.ProductTypeID
inner join refcode.AgreementSubType st on st.AgreementSubTypeID = csa.AgreementSubTypeID
inner join dbo.Position p on p.IssueID = i.IssueID 
inner join dbo.CollateralInterest ci on ci.AgreementID = c.AgreementID 
JOIN refcode.CollateralStatus cs ON cs.CollateralStatusID = c.CollateralStatusID 
inner join DataSource  ds on ds.DataSourceID = p.DataSourceID  and ds.sSourceName = 'Impact'

WHERE c.dtProcess = @dtProcess
AND p.dtPosition = c.dtProcess
AND ci.dtProcess = c.dtProcess
AND ci.dtCalcEnd = c.dtProcess
AND c.DataSourceID = @MurexDatasourceID 
--and p.DataSourceID = 
AND cs.sName != 'Pending' 
AND csa.TEMP_sApolloContractRef = '1500001'  
--, cs.sName  

select a.dPrice,*  from position a where a.IssueID = 11632028  and a.dtPosition = '9/24/2018' 

select p.dprice,i.IssueID,i.scusip, a.TEMP_sApolloContractRef,c.*   from Collateral  c
left join Agreement  a  on c.AgreementID = a.AgreementID
left join Issue  i on c.IssueID = i.IssueID
inner join position p on p.IssueID = c.IssueID  and p.dtPosition = c.dtProcess
where c.dtProcess = '9/24/2018'  and a.TEMP_sApolloContractRef = '1500001'
and i.sCusip = '912828M49' 

select a.dPrice,*  from position a 

where a.IssueID = 11632028  and a.dtPosition = '9/24/2018'

select sSourceName,*   from DataSource  d  where d.DataSourceID = 201 


select p.dprice,i.IssueID,i.scusip, a.TEMP_sApolloContractRef,c.*   from Collateral  c
left join Agreement  a  on c.AgreementID = a.AgreementID
left join Issue  i on c.IssueID = i.IssueID
left join position p on p.IssueID = c.IssueID  and p.dtPosition = c.dtProcess
-----Added a join to data source id as Impact------
inner join DataSource  ds on ds.DataSourceID = p.DataSourceID  and ds.sSourceName = 'Impact'

where c.dtProcess = '9/24/2018'  and a.TEMP_sApolloContractRef = '1500001'
and i.sCusip = '912828M49'   