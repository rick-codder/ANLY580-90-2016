use mcoredb;

--DROP TABLE #ACTIONS
--DROP TABLE #TRADEBOOK
--DROP TABLE #TX_IDs
--DROP TABLE #AFFILIATE
--DROP TABLE #CONTRACT
--DROP TABLE #COUNTERPARTY

DECLARE @start					DATETIME		= GETDATE()
DECLARE @debug					BIT				= 1
DECLARE @MSG					VARCHAR(1000)
DECLARE @OUTPUT					VARCHAR(MAX)	= ''
DECLARE @dt DATE = '20181030'

DECLARE @DATASOURCE_ID_MUREX	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Murex'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_APOLLO	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Apollo'
													AND		sEntityCode				= 'MCM')
DECLARE @DATASOURCE_ID_MARKIT	NUMERIC(18,0)	= (	SELECT	DataSourceID
													FROM	mcoredb..DataSource		d
													JOIN	mcoredb.refcode.Entity	e	ON	e.EntityID = d.EntityID
													WHERE	sSourceName				= 'Markit'
													AND		sEntityCode				= 'MSUSA')
DECLARE @TRDREFTYPE_PRIMARY_ID	NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Primary ID')
DECLARE @TRDREFTYPE_USI_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'USI ID')
DECLARE @TRDREFTYPE_CCP_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'CCP ID')
DECLARE @TRDREFTYPE_LINK_ID		NUMERIC(18,0)	= (	SELECT	OTCXRefTradeRefTypeID
													FROM	mcoredb.refcode.OTCXRefTradeRefType
													WHERE	sName					= 'Linked Trade ID')
DECLARE @TRADEBOOK_REL_ID		NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Organizational'
													AND		coFunctionalContext		= 'Core'
													AND		coSubFunctionalContext	= 'Trade Book')
DECLARE @CP_REL_ID				NUMERIC(18,0)	= (	SELECT	RelationshipTypeID
													FROM	mcoredb..RelationshipType
													WHERE	coRelationshipType		= 'Functional'
													AND		coFunctionalContext		= 'Credit'
													AND		coSuperRole				= 'Executing Broker'
													AND		coSubRole				= 'Client')
DECLARE @LEGACY_FRA_ID			NUMERIC(18,0)	= (	SELECT RiskInstrumentTypeID
													FROM	mcoredb..vwRiskProductType
													WHERE	sRiskInstrumentType		= 'FRA'
													AND		sRiskProductType		= 'Forward Rate Agreement'
													AND		sRiskAssetClass			= 'Fixed Income Derivatives')
DECLARE @FOLLOWING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Following')
DECLARE @PRECEDING_BDRMOD_ID	NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleModifier'
													AND		sCodeValue				= 'Preceding')
DECLARE @MOD_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Modified')
DECLARE @REG_BDRCONV_ID			NUMERIC(18,0)	= (	SELECT	CodeID
													FROM	mcoredb..LookupCodes
													WHERE	sCategory				= 'BusDayRuleConvention'
													AND		sCodeValue				= 'Regular')
DECLARE @BusDayRuleMurexBridge	TABLE			(MxDesc VARCHAR(50), BusDayRuleModifierID NUMERIC(18,0), BusDayRuleConventionID NUMERIC(18,0))
INSERT	@BusDayRuleMurexBridge
VALUES
	('Previous',			@PRECEDING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Next',				@FOLLOWING_BDRMOD_ID, @REG_BDRCONV_ID),
	('Modified following',	@FOLLOWING_BDRMOD_ID, @MOD_BDRCONV_ID),
	('Modified preceding',	@PRECEDING_BDRMOD_ID, @MOD_BDRCONV_ID)
--SET @MSG = 'Business Day Rule Codes inserted.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @cof_typos				TABLE			(M_TRN_FMLY CHAR(5),	M_TRN_GRP CHAR(5),	M_TRN_TYPE CHAR(5),	sTypo VARCHAR(10))
INSERT @cof_typos
VALUES
	('IRD',		'LN_BR',	'',			'Depo')
	,('CURR',	'FXD',		'SWLEG',	'Fx Swap')
	,('SCF',	'SCF',		'SCF',		'SCF')
	,('IRD',	'IRS',		'',			'IRS')
	,('CURR',	'FXD',		'FXD',		'Spot')
	,('IRD',	'FRA',		'',			'FRA')
	,('CRD',	'CDS',		'',			'CDS')
	,('CRD',	'CRDI',		'',			'CDS Index')


DECLARE @CLEARING_HOUSES TABLE  (sName VARCHAR(50))

INSERT @CLEARING_HOUSES
VALUES
	('CITIGROUP CME CLEARING BROKER ACCT')
	,('LONDON CLEARING HOUSE')
	,('MSUSA ICE CLEARING BROKER ACCOUNT')
	,('LCH AFFILIATES CLEARING')
	,('MHBK, TKY JSC CLEARING BROKER ACCT')
	,('LCH CCP')
	,('CME CCP')
	,('JSCC CCP')
	,('ICE US CCP')
--SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CLEARING_HOUSES.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @TRADEENDCODES TABLE (CodeID	NUMERIC(18,0))
INSERT @TRADEENDCODES
SELECT	CodeID
FROM	mcoredb..LookupCodes
WHERE	sCategory = 'OTC Trade Status'
AND		sCodeValue IN ('CANCELED','EXPIRED','EXERCISED','MATURED','TERMINATED')


--DECLARE @RoundingFuncBridge	TABLE			(MxDesc VARCHAR(50), sDescription VARCHAR(50))
--INSERT	@RoundingFuncBridge
--VALUES
--	('None',		NULL),
--	('Nearest',		'Nearest'),
--	('By excess',	'Round'),
--	('By default',	'RoundDown'),
--	('Currency',	NULL)
--SET @MSG = 'Rounding functions inserted.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

DECLARE @callables				TABLE			(TYPO CHAR(21) PRIMARY KEY CLUSTERED)
INSERT @callables
VALUES
	('IRS Callable')
	,('Rev Floater Callable')
	,('IR CapFloor Callable')
	,('IR CapFl Call CMS')
	,('IR CapFl Call CMS SP')
	,('IRS Callable CMS')
	,('IRS Callable CMS SP')
	,('IRS ZC Call CMS')
	,('IRS ZC Call CMS SP')
	,('IRS ZC Callable')
	,('Range Call CMS')
	,('Range Call CMS SP')
	,('Range Callable')
	,('Rev Flt Call CMS')
	,('Rev Flt Call CMS SP')

--IF OBJECT_ID('tempdb..#TX_IDs') IS NOT NULL
--	DROP TABLE #TX_IDs --select * from #tx_ids
--CREATE TABLE #TX_IDs (			--table to retain new PK's generated in OTCTx table for use in IRDTxLegs
--	Action			NVARCHAR(10)
--	,TransactionID	NUMERIC(18,0) NOT NULL	--will put PK here in a few steps
--	,M_H_NB_MZ		CHAR(12)
--	,M_NB_EXT		NUMERIC(18,0)	--M_H_ALT_ID	CHAR(20)
--	,M_USI_ID		CHAR(52)
--	,M_USI_NS		CHAR(10)
--	,M_BETA_ID		CHAR(10)
--	,M_CCP_TRN_ID	CHAR(14)
--	,M_TRN_FMLY		CHAR(5)
--	,M_CNT_ORG		NUMERIC(10,0)
--	,bLive			BIT
--)

--IF OBJECT_ID('tempdb..#ACTIONS') IS NOT NULL
--	DROP TABLE #ACTIONS
--CREATE TABLE #ACTIONS (			--table to retain whether each IRDTxLeg was an insert or update, just for total counts
--	Action			NVARCHAR(10)
--)
--IF OBJECT_ID('tempdb..#TRADEBOOK') IS NOT NULL
--	DROP TABLE #TRADEBOOK
--CREATE TABLE #TRADEBOOK	(	--select count(*) FROM #TRADEBOOK
--	sRef		VARCHAR(20)		PRIMARY KEY
--	,AccountID	NUMERIC(18,0)
--)
--INSERT #TRADEBOOK	--select count(*) from #tradebook order by sref
;WITH TRADEBOOK AS (
SELECT	RTRIM(LTRIM(xa.sRef)) sRef, a.AccountID
FROM	mcoredb..Account										a
JOIN	mcoredb..XRefAccount									xa	ON	xa.AccountID			= a.AccountID
JOIN	mcoredb..Party											p	ON	p.PartyID				= a.PartyID
JOIN	mcoredb..LookupCodes									ps	ON	ps.CodeID				= p.StatusID
JOIN	mcoredb..Relationship									tbr	ON	tbr.SubPartyID			= p.PartyID
WHERE	xa.DataSourceID			= @DATASOURCE_ID_MUREX
AND		p.coPartyType			= 'Internal Unit'
AND		ps.sCodeValue			= 'Active'
AND		tbr.RelationshipTypeID	= @TRADEBOOK_REL_ID --47
--order by sRef
)

--SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #TRADEBOOK.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--IF OBJECT_ID('tempdb..#AFFILIATE') IS NOT NULL
--	DROP TABLE #AFFILIATE
--CREATE TABLE #AFFILIATE	(	--select count(*) FROM #AFFILIATE
--	sRef		VARCHAR(20)		PRIMARY KEY
--	--,AccountID	NUMERIC(18,0)
--)
--INSERT #AFFILIATE	--select count(*) from #AFFILIATE order by sref
, AFFILIATE AS (
SELECT DISTINCT xa.sRef
FROM	Credit				c
JOIN	LookupCodes			lc	ON	lc.CodeID				= c.AffiliateID
JOIN	Relationship		r	ON	r.SuperPartyID			= c.PartyID
JOIN	Party				p	ON	p.PartyID				= r.SubPartyID
JOIN	Account				a	ON	a.PartyID				= p.PartyID
JOIN	XRefAccount			xa	ON	xa.AccountID			= a.AccountID
JOIN	RelationshipType	rt	ON	rt.RelationshipTypeID	= r.RelationshipTypeID
WHERE	xa.DataSourceID			= @DATASOURCE_ID_MUREX
AND		rt.coFunctionalContext	= 'Credit'
AND		rt.coRelationshipType	= 'Functional'
AND     lc.sCodeValue			= 'Yes'
AND		lc.sCategory			= 'Affiliate'
--order by sRef
)
--SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #AFFILIATE.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--IF OBJECT_ID('tempdb..#CONTRACT') IS NOT NULL
--	DROP TABLE #CONTRACT
--CREATE TABLE #CONTRACT (	--select count(*) FROM #CONTRACT ORDER BY M_CONTRACT
--	M_CONTRACT	NUMERIC(10,0)
--	,M_TP_CNTRP	CHAR(35)
--	,PRIMARY KEY CLUSTERED (M_CONTRACT, M_TP_CNTRP) -- PK MUST BE BOTH IF ADDED	--CONSTRAINT [PK_#CONTRACT] 
--)
--INSERT #CONTRACT
, CONTRACT AS (
SELECT		t.M_CONTRACT, RTRIM(t.M_TP_CNTRP) M_TP_CNTRP
FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP	t
JOIN		mcoredb..XRefLookup									xl	ON	xl.sRef					= t.M_CNT_TYPO
JOIN		mcoredb..LookupCodes								pt	ON	pt.CodeID				= xl.LookupCodeID
WHERE		xl.DataSourceID	= @DATASOURCE_ID_MUREX
--AND		pt.sCategory	= 'Product Type'		--not necessary
AND			t.dtArchive		= @dt
GROUP BY	t.M_CONTRACT, t.M_TP_CNTRP
)

--SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #CONTRACT.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--IF OBJECT_ID('tempdb..#COUNTERPARTY') IS NOT NULL
--	DROP TABLE #COUNTERPARTY
--CREATE TABLE #COUNTERPARTY (
--	M_DSP_LBL	CHAR(35)	NOT NULL
--	,M_CODE		CHAR(10)
--	,AccountID	NUMERIC(18,0)
--)
--INSERT #COUNTERPARTY
, COUNTERPARTY AS (
SELECT	--sRef--*
	LTRIM(RTRIM(cp.M_DSP_LBL)) M_DSP_LBL
	,M_CODE
	,xa.AccountID
FROM	mcoredb..XRefAccount								xa
JOIN	mcoredb_archive.stage.MDR_MUREX_DM_REF_CNTP_REP		cp	ON	cp.M_CODE		= xa.sRef
																AND	xa.DataSourceID	= @DATASOURCE_ID_MUREX
WHERE	cp.dtArchive	= @dt
--ORDER BY 1
)
--ALTER TABLE #COUNTERPARTY ADD PRIMARY KEY (M_DSP_LBL)

--SET @MSG = CONVERT(VARCHAR, @@ROWCOUNT) + ' rows inserted in #COUNTERPARTY.'
--IF @debug = 1 INSERT mcoredb_work.stage.MDR_MUREX__PROGRESS (STEP) VALUES (@MSG)
--PRINT @MSG
--SET @OUTPUT += @MSG + CHAR(13) + CHAR(10)

--IF OBJECT_ID('tempdb..#CLEARING_HOUSES') IS NOT NULL
--	DROP TABLE #CLEARING_HOUSES
--CREATE TABLE #CLEARING_HOUSES (
--	sName	VARCHAR(50)	PRIMARY KEY
--)
--INSERT #CLEARING_HOUSES

--,OTC AS (

	SELECT -- * --xt.TransactionID, count(*)
		pt.CodeID ProdTypeID,						
		@DATASOURCE_ID_MUREX DataSourceID,														
		CASE t.M_TP_INT WHEN 'Y' THEN tbi.AccountID 
						ELSE cp.AccountID END CP_ID,
						tb.AccountID TradeBookID,
	--ts.sCodeValue,
	--t.M_TP_STATUS2,
	--t.M_AMD_STS2,
	--ev.M_H_EVENT,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 1----------------------------------------------------
		ts.CodeID TradeStatusID,					CASE	WHEN t.M_TP_STATUS2 IN ('LIVE','MKT_OP') THEN 1 ELSE 0 END Active,				CASE t.M_TP_INT WHEN 'Y' THEN 1 ELSE 0 END Internal,		t.M_TP_DTETRN,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 2----------------------------------------------------
		CASE
		WHEN t.M_CNT_TYPO	= 'Fwd Start Van FXD'
					THEN	t.M_TP_DTEFXGL
		WHEN t.M_CNT_TYPO	IN ('Avg Rate Fwd FXD','Average Asian FXD')
					THEN	t.M_TP_DTEFXGF
		WHEN t.M_TRN_FMLY	= 'CURR'
					THEN	t.M_TP_DTEEXP
		WHEN t.M_TRN_FMLY	= 'SCF'
					THEN	t.M_TP_DTETRN
		WHEN t.M_CNT_TYPO	= 'Treasury Lock'
					THEN	t.M_TP_DTETRN
		ELSE				t.M_TP_RTSD0
		END					dtEffective,			t.M_TP_DTEEXP dtMaturity,																CASE
																																			WHEN	t.M_TRN_FMLY <> 'CURR'
																																			AND		t.M_TP_RTMAT0 IS NULL
																																			THEN	t.M_TP_RTMAT1
																																			WHEN	t.M_TRN_FMLY IN ('CURR', 'SCF')
																																			THEN	t.M_TP_DTEEXP
																																			ELSE	t.M_TP_RTMAT0 END dtUnadjustedMaturity,				t.M_TP_NOMCUR sCurrency,
		CASE
		WHEN t.M_TRN_FMLY = 'SCF'
		THEN CASE t.M_TP_RTPR0
				WHEN 'P' THEN -t.M_TP_NOMINAL
				WHEN 'R' THEN t.M_TP_NOMINAL
				END
		ELSE t.M_TP_NOMINAL END dNotional,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 3----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATE)
							dtCleared,				CASE
													WHEN	ch.sName		IS NOT NULL
													THEN	cpc.AccountID
													WHEN	t.M_TP_STATUS2	= 'MKT_OP'
													AND		t.M_AMD_STS2	= 'OA' 
													AND		ev.M_H_EVENT	IN ('Counterpart assignment'
																				,'Counterpart amendment (FULL)') 
													THEN	cpo.AccountID	
													END									OriginalCPAccountID,
																					NULL ParentTransactionID,									
													CASE	WHEN ch.sName IS NOT NULL
													THEN 1 ELSE 0 END Cleared,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 4----------------------------------------------------
		udf.M_CLR_BR sClearingBroker,				
		rpt.CodeID RiskProductTypeID,															
		NULL ClearingBrokerID,										
		NULL OriginatorID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 5----------------------------------------------------
		t.M_PACKAGE sStrategy,						
		CASE WHEN agr.M_SIMM_AGR IS NULL THEN 0
				ELSE
				CASE agr.M_SIMM_AGR
					WHEN 'No SIMM agreement' 
					THEN 0 ELSE 1 END
					END						bSIMMEligible,
					ag.AgreementID CollateralAgreementID,						
					CASE WHEN t.M_TP_PFOLIO
						IN ('ATD','ETD','HTD','ITD','STD','MIZS','MTB')
									OR	aff.sRef IS NOT NULL
									THEN 1 ELSE 0 END bAffiliate,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 6----------------------------------------------------
		TRY_PARSE(udf.M_CLR_TS AS DATETIME)
					dtClearingTimestamp,			
					TRY_PARSE(udf.M_CONF_TS AS DATETIME) dtConfirmationTimestamp,								
					TRY_PARSE(udf.M_EXEC_TS AS DATETIME) dtExecutionTimestamp,		
					CONVERT(NUMERIC, t.M_CONTRACT) ContractKey,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 7----------------------------------------------------
		t.M_CNT_VS2 ContractVersion,
		ISNULL(t.M_CNTLEVTAD2, t.M_TP_DTESYS)  dtModification,									
		t.M_TP_TRADER sTrader,										
		IIF(s.M_MB_ID = 'Y', 1, 0) bMutualBreak,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 8----------------------------------------------------
		term.MAX_M_BKMANDEFFD
			dtMutualMandatoryTermination,			
			IIF(t.M_CNT_TYPO IN (SELECT TYPO FROM @callables),
			cb.CallableByID, NULL)	CancellableByID,										
			os.OptionStyleID CancelTypeID,								
			bt.OptionStyleID BreakTypeID,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 9----------------------------------------------------
		oct.CollateralizationTypeID
			OurCollateralizationTypeID,				
			cct.CollateralizationTypeID CtpCollateralizationTypeID,									
			udf.M_EXEC_TYPE sExecutionVenue,							
			CASE
				WHEN	t.M_CNTLIMPL2 <> ''
				THEN	t.M_CNTLIMPL2
				WHEN	t.M_CNTLIMPL2 = ''
				AND		t.M_CNTLEVTL2 <> t.M_CNT_EVTL
				THEN	t.M_CNTLEVTL2 END sLastEventName,
		--------------------------------------------------------------------------------------------------------------------------------------------ROW 10---------------------------------------------------
		t.M_INSTRUMENT sMXGeneratorLabel,			brk.AccountID BrokerAccountID,															IIF(t.M_CNT_TYPO = 'COF', 1, 0) bCOF,
		--------------------------------------------------------------------COLUMNS FOR #TX_IDs ONLY---------------------------------------------------------------------------------------------------------
		t.M_H_NB_MZ,								xt.TransactionID,																		t.M_NB_EXT,	/*M_H_ALT_ID,*/									ec.CodeID,
		t.M_H_DATA_DT2,								LEFT(udf.M_USI_ID, 50) M_USI_ID,														LEFT(udf.M_BETA_ID, 50) M_BETA_ID,							udf.M_USI_NS M_USI_NS,
		udf.M_CCP_TRN_ID,							t.M_TRN_FMLY,																			t.M_CNT_ORG
--into #otc --select m_h_alt_id, * from #otc
	FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP					t
	LEFT JOIN	@cof_typos															cof		ON	cof.M_TRN_FMLY				= t.M_TRN_FMLY
																							AND	cof.M_TRN_GRP				= t.M_TRN_GRP
																							AND	cof.M_TRN_TYPE				= t.M_TRN_TYPE
	JOIN		mcoredb..XRefLookup													xl		ON	RTRIM(LTRIM(xl.sRef))		= IIF(t.M_CNT_TYPO <> 'COF', RTRIM(LTRIM(t.M_CNT_TYPO)), cof.sTypo)
																							AND	xl.DataSourceID				= @DATASOURCE_ID_MUREX
																							AND	t.dtArchive					= @dt
	JOIN		mcoredb..LookupCodes												pt		ON	pt.CodeID					= xl.LookupCodeID
																							AND	pt.sCategory				= 'Product Type'
																							AND	pt.ParentID					IS NOT NULL	--THIS REMOVES THE PARENT 'SCF' PT BUT LEAVES THE CHILD
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_SQL_REP				s		ON	s.M_NB						= t.M_NB
																							AND	s.dtArchive					= @dt
	LEFT JOIN (
		SELECT		M_H_NB_MZ, MAX(M_BKMANDEFFD) MAX_M_BKMANDEFFD
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_TRN_EXE_SCHDL_REP
		WHERE		dtArchive	= @dt
		AND			M_TP_BREAK	= 'Y'
		GROUP BY	M_H_NB_MZ
	)																				term	ON	term.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.CallableBy											cb		ON	cb.sName					= t.M_TP_CANCBY
	LEFT JOIN	@CLEARING_HOUSES													ch		ON	ch.sName					= t.M_TP_CNTRP
	LEFT JOIN (
		SELECT	xlr.sRef, lc.CodeID
		FROM	mcoredb..XRefLookup		xlr
		JOIN	mcoredb..LookupCodes	lc	ON	lc.CodeID = xlr.LookupCodeID
		WHERE	xlr.DataSourceID		= @DATASOURCE_ID_MUREX
		AND		lc.sCategory			= 'Risk Product Type'
		AND		lc.bActive				= 1
		AND		lc.CodeID				<> @LEGACY_FRA_ID
	)																				rpt		ON	rpt.sRef					= t.M_CNT_TYPO
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_DM_TRN_UDF_DEAL_REP					udf		ON	udf.M_UDF_REF				= t.M_UDF_REF2
																							AND	udf.dtArchive				= @dt
	LEFT JOIN	mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP				agr		ON	agr.M_TRADE_NB				= t.M_NB
																							AND	agr.dtArchive				= @dt
	LEFT JOIN	mcoredb..Agreement													ag		ON	ag.sLegalName				= agr.M_NETTING_KEY
	LEFT JOIN (
		SELECT	M_IDENTITY
				,e.M_H_NB_MZ
				,M_H_EVENT
				,M_H_DATA_DT2
		FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP						e
		CROSS APPLY (	SELECT	MAX(M_IDENTITY) MAX_ID, M_H_NB_MZ
						FROM	mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
						WHERE	M_H_NB_MZ	= e.M_H_NB_MZ
						AND		dtArchive	= @dt
						GROUP BY M_H_NB_MZ
					) g
		WHERE	M_IDENTITY = MAX_ID
		AND		e.dtArchive	= @dt

		)																			ev		ON	ev.M_H_NB_MZ				= t.M_H_NB_MZ
	LEFT JOIN (
		SELECT	CodeID, sCodeValue
		FROM	mcoredb..LookupCodes
		WHERE	sCategory = 'OTC Trade Status'
	)																				ts		ON	ts.sCodeValue				= CASE
																																WHEN			t.M_TP_STATUS2		IN ('MKT_OP','LIVE')			THEN 'ACTIVE'
																																WHEN			t.M_TP_STATUS2		= 'DEAD'						THEN
																																	CASE
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		= 'Restructure'					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'NA'
																																		AND		t.M_CNTLIMPL2		IN ('Cancel and reissue'
																																										,'Counterpart amendment (FULL)'
																																										,'Portfolio modification'
																																										,'Allocation')				THEN 'CANCELED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Expiry'						THEN 'EXPIRED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Exercise','Knock')			THEN 'EXERCISED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		= 'Unwind'
																																		AND		t.M_H_DATA_DT2		< t.M_TP_DTEEXP					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		t.M_CNTLIMPL2		IN ('Counterpart assignment'
																																										,'Step out'
																																										,'Portfolio assignment'
																																										,'Netting')					THEN 'TERMINATED'
																																		WHEN	t.M_AMD_STS2		= 'CL'
																																		AND		(t.M_TRN_GRP		= 'FRA'
																																				AND t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR 
																																				ev.M_H_EVENT		NOT IN ('Counterpart assignment'
																																											,'Step out')
																																				AND t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				)													THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2		NOT IN ('CA','CL','NA')
																																		AND
																																				(t.M_TRN_GRP		= 'FRA'
																																				AND	t.M_TP_RTSD0	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	<> 'CURR'
																																				AND	t.M_TP_RTMAT0	IS NULL
																																				AND	t.M_TP_RTMAT1	<= t.M_H_DATA_DT2
																																				OR	t.M_TRN_FMLY	= 'CURR'
																																				AND	t.M_TP_DTEEXP	<= t.M_H_DATA_DT2
																																				OR	t.M_TP_RTMAT0	<= t.M_H_DATA_DT2
																																				)													THEN 'MATURED'
																																		WHEN	t.M_AMD_STS2			= 'CL'						THEN 'TERMINATED'
																																		ELSE															 'CANCELED'
																																	END
																																END
	LEFT JOIN	@TRADEENDCODES														ec		ON	ec.CodeID							= ts.CodeID
	LEFT JOIN	CONTRACT															ct		ON	ct.M_CONTRACT						= LTRIM(RTRIM(t.M_TP_ROOTCNT))
																							AND	ct.M_TP_CNTRP						= LTRIM(RTRIM(t.M_TP_CNTRP))
	JOIN		TRADEBOOK															tb		ON	tb.sRef								= LTRIM(RTRIM(t.M_TP_PFOLIO))
	LEFT JOIN	COUNTERPARTY														cp		ON	cp.M_DSP_LBL						= LTRIM(RTRIM(t.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	TRADEBOOK															tbi		ON	tbi.sRef							= LTRIM(RTRIM(t.M_TP_CNTRP))		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
	LEFT JOIN	COUNTERPARTY														cpo		ON	cpo.M_DSP_LBL						= LTRIM(RTRIM(ct.M_TP_CNTRP))		--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	COUNTERPARTY														cpc		ON	cpc.M_DSP_LBL						= LTRIM(RTRIM(udf.M_BILAT_CTPY))	--in schedpymt, use m_reference/m_dt_ctpid instead of m_dsp_lbl/m_tp_cntrp
	LEFT JOIN	mcoredb..XRefOTCTransaction											xt		ON	xt.sRef								= LTRIM(RTRIM(t.M_H_NB_MZ))
																							AND	xt.DataSourceID						= @DATASOURCE_ID_MUREX
																							AND xt.XRefOTCTradeTypeID				= @TRDREFTYPE_PRIMARY_ID
	LEFT JOIN	AFFILIATE															aff		ON	aff.sRef							= cp.M_CODE		--for internal trades only, where there is no CP_ID, so we will use tbi.AccountID
	LEFT JOIN	(
		SELECT		M_H_NB_MZ, MAX(M_V_DATE)	MAX_M_V_DATE
		FROM		mcoredb_archive.stage.MDR_MUREX_DM_OPS_EVT_REP
		WHERE		dtArchive	= @dt
		GROUP BY	M_H_NB_MZ
	)																				mods	ON	mods.M_H_NB_MZ						= t.M_H_NB_MZ
	LEFT JOIN	mcoredb.refcode.OptionStyle											os		ON	os.sName					= CASE
																																WHEN	t.M_CNT_TYPO	IN (SELECT TYPO FROM @callables)
																																THEN	CASE t.M_TP_AE
																																		WHEN 'E' THEN 'European'
																																		WHEN 'A' THEN 'American'
																																		WHEN 'B' THEN 'Bermudan' END
																																END
	LEFT JOIN	mcoredb.refcode.OptionStyle											bt		ON	bt.sName					= CASE
																																WHEN	s.M_MB_ID = 'Y'
																																THEN	CASE s.M_MB_BRKMODE
																																		WHEN '0' THEN 'Bermudan'
																																		WHEN '1' THEN 'European' END
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								oct	ON	oct.sName						= CASE		udf.M_COL_TP_OUR
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	mcoredb.refcode.CollateralizationType								cct	ON	cct.sName						= CASE		udf.M_COL_TP_CTP
																																WHEN	'FC'	THEN	'Fully Covered'
																																WHEN	'PC'	THEN	'Partially Covered'
																																WHEN	'OC'	THEN	'One Way'
																																WHEN	'U'		THEN	'Uncollateralized'
																																END
	LEFT JOIN	COUNTERPARTY														brk	ON	brk.M_DSP_LBL					= LTRIM(RTRIM(t.M_TP_BROLBL0))
	--)
	--WHERE DataSourceID = 202-- IN(701979)-- (851449,824616,795872,795120,795866,794502,824626,826256,843716,843905)

	--)

	--SELECT *
	--FROM OTC 
	--WHERE TransactionID IN (SELECT TransactionID FROM OTCTransaction)

	--SELECT * FROM OTCTransaction
	--WHERE TransactionID IN (851449,824616,795872,795120,795866,794502,824626,826256,843716,843905)