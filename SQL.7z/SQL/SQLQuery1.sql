/*
SELECT *
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME LIKE '%IPREO%'
*/
--SELECT count(*)
--FROM APP.DCM_IpreoSalesperson;


/*



MERGE EXTRACT.MCO_DEALOGIC_QIB_CERTIFICATE AS TGT
USING STAGE.MCO_DEALOGIC_QIB_CERTIFICATE AS SRC ON TGT.iCertificate = TGT.iCertificate
WHEN MATCHED AND	(SRC.sAccountNumber <> TGT.sAccountNumber OR 
					SRC.sClientName <> TGT.sClientName OR
					SRC.bCertificateBlanketStatus <> TGT.bCertificateBlanketStatus OR
					SRC.sCertificateStatus <> TGT.sCertificateStatus OR
					SRC.dtCertificateExpirationDate <> TGT.dtCertificateExpirationDate OR
					SRC.dtCertificateUploadDate <> TGT.dtCertificateUploadDate OR
					SRC.dtCertificateModifiedDate <> TGT.dtCertificateModifiedDate OR
					SRC.sParentAccountNumber <> TGT.sParentAccountNumber)
THEN UPDATE 
SET TGT.sAccountNumber = SRC.sAccountNumber,
	TGT.sClientName = SRC.sClientName,
	TGT.bCertificateBlanketStatus  = SRC.bCertificateBlanketStatus ,
	TGT.sCertificateStatus = SRC.sCertificateStatus,
	TGT.dtCertificateExpirationDate = SRC.dtCertificateExpirationDate,
	TGT.dtCertificateUploadDate = SRC.dtCertificateUploadDate,
	TGT.dtCertificateModifiedDate = SRC.dtCertificateModifiedDate,
	TGT.sParentAccountNumber = SRC.sParentAccountNumber
WHEN NOT MATCHED BY TARGET
THEN	INSERT (sAccountNumber,sClientName, bCertificateBlanketStatus, dtCertificateExpirationDate,dtCertificateUploadDate,dtCertificateModifiedDate,sParentAccountNumber) 
		VALUES (sAccountNumber,sClientName, bCertificateBlanketStatus, dtCertificateExpirationDate,dtCertificateUploadDate,dtCertificateModifiedDate,sParentAccountNumber) ;
			
--sAccountNumber
--sClientName
--bCertificateBlanketStatus
--sCertificateStatus
--dtCertificateExpirationDate
--dtCertificateUploadDate
--dtCertificateModifiedDate
--sParentAccountNumber


SELECT *
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME LIKE '%MCO_DEALOGIC_QIB_CERTIFICATE%';

*/

DECLARE @nam AS NVARCHAR(100),
		@sch AS NVARCHAR(100),
		@RN AS NVARCHAR(100),
		@INT AS INT = 2

--WHILE @nam IS NOT NULL

DECLARE CUS CURSOR
 FAST_FORWARD FOR
 SELECT TABLE_NAME,TABLE_SCHEMA,RN
 FROM
 (
 SELECT TABLE_SCHEMA,TABLE_NAME, ROW_NUMBER() OVER(ORDER BY TABLE_SCHEMA,TABLE_NAME) RN
 FROM INFORMATION_SCHEMA.TABLES) AS A
 WHERE RN < 100
 
 OPEN CUS
  FETCH NEXT FROM CUS INTO @NAM,@SCH, @RN

WHILE @@FETCH_STATUS = 0
BEGIN
 --SELECT @nam,@sch,@RN
 DECLARE @str AS NVARCHAR(100) = 'SELECT COUNT(*) FROM ' + @sch + '.' +'['+ @nam + ']'



 EXECUTE (@str)

 FETCH NEXT FROM CUS INTO @NAM,@SCH,@RN
 END
CLOSE CUS
DEALLOCATE CUS;

GO


--SELECT *
--FROM app.[17a13_Contact];