USE mcoredb_archive
DECLARE @JOBDT  AS DATETIME = '20190319'
DECLARE @DT  AS DATETIME = '20190322'


set nocount on
DECLARE @T TABLE([TABLE NAME] VARCHAR(100), DTARCHIVE VARCHAR(100) ,[COUNT] VARCHAR(100))

INSERT INTO @T([TABLE NAME],DTARCHIVE)
SELECT 'COL_EXC_ALLOC1_REP'			,dtArchive FROM stage.mdr_murex_COL_EXC_ALLOC1_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'COL_EXC_MR1_REP'			,dtArchive FROM stage.mdr_murex_COL_EXC_MR1_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'COL_INTERESTS1_REP'			,dtArchive FROM stage.mdr_murex_COL_INTERESTS1_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'COL_INVENTORY1_REP'			,dtArchive FROM stage.mdr_murex_COL_INVENTORY1_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'COL_MLC_EXPAGG1_REP'		,dtArchive FROM stage.mdr_murex_COL_MLC_EXPAGG1_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_OPS_EVT_REP'				,dtArchive FROM stage.mdr_murex_DM_OPS_EVT_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_OPS_FIX_REP'				,dtArchive FROM stage.mdr_murex_DM_OPS_FIX_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_LEG_REP'				,dtArchive FROM stage.mdr_murex_DM_PL_LEG_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_TRADE_REP'			,dtArchive FROM stage.mdr_murex_DM_PL_TRADE_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_REF_CDX_UDF_REP'			,dtArchive FROM stage.mdr_murex_DM_REF_CDX_UDF_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_REF_CNTP_REP'			,dtArchive FROM stage.mdr_murex_DM_REF_CNTP_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_RSK_DV01_REP'			,dtArchive FROM stage.mdr_murex_DM_RSK_DV01_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_CF_REP'				,dtArchive FROM stage.mdr_murex_DM_TRN_CF_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_EXE_SCHDL_REP'		,dtArchive FROM stage.mdr_murex_DM_TRN_EXE_SCHDL_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_RANGE_REP'			,dtArchive FROM stage.mdr_murex_DM_TRN_RANGE_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_SCHDL_REP'			,dtArchive FROM stage.mdr_murex_DM_TRN_SCHDL_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_TRADE_REP'			,dtArchive FROM stage.mdr_murex_DM_TRN_TRADE_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_TRADE_SQL_REP'		,dtArchive FROM stage.mdr_murex_DM_TRN_TRADE_SQL_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_UDF_DEAL_REP'		,dtArchive FROM stage.mdr_murex_DM_TRN_UDF_DEAL_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'LRB_COL_AGR_ASGN_REP'		,dtArchive FROM stage.mdr_murex_LRB_COL_AGR_ASGN_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_GEN_DT_REP'			,dtArchive FROM stage.MDR_MUREX_DM_TRN_GEN_DT_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_TRN_ALT_ID_REP'			,dtArchive FROM stage.MDR_MUREX_DM_TRN_ALT_ID_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_INF_XENO_REP'			,dtArchive FROM stage.MDR_MUREX_DM_INF_XENO_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_COLRBPL_DT_REP' 		,dtArchive FROM stage.MDR_MUREX_DM_PL_COLRBPL_DT_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_COLRBPL_MN_REP' 		,dtArchive FROM stage.MDR_MUREX_DM_PL_COLRBPL_MN_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_PLVAR_SCN_REP'		,dtArchive FROM stage.MDR_MUREX_DM_PL_PLVAR_SCN_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_RBPL_DT_REP'			,dtArchive FROM stage.MDR_MUREX_DM_PL_RBPL_DT_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_RBPL_MAIN_REP' 		,dtArchive FROM stage.MDR_MUREX_DM_PL_RBPL_MAIN_REP 		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_PL_XVARBPL_DT_REP'		,dtArchive FROM stage.MDR_MUREX_DM_PL_XVARBPL_DT_REP		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_RSK_SIMM_CL_REP MRX'		,dtArchive FROM stage.MDR_MUREX_DM_RSK_SIMM_CL_REP MRX		WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_RSK_FX_DELTA_REP'		,dtArchive FROM stage.MDR_MUREX_DM_RSK_FX_DELTA_REP			WHERE dtArchive > @jobdt UNION ALL
SELECT 'DM_RSK_DV01_REP'			,dtArchive FROM stage.MDR_MUREX_DM_RSK_DV01_REP				WHERE dtArchive > @jobdt UNION ALL
SELECT 'ERM_BT_1D_REP MRX'			,dtArchive FROM stage.MDR_MUREX_ERM_BT_1D_REP MRX			WHERE dtArchive > @jobdt UNION ALL
SELECT 'ERM_BT_10D_REP MRX'			,dtArchive FROM stage.MDR_MUREX_ERM_BT_10D_REP MRX			WHERE dtArchive > @jobdt 

SELECT [TABLE NAME], [2019-03-22] 
FROM @T
PIVOT
(COUNT([DTARCHIVE])
FOR [DTARCHIVE] IN ([2019-03-22])) AS A  



INSERT INTO @T([TABLE NAME], DTARCHIVE,COUNT)
SELECT	'MDR_MUREX_CF_VOL_REP'              ,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_CF_VOL_REP                   WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_COLLATCATCURVEMAPPING'	,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_COLLATCATCURVEMAPPING		 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_CR_RATING'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_CR_RATING					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_CR_SPREAD'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_CR_SPREAD					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_DM_REF_CNTP_REP'			,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_DM_REF_CNTP_REP				 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_DM_RSK_CR_JTD_REP'		,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_DM_RSK_CR_JTD_REP			 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_FG_FX_REP'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_FG_FX_REP					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_FG_INDX'					,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_FG_INDX						 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_FX_RATES'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_FX_RATES					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_FX_VOL_REP'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_FX_VOL_REP					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_IR_CURVE'				,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_IR_CURVE					 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_JAC_DV01_HSC_REP'		,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_JAC_DV01_HSC_REP			 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_JAC_DV01_PAR_REP'		,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_JAC_DV01_PAR_REP			 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_JAC_DV01_ZERO_REP'		,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_JAC_DV01_ZERO_REP			 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_JAC_FWD_RATES'			,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_JAC_FWD_RATES				 WHERE dtArchive > @jobdt group by dtArchive	  UNION
SELECT	'MDR_MUREX_SWAP_VOL_REP'			,DTARCHIVE, COUNT(*)	FROM  REFDATA.MDR_MUREX_SWAP_VOL_REP				 WHERE dtArchive > @jobdt group by dtArchive	  

SELECT * FROM @T

SELECT count(*)
FROM OTCTransactionValuation a
--join PositionValuation b on a.ValuationTypeID = b.ValuationTypeID
--WHERE  b.DTTIMESTAMP >= '2018-11-19 22:25:35.713' and b.DTTIMESTAMP <= '2018-11-19 23:00:35.713'
where a.dtValuation = '2018-11-16' and datasourceid = 199
ORDER BY a.dtTimestamp DESC

SELECT *--COUNT(*)
FROM POSITIONVALUATION
WHERE  DTTIMESTAMP >= '2018-11-19 21:25:35.713' --and DTTIMESTAMP <= '2018-11-19 23:00:35.713'
ORDER BY DTTIMESTAMP DESC

SELECT *--COUNT(*)
FROM TradeBookValuation
WHERE  DTTIMESTAMP >= '2018-11-19 21:25:35.713' --and DTTIMESTAMP <= '2018-11-19 23:00:35.713'
ORDER BY DTTIMESTAMP DESC

        
SELECT dtarchive, m_src_date,count(*)
FROM mcoredb_archive.stage.MDR_MUREX_DM_PL_XVARBPL_DT_REP
where dtarchive > '20190301'         
group by dtarchive, m_src_date                 

SELECT M_H_NB_MZ,M_H_DATA_DT2,count(*)-- distinct M_H_DATA_LB
FROM mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
WHERE dtArchive = '20181031'
group by M_H_NB_MZ,M_H_DATA_DT2
having count(*) > 1
order by count(*) desc


SELECT *
FROM mcoredb_archive.stage.MDR_MUREX_DM_REF_CNTP_REP
WHERE DTARCHIVE = '20181220'


select *
from mcoredb_archive.stage.MDR_MUREX_DM_PL_PLVAR_SCN_REP
where dtarchive = '20181122'

select *
from mcoredb_archive.stage.MDR_MUREX_DM_TRN_ALT_ID_REP


SELECT dtArchive,COUNT(*)
from mcoredb_archive.stage.mdr_murex_DM_TRN_UDF_DEAL_REP
where dtArchive > '20190211'
GROUP BY dtArchive

select distinct M_REF_DATA, count(*)
from mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
where dtArchive = '20181130'
group by M_REF_DATA

select distinct M_H_DATA_LB,M_REF_DATA,M_H_DATA_DT2, count(*)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_TRADE_REP
where dtArchive > '20181113'
group by M_H_DATA_LB,M_REF_DATA,M_H_DATA_DT2

--DELETE FROM mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
--WHERE M_H_DATA_LB = 'EOD_CSA' AND dtArchive = '20181030' AND M_H_DATA_DT2 = '20181031'

SELECT count(*)--distinct M_H_DATA_LB
from mcoredb_work.stage.MDR_MUREX_DM_PL_LEG_REP
WHERE dtArchive = '20181031'
       
select dtarchive, M_REF_DATA, count(*)--M_H_NB_MZ i,*
select distinct M_H_DATA_LB
from mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
where dtarchive = '20181031'
group by M_REF_DATA,dtArchive
order by dtArchive,M_REF_DATA--M_H_NB_MZ 

--delete from mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
--where M_REF_DATA = 2862 and dtArchive ='20181112'

SELECT *--distinct dtarchive, count(*)
FROM mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP
where dtarchive = '20181130'
order by M_TRADE_NB

group by dtArchive 
order by dtarchive desc


--SELECT * INTO ##CHAMP   
--DELETE FROM mcoredb_archive.stage.MDR_MUREX_LRB_COL_AGR_ASGN_REP
--WHERE dtArchive = '20181030'

1635618

SELECT COUNT(*)
FROM mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
where dtArchive = '20190129'
order by M_H_NB_MZ

select dtArchive,M_REF_DATA, sUser,M_H_DATA_LB,count(*)
from mcoredb_archive.stage.MDR_MUREX_DM_PL_LEG_REP
where dtArchive > '20181104'
group by M_REF_DATA,sUser,dtarchive,M_H_DATA_LB
order by dtArchive 

SELECT *--distinct dtArchive 
FROM mcoredb_work.stage.MDR_MUREX_COL_INTERESTS1_REP     
order by dtArchive desc

select dtArchive,count(*)
from mcoredb_archive.stage.MDR_MUREX_DM_REF_SEC_REP
group by dtarchive
order by dtArchive desc

SELECT count(*)
FROM mcoredb_work.stage.MDR_MUREX_DM_TRN_TRADE_REP

select *--DISTINCT M_SRC_DATE
from mcoredb_archive.stage.MDR_MUREX_DM_PL_RBPL_MAIN_REP
--where M_TIMEDECAY <> 0
ORDER BY M_SRC_DATE DESC

SELECT *-- COUNT(*) 
FROM mcoredb_work.stage.mdr_murex_DM_TRN_UDF_DEAL_REP	


select  *
from mcoredb_archive.stage.MDR_MUREX_DM_PL_RBPL_MAIN_REP
WHERE DTARCHIVE = '20181130'

select COUNT(*)
from mcoredb_work.stage.MDR_MUREX_DM_TRN_TRADE_REP


SELECT DISTINCT dtArchive,COUNT(*),dtTimestamp 
FROM mcoredb_archive.STAGE.MDR_MUREX_COL_INTERESTS1_REP
--WHERE dtArchive = '20181030'
GROUP BY dtArchive,dtTimestamp
ORDER BY DTARCHIVE DESC

select M_REF_DATA, count(*)
from mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
WHERE DTARCHIVE ='20181203'
group by M_REF_DATA


--delete from mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
--where M_REF_DATA = 2846 and dtArchive ='20181112'

select COUNT(*)--,dtTimestamp
from mcoredb_work.stage.MDR_MUREX_DM_TRN_SCHDL_REP



select top 10000 M_H_NB_MZ i, *--COUNT(*)--,dtTimestamp
from mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
WHERE DTARCHIVE ='20181112'
ORDER BY M_H_NB_MZ 
GROUP BY dtArchive--,dtTimestamp
order by dtarchive desc

SELECT COUNT(*)
FROM mcoredb_work.stage.MDR_MUREX_DM_RSK_DV01_REP (READUNCOMMITTED)
--WHERE dtTimestamp  > '2018-10-25 12:20:53.410'
ORDER BY M_H_DATA_DT2 DESC;

--UPDATE mcoredb_archive.STAGE.MDR_MUREX_DM_TRN_TRADE_REP
--SET DTARCHIVE = '20181105'
--WHERE DTARCHIVE = '20181106'







SELECT COUNT(*)
FROM mcoredb_archive.stage.MDR_MUREX_DM_RSK_DV01_REP --(READUNCOMMITTED)
WHERE dtArchive = '20190218'
ORDER BY dtArchive DESC

--8092012
select getdate() - 90

SELECT COUNT(*)
FROM mcoredb_archive.stage.mdr_murex_DM_TRN_SCHDL_REP
WHERE dtArchive = '20190218'
--delete 
--UPDATE
--FROM 
--mcoredb_archive.stage.mdr_murex_DM_TRN_SCHDL_REP
--SET dtArchive = '20181108'
WHERE dtArchive = '20190208'
ORDER BY dtArchive DESC;

SELECT *
--M_ROLL_DATE1
FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_GEN_DT_REP

SELECT DISTINCT DTARCHIVE FROM
mcoredb_archive.stage.MDR_MUREX_DM_TRN_TRADE_REP
ORDER BY dtArchive DESC



select M_IDENTITY,M_DT_ADFLW,M_DT_CAPXCD,M_DT_ADFLWSD,M_DT_ADFLWT,M_DT_ADFLWD,M_DT_ADFLWC,M_DT_ADFLWA,
M_TP_RTFLWAD,M_DT_NDXFAC0,M_DT_START0,M_DT_STRK0,M_NB,M_DT_OAMT1,M_TRN_FMLY,M_DT_UPFIX0,M_DT_CAPCUR0,
M_DT_CCINT0,M_DT_PAYMNT0,M_DT_PHASE,M_DT_CAPXCC,M_DT_FLWTYP2,M_TRN_TYPE,M_DT_OAMT0,M_DT_OAMTD0,
M_DT_OAMTD1,M_DT_CTPID,M_DT_LEGSTP0,M_DT_CURFLG,M_MX_REF_JOB,M_DT_MARGIN0,M_DT_CAPXC,
M_H_DATA_LB,M_DT_FLOWTYP,M_DT_STRK20,M_DT_FLWTYP0,M_DT_ESTSD0,M_DT_FLOWNAT,M_DT_FLWTYP1,M_DT_FIXING0,
M_DT_END0,M_DT_CAPXCA,M_DT_ESTED0,M_H_DATA_DT2,M_DT_LEG0,M_H_PERID_ID,M_TRN_GRP,M_REF_DATA,M_DT_FWDPR0,
M_DT_FLWTYP3,M_DT_FLWTYP4,M_H_NB_MZ,M_DT_CAPREM0,M_DT_LGFIX0,M_DT_LGPR0,M_DT_CLCDEN0,M_DT_CLCNUM0,
M_DT_PAYCUR0,M_DT_FXNGF0,M_DT_FXNGM0,M_DT_FXNG10,M_DT_NDXRCD0

--SELECT *
FROM mcoredb_archive.stage.MDR_MUREX_DM_TRN_SCHDL_REP
ORDER BY M_H_DATA_DT2 DESC


Invalid column name 'M_ROLL_DATE0'.
Msg 207, Level 16, State 1, Line 1
Invalid column name 'M_ROLL_DATE1'. 


SELECT *--M_ROLL_DATE0, M_ROLL_DATE1
FROM mcoredb_work.stage.MDR_MUREX_DM_TRN_GEN_DT_REP;


SELECT *--M_ROLL_DATE0, M_ROLL_DATE1
FROM mcoredb_archive.stage.MDR_MUREX_DM_INF_XENO_REP
where dtArchive = '20190218'
ORDER BY DTARCHIVE DESC;

SELECT *
FROM mcoredb_archive.STAGE.MDR_MUREX_DM_RSK_FX_DELTA_REP
WHERE dtArchive = '20181123'

SELECT --M_BASE_ID BASE,M_MX_REF_JOB MX_REF, M_REF_DATA REF,* 
 dtArchive,--,M_MX_REF_JOB,M_REF_DATA, 
 COUNT(*) COUNT
FROM mcoredb_archive.stage.MDR_MUREX_COL_EXC_MR1_REP
WHERE dtArchive >='20190219'
GROUP BY dtArchive--,M_MX_REF_JOB,M_REF_DATA
ORDER BY dtArchive--,M_MX_REF_JOB,M_REF_DATA --dtArchive

