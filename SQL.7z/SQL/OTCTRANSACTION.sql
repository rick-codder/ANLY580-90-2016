--DROP TABLE stage.OTCTransaction;

CREATE TABLE [stage].[OTCTransaction](
	[TransactionID] [numeric](18, 0) IDENTITY(1,1) NOT NULL,
	[TransactionIDDD] [numeric](18,0)NOT NULL,
	[ProductTypeID] [numeric](18, 0) NOT NULL,
	[DataSourceID] [numeric](18, 0) NOT NULL,
	[CPAccountID] [numeric](18, 0) NULL,
	[TradingAccountID] [numeric](18, 0) NOT NULL,
	[TradeStatusID] [numeric](18, 0) NULL,
	[bActive] [bit] NULL,
	[sDescription] [varchar](100) NULL,
	[bInternal] [bit] NOT NULL,
	[dtTrade] [datetime] NULL,
	[dtEffective] [datetime] NULL,
	[dtMaturity] [datetime] NULL,
	[sCurrency] [char](3) NOT NULL,
	[dNotional] [numeric](29, 8) NOT NULL,
	[dtCleared] [date] NULL,
	[OriginalCPAccountID] [numeric](18, 0) NULL,
	[ParentTransactionID] [numeric](18, 0) NULL,
	[bCleared] [bit] NOT NULL,
	[sClearingBroker] [varchar](100) NULL,
	[RiskProductTypeID] [numeric](18, 0) NULL,
	[sBusinessKey] [varchar](100) NULL,
	[ClearingBrokerID] [numeric](18, 0) NULL,
	[OriginatorID] [numeric](18, 0) NULL,
	[sStrategy] [varchar](50) NULL,
	[bSIMMEligible] [bit] NULL,
	[CollateralAgreementID] [numeric](18, 0) NULL,
	[ClearingHouseAccountID] [numeric](18, 0) NULL,
	[dtClearingTimestamp] [datetime] NULL,
	[dtConfirmationTimestamp] [datetime] NULL,
	[dtExecutionTimestamp] [datetime] NULL,
	[ContractKey] [numeric](18, 0) NULL,
	[ContractVersion] [numeric](6, 0) NULL,
	[dtModification] [datetime] NULL,
	[dtUnadjustedMaturity] [date] NULL,
	[sTrader] [varchar](100) NULL,
	[bMutualBreak] [bit] NULL,
	[dtMutualMandatoryTermination] [date] NULL,
	[CancellableByID] [smallint] NULL,
	[CancelTypeID] [smallint] NULL,
	[BreakTypeID] [smallint] NULL,
	[bAffiliate] [bit] NULL,
	[OurCollateralizationTypeID] [smallint] NULL,
	[CtpCollateralizationTypeID] [smallint] NULL,
	[sExecutionVenue] [varchar](15) NULL,
	[sLastEventName] [varchar](50) NULL,
	[sMXGeneratorLabel] [char](35) NULL,
	[BrokerAccountID] [numeric](18, 0) NULL,
	[bCOF] [bit] NULL,
	[dtTimestamp] [datetime] NULL,
	[sUser] [varchar](150) NULL,
 CONSTRAINT [PK_OTCTransaction] PRIMARY KEY CLUSTERED 
(
	[TransactionID] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Index [IX_OTCTransaction_01]    Script Date: 10/18/2018 12:56:20 PM ******/
CREATE NONCLUSTERED INDEX [IX_OTCTransaction_01] ON [stage].[OTCTransaction]
(
	[RiskProductTypeID] ASC,
	[TransactionID] ASC,
	[DataSourceID] ASC,
	[CPAccountID] ASC,
	[TradeStatusID] ASC,
	[dtMaturity] ASC,
	[bActive] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_OTCTransaction_DataSourceId]    Script Date: 10/18/2018 12:56:20 PM ******/
CREATE NONCLUSTERED INDEX [IX_OTCTransaction_DataSourceId] ON [stage].[OTCTransaction]
(
	[DataSourceID] ASC
)
INCLUDE ( 	[TransactionID],
	[ProductTypeID]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_OTCTransaction_DataSourceId_TransactionId]    Script Date: 10/18/2018 12:56:20 PM ******/
CREATE NONCLUSTERED INDEX [IX_OTCTransaction_DataSourceId_TransactionId] ON [stage].[OTCTransaction]
(
	[DataSourceID] ASC,
	[TransactionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_OTCTransaction_sBusinessKey]    Script Date: 10/18/2018 12:56:20 PM ******/
CREATE NONCLUSTERED INDEX [IX_OTCTransaction_sBusinessKey] ON [stage].[OTCTransaction]
(
	[sBusinessKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO