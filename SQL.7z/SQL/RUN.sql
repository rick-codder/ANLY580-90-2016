use mcoredb


DECLARE --@dt			DATE = '20190212'
	 @InsertCount		INT
	,@UpdateCount		INT
	,@DeleteCount		INT
	,@Leg0InsertCount	INT
	,@Leg1InsertCount	INT
	,@Leg0UpdateCount	INT
	,@Leg1UpdateCount	INT

DECLARE @start					DATETIME		= GETDATE()
DECLARE @debug					BIT				= 1
DECLARE @MSG					VARCHAR(1000)
DECLARE @OUTPUT					VARCHAR(MAX)	= ''


EXEC [stage].[spMDR_MUREX_ISSUE] @dt

EXEC [stage].[spMDR_MUREX_BROKER_ACCOUNT] @dt, @InsertCount OUT, @UpdateCount OUT

EXEC [stage].[spMDR_MUREX_ISSUE_CDS_INDEX] @dt, @InsertCount OUT, @DeleteCount OUT, @UpdateCount OUT

EXEC [stage].[spMDR_MUREX_ISSUE_CDS_RED_ID] @dt, @InsertCount OUT


EXEC [stage].[spMDR_MUREX_TRANSACTION] @dt, @InsertCount OUT, @UpdateCount OUT, @DeleteCount OUT

EXEC [stage].[spMDR_MUREX_TRANSACTION_LEG] @dt, @Leg0InsertCount OUT, @Leg1InsertCount OUT, @Leg0UpdateCount OUT, @Leg1UpdateCount OUT

EXEC stage.spMDR_MUREX_TRANSACTION_CDS								@dt, @InsertCount OUT, @UpdateCount OUT

EXEC stage.spMDR_MUREX_TRANSACTION_DAILY							@dt, @InsertCount OUT, @DeleteCount OUT, @UpdateCount OUT

EXEC stage.spMDR_MUREX_TRANSACTION_IRD_NONLINEAR					@dt, @InsertCount OUT, @UpdateCount OUT

EXEC stage.spMDR_MUREX_RANGE_DETAIL									@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_FX_DERIVATIVE								@dt, @InsertCount OUT, @UpdateCount OUT

EXEC stage.spMDR_MUREX_FX_TRANSACTION_DAILY							@dt, @InsertCount OUT, @UpdateCount OUT

EXEC stage.spMDR_MUREX_EXERCISE_SCHEDULE							@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_CANCEL_SCHEDULE								@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_COLLATERAL									@dt, @DeleteCount OUT, @InsertCount OUT --manual

EXEC stage.spMDR_MUREX_COLLATERAL_EXPOSURE							@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_COLLATERAL_INTEREST							@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_MARGIN_CALL									@dt, @UpdateCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_COLLATERAL_ALLOCATION						@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_FIXING_SCHEDULE								@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_TLOCK										@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_TRANSACTION_LEG_DAILY						@dt, @Leg0InsertCount OUT, @Leg0UpdateCount OUT, @Leg1InsertCount OUT, @Leg1UpdateCount OUT

EXEC stage.spMDR_MUREX_PAYMENT_SCHEDULE_IRD							@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_NOTIONAL_SCHEDULE_IRD						@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_PAYMENT_SCHEDULE_FX							@dt, @DeleteCount OUT, @InsertCount OUT

EXEC stage.spMDR_MUREX_PAYMENT_SCHEDULE_CDS							@dt, @DeleteCount OUT, @InsertCount OUT


EXEC [stage].[spMDR_MUREX_TRANSACTION_SYNTH_COLVA]			   @dt, @InsertCount OUT, @UpdateCount OUT
 															   
--EXEC [stage].[spMDR_MUREX_TRANSACTION_SYNTH_COLVA_DAILY]	   @dt, @InsertCount OUT, @UpdateCount OUT
 															   
EXEC [stage].[spMDR_MUREX_TRANSACTION_SYNTH_COLVA_PYMT]		   @dt, @DeleteCount OUT, @InsertCount OUT
 															  
EXEC [stage].[spMDR_MUREX_TRANSACTION_SYNTH_PURGED]			   @dt, @InsertCount OUT, @DeleteCount OUT, @UpdateCount OUT
 															  
EXEC [stage].[spMDR_MUREX_TRANSACTION_SYNTH_PURGED_DAILY]      @dt, @InsertCount OUT, @DeleteCount OUT, @UpdateCount OUT