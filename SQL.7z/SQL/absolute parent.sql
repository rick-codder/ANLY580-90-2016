select xp.sRef, p.sName PARTYNAME, A.sName ACCOUNTNAME,A.sLongName, P.PartyID,*
from dbo.XRefAccount xa
inner join dbo.Account a on a.AccountID=xa.AccountID
inner join dbo.Relationship r on r.SubPartyID=a.PartyID and r.RelationshipTypeID=(select RelationshipTypeID from dbo.RelationshipType where coSubRole='Client' and coSuperRole='Client' and coRelationshipType='Functional' and coFunctionalContext='Compliance')
inner join dbo.XRefParty xp on xp.PartyID=r.SuperPartyID
inner join dbo.Party p on p.PartyID=xp.PartyID
--where P.PartyID  = 313843
--where xa.sRef='200-010382'
--WHERE P.sName = 'ABU DHABI INVESTMENT AUTHORITY'--'1832 ASSET MANAGEMENT L.P.'
ORDER BY P.sName ASC


select  xp.sRef, p.sName PARTYNAME, A.sName ACCOUNTNAME, P.PartyID, A.AccountID, A.ParentID, A.bActive, A.sLongName
from dbo.XRefAccount xa
inner join dbo.Account a on a.AccountID=xa.AccountID
inner join dbo.Relationship r on r.SubPartyID=a.PartyID and r.RelationshipTypeID = (select RelationshipTypeID from dbo.RelationshipType where coSubRole='Client' and coSuperRole='Client' and coRelationshipType='Functional' and coFunctionalContext='Credit')
inner join dbo.XRefParty xp on xp.PartyID=r.SuperPartyID
inner join dbo.Party p on p.PartyID=xp.PartyID
WHERE P.sName = 'ABERDEEN ASSET MANAGEMENT INC'-- '1832 ASSET MANAGEMENT L.P.'
--where P.PartyID  = 247594 --xa.sRef='200-010382'
ORDER BY A.sName ASC



SELECT DISTINCT P.sValue
FROM APP.CoreDomain_PartyProperty P
JOIN APP.CoreDomain_PartyPropertyType PR ON P.PropertyTypeID = PR.ID
WHERE PR.sName = 'CERTIFICATE_QIB'
GO


SELECT *
FROM APP.CoreDomain_PartyProperty;
GO


SELECT	PT.sName,
		XP.sRef,
		P.*  
FROM [mcoredb].[app].[CoreDomain_PartyProperty] P
INNER JOIN [mcoredb].[app].[CoreDomain_PartyPropertyType] T ON P.PropertyTypeID = T.ID 
JOIN PARTY PT ON PT.PartyID = P.PartyID
LEFT JOIN XRefParty XP ON XP.PartyID = P.PartyID
WHERE T.sName = 'CERTIFICATE_QIB'


SELECT *
FROM Relationship
WHERE SuperPartyID = 313843

--276944
--276946
--287066
--314429
--277247

SELECT *
FROM DBO.XRefParty XP
left JOIN DBO.party A ON a.PartyID = xp.PartyID
WHERE sRef = 'M002898' -- 'M004305'
GO

SELECT *
FROM PARTY
--WHERE PARTYID = 12775
WHERE sName  = 'ABERDEEN ASSET MGT'--'ABU DHABI INVESTMENT AUTHORITY' --= '1832 ASSET MANAGEMENT L.P.'

--276946
SELECT XP.sRef,P.sName SubParty ,PP.sName SuperParty, *
FROM Relationship R
JOIN PARTY P ON R.SubPartyID = P.PartyID
JOIN PARTY PP ON PP.PartyID = R.SuperPartyID
 JOIN XRefParty XP ON XP.PartyID = PP.PARTYID 
join Account a on a.PartyID = p.PartyID
WHERE P.sName = 'ABU DHABI INVESTMENT AUTHORITY'--'ABERDEEN ASSET MANAGEMENT INC'-- '1832 ASSET MANAGEMENT L.P.' --SubPartyID = 276946
ORDER BY SuperParty


SELECT A.sName,PP.sName,P.sName,RO.SubPartyID,*
FROM PARTY P 
--LEFT JOIN Relationship R ON R.SubPartyID = P.PartyID
LEFT JOIN Relationship RO ON RO.SuperPartyID = P.PartyID
LEFT JOIN Party PP ON PP.PartyID = RO.SubPartyID
LEFT JOIN Account A ON A.ParentID = PP.PartyID
WHERE P.sName LIKE '%ABERDEEN ASSET MANAGEMENT INC%'

SELECT A.sName SUB,P.sName PARENT,PP.sName MASTER, PP.sLongName "MASTER LONG NAME",PT.sName SUPER,PT.PartyID SUPER,A.AccountID SUB,P.PartyID PARENT,PP.PartyID MASTER,XP.sRef,*
FROM ACCOUNT A
JOIN PARTY P ON P.PartyID = A.PartyID
JOIN Relationship R ON R.SubPartyID = P.PartyID
JOIN PARTY PP ON PP.PartyID = R.SuperPartyID
JOIN XRefParty XP ON XP.PartyID = PP.PartyID
JOIN Relationship RO ON RO.SubPartyID = PP.PARTYID
JOIN PARTY PT ON PT.PARTYID = RO.SuperPartyID
WHERE A.sName = 'AEGON-250044'

SELECT PP.sName SUB,PP.coPartyType,PP.coPartyTypeID,*
FROM PARTY P
JOIN Relationship R ON P.PARTYID = R.SuperPartyID
JOIN PARTY PP ON PP.PARTYID = R.SubPartyID
WHERE --P.PartyID IN (285221, 18125) AND 
--PP.SNAME LIKE '%AEGON USA INVESTMENT MANAGEMENT, LLC%'
--P.coPartyType = 'Legal Entity'

SELECT DISTINCT coPartyType, coPartySubType, sName
FROM PARTY
WHERE coPartyType = 'INTERNAL UNIT'
ORDER BY coPartyType

select PT.sName,* 
from party P
JOIN Relationship R ON R.SuperPartyID = P.PartyID
JOIN Party PT ON PT.PartyID = R.SubPartyID
where P.PARTYID = 250188

SELECT *
FROM Relationship
WHERE SuperPartyID = 157299 or SubPartyID = 12119;
go

SELECT --XP.sRef,
*
FROM PARTY P
JOIN XRefParty XP ON XP.PartyID != P.PartyID
WHERE P.PARTYID IN (312774,22851,249733,14106)

SELECT *
FROM INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME LIKE '%CLIENT%NAM%';
GO

SELECT *
FROM APP.DCM_ClientCode;
GO

SELECT *
FROM Account
WHERE sName LIKE '1832%';
GO