﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Saxy;
using Webscraper.Filters;
using Webscraper.Exception;
using TagSoup.Net;
namespace Webscraper.Documents
{
    public interface DocumentSource
    {
        TextDocument ToTextDocument();
    }

    public interface Input
    {
        TextDocument GetTextDocument();

    }

    public class Image : IComparable<Image>
    {
        private string src;
        private string width;
        private string height;
        private string alt;
        private int area;


        public Image(string src, string width, string height, string alt)
        {
            this.src = src;
            if (src == null)
            {
                throw new NullReferenceException("src attribute must not be null");
            }
            this.width = nullTrim(width);
            this.height = nullTrim(height);
            this.alt = nullTrim(alt);

            if (width != null && height != null)
            {
                int a;
                try
                {
                    a = int.Parse(width) * int.Parse(height);
                }
                catch (FormatException e)
                {
                    a = -1;
                }
                this.area = a;
            }
            else
            {
                this.area = -1;
            }
        }

        public string GetSrc()
        {
            return src;
        }

        public string GetWidth()
        {
            return width;
        }

        public string GetHeight()
        {
            return height;
        }

        public string GetAlt()
        {
            return alt;
        }

        private static string nullTrim(string s)
        {
            if (s == null)
            {
                return null;
            }
            s = s.Trim();
            if (s.Length == 0)
            {
                return null;
            }
            return s;
        }

        public int GetArea()
        {
            return area;
        }

        public override string ToString()
        {
            return src + "\twidth=" + width + "\theight=" + height + "\talt=" + alt + "\tarea=" + area;
        }

        public int CompareTo(Image img)
        {
            if (img == this)
            {
                return 0;
            }
            if (area > img.area)
            {
                return -1;
            }
            else if (area == img.area)
            {
                return src.CompareTo(img.src);
            }
            return 1;
        }

    }

    public class TextDocumentStatistics
    {
        private int numWords = 0;
        private int numBlocks = 0;


        public TextDocumentStatistics(TextDocument doc, bool contentOnly)
        {
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (contentOnly && !tb.IsContent())
                {
                    continue;
                }

                numWords += tb.NumWords;
                numBlocks++;
            }
        }

        public float AvgNumWords()
        {
            return numWords / (float)numBlocks;
        }


        public int GetNumWords()
        {
            return numWords;
        }

    }

    public class TextDocument : ICloneable
    {
        List<TextBlock> textBlocks;
        string title;


        public TextDocument(List<TextBlock> textBlocks) : this(null, textBlocks)
        {

        }

        public TextDocument(string title, List<TextBlock> textBlocks)
        {
            Console.WriteLine("did any come in....  " + textBlocks.Count);

            //Console.WriteLine(textBlocks[140].Text);


            this.title = title;
            this.textBlocks = textBlocks;
        }

        public List<TextBlock> GetTextBlocks()
        {
            return textBlocks;
        }

        public string GetTitle()
        {
            return title;
        }

        public string GetContent()
        {
            return GetText(true, false);
        }

        public string GetText(bool includeContent, bool includeNonContent)
        {
            StringBuilder sb = new StringBuilder();

            foreach (TextBlock tb in GetTextBlocks())
            {
                if (tb.IsContent())
                {
                    if (!includeContent)
                    {
                        continue;
                    }
                }
                else
                {
                    if (!includeNonContent)
                    {
                        continue;
                    }
                }
                sb.Append(tb.Text);
                sb.Append("\n");
            }

            return sb.ToString();

        }

        public string DebugString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (TextBlock tb in GetTextBlocks())
            {
                sb.Append(tb.ToString());
                sb.Append("\n");
            }

            return sb.ToString();

        }

        public object Clone()
        {
            List<TextBlock> list = new List<TextBlock>(textBlocks.Count);

            foreach (TextBlock tb in textBlocks)
            {
                list.Add((TextBlock)tb.Clone());
            }

            return new TextDocument(title, list);
        }

    }

    public class TextBlock : ICloneable
    {
        public bool isContent = false;
        private StringBuilder text;
        HashSet<string> labels = null;

        int offsetBlocksStart;
        int offsetBlocksEnd;

        int numWords;
        int numWordsInAnchorText;
        int numWordsInWrappedLines;
        int numWrappedLines;
        float textDensity;
        float linkDensity;

        BitArray containedTextElements;

        private int numFullTextWords = 0;
        private int tagLevel;

        public static BitArray EMPTY_BITSET = new BitArray(0);
        public static TextBlock EMPTY_START = new TextBlock("", EMPTY_BITSET, 0, 0, 0, 0, -1);
        public static TextBlock EMPTY_END = new TextBlock("", EMPTY_BITSET, 0, 0, 0, 0, int.MaxValue);


        public TextBlock(string text) : this(text, null, 0, 0, 0, 0, 0)
        {
        }


        public TextBlock(string text, BitArray containedTextElements, int numWords, int numWordsInAnchorText,
            int numWordsInWrappedLines, int numWrappedLines, int offsetBlocks)
        {
            this.text = new StringBuilder(text);
            this.containedTextElements = containedTextElements;
            this.numWords = numWords;
            this.numWordsInAnchorText = numWordsInAnchorText;
            this.numWordsInWrappedLines = numWordsInWrappedLines;
            this.numWrappedLines = numWrappedLines;
            this.offsetBlocksStart = offsetBlocks;
            this.offsetBlocksEnd = offsetBlocks;

            InitDensities();


        }

        public bool IsContent()
        {

            return isContent;
        }

        public bool SetIsContent(bool isContent)
        {
            if (isContent != this.isContent)
            {
                this.isContent = isContent;
                return true;
            }
            else
            {
                return false;
            }
        }

        public string Text { get { return text.ToString(); }  }

        //public string GetText()
        //{
        //    return text.ToString();
        //}

        public int NumWords { get { return numWords; }  }

        public int NumWordsInAnchorText { get { return numWordsInAnchorText; } }

        //public int GetNumWords()
        //{
        //    return numWordsInAnchorText;
        //}

        public float TextDensity { get { return textDensity; }  }

        //public float GetTextDensity()
        //{
        //    return textDensity;
        //}

        public float LinkDensity { get { return linkDensity; }  }

        //public float GetLinkDensity()
        //{
        //    return linkDensity;
        //}

        public void MergeNext(TextBlock other)
        {
            if (!(text.GetType() == typeof(StringBuilder)))
            {
                text = new StringBuilder(text.ToString());

            }

            StringBuilder sb = (StringBuilder)text;
            sb.Append("\n");
            sb.Append(other.text);

            numWords += other.numWords;
            numWordsInAnchorText += other.numWordsInAnchorText;

            numWordsInWrappedLines += other.numWordsInWrappedLines;
            numWrappedLines += other.numWrappedLines;

            offsetBlocksStart = Math.Min(offsetBlocksStart, other.offsetBlocksStart);
            offsetBlocksEnd = Math.Max(offsetBlocksEnd, other.offsetBlocksEnd);

            InitDensities();

            this.isContent |= other.isContent;

            if (containedTextElements == null)
            {
                containedTextElements = (BitArray)other.containedTextElements.Clone();
            }
            else
            {
                containedTextElements.Or(other.containedTextElements);

            }

            numFullTextWords += other.numFullTextWords;

            if (other.labels != null)
            {
                if (labels == null)
                {
                    labels = new HashSet<string>(other.labels);
                }
                else
                {
                    labels.Union(other.labels);

                }
            }

            tagLevel = Math.Min(tagLevel, other.tagLevel);

        }

        private void InitDensities()
        {
            if (numWordsInWrappedLines == 0)
            {
                numWordsInWrappedLines = numWords;
                numWrappedLines = 1;
            }

            textDensity = numWordsInWrappedLines / (float)numWrappedLines;
            linkDensity = numWords == 0 ? 0 : numWordsInAnchorText / (float)numWords;
        }

        public int OffsetBlocksStart { get { return offsetBlocksStart; } set { } }

        //public int GetOffsetBlocksStart()
        //{
        //    return offsetBlocksStart;
        //}

        public int OffsetBlocksEnd { get { return offsetBlocksEnd; } set { } }

        //public int GetOffsetBlocksEnd()
        //{
        //    return offsetBlocksEnd;
        //}

        public override string ToString()
        {
            return "[" + offsetBlocksStart + "-" + offsetBlocksEnd + ";tl=" + tagLevel + "; new=" + numWords
                + ";nwl=" + numWrappedLines + ";ld=" + linkDensity + "]\t"
                + (isContent ? "CONTENT" : "webscraper") + "," + string.Join("," ,Labels ?? Enumerable.Empty<string>()) + "\n" + Text;
        }

        public void AddLabel(string label)
        {
            if (labels == null)
            {
                labels = new HashSet<string>();
            }
            labels.Add(label);
        }

        public bool HasLabel(string label)
        {
            return labels != null && labels.Contains(label);
        }

        public bool RemoveLabel(string label)
        {
            return labels != null && labels.Remove(label);
        }

        public HashSet<string> Labels { get { return labels; } set { } }


        //public HashSet<string> GetLabels()
        //{
        //    return labels;
        //}

        public void AddLabels(params string[] l)
        {
            if (l == null)
            {
                return;
            }
            if (this.labels == null)
            {
                this.labels = new HashSet<string>();
            }
            else
            {
                this.labels.Union(l);
            }
        }

        public BitArray ContainedTextElements { get { return containedTextElements; } set { } }

        //public BitArray GetContainedTextElements()
        //{
        //    return containedTextElements;
        //}



        public object Clone()
        {
            TextBlock clone = new TextBlock("");
            try
            {
                clone = (TextBlock)this.MemberwiseClone();
            }
            catch (SAXException e)
            {
                throw new SAXException(e.Message);
            }
            if (text != null && !(text.GetType() == typeof(StringBuilder)))
            {
                clone.text = new StringBuilder(text.ToString());
            }
            if (labels != null && !(labels.Any()))
            {
                clone.labels = new HashSet<string>(labels);

            }
            if (containedTextElements != null)
            {
                clone.containedTextElements = (BitArray)containedTextElements.Clone();
            }

            return clone;
        }

        public int TagLevel { get { return tagLevel; } set { tagLevel = value; } }

        //public int GetTagLevel()
        //{
        //    return tagLevel;
        //}

        //public void SetTagLevel(int tagLevel)
        //{
        //    this.tagLevel = tagLevel;
        //}

    }

}
