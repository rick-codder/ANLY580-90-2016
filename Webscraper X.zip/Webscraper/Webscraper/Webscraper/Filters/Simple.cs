﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Conditions;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;


namespace Webscraper.Filters
{
    public class BlockFilter : Filter
    {

        public static BlockFilter INSTANCE = new BlockFilter(null);
        public static BlockFilter INSTANCE_KEEP_TITLE = new BlockFilter(DefaultLabels.TITLE);
        private String labelToKeep;


        public static BlockFilter GetInstance()
        {
            return INSTANCE;
        }

        public BlockFilter(String labelToKeep)
        {
            this.labelToKeep = labelToKeep;
        }

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            bool hasChanges = false;

            Console.WriteLine("bloxk text blocks... " + textBlocks.Count);

            var it = textBlocks.GetEnumerator();
            //for (Iterator<TextBlock> it = textBlocks.iterator(); it.hasNext();)
            //while (it.MoveNext())
            //{
                //TextBlock tb = it.Current;
                //if (!it.Current.IsContent()
                //    && (labelToKeep == null || !it.Current.HasLabel(DefaultLabels.TITLE)))
                    foreach(TextBlock tb in textBlocks.ToList().Where(n => !n.IsContent()
                    //&& (labelToKeep == null || !n.HasLabel(DefaultLabels.TITLE))
                    ))
                {
                    textBlocks.Remove(tb);
                Console.WriteLine(textBlocks.Count);

                    hasChanges = true;
                }
            //}
            Console.WriteLine("bloxk text blocks... " + textBlocks.Count);
            Console.ReadLine();

            return hasChanges;
        }


    }

    public class InvertedFilter : Filter
    {
        public static InvertedFilter INSTANCE = new InvertedFilter();

        private InvertedFilter()
        {
        }

        public bool Process(TextDocument doc)
        {

            List<TextBlock> tbs = doc.GetTextBlocks();
            if (tbs.Any())
            {
                return false;
            }
            foreach (TextBlock tb in tbs)
            {
                tb.SetIsContent(!tb.IsContent());
            }

            return true;
        }



    }

    public class LabelToBoilerplateFilter : Filter
    {
        public static LabelToBoilerplateFilter INSTANCE_STRICTLY_NOT_CONTENT = new LabelToBoilerplateFilter(DefaultLabels.STRICTLY_NOT_CONTENT);

        private String[] labels;

        public LabelToBoilerplateFilter(params String[] label)
        {
            this.labels = label;
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (tb.IsContent())
                {
                    foreach (String label in labels)
                    {
                        if (tb.HasLabel(label))
                        {
                            tb.SetIsContent(false);
                            changes = true;
                            continue;
                        }
                    }
                }
            }

            return changes;
        }


    }

    public class LabelToContentFilter : Filter
    {
        private String[] labels;

        public LabelToContentFilter(params String[] label)
        {
            this.labels = label;
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {
                    foreach (String label in labels)
                    {
                        if (tb.HasLabel(label))
                        {
                            tb.SetIsContent(true);
                            changes = true;
                            continue;
                        }
                    }
                }
            }

            return changes;
        }


    }

    public class MarkEverythingBoilerplateFilter : Filter
    {
        public static MarkEverythingBoilerplateFilter INSTANCE = new MarkEverythingBoilerplateFilter();

        private MarkEverythingBoilerplateFilter()
        {
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (tb.IsContent())
                {
                    tb.SetIsContent(false);
                    changes = true;
                }
            }

            return changes;

        }



    }

    public class MarkEverythingContentFilter : Filter
    {
        public static MarkEverythingContentFilter INSTANCE = new MarkEverythingContentFilter();

        private MarkEverythingContentFilter()
        {
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {
                    tb.SetIsContent(true);
                    changes = true;
                }
            }

            return changes;

        }



    }

    public class MinClauseWordsFilter : Filter
    {
        public static MinClauseWordsFilter INSTANCE = new MinClauseWordsFilter(5, false);
        private int minWords;
        private bool acceptClausesWithoutDelimiter;

        public MinClauseWordsFilter(int minWords) : this(minWords, false)
        {

        }

        public MinClauseWordsFilter(int minWords, bool acceptClausesWithoutDelimiter)
        {
            this.minWords = minWords;
            this.acceptClausesWithoutDelimiter = acceptClausesWithoutDelimiter;
        }

        private Regex PAT_CLAUSE_DELIMITER = new Regex("[\\p{L}\\d][\\,\\.\\:\\;\\!\\?]+([ \\n\\r]+|$)");
        private Regex PAT_WHITESPACE = new Regex("[ \\n\\r]+");

        public bool Process(TextDocument doc)
        {

            bool changes = false;
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {
                    continue;
                }
                String text = tb.Text;

                Match m = PAT_CLAUSE_DELIMITER.Match(text);
                bool found = m.Success;
                int start = 0;
                int end;
                bool hasClause = false;
                while (found)
                {
                    end = m.Index + 1;
                    hasClause = isClause(text.Substring(start, end));
                    start = m.Length;

                    if (hasClause)
                    {
                        break;
                    }
                    found = m.Success;
                }
                end = text.Length;

                // since clauses should *always end* with a delimiter, we normally
                // don't consider text without one
                if (acceptClausesWithoutDelimiter)
                {
                    hasClause |= isClause(text.Substring(start, end));
                }

                if (!hasClause)
                {
                    tb.SetIsContent(false);
                    changes = true;
                    // System.err.println("IS NOT CONTENT: " + text);
                }
            }

            return changes;

        }

        private bool isClause(string text)
        {
            Match m = PAT_WHITESPACE.Match(text);
            int n = 1;
            while (m.Success)
            {
                n++;
                if (n >= minWords)
                {
                    return true;
                }
            }
            return n >= minWords;
        }




    }

    public class MinWordsFilter : Filter
    {
        private int minWords;

        public MinWordsFilter(int minWords)
        {
            this.minWords = minWords;
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {
                    continue;
                }
                if (tb.NumWords < minWords)
                {
                    tb.SetIsContent(false);
                    changes = true;
                }

            }

            return changes;

        }


    }

    public class SplitParagraphBlocksFilter : Filter
    {
        public static SplitParagraphBlocksFilter INSTANCE = new SplitParagraphBlocksFilter();

        public static SplitParagraphBlocksFilter getInstance()
        {
            return INSTANCE;
        }

        public bool Process(TextDocument doc)
        {
            bool changes = false;

            List<TextBlock> blocks = doc.GetTextBlocks();
            List<TextBlock> blocksNew = new List<TextBlock>();

            foreach (TextBlock tb in blocks)
            {
                String text = tb.Text;
                String[] paragraphs = text.Split(new string[] { "[\n\r]+" }, StringSplitOptions.None);
                if (paragraphs.Length < 2)
                {
                    blocksNew.Add(tb);
                    continue;
                }
                bool isContent = tb.IsContent();
                string[] labels = tb.Labels.ToArray();
                foreach (String p in paragraphs)
                {
                    TextBlock tbP = new TextBlock(p);
                    tbP.SetIsContent(isContent);
                    tbP.AddLabels(labels);
                    blocksNew.Add(tbP);
                    changes = true;
                }
            }

            if (changes)
            {
                blocks.Clear();
                blocks.Union(blocksNew);
            }

            return changes;
        }



    }

    public class SurroundingToContentFilter : Filter
    {

        public static SurroundingToContentFilter INSTANCE_TEXT = new SurroundingToContentFilter();


        public class Condit : TextBlockCondition
        {
            public bool meetsCondition(TextBlock tb)
            {
                return tb.LinkDensity == 0 && tb.NumWords > 6;
            }
            
        }

        public bool meetsCondition(TextBlock tb)
        {
            return tb.LinkDensity == 0 && tb.NumWords > 6;
        }

        //static TextBlock tb;
        private TextBlockCondition cond;

        public SurroundingToContentFilter()
        {
            Condit co = new Condit();

            this.cond = co;

        }

        public bool Process(TextDocument doc)
        {

            List<TextBlock> tbs = doc.GetTextBlocks();
            if (tbs.Count < 3)
            {
                return false;
            }

            TextBlock a = tbs.ElementAt(0);
            TextBlock b = tbs.ElementAt(1);
            TextBlock c;
            bool hasChanges = false;
            while (tbs.GetEnumerator().MoveNext())
            //for (Iterator<TextBlock> it = tbs.listIterator(2); it.hasNext();)
            {
                c = tbs.GetEnumerator().Current;
                if (!b.IsContent() && a.IsContent() && c.IsContent() && cond.meetsCondition(b))
                {
                    b.SetIsContent(true);
                    hasChanges = true;
                }

                a = c;
                if (!tbs.GetEnumerator().MoveNext())
                {
                    break;
                }
                b = c;
            }

            return hasChanges;
        }


    }

}
