﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Labels;
using System.IO;
using System.Text.RegularExpressions;
using Webscraper.Saxy;

namespace Webscraper.Filters
{

    class AddPrecedingLabelsFilter : Filter
    {
        public static AddPrecedingLabelsFilter INSTANCE = new AddPrecedingLabelsFilter("");
        public static AddPrecedingLabelsFilter INSTANCE_PRE = new AddPrecedingLabelsFilter("^");

        private string labelPrefix;


        public AddPrecedingLabelsFilter(string labelPrefix)
        {
            this.labelPrefix = labelPrefix;
        }

        public bool Process(TextDocument doc)
        {

            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }

            bool changes = false;

            int remaining = textBlocks.Count;

            TextBlock blockBelow = null;
            TextBlock block;

            var it = GetP.GetPrevious(textBlocks, textBlocks.Count);

            while(it.MoveNext())
            //for (ListIterator<TextBlock> it = textBlocks.listIterator(textBlocks.size()); it.hasPrevious();)
            {
                if (--remaining <= 0)
                {
                    break;
                }
                if (blockBelow == null)
                {
                    blockBelow = it.Current;
                    continue;
                }
                block = it.Current;

                HashSet<String> labels = block.Labels;
                if (labels != null && !labels.Any())
                {
                    foreach (String l in labels)
                    {
                        blockBelow.AddLabel(labelPrefix + l);
                    }
                    changes = true;
                }
                blockBelow = block;
            }

            return changes;
        }
    }
   
    public class ArticleMetadataFilter : Filter
    {
        private static Regex[] PATTERNS_SHORT = new Regex[]
        {
          new  Regex ("^[0-9 \\,\\./]*\\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)?\\b[0-9 \\,\\:apm\\./]*([CPSDMGET]{2,3})?$"),
          new Regex("^[Bb]y ")
        };

        public static ArticleMetadataFilter INSTANCE = new ArticleMetadataFilter();

        private ArticleMetadataFilter()
        {

        }

        public bool Process(TextDocument doc)
        {
            bool changed = false;
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (tb.NumWords > 10)
                {
                    continue;
                }

                string text = tb.Text;
                foreach (Regex p in PATTERNS_SHORT)
                {
                    if (p.Match(text).Success)
                    {
                        changed = true;
                        tb.SetIsContent(true);
                        tb.AddLabel(DefaultLabels.ARTICLE_METADATA);
                    }
                }
            }

            return changed;

        }


    }

    public class BlockProximityFusion : Filter
    {

        private int maxBlocksDistance;

        public static BlockProximityFusion MAX_DISTANCE_1 = new BlockProximityFusion(1, false, false);
        public static BlockProximityFusion MAX_DISTANCE_1_SAME_TAGLEVEL = new BlockProximityFusion(1, false, true);
        public static BlockProximityFusion MAX_DISTANCE_1_CONTENT_ONLY = new BlockProximityFusion(1, true, false);
        public static BlockProximityFusion MAX_DISTANCE_1_CONTENT_ONLY_SAME_TAGLEVEL = new BlockProximityFusion(1, true, true);

        private bool contentOnly;

        private bool sameTagLevelOnly;


        public BlockProximityFusion(int maxBlocksDistance, bool contentOnly, bool sameTagLevelOnly)
        {
            this.maxBlocksDistance = maxBlocksDistance;
            this.contentOnly = contentOnly;
            this.sameTagLevelOnly = sameTagLevelOnly;

        }

        public bool Process(TextDocument doc)
        {
            Console.WriteLine("Proximity ya know");
            Console.ReadLine();


            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }

            bool changes = false;
            TextBlock prevBlock;

            int offset;
            if (contentOnly)
            {
                prevBlock = null;
                offset = 0;
                foreach (TextBlock tb in textBlocks)
                {
                    offset++;
                    if (tb.IsContent())
                    {
                        prevBlock = tb;
                        break;
                    }
                }
                if (prevBlock == null)
                {
                    return false;
                }
            }
            else
            {
                prevBlock = textBlocks.ElementAt(0);
                offset = 1;
            }

            textBlocks.RemoveRange(0, offset);
            List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();

            foreach(TextBlock block in textBlocks.Skip(offset).ToList())
            { 
            //while (iTb.MoveNext())
            //{
            //    TextBlock block = iTb.Current;
                if (!block.IsContent())
                {
                    prevBlock = block;
                    continue;
                }
                int diffBlocks = block.OffsetBlocksStart - prevBlock.OffsetBlocksEnd - 1;
                if (diffBlocks <= maxBlocksDistance)
                {
                    bool ok = true;
                    if (contentOnly)
                    {
                        if (!prevBlock.IsContent() || !block.IsContent())
                        {
                            ok = false;
                        }
                    }
                    if (ok && sameTagLevelOnly && prevBlock.TagLevel != block.TagLevel)
                    {
                        ok = false;
                    }
                    if (ok)
                    {
                        prevBlock.MergeNext(block);
                        textBlocks.Remove(block);
                        changes = true;

                    }
                    else
                    {
                        prevBlock = block;
                    }
                }
                else
                {
                    prevBlock = block;
                }
            }

            return changes;
        }

    }

    public class ContentFusion : Filter
    {

        public static ContentFusion INSTANCE = new ContentFusion();


        public ContentFusion()
        {
        }

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }

            TextBlock prevBlock = textBlocks.ElementAt(0);

            bool changes = false;
            do
            {
                changes = false;

                //textBlocks.RemoveRange(0, offset);
                List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();


                while (iTb.MoveNext())
                {
                    TextBlock block = iTb.Current;

                    if (prevBlock.IsContent() && block.LinkDensity < 0.56
                        && !block.HasLabel(DefaultLabels.STRICTLY_NOT_CONTENT))
                    {

                        prevBlock.MergeNext(block);
                        textBlocks.RemoveAt(0);
                        changes = true;
                    }
                    else
                    {
                        prevBlock = block;
                    }
                }
            } while (changes);

            return true;
        }


    }

    public class DocumentTitleMatchClassifier : Filter
    {
        private HashSet<String> potentialTitles;

        public DocumentTitleMatchClassifier(String title)
        {
            if (title == null)
            {
                this.potentialTitles = null;
            }
            else
            {

                title = title.Replace('\u00a0', ' ');
                title = title.Replace("'", "");

                title = title.Trim().ToLower();

                if (title.Length == 0)
                {
                    this.potentialTitles = null;
                }
                else
                {
                    this.potentialTitles = new HashSet<String>();

                    potentialTitles.Add(title);

                    String p;

                    p = GetLongestPart(title, "[ ]*[\\|»|-][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }
                    p = GetLongestPart(title, "[ ]*[\\|»|:][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }
                    p = GetLongestPart(title, "[ ]*[\\|»|:\\(\\)][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }
                    p = GetLongestPart(title, "[ ]*[\\|»|:\\(\\)\\-][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }
                    p = GetLongestPart(title, "[ ]*[\\|»|,|:\\(\\)\\-][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }
                    p = GetLongestPart(title, "[ ]*[\\|»|,|:\\(\\)\\-\u00a0][ ]*");
                    if (p != null)
                    {
                        potentialTitles.Add(p);
                    }

                    AddPotentialTitles(potentialTitles, title, "[ ]+[\\|][ ]+", 4);
                    AddPotentialTitles(potentialTitles, title, "[ ]+[\\-][ ]+", 4);

                    potentialTitles.Add(Regex.Replace(title, " - [^\\-]+$", ""));
                    potentialTitles.Add(Regex.Replace(title, "^[^\\-]+ - ", ""));
                }
            }
        }

        public HashSet<String> GetPotentialTitles()
        {
            return potentialTitles;
        }

        private void AddPotentialTitles(HashSet<String> potentialTitles, String title, String pattern, int minWords)
        {
            String[] parts = title.Split(new string[] { pattern }, StringSplitOptions.None);
            if (parts.Length == 1)
            {
                return;
            }
            for (int i = 0; i < parts.Length; i++)
            {
                String p = parts[i];
                if (p.Contains(".com"))
                {
                    continue;
                }
                int numWords = Regex.Split(p, "[\b ]+").Length;
                if (numWords >= minWords)
                {
                    potentialTitles.Add(p);
                }
            }
        }

        private String GetLongestPart(String title, String pattern)
        {
            String[] parts = title.Split(new string[] { pattern }, StringSplitOptions.None);
            if (parts.Length == 1)
            {
                return null;
            }
            int longestNumWords = 0;
            String longestPart = "";
            for (int i = 0; i < parts.Length; i++)
            {
                String p = parts[i];
                if (p.Contains(".com"))
                {
                    continue;
                }
                int numWords = Regex.Split(p, "[\b ]+").Length;
                if (numWords > longestNumWords || p.Length > longestPart.Length)
                {
                    longestNumWords = numWords;
                    longestPart = p;
                }
            }
            if (longestPart.Length == 0)
            {
                return null;
            }
            else
            {
                return longestPart.Trim();
            }
        }

        private static Regex PAT_REMOVE_CHARACTERS = new Regex("[\\?\\!\\.\\-\\:]+");

        public bool Process(TextDocument doc)
        {
            if (potentialTitles == null)
            {
                return false;
            }
            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                String text = tb.Text;

                text = text.Replace('\u00a0', ' ');
                text = text.Replace("'", "");

                text = text.Trim().ToLower();

                if (potentialTitles.Contains(text))
                {
                    tb.AddLabel(DefaultLabels.TITLE);
                    changes = true;
                    break;
                }

                text = PAT_REMOVE_CHARACTERS.Match(text).Value.Trim();
                if (potentialTitles.Contains(text))
                {
                    tb.AddLabel(DefaultLabels.TITLE);
                    changes = true;
                    break;
                }
            }
            return changes;
        }





    }

    public class ExpandTitleToContentFilter : Filter
    {

        public static ExpandTitleToContentFilter INSTANCE = new ExpandTitleToContentFilter();


        public static ExpandTitleToContentFilter getInstance()
        {
            return INSTANCE;
        }

        public bool Process(TextDocument doc)
        {
            Console.WriteLine("ExpandTitleToContentFilter... Not empty = " + doc.GetTextBlocks().Where(n => n.IsContent() == true).Count());
            Console.ReadLine();
            int i = 0;
            int title = -1;
            int contentStart = -1;
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (contentStart == -1 && tb.HasLabel(DefaultLabels.TITLE))
                {
                    title = i;
                    contentStart = -1;
                }
                if (contentStart == -1 && tb.IsContent())
                {
                    contentStart = i;
                }

                i++;
            }

            if (contentStart <= title || title == -1)
            {
                return false;
            }
            bool changes = false;
            foreach (TextBlock tb in doc.GetTextBlocks().GetRange(title, contentStart))
            {
                if (tb.HasLabel(DefaultLabels.MIGHT_BE_CONTENT))
                {
                    changes = tb.SetIsContent(true) | changes;
                }
            }
            return changes;
        }


    }

    public class LabelFusion : Filter
    {

        public static LabelFusion INSTANCE = new LabelFusion();

        private LabelFusion()
        {
        }

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }

            bool changes = false;
            TextBlock prevBlock = textBlocks.ElementAt(0);
            int offset = 1;

            textBlocks.RemoveRange(0, offset);
            List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();
            while (iTb.MoveNext())
            {
                TextBlock block = iTb.Current;

                if (EqualLabels(prevBlock.Labels, block.Labels))
                {
                    prevBlock.MergeNext(block);
                    textBlocks.RemoveAt(0);
                    changes = true;
                }
                else
                {
                    prevBlock = block;
                }
            }

            return changes;
        }

        private bool EqualLabels(HashSet<String> labels, HashSet<String> labels2)
        {
            if (labels == null || labels2 == null)
            {
                return false;
            }
            return MarkupLabelsOnly(labels).Equals(MarkupLabelsOnly(labels2));
        }

        private HashSet<String> MarkupLabelsOnly(HashSet<String> set1)
        {
            HashSet<String> set = new HashSet<String>(set1);
            //for (Iterator<String> iTb = set.iterator(); it.hasNext();)

            //textBlocks.RemoveRange(0, offset);
            HashSet<string>.Enumerator iTb = set.GetEnumerator();
            while (iTb.MoveNext())
            {
                String label = iTb.Current;
                if (!label.StartsWith(DefaultLabels.MARKUP_PREFIX))
                {
                    set.Remove(label);
                }
            }
            return set;
        }

    }

    public class LargeBlockSameTagLevelToContentFilter : Filter
    {

        public static LargeBlockSameTagLevelToContentFilter INSTANCE = new LargeBlockSameTagLevelToContentFilter();

        private LargeBlockSameTagLevelToContentFilter()
        {
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            int tagLevel = -1;
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (tb.IsContent() && tb.HasLabel(DefaultLabels.VERY_LIKELY_CONTENT))
                {
                    tagLevel = tb.TagLevel;
                    break;
                }
            }

            if (tagLevel == -1)
            {
                return false;
            }

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {

                    if (tb.NumWords >= 100 && tb.TagLevel == tagLevel)
                    {
                        tb.SetIsContent(true);
                        changes = true;
                    }
                }
            }

            return changes;

        }



    }

    public class ListAtEndFilter : Filter
    {

        public static ListAtEndFilter INSTANCE = new ListAtEndFilter();

        private ListAtEndFilter()
        {
        }

        public bool Process(TextDocument doc)
        {

            bool changes = false;

            int tagLevel = int.MaxValue;
            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (tb.IsContent() && tb.HasLabel(DefaultLabels.VERY_LIKELY_CONTENT))
                {
                    tagLevel = tb.TagLevel;
                }
                else
                {
                    if (tb.TagLevel > tagLevel && tb.HasLabel(DefaultLabels.MIGHT_BE_CONTENT)
                        && tb.HasLabel(DefaultLabels.LI) && tb.LinkDensity == 0)
                    {
                        tb.SetIsContent(true);
                        changes = true;
                    }
                    else
                    {
                        tagLevel = int.MaxValue;
                    }
                }
            }
            Console.WriteLine("ListAtEndFilter... Not empty = " + doc.GetTextBlocks().Where(n => n.IsContent() == true).Count());
            Console.ReadLine();
            return changes;

        }

    }

    public class SimpleBlockFusionProcessor : Filter
    {

        public static SimpleBlockFusionProcessor INSTANCE = new SimpleBlockFusionProcessor();


        public static SimpleBlockFusionProcessor getInstance()
        {
            return INSTANCE;
        }

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            bool changes = false;

            if (textBlocks.Count < 2)
            {
                return false;
            }

            TextBlock b1 = textBlocks.ElementAt(0);
            //for (Iterator<TextBlock> it = textBlocks.listIterator(1); it.hasNext();)


            //textBlocks.RemoveRange(0, 1);
            List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();

            while (iTb.MoveNext())
            {
                TextBlock b2 = iTb.Current;

                bool similar = (b1.TextDensity == b2.TextDensity);

                if (similar)
                {
                    b1.MergeNext(b2);
                    textBlocks.RemoveAt(0);
                    changes = true;
                }
                else
                {
                    b1 = b2;
                }
            }

            return changes;
        }


    }

    public class TrailingHeadlineToFilter : Filter
    {

        public static TrailingHeadlineToFilter INSTANCE = new TrailingHeadlineToFilter();


        public static TrailingHeadlineToFilter getInstance()
        {
            return INSTANCE;
        }

        public bool Process(TextDocument doc)
        {
            bool changes = false;

            List<TextBlock> list = doc.GetTextBlocks();

            var it = GetP.GetPrevious(list, list.Count);
            //for (ListIterator<TextBlock> it = list.listIterator(list.size()); it.hasPrevious();) {
            while (it.MoveNext())
            {
                TextBlock tb = it.Current;
                if (tb.IsContent())
                {
                    if (tb.HasLabel(DefaultLabels.HEADING))
                    {
                        tb.SetIsContent(false);
                        changes = true;
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return changes;
        }



    } 

    public class KeepLargestBlockFilter : Filter
    {
        public static KeepLargestBlockFilter INSTANCE = new KeepLargestBlockFilter(false, 0);
        public static KeepLargestBlockFilter INSTANCE_EXPAND_TO_SAME_TAGLEVEL = new KeepLargestBlockFilter(true, 0);
        public static KeepLargestBlockFilter INSTANCE_EXPAND_TO_SAME_TAGLEVEL_MIN_WORDS = new KeepLargestBlockFilter(true, 150);

        private bool expandToSameLevelText;
        private int minWords;

        public KeepLargestBlockFilter(bool expandToSameLevelText, int minWords)
        {
            this.expandToSameLevelText = expandToSameLevelText;
            this.minWords = minWords;
        }


        public bool Process(TextDocument doc)
        {
            Console.WriteLine("Surest boy");
            Console.WriteLine("Surest block...... " + doc.GetTextBlocks().Count);
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }
            Console.WriteLine("Surest man");
            int maxNumWords = -1;
            TextBlock largestBlock = null;

            int level = -1;

            int i = 0;
            int n = -1;


            foreach (TextBlock tb in textBlocks)
            {
                if (tb.IsContent())
                {
                    int nw = tb.NumWords;

                    if (nw > maxNumWords)
                    {
                        largestBlock = tb;
                        maxNumWords = nw;

                        n = i;

                        if (expandToSameLevelText)
                        {
                            level = tb.TagLevel;
                        }

                    }
                }
                i++;
            }

            foreach (TextBlock tb in textBlocks)
            {
                if (tb == largestBlock)
                {
                    tb.SetIsContent(true);
                    tb.AddLabel(DefaultLabels.VERY_LIKELY_CONTENT);
                }
                else
                {
                    tb.SetIsContent(false);
                    tb.AddLabel(DefaultLabels.MIGHT_BE_CONTENT);
                }

            }

            if (expandToSameLevelText && n != -1)
            {

                //var it = GetP.GetPrevious(textBlocks, n);
                foreach(TextBlock tb in textBlocks.Skip(n).Reverse())

                //while(it.MoveNext())
                //for (ListIterator<TextBlock> it = textBlocks.listIterator(n); it.hasPrevious();)
                {
                    //TextBlock tb = it.Current;
                    int tl = tb.TagLevel;
                    if (tl < level)
                    {
                        break;
                    }
                    else if (tl == level)
                    {
                        if (tb.NumWords >= minWords)
                        {
                            tb.SetIsContent(true);
                        }
                    }
                }

                //var it2 = textBlocks.GetRange(0,n).GetEnumerator();
                foreach(TextBlock tb in textBlocks.Skip(n))
                //while(it2.MoveNext())
                //for (ListIterator<TextBlock> it = textBlocks.listIterator(n); it.hasNext();)
                {
                    //TextBlock tb = it.Current;
                     int tl = tb.TagLevel;
                    if (tl < level)
                    {
                        break;
                    }
                    else if (tl == level)
                    {
                        if (tb.NumWords >= minWords)
                        {
                            tb.SetIsContent(true);
                        }
                    }
                }
            }
            

            return true;
        }
    } 



}
