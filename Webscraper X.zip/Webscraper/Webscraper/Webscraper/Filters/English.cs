﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Saxy;
using System.IO;

namespace Webscraper.Filters
{

    public interface Filter
    {
        bool Process(TextDocument doc);
    }

    public class PrintDebugFilter : Filter
    {
        static MemoryStream ms = new MemoryStream();

        public static PrintDebugFilter INSTANCE = new PrintDebugFilter(new StreamWriter(ms));

        private StreamWriter output;


        public static PrintDebugFilter GetInstance()
        {
            return INSTANCE;
        }

        public PrintDebugFilter(StreamWriter output)
        {
            this.output = output;
        }

        public bool Process(TextDocument doc)
        {
            output.WriteLine(doc.DebugString());

            return false;
        }



    }

    public class DensityRulesClassifier : Filter
    {

        public static DensityRulesClassifier INSTANCE = new DensityRulesClassifier();


        public static DensityRulesClassifier GetInstance()
        {
            return INSTANCE;
        }


        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            bool hasChanges = false;

            List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();

            if (!iTb.MoveNext())
            {
                return false;
            }

            TextBlock prevBlock = TextBlock.EMPTY_START;
            TextBlock currentBlock = iTb.Current;
            TextBlock nextBlock = iTb.MoveNext() ? iTb.Current : TextBlock.EMPTY_START;

            hasChanges = Classify(prevBlock, currentBlock, nextBlock) | hasChanges;

            if (nextBlock != TextBlock.EMPTY_START)
            {
                while (iTb.MoveNext())
                {
                    prevBlock = currentBlock;
                    currentBlock = nextBlock;
                    nextBlock = iTb.Current;
                    hasChanges = Classify(prevBlock, currentBlock, nextBlock) | hasChanges;
                }
                prevBlock = currentBlock;
                currentBlock = nextBlock;
                nextBlock = iTb.Current;
                hasChanges = Classify(prevBlock, currentBlock, nextBlock) | hasChanges;
            }

            return hasChanges;
        }


        protected bool Classify(TextBlock previous, TextBlock current, TextBlock next)
        {
            bool isContent;

            if (current.LinkDensity <= 0.333333)
            {
                if (previous.LinkDensity <= 0.555556)
                {
                    if (current.TextDensity <= 9)
                    {
                        if (next.TextDensity <= 10)
                        {
                            if (previous.TextDensity <= 4)
                            {
                                isContent = false;
                            }
                            else
                            {
                                isContent = true;
                            }
                        }
                        else
                        {
                            isContent = true;
                        }
                    }
                    else
                    {
                        if (next.TextDensity == 0)
                        {
                            isContent = false;
                        }
                        else
                        {
                            isContent = true;
                        }
                    }
                }
                else
                {
                    if (next.TextDensity <= 11)
                    {
                        isContent = false;
                    }
                    else
                    {
                        isContent = true;
                    }
                }
            }
            else
            {
                isContent = false;
            }

            return current.SetIsContent(isContent);


        }

    }

    abstract class HeuristicFilterBase
    {
        protected static int GetNumFullTextWords(TextBlock tb)
        {
            return GetNumFullTextWords(tb, 9);
        }

        protected static int GetNumFullTextWords(TextBlock tb, float minTextDensity)
        {
            if (tb.TextDensity >= minTextDensity)
            {
                return tb.NumWords;
            }
            else
            {
                return 0;
            }
        }


    }

    class IgnoreBlocksAfterContentFilter : HeuristicFilterBase
    {

        public static IgnoreBlocksAfterContentFilter DEFAULT_INSTANCE = new IgnoreBlocksAfterContentFilter(60);

        public static IgnoreBlocksAfterContentFilter INSTANCE_200 = new IgnoreBlocksAfterContentFilter(200);

        private int minNumWords;


        public static IgnoreBlocksAfterContentFilter GetDefaultInstance()
        {
            return DEFAULT_INSTANCE;
        }

        public IgnoreBlocksAfterContentFilter(int minNumWords)
        {
            this.minNumWords = minNumWords;
        }

        public bool Process(TextDocument doc)
        {

            Console.WriteLine("IgnoreBlocksAfterContentFilter... Not empty = " + doc.GetTextBlocks().Where(n => n.IsContent() == true).Count());
            Console.ReadLine();
            bool changes = false;

            int numWords = 0;
            bool foundEndOfText = false;
            var iTb = doc.GetTextBlocks().GetEnumerator();

            while (iTb.MoveNext())
            {
                TextBlock tb = iTb.Current;

                bool endOfText = tb.HasLabel(DefaultLabels.INDICATES_END_OF_TEXT);
                if (tb.IsContent())
                {
                    numWords += GetNumFullTextWords(tb);
                }
                if (endOfText && numWords >= minNumWords)
                {
                    foundEndOfText = true;
                }
                if (foundEndOfText)
                {
                    changes = true;
                    tb.SetIsContent(false);
                }
            }

            return changes;

        }

    }

    class IgnoreBlocksAfterContentFromEndFilter : HeuristicFilterBase, Filter
    {

        public static IgnoreBlocksAfterContentFromEndFilter INSTANCE = new IgnoreBlocksAfterContentFromEndFilter();

        private IgnoreBlocksAfterContentFromEndFilter()
        {

        }

        public bool Process(TextDocument doc)
        {
            bool changes = false;

            int words = 0;

            List<TextBlock> blocks = doc.GetTextBlocks();
            if (!blocks.Any())
            {
                var it = GetP.GetPrevious(blocks, blocks.Count);
                TextBlock tb;

                while(it.MoveNext())
                {
                    tb = it.Current;
                    if (tb.HasLabel(DefaultLabels.INDICATES_END_OF_TEXT))
                    {
                        tb.AddLabel(DefaultLabels.STRICTLY_NOT_CONTENT);
                        tb.RemoveLabel(DefaultLabels.MIGHT_BE_CONTENT);
                        tb.SetIsContent(false);
                        changes = true;
                    }
                    else if (tb.IsContent())
                    {
                        words += tb.NumWords;
                        if (words > 200)
                        {
                            break;
                        }
                    }

                }
            }


            return changes;
        }

    } 

    class KeepLargestFulltextBlockFilter : HeuristicFilterBase, Filter
    {
        public static KeepLargestFulltextBlockFilter INSTANCE = new KeepLargestFulltextBlockFilter();

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            if (textBlocks.Count < 2)
            {
                return false;
            }

            int max = -1;
            TextBlock largestBlock = null;
            foreach (TextBlock tb in textBlocks)
            {
                if (!tb.IsContent())
                {
                    continue;
                }
                int numWords = GetNumFullTextWords(tb);
                if (numWords > max)
                {
                    largestBlock = tb;
                    max = numWords;
                }
            }

            if (largestBlock == null)
            {
                return false;
            }

            foreach (TextBlock tb in textBlocks)
            {
                if (tb == largestBlock)
                {
                    tb.SetIsContent(true);
                }
                else
                {
                    tb.SetIsContent(false);
                    tb.AddLabel(DefaultLabels.MIGHT_BE_CONTENT);
                }
            }

            return true;
        }


    }

    class MinFullTextWordsFilter : HeuristicFilterBase, Filter
    {
        public static MinFullTextWordsFilter DEFAULT_INSTANCE = new MinFullTextWordsFilter(30);
        private int minWords;

        public static MinFullTextWordsFilter GeDefaultInstance()
        {
            return DEFAULT_INSTANCE;
        }


        public MinFullTextWordsFilter(int minWords)
        {
            this.minWords = minWords;
        }

        public bool Process(TextDocument doc)
        {
            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                if (!tb.IsContent())
                {
                    continue;
                }
                if (GetNumFullTextWords(tb) < minWords)
                {
                    tb.SetIsContent(false);
                    changes = true;
                }
            }

            return changes;
        }


    }

    class NumWordsRulesClassifier : Filter
    {
        public static NumWordsRulesClassifier INSTANCE = new NumWordsRulesClassifier();

        public static NumWordsRulesClassifier GetInstance()
        {
            return INSTANCE;
        }

        public bool Process(TextDocument doc)
        {
            List<TextBlock> textBlocks = doc.GetTextBlocks();
            Console.WriteLine("NumWordsRulesClassifier..." + textBlocks.Count);

            Console.ReadLine();

            bool hasChanges = false;

            List<TextBlock>.Enumerator iTb = textBlocks.GetEnumerator();

            if (!iTb.MoveNext())
            {
                Console.WriteLine("NumWordsRulesClassifier... false" + textBlocks.Count);
                Console.ReadLine();

                return false;
            }

            TextBlock previousBlock = TextBlock.EMPTY_START;
            TextBlock currentBlock = iTb.Current;
            TextBlock nextBlock = iTb.MoveNext() ? iTb.Current : TextBlock.EMPTY_START;

            hasChanges = Classify(previousBlock, currentBlock, nextBlock);

            if (nextBlock != TextBlock.EMPTY_START)
            {
                Console.WriteLine("NumWordsRulesClassifier... Not empty" + textBlocks.Count);
                Console.ReadLine();

                while (iTb.MoveNext())
                {
                    previousBlock = currentBlock;
                    currentBlock = nextBlock;
                    nextBlock = iTb.Current;
                    hasChanges = Classify(previousBlock, currentBlock, nextBlock) | hasChanges;

                }

                previousBlock = currentBlock;
                currentBlock = nextBlock;
                nextBlock = TextBlock.EMPTY_START;
                hasChanges = Classify(previousBlock, currentBlock, nextBlock) | hasChanges;
            }
            Console.WriteLine("NumWordsRulesClassifier... Not empty = " + textBlocks.Where(n => n.IsContent() == true).Count());
            Console.ReadLine();
            return hasChanges;
        }



        protected bool Classify(TextBlock previous, TextBlock current, TextBlock next)
        {
            bool isContent;

            if (current.LinkDensity <= 0.333333)
            {
                if (previous.LinkDensity <= 0.555556)
                {
                    if (current.NumWords <= 16)
                    {
                        if (next.NumWords <= 15)
                        {
                            if (previous.NumWords <= 4)
                            {
                                isContent = false;
                            }
                            else
                            {
                                isContent = true;
                            }
                        }
                        else
                        {
                            isContent = true;
                        }
                    }
                    else
                    {
                        isContent = true;
                    }
                }
                else
                {
                    if (current.NumWords <= 40)
                    {
                        if (next.NumWords <= 17)
                        {
                            isContent = false;
                        }
                        else
                        {
                            isContent = true;
                        }

                    }
                    else
                    {
                        isContent = true;
                    }
                }
            }
            else
            {
                isContent = false;
            }
            Console.WriteLine("\nText - " + current.Text + "\nLinkDensity - " + current.LinkDensity + "\nTextDensity - " + current.TextDensity);

            return current.SetIsContent(isContent);
        }

    }

    class TerminatingBlocksFinder : Filter
    {
        public static TerminatingBlocksFinder INSTANCE = new TerminatingBlocksFinder();


        public static TerminatingBlocksFinder GetInstance()
        {
            return INSTANCE;
        }


        public bool Process(TextDocument doc)
        {
            Console.WriteLine("TerminatingBlocksFinder.." + doc.GetTextBlocks().Count);
            Console.ReadLine();

            bool changes = false;

            foreach (TextBlock tb in doc.GetTextBlocks())
            {
                int numWords = tb.NumWords;
                if (numWords < 15)
                {
                    string text = tb.Text.Trim();
                    int len = text.Length;
                    if (len >= 0)
                    {
                        string textLC = text.ToLower();
                        if (textLC.StartsWith("comments")
                            || StartsWithNumber(textLC, len, " comments", " users responded in")
              || textLC.StartsWith("© reuters") || textLC.StartsWith("please rate this")
              || textLC.StartsWith("post a comment") || textLC.Contains("what you think...")
              || textLC.Contains("add your comment") || textLC.Contains("add comment")
              || textLC.Contains("reader views") || textLC.Contains("have your say")
              || textLC.Contains("reader comments") || textLC.Contains("rätta artikeln")
              || textLC.Equals("thanks for your comments - this feedback is now closed"))
                        {
                            tb.AddLabel(DefaultLabels.INDICATES_END_OF_TEXT);
                            changes = true;
                        }
                    }
                    else if (tb.LinkDensity == 1.0)
                    {
                        if (text.Equals("Comment"))
                        {
                            tb.AddLabel(DefaultLabels.INDICATES_END_OF_TEXT);
                        }
                    }
                }
            }

            return changes;

        }


        private static bool StartsWithNumber(string t, int len, params string[] str)
        {
            int j = 0;
            while (j < len && isDigit(t.ToCharArray()[j]))
            {
                j++;
            }
            if(j != 0)
            {
                foreach(string s in str)
                {
                    if(t.Substring(j).StartsWith(s))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool isDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

    }
}
