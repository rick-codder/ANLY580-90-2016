﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Exception;
using TagSoup.Net;

namespace Webscraper.Saxy
{
    public class UnicodeTokenizer
    {
        private static Regex PAT_WORD_BOUNDARY = new Regex("\\b");
        private static Regex PAT_NOT_WORD_BOUNDARY = new Regex("[\u2063]*([\\\"'\\.,\\!\\@\\-\\:\\;\\$\\?\\(\\)/])[\u2063]*");

        /**
         * Tokenizes the text and returns an array of tokens.
         * 
         * @param text The text
         * @return The tokens
         */
        public static String[] tokenize(string text)
        {

            return Regex.Split(
         Regex.Replace(
           PAT_NOT_WORD_BOUNDARY.Replace(PAT_WORD_BOUNDARY.Replace(text.ToString(), "\u2063"), "$1"), "[ \u2063]+", " "
         ).Trim(), "[ ]+");

            //return PAT_NOT_WORD_BOUNDARY.Match(PAT_WORD_BOUNDARY.Match(text).Result("\u2063"))
            //    .Result("$1").Replace("[ \u2063]+", " ").Trim()
            //    .Split(new string[] { "[ ]+" },StringSplitOptions.None);

        }

    }

    public class GetP
    {
        List<Type> ls = new List<Type>();


        public static List<TextBlock>.Enumerator GetPrevious(List<TextBlock> ls, int index)
        {
            var lsext = ls.GetRange(0, index);
            lsext.Reverse();
            return lsext.GetEnumerator();
        }



    }

}
