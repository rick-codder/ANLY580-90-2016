﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Labels;

namespace Webscraper.Estimators
{

    public class SimpleEstimator
    {

        public static SimpleEstimator INSTANCE = new SimpleEstimator();

        private SimpleEstimator()
        {
        }

        public bool IsLowQuality(TextDocumentStatistics dsBefore, TextDocumentStatistics dsAfter)
        {
            if (dsBefore.GetNumWords() < 90 || dsAfter.GetNumWords() < 70)
            {
                return true;
            }

            if (dsAfter.AvgNumWords() < 25)
            {
                return true;
            }

            return false;
        }

    }




}



