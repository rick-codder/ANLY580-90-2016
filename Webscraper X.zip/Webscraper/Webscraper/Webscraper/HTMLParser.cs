﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax.Net.Helpers;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Exception;
using TagSoup.Net;
using HtmlAgilityPack;
using Sax.Net.Ext;



namespace Webscraper.Saxy
{

    public class HTMLParser : HTMLContentHandler, IScanHandler, IXmlReader, ILexicalHandler
    {
        private const bool DEFAULT_NAMESPACES = true;
        private const bool DEFAULT_IGNORE_BOGONS = false;
        private const bool DEFAULT_BOGONS_EMPTY = false;
        private const bool DEFAULT_ROOT_BOGONS = true;
        private const bool DEFAULT_DEFAULT_ATTRIBUTES = true;
        private const bool DEFAULT_TRANSLATE_COLONS = false;
        private const bool DEFAULT_RESTART_ELEMENTS = true;
        private const bool DEFAULT_IGNORABLE_WHITESPACE = false;
        private const bool DEFAULT_CDATA_ELEMENTS = true;

        // Feature flags.

        /// <summary>
        ///   A value of "true" indicates namespace URIs and unprefixed local
        ///   names for element and attribute names will be available.
        /// </summary>
        public const string NAMESPACES_FEATURE = "http://xml.org/sax/features/namespaces";

        /// <summary>
        ///   A value of "true" indicates that XML qualified names (with prefixes)
        ///   and attributes (including xmlns* attributes) will be available.
        ///   We don't support this value.
        /// </summary>
        public const string NAMESPACE_PREFIXES_FEATURE = "http://xml.org/sax/features/namespace-prefixes";

        /// <summary>
        ///   Reports whether this parser processes external general entities
        ///   (it doe
        /// </summary>
        public const string EXTERNAL_GENERAL_ENTITIES_FEATURE = "http://xml.org/sax/features/external-general-entities";

        /// <summary>
        ///   Reports whether this parser processes external parameter entities
        ///   (it doesn't).
        /// </summary>
        public const string EXTERNAL_PARAMETER_ENTITIES_FEATURE = "http://xml.org/sax/features/external-parameter-entities";

        /// <summary>
        ///   May be examined only during a parse, after the startDocument()
        ///   callback has been completed; read-only. The value is true if
        ///   the document specified standalone="yes" in its XML declaration,
        ///   and otherwise is false.  (It's always false.)
        /// </summary>
        public const string IS_STANDALONE_FEATURE = "http://xml.org/sax/features/is-standalone";

        /// <summary>
        ///   A value of "true" indicates that the LexicalHandler will report
        ///   the beginning and end of parameter entities (it won't).
        /// </summary>
        public const string LEXICAL_HANDLER_PARAMETER_ENTITIES_FEATURE =
          "http://xml.org/sax/features/lexical-handler/parameter-entities";

        /// <summary>
        ///   A value of "true" indicates that system IDs in declarations will
        ///   be absolutized (relative to their base URIs) before reporting.
        ///   (This returns true but doesn't actually do anything.)
        /// </summary>
        public const string RESOLVE_DTD_URIS_FEATURE = "http://xml.org/sax/features/resolve-dtd-uris";

        /// <summary>
        ///   Has a value of "true" if all XML names (for elements,
        ///   prefixes, attributes, entities, notations, and local
        ///   names), as well as Namespace URIs, will have been interned
        ///   using <see cref="string.Intern" />. This supports fast testing of
        ///   equality/inequality against string constants, rather than forcing
        ///   slower calls to <see cref="string.Equals(object)" />.  (We always intern.)
        /// </summary>
        public const string STRING_INTERNING_FEATURE = "http://xml.org/sax/features/string-interning";

        /// <summary>
        ///   Returns "true" if the Attributes objects passed by this
        ///   parser in <see cref="IContentHandler.StartElement" /> implement the
        ///   <see cref="Sax.Net.Ext.IAttributes2" /> interface.	(They don't.)
        /// </summary>
        public const string USE_ATTRIBUTES2_FEATURE = "http://xml.org/sax/features/use-attributes2";

        /// <summary>
        ///   Returns "true" if the Locator objects passed by this parser
        ///   parser in <see cref="IContentHandler.SetDocumentLocator" /> implement the
        ///   <see cref="Sax.Net.Ext.ILocator2" /> interface.  (They don't.)
        /// </summary>
        public const string USE_LOCATOR2_FEATURE = "http://xml.org/sax/features/use-locator2";
        /// <summary>
        ///   Returns "true" if, when setEntityResolver is given an object
        ///   implementing the  <see cref="Sax.Net.Ext.IEntityResolver2" /> interface,
        ///   those new methods will be used.  (They won't be.)
        /// </summary>
        public const string USE_ENTITY_RESOLVER2_FEATURE = "http://xml.org/sax/features/use-entity-resolver2";

        /// <summary>
        ///   Controls whether the parser is reporting all validity errors
        ///   (We don't report any validity errors.)
        /// </summary>
        public const string VALIDATION_FEATURE = "http://xml.org/sax/features/validation";

        /// <summary>
        ///   Controls whether the parser reports Unicode normalization
        ///   errors as described in section 2.13 and Appendix B of the XML
        ///   1.1 Recommendation.  (We don't normalize.)
        /// </summary>
        public const string UNICODE_NORMALIZATION_CHECKING_FEATURE =
          "http://xml.org/sax/features/unicode-normalization-checking";

        /// <summary>
        ///   Controls whether, when the namespace-prefixes feature is set,
        ///   the parser treats namespace declaration attributes as being in
        ///   the http://www.w3.org/2000/xmlns/ namespace.  (It doesn't.)
        /// </summary>
        public const string XMLNS_URIS_FEATURE = "http://xml.org/sax/features/xmlns-uris";

        /// <summary>
        ///   Returns <c>true</c> if the parser supports both XML 1.1 and XML 1.0.
        ///   (Always <c>false</c>.)
        /// </summary>
        public const string XML11_FEATURE = "http://xml.org/sax/features/xml-1.1";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will ignore
        ///   unknown elements.
        /// </summary>
        public const string IGNORE_BOGONS_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/ignore-bogons";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will give unknown
        ///   elements a content model of EMPTY; a value of <c>false</c>, a
        ///   content model of ANY.
        /// </summary>
        public const string BOGONS_EMPTY_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/bogons-empty";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will allow unknown
        ///   elements to be the root element.
        /// </summary>
        public const string ROOT_BOGONS_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/root-bogons";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will return default
        ///   attribute values for missing attributes that have default values.
        /// </summary>
        public const string DEFAULT_ATTRIBUTES_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/default-attributes";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will
        ///   translate colons into underscores in names.
        /// </summary>
        public const string TRANSLATE_COLONS_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/translate-colons";

        /// <summary>
        ///   A value of <c>true</c> indicates that the parser will
        ///   attempt to restart the restartable elements.
        /// </summary>
        public const string RESTART_ELEMENTS_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/restart-elements";

        /// <summary>
        ///   A value of "true" indicates that the parser will
        ///   transmit whitespace in element-only content via the SAX
        ///   ignorableWhitespace callback.  Normally this is not done,
        ///   because HTML is an SGML application and SGML suppresses
        ///   such whitespace.
        /// </summary>
        public const string IGNORABLE_WHITESPACE_FEATURE =
          "http://www.ccil.org/~cowan/tagsoup/features/ignorable-whitespace";

        /// <summary>
        ///   A value of "true" indicates that the parser will treat CDATA
        ///   elements specially.  Normally true, since the input is by
        ///   default HTML.
        /// </summary>
        public const string CDATA_ELEMENTS_FEATURE = "http://www.ccil.org/~cowan/tagsoup/features/cdata-elements";

        /// <summary>
        ///   Used to see some syntax events that are essential in some
        ///   applications: comments, CDATA delimiters, selected general
        ///   entity inclusions, and the start and end of the DTD (and
        ///   declaration of document element name). The Object must implement
        ///   <see cref="ILexicalHandler" />
        /// </summary>
        public const string LEXICAL_HANDLER_PROPERTY = "http://xml.org/sax/properties/lexical-handler";

        /// <summary>
        ///   Specifies the Scanner object this Parser uses.
        /// </summary>
        public const string SCANNER_PROPERTY = "http://www.ccil.org/~cowan/tagsoup/properties/scanner";

        /// <summary>
        ///   Specifies the Schema object this Parser uses.
        /// </summary>
        public const string SCHEMA_PROPERTY = "http://www.ccil.org/~cowan/tagsoup/properties/schema";

        /// <summary>
        ///   Specifies the AutoDetector (for encoding detection) this Parser uses.
        /// </summary>
        public const string AUTO_DETECTOR_PROPERTY = "http://www.ccil.org/~cowan/tagsoup/properties/auto-detector";
        private const string LEGAL = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-'()+,./:=?;!*#@$_%";
        private static readonly char[] Etagchars = { '<', '/', '>' };

        // Due to sucky Java order of initialization issues, these
        // entries are maintained separately from the initial values of
        // the corresponding instance variables, but care must be taken
        // to keep them in sync.

        private readonly Hashtable _features = new Hashtable {
      { NAMESPACES_FEATURE, DEFAULT_NAMESPACES },
      { NAMESPACE_PREFIXES_FEATURE, false },
      { EXTERNAL_GENERAL_ENTITIES_FEATURE, false },
      { EXTERNAL_PARAMETER_ENTITIES_FEATURE, false },
      { IS_STANDALONE_FEATURE, false },
      { LEXICAL_HANDLER_PARAMETER_ENTITIES_FEATURE, false },
      { RESOLVE_DTD_URIS_FEATURE, true },
      { STRING_INTERNING_FEATURE, true },
      { USE_ATTRIBUTES2_FEATURE, false },
      { USE_LOCATOR2_FEATURE, false },
      { USE_ENTITY_RESOLVER2_FEATURE, false },
      { VALIDATION_FEATURE, false },
      { XMLNS_URIS_FEATURE, false },
      { XML11_FEATURE, false },
      { IGNORE_BOGONS_FEATURE, DEFAULT_IGNORE_BOGONS },
      { BOGONS_EMPTY_FEATURE, DEFAULT_BOGONS_EMPTY },
      { ROOT_BOGONS_FEATURE, DEFAULT_ROOT_BOGONS },
      { DEFAULT_ATTRIBUTES_FEATURE, DEFAULT_DEFAULT_ATTRIBUTES },
      { TRANSLATE_COLONS_FEATURE, DEFAULT_TRANSLATE_COLONS },
      { RESTART_ELEMENTS_FEATURE, DEFAULT_RESTART_ELEMENTS },
      { IGNORABLE_WHITESPACE_FEATURE, DEFAULT_IGNORABLE_WHITESPACE },
      { CDATA_ELEMENTS_FEATURE, DEFAULT_CDATA_ELEMENTS },
    };
        private string _attributeName;
        private IAutoDetector _autoDetector;
        private bool _bogonsEmpty = DEFAULT_BOGONS_EMPTY;
        private bool _cdataElements = DEFAULT_CDATA_ELEMENTS;
        private IContentHandler _contentHandler;
        private bool _defaultAttributes = DEFAULT_DEFAULT_ATTRIBUTES;
        private bool _doctypeIsPresent;
        private string _doctypeName;
        private string _doctypePublicId;
        private string _doctypeSystemId;
        private IDTDHandler _dtdHandler;
        private int _entity; // needs to support chars past U+FFFF
        private IEntityResolver _entityResolver;
        private IErrorHandler _errorHandler;
        private bool _ignorableWhitespace = DEFAULT_IGNORABLE_WHITESPACE;
        private bool _ignoreBogons = DEFAULT_IGNORE_BOGONS;
        private ILexicalHandler _lexicalHandler;
        private bool _namespaces = DEFAULT_NAMESPACES;
        private Element _newElement;
        private Element _pcdata;
        private string _piTarget;
        private bool _restartElements = DEFAULT_RESTART_ELEMENTS;
        private bool _rootBogons = DEFAULT_ROOT_BOGONS;
        private Element _saved;
        private IScanner _scanner;
        private Schema _schema;
        private Element _stack;
        private char[] _theCommentBuffer = new char[2000];
        private bool _translateColons = DEFAULT_TRANSLATE_COLONS;
        private bool _virginStack = true;

        /// <summary>
        ///   Creates a new instance of <see cref="Parser" />
        /// </summary>
        public HTMLParser()
        {
            Console.WriteLine("double pack back");

            _newElement = null;
            _contentHandler = new HTMLContentHandler();
            _lexicalHandler = this;
            _dtdHandler = this;
            _errorHandler = this;
            _entityResolver = this;
        }

        public void Comment(char[] ch, int start, int length)
        {
        }

        public void EndCDATA()
        {
        }

        public void EndDTD()
        {
        }

        public void EndEntity(string name)
        {
        }

        public void StartCDATA()
        {
        }

        public void StartDTD(string name, string publicid, string systemid)
        {
        }

        public void StartEntity(string name)
        {
        }

        public void Adup(char[] buff, int offset, int length)
        {
            if (_newElement == null || _attributeName == null)
            {
                return;
            }
            _newElement.SetAttribute(_attributeName, null, _attributeName);
            _attributeName = null;
        }

        public void Aname(char[] buff, int offset, int length)
        {
            if (_newElement == null)
            {
                return;
            }
            // Currently we don't rely on Schema to canonicalize
            // attribute names.
            _attributeName = MakeName(buff, offset, length).ToLowerInvariant();
            //		System.err.println("%% Attribute name " + theAttributeName);
        }

        public void Aval(char[] buff, int offset, int length)
        {
            if (_newElement == null || _attributeName == null)
            {
                return;
            }
            var value = new string(buff, offset, length);
            //		System.err.println("%% Attribute value [" + value + "]");
            value = ExpandEntities(value);
            _newElement.SetAttribute(_attributeName, null, value);
            _attributeName = null;
            //		System.err.println("%% Aval done");
        }

        public void Entity(char[] buff, int offset, int length)
        {
            _entity = LookupEntity(buff, offset, length);
        }

        public void EOF(char[] buff, int offset, int length)
        {
            if (_virginStack)
            {
                Rectify(_pcdata);
            }
            while (_stack.Next != null)
            {
                Pop();
            }
            if (!(_schema.Uri.Equals("")))
            {
                _contentHandler.EndPrefixMapping(_schema.Prefix);
            }
            _contentHandler.EndDocument();
        }

        public void ETag(char[] buff, int offset, int length)
        {
            if (ETagCdata(buff, offset, length))
            {
                return;
            }
            ETagBasic(buff, offset, length);
        }

        /// <summary>
        ///   Parsing the complete XML Document Type Definition is way too complex,
        ///   but for many simple cases we can extract something useful from it.
        ///   doctypedecl ::= '&lt;!DOCTYPE' S Name (S ExternalID)? S? ('[' intSubset ']' S?)? '>'
        ///   DeclSep ::= PEReference | S
        ///   intSubset ::= (markupdecl | DeclSep)*
        ///   markupdecl ::= elementdecl | AttlistDecl | EntityDecl | NotationDecl | PI | Comment
        ///   ExternalID ::= 'SYSTEM' S SystemLiteral | 'PUBLIC' S PubidLiteral S SystemLiteral
        /// </summary>
        /// <param name="buff"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        public void Decl(char[] buff, int offset, int length)
        {
            var s = new string(buff, offset, length);
            string name = null;
            string systemid = null;
            string publicid = null;
            string[] v = Split(s);
            if (v.Length > 0 && "DOCTYPE".Equals(v[0], StringComparison.OrdinalIgnoreCase))
            {
                if (_doctypeIsPresent)
                {
                    return; // one doctype only!
                }
                _doctypeIsPresent = true;
                if (v.Length > 1)
                {
                    name = v[1];
                    if (v.Length > 3 && "SYSTEM".Equals(v[2]))
                    {
                        systemid = v[3];
                    }
                    else if (v.Length > 3 && "PUBLIC".Equals(v[2]))
                    {
                        publicid = v[3];
                        if (v.Length > 4)
                        {
                            systemid = v[4];
                        }
                        else
                        {
                            systemid = "";
                        }
                    }
                }
            }
            publicid = TrimQuotes(publicid);
            systemid = TrimQuotes(systemid);
            if (name != null)
            {
                publicid = CleanPublicid(publicid);
                _lexicalHandler.StartDTD(name, publicid, systemid);
                _lexicalHandler.EndDTD();
                _doctypeName = name;
                _doctypePublicId = publicid;
                var locator = _scanner as ILocator;
                if (locator != null)
                {
                    // Must resolve systemid
                    _doctypeSystemId = locator.SystemId;
                    try
                    {
                        if (Uri.IsWellFormedUriString(_doctypeSystemId, UriKind.Absolute))
                        {
                            _doctypeSystemId = new Uri(new Uri(_doctypeSystemId), systemid).ToString();
                        }
                    }
                    catch (System.Exception e)
                    {
                    }
                }
            }
        }

        public void GI(char[] buff, int offset, int length)
        {
            if (_newElement != null)
            {
                return;
            }
            string name = MakeName(buff, offset, length);
            if (name == null)
            {
                return;
            }
            ElementType type = _schema.GetElementType(name);
            if (type == null)
            {
                // Suppress unknown elements if ignore-bogons is on
                if (_ignoreBogons)
                {
                    return;
                }
                int bogonModel = (_bogonsEmpty ? Schema.M_EMPTY : Schema.M_ANY);
                int bogonMemberOf = (_rootBogons ? Schema.M_ANY : (Schema.M_ANY & ~Schema.M_ROOT));
                _schema.ElementType(name, bogonModel, bogonMemberOf, 0);
                if (!_rootBogons)
                {
                    _schema.Parent(name, _schema.RootElementType.Name);
                }
                type = _schema.GetElementType(name);
            }

            _newElement = new Element(type, _defaultAttributes);
            //		System.err.println("%% Got GI " + theNewElement.name());
        }

        public void CDSect(char[] buff, int offset, int length)
        {
            _lexicalHandler.StartCDATA();
            PCDATA(buff, offset, length);
            _lexicalHandler.EndCDATA();
        }

        public void PCDATA(char[] buff, int offset, int length)
        {
            if (length == 0)
            {
                return;
            }
            bool allWhite = true;
            for (int i = 0; i < length; i++)
            {
                if (!char.IsWhiteSpace(buff[offset + i]))
                {
                    allWhite = false;
                }
            }
            if (allWhite && !_stack.CanContain(_pcdata))
            {
                if (_ignorableWhitespace)
                {
                    _contentHandler.IgnorableWhitespace(buff, offset, length);
                }
            }
            else
            {
                Rectify(_pcdata);
                _contentHandler.Characters(buff, offset, length);
            }
        }

        public void PITarget(char[] buff, int offset, int length)
        {
            if (_newElement != null)
            {
                return;
            }
            _piTarget = MakeName(buff, offset, length).Replace(':', '_');
        }

        public void PI(char[] buff, int offset, int length)
        {
            if (_newElement != null || _piTarget == null)
            {
                return;
            }
            if ("xml".Equals(_piTarget, StringComparison.OrdinalIgnoreCase))
            {
                return;
            }
            //		if (length > 0 && buff[length - 1] == '?') System.err.println("%% Removing ? from PI");
            if (length > 0 && buff[length - 1] == '?')
            {
                length--; // remove trailing ?
            }
            _contentHandler.ProcessingInstruction(_piTarget, new string(buff, offset, length));
            _piTarget = null;
        }

        public void STagc(char[] buff, int offset, int length)
        {
            //		System.err.println("%% Start-tag");
            if (_newElement == null)
            {
                return;
            }
            Rectify(_newElement);
            if (_stack.Model == Schema.M_EMPTY)
            {
                // Force an immediate end tag
                ETagBasic(buff, offset, length);
            }
        }

        public void STage(char[] buff, int offset, int length)
        {
            //		System.err.println("%% Empty-tag");
            if (_newElement == null)
            {
                return;
            }
            Rectify(_newElement);
            // Force an immediate end tag
            ETagBasic(buff, offset, length);
        }

        public void Cmnt(char[] buff, int offset, int length)
        {
            _lexicalHandler.Comment(buff, offset, length);
        }

        public int GetEntity()
        {
            return _entity;
        }

        public bool GetFeature(string name)
        {
            if (_features.ContainsKey(name))
            {
                return (bool)_features[name];
            }
            throw new SAXNotRecognizedException("Unknown feature " + name);
        }

        public void SetFeature(string name, bool value)
        {
            if (false == _features.ContainsKey(name))
            {
                throw new SAXNotRecognizedException("Unknown feature " + name);
            }
            _features[name] = value;

            if (name.Equals(NAMESPACES_FEATURE))
            {
                _namespaces = value;
            }
            else if (name.Equals(IGNORE_BOGONS_FEATURE))
            {
                _ignoreBogons = value;
            }
            else if (name.Equals(BOGONS_EMPTY_FEATURE))
            {
                _bogonsEmpty = value;
            }
            else if (name.Equals(ROOT_BOGONS_FEATURE))
            {
                _rootBogons = value;
            }
            else if (name.Equals(DEFAULT_ATTRIBUTES_FEATURE))
            {
                _defaultAttributes = value;
            }
            else if (name.Equals(TRANSLATE_COLONS_FEATURE))
            {
                _translateColons = value;
            }
            else if (name.Equals(RESTART_ELEMENTS_FEATURE))
            {
                _restartElements = value;
            }
            else if (name.Equals(IGNORABLE_WHITESPACE_FEATURE))
            {
                _ignorableWhitespace = value;
            }
            else if (name.Equals(CDATA_ELEMENTS_FEATURE))
            {
                _cdataElements = value;
            }
        }

        public object GetProperty(string name)
        {
            if (name.Equals(LEXICAL_HANDLER_PROPERTY))
            {
                return _lexicalHandler == this ? null : _lexicalHandler;
            }
            if (name.Equals(SCANNER_PROPERTY))
            {
                return _scanner;
            }
            if (name.Equals(SCHEMA_PROPERTY))
            {
                return _schema;
            }
            if (name.Equals(AUTO_DETECTOR_PROPERTY))
            {
                return _autoDetector;
            }
            throw new SAXNotRecognizedException("Unknown property " + name);
        }

        public void SetProperty(string name, object value)
        {
            if (name.Equals(LEXICAL_HANDLER_PROPERTY))
            {
                if (value == null)
                {
                    _lexicalHandler = this;
                }
                else
                {
                    var handler = value as ILexicalHandler;
                    if (handler != null)
                    {
                        _lexicalHandler = handler;
                    }
                    else
                    {
                        throw new SAXNotSupportedException("Your lexical handler is not a ILexicalHandler");
                    }
                }
            }
            else if (name.Equals(SCANNER_PROPERTY))
            {
                var scanner = value as IScanner;
                if (scanner != null)
                {
                    _scanner = scanner;
                }
                else
                {
                    throw new SAXNotSupportedException("Your scanner is not a IScanner");
                }
            }
            else if (name.Equals(SCHEMA_PROPERTY))
            {
                var schema = value as Schema;
                if (schema != null)
                {
                    _schema = schema;
                }
                else
                {
                    throw new SAXNotSupportedException("Your schema is not a Schema");
                }
            }
            else if (name.Equals(AUTO_DETECTOR_PROPERTY))
            {
                var detector = value as IAutoDetector;
                if (detector != null)
                {
                    _autoDetector = detector;
                }
                else
                {
                    throw new SAXNotSupportedException("Your auto-detector is not an IAutoDetector");
                }
            }
            else
            {
                throw new SAXNotRecognizedException("Unknown property " + name);
            }
        }

        public IEntityResolver EntityResolver
        {
            get { return _entityResolver == this ? null : _entityResolver; }
            set { _entityResolver = value ?? this; }
        }

        public IDTDHandler DTDHandler
        {
            get { return _dtdHandler == this ? null : _dtdHandler; }
            set { _dtdHandler = value ?? this; }
        }

        public IContentHandler ContentHandler
        {
            get {
                return _contentHandler == this ? null : _contentHandler;
            }
            set { _contentHandler = value ?? this; }
        }

        public IErrorHandler ErrorHandler
        {
            get { return _errorHandler == this ? null : _errorHandler; }
            set { _errorHandler = value ?? this; }
        }

        public void Parse(InputSource input)
        {
            Setup();
            TextReader r = GetReader(input);
            _contentHandler.StartDocument();
            _scanner.ResetDocumentLocator(input.PublicId, input.SystemId);
            var locator = _scanner as ILocator;
            if (locator != null)
            {
                _contentHandler.SetDocumentLocator(locator);
            }
            if (!(_schema.Uri.Equals("")))
            {
                _contentHandler.StartPrefixMapping(_schema.Prefix, _schema.Uri);
            }
            _scanner.Scan(r, this);
        }

        public void Parse(string systemid)
        {
            Parse(new InputSource(systemid));
        }

        // Sets up instance variables that haven't been set by setFeature
        private void Setup()
        {
            if (_schema == null)
            {
                _schema = new HTMLSchema();
            }
            if (_scanner == null)
            {
                _scanner = new HTMLScanner();
            }
            if (_autoDetector == null)
            {
                _autoDetector = new AutoDetectorDelegate(stream => new StreamReader(stream));
            }
            _stack = new Element(_schema.GetElementType("<root>"), _defaultAttributes);
            _pcdata = new Element(_schema.GetElementType("<pcdata>"), _defaultAttributes);
            _newElement = null;
            _attributeName = null;
            _piTarget = null;
            _saved = null;
            _entity = 0;
            _virginStack = true;
            _doctypeName = _doctypePublicId = _doctypeSystemId = null;
        }

        /// <summary>
        ///   Return a Reader based on the contents of an InputSource
        ///   Buffer the Stream
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private TextReader GetReader(InputSource s)
        {
            TextReader r = s.Reader;
            Stream i = s.Stream;
            Encoding encoding = s.Encoding;
            string publicid = s.PublicId;
            string systemid = s.SystemId;
            if (r == null)
            {
                if (i == null)
                {
                    i = GetInputStream(publicid, systemid);
                }
                if (!(i is BufferedStream))
                {
                    i = new BufferedStream(i);
                }
                if (encoding == null)
                {
                    r = _autoDetector.AutoDetectingReader(i);
                }
                else
                {
                    //try {
                    //TODO: Safe?
                    r = new StreamReader(i, encoding);
                    //  }
                    //catch (UnsupportedEncodingException e) {
                    //  r = new StreamReader(i);
                    //  }
                }
            }
            //		r = new BufferedReader(r);
            return r;
        }

        /// <summary>
        ///   Get an Stream based on a publicid and a systemid
        ///   We don't process publicids (who uses them anyhow?)
        /// </summary>
        /// <param name="publicid"></param>
        /// <param name="systemid"></param>
        /// <returns></returns>
        private Stream GetInputStream(string publicid, string systemid)
        {
            var basis = new Uri("file://" + Environment.CurrentDirectory + Path.DirectorySeparatorChar);
            var url = new Uri(basis, systemid);
            return new FileStream(url.LocalPath, FileMode.Open, FileAccess.Read, FileShare.Read);
        }

        /// <summary>
        ///   Expand entity references in attribute values selectively.
        ///   Currently we expand a reference iff it is properly terminated
        ///   with a semicolon.
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        private string ExpandEntities(string src)
        {
            int refStart = -1;
            int len = src.Length;
            var dst = new char[len];
            int dstlen = 0;
            for (int i = 0; i < len; i++)
            {
                char ch = src[i];
                dst[dstlen++] = ch;
                //			System.err.print("i = " + i + ", d = " + dstlen + ", ch = [" + ch + "] ");
                if (ch == '&' && refStart == -1)
                {
                    // start of a ref excluding &
                    refStart = dstlen;
                    //				System.err.println("start of ref");
                }
                else if (refStart == -1)
                {
                    // not in a ref
                    //				System.err.println("not in ref");
                }
                else if (char.IsLetter(ch) || char.IsDigit(ch) || ch == '#')
                {
                    // valid entity char
                    //				System.err.println("valid");
                }
                else if (ch == ';')
                {
                    // properly terminated ref
                    //				System.err.print("got [" + new string(dst, refStart, dstlen-refStart-1) + "]");
                    int ent = LookupEntity(dst, refStart, dstlen - refStart - 1);
                    //				System.err.println(" = " + ent);
                    if (ent > 0xFFFF)
                    {
                        ent -= 0x10000;
                        dst[refStart - 1] = (char)((ent >> 10) + 0xD800);
                        dst[refStart] = (char)((ent & 0x3FF) + 0xDC00);
                        dstlen = refStart + 1;
                    }
                    else if (ent != 0)
                    {
                        dst[refStart - 1] = (char)ent;
                        dstlen = refStart;
                    }
                    refStart = -1;
                }
                else
                {
                    // improperly terminated ref
                    //				System.err.println("end of ref");
                    refStart = -1;
                }
            }
            return new string(dst, 0, dstlen);
        }

        /// <summary>
        ///   Process numeric character references,
        ///   deferring to the schema for named ones.
        /// </summary>
        /// <param name="buff"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        private int LookupEntity(char[] buff, int offset, int length)
        {
            int result = 0;
            if (length < 1)
            {
                return result;
            }
            //		System.err.println("%% Entity at " + offset + " " + length);
            //		System.err.println("%% Got entity [" + new string(buff, offset, length) + "]");
            if (buff[offset] == '#')
            {
                if (length > 1 && (buff[offset + 1] == 'x' || buff[offset + 1] == 'X'))
                {
                    try
                    {
                        return Convert.ToInt32(new string(buff, offset + 2, length - 2), 16);
                    }
                    catch (FormatException e)
                    {
                        return 0;
                    }
                }
                try
                {
                    return Convert.ToInt32(new string(buff, offset + 1, length - 1), 10);
                }
                catch (FormatException e)
                {
                    return 0;
                }
            }
            return _schema.GetEntity(new string(buff, offset, length));
        }

        public bool ETagCdata(char[] buff, int offset, int length)
        {
            string currentName = _stack.Name;
            // If this is a CDATA element and the tag doesn't match,
            // or isn't properly formed (junk after the name),
            // restart CDATA mode and process the tag as characters.
            if (_cdataElements && (_stack.Flags & Schema.F_CDATA) != 0)
            {
                bool realTag = (length == currentName.Length);
                if (realTag)
                {
                    for (int i = 0; i < length; i++)
                    {
                        if (char.ToLower(buff[offset + i]) != char.ToLower(currentName[i]))
                        {
                            realTag = false;
                            break;
                        }
                    }
                }
                if (!realTag)
                {
                    _contentHandler.Characters(Etagchars, 0, 2);
                    _contentHandler.Characters(buff, offset, length);
                    _contentHandler.Characters(Etagchars, 2, 1);
                    _scanner.StartCDATA();
                    return true;
                }
            }
            return false;
        }

        public void ETagBasic(char[] buff, int offset, int length)
        {
            _newElement = null;
            string name;
            if (length != 0)
            {
                // Canonicalize case of name
                name = MakeName(buff, offset, length);
                //			System.err.println("got etag [" + name + "]");
                ElementType type = _schema.GetElementType(name);
                if (type == null)
                {
                    return; // mysterious end-tag
                }
                name = type.Name;
            }
            else
            {
                name = _stack.Name;
            }
            //		System.err.println("%% Got end of " + name);

            Element sp;
            bool inNoforce = false;
            for (sp = _stack; sp != null; sp = sp.Next)
            {
                if (sp.Name.Equals(name))
                {
                    break;
                }
                if ((sp.Flags & Schema.F_NOFORCE) != 0)
                {
                    inNoforce = true;
                }
            }

            if (sp == null)
            {
                return; // Ignore unknown etags
            }
            if (sp.Next == null || sp.Next.Next == null)
            {
                return;
            }
            if (inNoforce)
            {
                // inside an F_NOFORCE element?
                sp.Preclose(); // preclose the matching element
            }
            else
            {
                // restartably pop everything above us
                while (_stack != sp)
                {
                    RestartablyPop();
                }
                Pop();
            }
            // pop any preclosed elements now at the top
            while (_stack.IsPreclosed)
            {
                Pop();
            }
            Restart(null);
        }

        /// <summary>
        ///   Push restartables on the stack if possible
        ///   e is the next element to be started, if we know what it is
        /// </summary>
        /// <param name="e"></param>
        private void Restart(Element e)
        {
            while (_saved != null && _stack.CanContain(_saved) && (e == null || _saved.CanContain(e)))
            {
                Element next = _saved.Next;
                Push(_saved);
                _saved = next;
            }
        }

        /// <summary>
        ///   Pop the stack irrevocably
        /// </summary>
        private void Pop()
        {
            if (_stack == null)
            {
                return; // empty stack
            }
            string name = _stack.Name;
            string localName = _stack.LocalName;
            string ns = _stack.Namespace;
            string prefix = PrefixOf(name);

            //		System.err.println("%% Popping " + name);
            if (!_namespaces)
            {
                ns = localName = "";
            }
            _contentHandler.EndElement(ns, localName, name);
            if (Foreign(prefix, ns))
            {
                _contentHandler.EndPrefixMapping(prefix);
                //			System.err.println("%% Unmapping [" + prefix + "] for elements to " + namespace);
            }
            Attributes atts = _stack.Attributes;
            for (int i = atts.Length - 1; i >= 0; i--)
            {
                string attNamespace = atts.GetUri(i);
                string attPrefix = PrefixOf(atts.GetQName(i));
                if (Foreign(attPrefix, attNamespace))
                {
                    _contentHandler.EndPrefixMapping(attPrefix);
                    //			System.err.println("%% Unmapping [" + attPrefix + "] for attributes to " + attNamespace);
                }
            }
            _stack = _stack.Next;
        }

        /// <summary>
        ///   Pop the stack restartably
        /// </summary>
        private void RestartablyPop()
        {
            Element popped = _stack;
            Pop();
            if (_restartElements && (popped.Flags & Schema.F_RESTART) != 0)
            {
                popped.Anonymize();
                popped.Next = _saved;
                _saved = popped;
            }
        }

        /// <summary>
        ///   Push element onto stack
        /// </summary>
        /// <param name="e"></param>
        private void Push(Element e)
        {
            string name = e.Name;
            string localName = e.LocalName;
            string ns = e.Namespace;
            string prefix = PrefixOf(name);

            //		System.err.println("%% Pushing " + name);
            e.Clean();
            if (!_namespaces)
            {
                ns = localName = "";
            }
            if (_virginStack && localName.Equals(_doctypeName, StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    _entityResolver.ResolveEntity(_doctypePublicId, _doctypeSystemId);
                }
                catch (IOException ew)
                {
                } // Can't be thrown for root I believe.
            }
            if (Foreign(prefix, ns))
            {
                _contentHandler.StartPrefixMapping(prefix, ns);
                //			System.err.println("%% Mapping [" + prefix + "] for elements to " + namespace);
            }
            Attributes atts = e.Attributes;
            int len = atts.Length;
            for (int i = 0; i < len; i++)
            {
                string attNamespace = atts.GetUri(i);
                string attPrefix = PrefixOf(atts.GetQName(i));
                if (Foreign(attPrefix, attNamespace))
                {
                    _contentHandler.StartPrefixMapping(attPrefix, attNamespace);
                    //				System.err.println("%% Mapping [" + attPrefix + "] for attributes to " + attNamespace);
                }
            }
            _contentHandler.StartElement(ns, localName, name, e.Attributes);
            e.Next = _stack;
            _stack = e;
            _virginStack = false;
            if (_cdataElements && (_stack.Flags & Schema.F_CDATA) != 0)
            {
                _scanner.StartCDATA();
            }
        }

        /// <summary>
        ///   Get the prefix from a QName
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static string PrefixOf(string name)
        {
            int i = name.IndexOf(':');
            string prefix = "";
            if (i != -1)
            {
                prefix = name.Substring(0, i);
            }
            //		System.err.println("%% " + prefix + " is prefix of " + name);
            return prefix;
        }

        /// <summary>
        ///   Return true if we have a foreign name
        /// </summary>
        /// <param name="prefix"></param>
        /// <param name="ns"></param>
        /// <returns></returns>
        private bool Foreign(string prefix, string ns)
        {
            //		System.err.print("%% Testing " + prefix + " and " + namespace + " for foreignness -- ");
            bool foreign = !(prefix.Equals("") || ns.Equals("") || ns.Equals(_schema.Uri));
            //		System.err.println(foreign);
            return foreign;
        }

        // If the string is quoted, trim the quotes.
        private static string TrimQuotes(string value)
        {
            if (value == null)
            {
                return null;
            }
            int length = value.Length;
            if (length == 0)
            {
                return value;
            }
            char s = value[0];
            char e = value[length - 1];
            if (s == e && (s == '\'' || s == '"'))
            {
                value = value.Substring(1, value.Length - 1);
            }
            return value;
        }

        /// <summary>
        ///   Split the supplied string into words or phrases seperated by spaces.
        ///   Recognises quotes around a phrase and doesn't split it.
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        private static string[] Split(string val)
        {
            val = val.Trim();
            if (val.Length == 0)
            {
                return new string[0];
            }
            var l = new List<string>();
            int s = 0;
            int e = 0;
            bool sq = false; // single quote
            bool dq = false; // double quote
            var lastc = (char)0;
            int len = val.Length;
            for (e = 0; e < len; e++)
            {
                char c = val[e];
                if (!dq && c == '\'' && lastc != '\\')
                {
                    sq = !sq;
                    if (s < 0)
                    {
                        s = e;
                    }
                }
                else if (!sq && c == '\"' && lastc != '\\')
                {
                    dq = !dq;
                    if (s < 0)
                    {
                        s = e;
                    }
                }
                else if (!sq && !dq)
                {
                    if (char.IsWhiteSpace(c))
                    {
                        if (s >= 0)
                        {
                            l.Add(val.Substring(s, e - s));
                        }
                        s = -1;
                    }
                    else if (s < 0 && c != ' ')
                    {
                        s = e;
                    }
                }
                lastc = c;
            }
            l.Add(val.Substring(s, e - s));
            return l.ToArray();
        }

        /// <summary>
        ///   Replace junk in publicids with spaces
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        private string CleanPublicid(string src)
        {
            if (src == null)
            {
                return null;
            }
            int len = src.Length;
            var dst = new StringBuilder(len);
            bool suppressSpace = true;
            for (int i = 0; i < len; i++)
            {
                char ch = src[i];
                if (LEGAL.IndexOf(ch) != -1)
                {
                    // legal but not whitespace
                    dst.Append(ch);
                    suppressSpace = false;
                }
                else if (suppressSpace)
                {
                    // normalizable whitespace or junk
                }
                else
                {
                    dst.Append(' ');
                    suppressSpace = true;
                }
            }
            //		System.err.println("%% Publicid [" + dst.tostring().trim() + "]");
            return dst.ToString().Trim(); // trim any final junk whitespace
        }

        /// <summary>
        ///   Rectify the stack, pushing and popping as needed
        ///   so that the argument can be safely pushed
        /// </summary>
        /// <param name="e"></param>
        private void Rectify(Element e)
        {
            Element sp;
            while (true)
            {
                for (sp = _stack; sp != null; sp = sp.Next)
                {
                    if (sp.CanContain(e))
                    {
                        break;
                    }
                }
                if (sp != null)
                {
                    break;
                }
                ElementType parentType = e.Parent;
                if (parentType == null)
                {
                    break;
                }
                var parent = new Element(parentType, _defaultAttributes);
                //			System.err.println("%% Ascending from " + e.name() + " to " + parent.name());
                parent.Next = e;
                e = parent;
            }
            if (sp == null)
            {
                return; // don't know what to do
            }
            while (_stack != sp)
            {
                if (_stack == null || _stack.Next == null || _stack.Next.Next == null)
                {
                    break;
                }
                RestartablyPop();
            }
            while (e != null)
            {
                Element nexte = e.Next;
                if (!e.Name.Equals("<pcdata>"))
                {
                    Push(e);
                }
                e = nexte;
                Restart(e);
            }
            _newElement = null;
        }

        /// <summary>
        ///   Return the argument as a valid XML name
        ///   This no longer lowercases the result: we depend on Schema to
        ///   canonicalize case.
        /// </summary>
        /// <param name="buff"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        private string MakeName(char[] buff, int offset, int length)
        {
            var dst = new StringBuilder(length + 2);
            bool seenColon = false;
            bool start = true;
            //		string src = new string(buff, offset, length); // DEBUG
            for (; length-- > 0; offset++)
            {
                char ch = buff[offset];
                if (char.IsLetter(ch) || ch == '_')
                {
                    start = false;
                    dst.Append(ch);
                }
                else if (char.IsDigit(ch) || ch == '-' || ch == '.')
                {
                    if (start)
                    {
                        dst.Append('_');
                    }
                    start = false;
                    dst.Append(ch);
                }
                else if (ch == ':' && !seenColon)
                {
                    seenColon = true;
                    if (start)
                    {
                        dst.Append('_');
                    }
                    start = true;
                    dst.Append(_translateColons ? '_' : ch);
                }
            }
            int dstLength = dst.Length;
            if (dstLength == 0 || dst[dstLength - 1] == ':')
            {
                dst.Append('_');
            }
            //		System.err.println("Made name \"" + dst + "\" from \"" + src + "\"");
            return string.Intern(dst.ToString());
        }

        public new TextDocument ToTextDocument()
        {
            HTMLContentHandler hh = (HTMLContentHandler)_contentHandler;
            return hh.ToTextDocument();
        }

        private class AutoDetectorDelegate : IAutoDetector
        {
            private readonly Func<Stream, StreamReader> _delegate;

            public AutoDetectorDelegate(Func<Stream, StreamReader> @delegate)
            {
                _delegate = @delegate;
            }

            public TextReader AutoDetectingReader(Stream stream)
            {
                return _delegate(stream);
            }
        }




    }

    //public class HTMLParser1 : TagSoup.Net.Parser, DocumentSource
    //{
    //    private HTMLContentHandler contentHandler;

    //    public HTMLParser() : this(new HTMLContentHandler())
    //    {

    //    }

    //    public HTMLParser(HTMLContentHandler contentHandler) : base()
    //    {

    //        SetContentHandler(contentHandler);


    //    }



    //    protected HTMLParser(bool ignore)
    //    {
    //        //base(new HTMLConfiguration());
    //    }

    //    public void SetContentHandler(HTMLContentHandler contentHandler)
    //    {
    //        this.contentHandler = contentHandler;
    //        base.ContentHandler = contentHandler;
    //        //(contentHandler);
    //    }

    //    public void SetContentHandler(IContentHandler contentHandler)
    //    {
    //        this.contentHandler = null;
    //        base.ContentHandler = contentHandler;


    //    }


    //    public new void Parse(InputSource input)
    //    {
    //        var document = new HtmlDocument();
    //        Console.WriteLine("HTMLHighlighter parsing thru........ ");
    //        Console.ReadLine();
    //        if (input.Stream != null)
    //        {
    //            document.Load(input.Stream, input.Encoding);
    //        }
    //        else if (input.Reader != null)
    //        {
    //            document.Load(input.Reader);
    //        }
    //        else if (input.PublicId != null)
    //        {
    //            document.Load(input.PublicId);
    //        }
    //        else if (input.SystemId != null)
    //        {
    //            document.Load(input.SystemId);
    //        }
    //        Console.WriteLine("HTMLHighlighter parsing thru........ ");
    //        Console.ReadLine();
    //        ContentHandler.StartDocument();

    //        TraverseNode(document.DocumentNode);

    //        ContentHandler.EndDocument();
    //    }

    //    public new void Parse(string systemId)
    //    {
    //        Parse(new InputSource(systemId));
    //    }


    //    private void TraverseNode(HtmlNode htmlNode)
    //    {
    //        if (htmlNode == null || htmlNode.NodeType == HtmlNodeType.Comment)
    //        {



    //            return;


    //        }

    //        var attributes = new Attributes();
    //        if (htmlNode.HasAttributes)
    //        {
    //            foreach (HtmlAttribute attribute in htmlNode.Attributes)
    //            {
    //                attributes.AddAttribute(null, htmlNode.Name, attribute.Name, null, attribute.Value);
    //            }
    //        }

    //        ContentHandler.StartElement(null, htmlNode.Name, htmlNode.Name, attributes);
    //        if (htmlNode.NodeType == HtmlNodeType.Text)
    //        {
    //            ContentHandler.Characters(htmlNode.InnerText.ToCharArray(), 0, htmlNode.InnerText.Length);
    //        }
    //        else if (htmlNode.HasChildNodes)
    //        {
    //            foreach (HtmlNode childNode in htmlNode.ChildNodes)
    //            {
    //                TraverseNode(childNode);
    //            }
    //        }
    //        ContentHandler.EndElement(null, htmlNode.Name, htmlNode.Name);
    //    }

    //    public TextDocument ToTextDocument()
    //    {
    //        return contentHandler.ToTextDocument();
    //    }

    //}
}
//public class HTMLParser3 : DefaultHandler, IScanHandler, IXmlReader, ILexicalHandler
//{
//    // XMLReader implementation

//    private IContentHandler theContentHandler { get; set; }
//    private ILexicalHandler theLexicalHandler { get; set; }
//    private IDTDHandler theDTDHandler { get; set; }
//    private IErrorHandler theErrorHandler { get; set; }
//    private IEntityResolver theEntityResolver { get; set; }
//    private Schema theSchema;
//    private IScanner theScanner;
//    private IAutoDetector theAutoDetector;

//    // Default values for feature flags

//    private static bool DEFAULT_NAMESPACES = true;
//    private static bool DEFAULT_IGNORE_BOGONS = false;
//    private static bool DEFAULT_BOGONS_EMPTY = false;
//    private static bool DEFAULT_ROOT_BOGONS = true;
//    private static bool DEFAULT_DEFAULT_ATTRIBUTES = true;
//    private static bool DEFAULT_TRANSLATE_COLONS = false;
//    private static bool DEFAULT_RESTART_ELEMENTS = true;
//    private static bool DEFAULT_IGNORABLE_WHITESPACE = false;
//    private static bool DEFAULT_CDATA_ELEMENTS = true;

//    // Feature flags.  

//    private bool namespaces = DEFAULT_NAMESPACES;
//    private bool ignoreBogons = DEFAULT_IGNORE_BOGONS;
//    private bool bogonsEmpty = DEFAULT_BOGONS_EMPTY;
//    private bool rootBogons = DEFAULT_ROOT_BOGONS;
//    private bool defaultAttributes = DEFAULT_DEFAULT_ATTRIBUTES;
//    private bool translateColons = DEFAULT_TRANSLATE_COLONS;
//    private bool restartElements = DEFAULT_RESTART_ELEMENTS;
//    private bool ignorableWhitespace = DEFAULT_IGNORABLE_WHITESPACE;
//    private bool CDATAElements = DEFAULT_CDATA_ELEMENTS;

//    /**
//    A value of "true" indicates namespace URIs and unprefixed local
//    names for element and attribute names will be available.
//    **/
//    public static String namespacesFeature =
//        "http://xml.org/sax/features/namespaces";

//    /**
//    A value of "true" indicates that XML qualified names (with prefixes)
//    and attributes (including xmlns* attributes) will be available.
//    We don't support this value.
//    **/
//    public static String namespacePrefixesFeature =
//        "http://xml.org/sax/features/namespace-prefixes";

//    /**
//    Reports whether this parser processes external general entities
//    (it doesn't).
//    **/
//    public static String externalGeneralEntitiesFeature =
//        "http://xml.org/sax/features/external-general-entities";

//    /**
//    Reports whether this parser processes external parameter entities
//    (it doesn't).
//    **/
//    public static String externalParameterEntitiesFeature =
//        "http://xml.org/sax/features/external-parameter-entities";

//    /**
//    May be examined only during a parse, after the startDocument()
//    callback has been completed; read-only. The value is true if
//    the document specified standalone="yes" in its XML declaration,
//    and otherwise is false.  (It's always false.)
//    **/
//    public static String isStandaloneFeature =
//        "http://xml.org/sax/features/is-standalone";

//    /**
//    A value of "true" indicates that the LexicalHandler will report
//    the beginning and end of parameter entities (it won't).
//    **/
//    public static String lexicalHandlerParameterEntitiesFeature =
//        "http://xml.org/sax/features/lexical-handler/parameter-entities";

//    /**
//    A value of "true" indicates that system IDs in declarations will
//    be absolutized (relative to their base URIs) before reporting.
//    (This returns true but doesn't actually do anything.)
//    **/
//    public static String resolveDTDURIsFeature =
//        "http://xml.org/sax/features/resolve-dtd-uris";

//    /**
//    Has a value of "true" if all XML names (for elements,
//    prefixes, attributes, entities, notations, and local
//    names), as well as Namespace URIs, will have been interned
//    using java.lang.String.intern. This supports fast testing of
//    equality/inequality against string constants, rather than forcing
//    slower calls to String.equals().  (We always intern.)
//    **/
//    public static String stringInterningFeature =
//        "http://xml.org/sax/features/string-interning";

//    /**
//    Returns "true" if the Attributes objects passed by this
//    parser in ContentHandler.startElement() implement the
//    org.xml.sax.ext.Attributes2 interface.	(They don't.)
//    **/

//    public static String useAttributes2Feature =
//        "http://xml.org/sax/features/use-attributes2";

//    /**
//    Returns "true" if the Locator objects passed by this parser
//    in ContentHandler.setDocumentLocator() implement the
//    org.xml.sax.ext.Locator2 interface.  (They don't.)
//    **/
//    public static String useLocator2Feature =
//        "http://xml.org/sax/features/use-locator2";

//    /**
//    Returns "true" if, when setEntityResolver is given an object
//    implementing the org.xml.sax.ext.EntityResolver2 interface,
//    those new methods will be used.  (They won't be.)
//    **/
//    public static String useEntityResolver2Feature =
//        "http://xml.org/sax/features/use-entity-resolver2";

//    /**
//    Controls whether the parser is reporting all validity errors
//    (We don't report any validity errors.)
//    **/
//    public static String validationFeature =
//        "http://xml.org/sax/features/validation";

//    /**
//    Controls whether the parser reports Unicode normalization
//    errors as described in section 2.13 and Appendix B of the XML
//    1.1 Recommendation.  (We don't normalize.)
//    **/
//    public static String unicodeNormalizationCheckingFeature =
//"http://xml.org/sax/features/unicode-normalization-checking";

//    /**
//    Controls whether, when the namespace-prefixes feature is set,
//    the parser treats namespace declaration attributes as being in
//    the http://www.w3.org/2000/xmlns/ namespace.  (It doesn't.)
//    **/
//    public static String xmlnsURIsFeature =
//        "http://xml.org/sax/features/xmlns-uris";

//    /**
//    Returns "true" if the parser supports both XML 1.1 and XML 1.0.
//    (Always false.)
//    **/
//    public static String XML11Feature =
//        "http://xml.org/sax/features/xml-1.1";

//    /**
//    A value of "true" indicates that the parser will ignore
//    unknown elements.
//    **/
//    public static String ignoreBogonsFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/ignore-bogons";

//    /**
//    A value of "true" indicates that the parser will give unknown
//    elements a content model of EMPTY; a value of "false", a
//    content model of ANY.
//    **/
//    public static String bogonsEmptyFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/bogons-empty";

//    /**
//    A value of "true" indicates that the parser will allow unknown
//    elements to be the root element.
//    **/
//    public static String rootBogonsFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/root-bogons";

//    /**
//    A value of "true" indicates that the parser will return default
//    attribute values for missing attributes that have default values.
//    **/
//    public static String defaultAttributesFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/default-attributes";

//    /**
//    A value of "true" indicates that the parser will 
//    translate colons into underscores in names.
//    **/
//    public static String translateColonsFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/translate-colons";

//    /**
//    A value of "true" indicates that the parser will 
//    attempt to restart the restartable elements.
//    **/
//    public static String restartElementsFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/restart-elements";

//    /**
//    A value of "true" indicates that the parser will 
//    transmit whitespace in element-only content via the SAX
//    ignorableWhitespace callback.  Normally this is not done,
//    because HTML is an SGML application and SGML suppresses
//    such whitespace.
//    **/
//    public static String ignorableWhitespaceFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/ignorable-whitespace";

//    /**
//    A value of "true" indicates that the parser will treat CDATA
//    elements specially.  Normally true, since the input is by
//    default HTML.
//    **/
//    public static String CDATAElementsFeature =
//        "http://www.ccil.org/~cowan/tagsoup/features/cdata-elements";

//    /**
//    Used to see some syntax events that are essential in some
//    applications: comments, CDATA delimiters, selected general
//    entity inclusions, and the start and end of the DTD (and
//    declaration of document element name). The Object must implement
//    org.xml.sax.ext.LexicalHandler.
//    **/
//    public static String lexicalHandlerProperty =
//        "http://xml.org/sax/properties/lexical-handler";

//    /**
//    Specifies the Scanner object this Parser uses.
//    **/
//    public static String scannerProperty =
//        "http://www.ccil.org/~cowan/tagsoup/properties/scanner";

//    /**
//    Specifies the Schema object this Parser uses.
//    **/
//    public static String schemaProperty =
//        "http://www.ccil.org/~cowan/tagsoup/properties/schema";

//    /**
//    Specifies the AutoDetector (for encoding detection) this Parser uses.
//    **/
//    public static String autoDetectorProperty =
//        "http://www.ccil.org/~cowan/tagsoup/properties/auto-detector";

//    // Due to sucky Java order of initialization issues, these
//    // entries are maintained separately from the initial values of
//    // the corresponding instance variables, but care must be taken
//    // to keep them in sync.

//    public class Features
//    {




//    }


//    private Dictionary<string, bool> theFeatures = new Dictionary<string, bool>();



//    //theFeatures.Add(namespacesFeature, truthValue(DEFAULT_NAMESPACES));
//    //theFeatures.Add(namespacePrefixesFeature, Boolean.FALSE);
//    //theFeatures.Add(externalGeneralEntitiesFeature, Boolean.FALSE);
//    //theFeatures.Add(externalParameterEntitiesFeature, Boolean.FALSE);
//    //theFeatures.Add(isStandaloneFeature, Boolean.FALSE);
//    //theFeatures.Add(lexicalHandlerParameterEntitiesFeature,Boolean.FALSE);
//    //theFeatures.Add(resolveDTDURIsFeature, Boolean.TRUE);
//    //theFeatures.Add(stringInterningFeature, Boolean.TRUE);
//    //theFeatures.Add(useAttributes2Feature, Boolean.FALSE);
//    //theFeatures.Add(useLocator2Feature, Boolean.FALSE);
//    //theFeatures.Add(useEntityResolver2Feature, Boolean.FALSE);
//    //theFeatures.Add(validationFeature, Boolean.FALSE);
//    //theFeatures.Add(xmlnsURIsFeature, Boolean.FALSE);
//    //theFeatures.Add(xmlnsURIsFeature, Boolean.FALSE);
//    //theFeatures.Add(XML11Feature, Boolean.FALSE);
//    //theFeatures.Add(ignoreBogonsFeature, truthValue(DEFAULT_IGNORE_BOGONS));
//    //theFeatures.Add(bogonsEmptyFeature, truthValue(DEFAULT_BOGONS_EMPTY));
//    //theFeatures.Add(rootBogonsFeature, truthValue(DEFAULT_ROOT_BOGONS));
//    //theFeatures.Add(defaultAttributesFeature, truthValue(DEFAULT_DEFAULT_ATTRIBUTES));
//    //theFeatures.Add(translateColonsFeature, truthValue(DEFAULT_TRANSLATE_COLONS));
//    //theFeatures.Add(restartElementsFeature, truthValue(DEFAULT_RESTART_ELEMENTS));
//    //theFeatures.Add(ignorableWhitespaceFeature, truthValue(DEFAULT_IGNORABLE_WHITESPACE));
//    //theFeatures.Add(CDATAElementsFeature, truthValue(DEFAULT_CDATA_ELEMENTS));


//    // Private clone of Boolean.valueOf that is guaranteed to return
//    // Boolean.TRUE or Boolean.FALSE
//    private static bool truthValue(bool b)
//    {
//        return b ? true : false;
//    }


//    public bool GetFeature(String name)

//    {
//        bool b;
//        theFeatures.TryGetValue(name, out b);


//        return b;
//    }

//    public void SetFeature(String name, bool value)

//    {
//        bool b;
//        theFeatures.TryGetValue(name, out b);


//        if (value)
//        {
//            theFeatures.Add(name, true);
//        }

//        else
//        {
//            theFeatures.Add(name, false);
//        }

//        if (name.Equals(namespacesFeature)) namespaces = value;
//        else if (name.Equals(ignoreBogonsFeature)) ignoreBogons = value;
//        else if (name.Equals(bogonsEmptyFeature)) bogonsEmpty = value;
//        else if (name.Equals(rootBogonsFeature)) rootBogons = value;
//        else if (name.Equals(defaultAttributesFeature)) defaultAttributes = value;
//        else if (name.Equals(translateColonsFeature)) translateColons = value;
//        else if (name.Equals(restartElementsFeature)) restartElements = value;
//        else if (name.Equals(ignorableWhitespaceFeature)) ignorableWhitespace = value;
//        else if (name.Equals(CDATAElementsFeature)) CDATAElements = value;
//    }

//    public Object GetProperty(String name)
//    {
//        if (name.Equals(lexicalHandlerProperty))
//        {
//            return theLexicalHandler == this ? null : theLexicalHandler;

//        }
//        else if (name.Equals(scannerProperty))
//        {
//            return theScanner;
//        }
//        else if (name.Equals(schemaProperty))
//        {
//            return theSchema;
//        }
//        else if (name.Equals(autoDetectorProperty))
//        {
//            return theAutoDetector;
//        }
//        else
//        {
//            throw new SAXNotRecognizedException("Unknown property " + name);
//        }
//    }

//    public void SetProperty(String name, Object value)
//    {
//        if (name.Equals(lexicalHandlerProperty))
//        {
//            if (value == null)
//            {
//                theLexicalHandler = this;

//            }
//            else if (value.GetType() == typeof(ILexicalHandler))
//            {
//                theLexicalHandler = (ILexicalHandler)value;
//            }
//            else
//            {
//                throw new SAXNotSupportedException("Your lexical handler is not a LexicalHandler");
//            }
//        }
//        else if (name.Equals(scannerProperty))
//        {
//            if (value.GetType() == typeof(IScanner))
//            {
//                theScanner = (IScanner)value;
//            }
//            else
//            {
//                throw new SAXNotSupportedException("Your scanner is not a Scanner");
//            }
//        }
//        else if (name.Equals(schemaProperty))
//        {
//            if (value.GetType() == typeof(Schema))
//            {
//                theSchema = (Schema)value;
//            }
//            else
//            {
//                throw new SAXNotSupportedException("Your schema is not a Schema");
//            }
//        }
//        else if (name.Equals(autoDetectorProperty))
//        {
//            if (value.GetType() == typeof(IAutoDetector))
//            {
//                theAutoDetector = (IAutoDetector)value;
//            }
//            else
//            {
//                throw new SAXNotSupportedException("Your auto-detector is not an AutoDetector");
//            }
//        }
//        else
//        {
//            throw new SAXNotRecognizedException("Unknown property " + name);
//        }
//    }

//    public void SetEntityResolver(IEntityResolver resolver)
//    {
//        theEntityResolver = (resolver == null) ? this : resolver;
//    }

//    public IEntityResolver GetEntityResolver()
//    {
//        return (theEntityResolver == this) ? null : theEntityResolver;
//    }

//    public void SetDTDHandler(IDTDHandler handler)
//    {
//        theDTDHandler = (handler == null) ? this : handler;
//    }

//    public IDTDHandler GetDTDHandler()
//    {
//        return (theDTDHandler == this) ? null : theDTDHandler;
//    }

//    public void SetContentHandler(IContentHandler handler)
//    {
//        theContentHandler = (handler == null) ? this : handler;
//    }

//    public IContentHandler GetContentHandler()
//    {
//        return (theContentHandler == this) ? null : theContentHandler;
//    }

//    public void SetErrorHandler(IErrorHandler handler)
//    {
//        theErrorHandler = (handler == null) ? this : handler;
//    }

//    public IErrorHandler GetErrorHandler()
//    {
//        return (theErrorHandler == this) ? null : theErrorHandler;
//    }

//    public void Parse(InputSource input)
//    {

//        Setup();
//        StreamReader r = GetReader(input);
//        theContentHandler.StartDocument();
//        theScanner.ResetDocumentLocator(input.PublicId, input.SystemId);
//        if (theScanner.GetType() == typeof(Locator))
//        {
//            theContentHandler.SetDocumentLocator((Locator)theScanner);
//        }
//        if (!(theSchema.Uri.Equals("")))
//            theContentHandler.StartPrefixMapping(theSchema.Prefix,
//                theSchema.Uri);
//        theScanner.Scan(r, this);
//    }

//    public void Parse(String systemid)
//    {

//        Parse(new InputSource(systemid));
//    }



//    public class AutoDetector : IAutoDetector
//    {

//        public TextReader AutoDetectingReader(Stream i)
//        {
//            TextReader txt = new StreamReader(i);
//            return txt;
//        }
//    }
//    // Sets up instance variables that haven't been set by setFeature
//    private void Setup()
//    {



//        if (theSchema == null)
//        {
//            theSchema = new HTMLSchema();
//        }
//        if (theScanner == null)
//        {
//            theScanner = new HTMLScanner();
//        }
//        if (theAutoDetector == null)
//        {
//            theAutoDetector = new AutoDetector();

//        }
//        theStack = new Element(theSchema.GetElementType("<root>"), defaultAttributes);
//        thePCDATA = new Element(theSchema.GetElementType("<pcdata>"), defaultAttributes);
//        theNewElement = null;
//        theAttributeName = null;
//        thePITarget = null;
//        theSaved = null;
//        theEntity = 0;
//        virginStack = true;
//        theDoctypeName = theDoctypePublicId = theDoctypeSystemId = null;
//    }

//    // Return a Reader based on the contents of an InputSource
//    // Buffer both the InputStream and the Reader
//    private TextReader GetReader(InputSource s)
//    {
//        TextReader r = s.Reader;
//        Stream i = s.Stream;
//        String encoding = s.Encoding.BodyName;
//        String publicid = s.PublicId;
//        String systemid = s.SystemId;
//        if (r == null)
//        {
//            if (i == null)
//            { i = getInputStream(publicid, systemid); }
//            //			i = new BufferedInputStream(i);
//            if (encoding == null)
//            {
//                r = theAutoDetector.autoDetectingReader(i);
//            }
//            else
//            {
//                try
//                {
//                    r = new InputStreamReader(i, encoding);
//                }
//                catch (UnsupportedEncodingException e)
//                {
//                    r = new InputStreamReader(i);
//                }
//            }
//        }
//        //		r = new BufferedReader(r);
//        return r;
//    }

//    // Get an InputStream based on a publicid and a systemid
//    private  GetInputStream(String publicid, String systemid)
//    {
//        Uri basis = new Uri("file", "", System.get("user.dir") + "/.");
//        URL url = new (basis, systemid);
//        URLConnection c = url.openConnection();
//        return c.getInputStream();
//    }
//    // We don't process publicids (who uses them anyhow?)

//    // ScanHandler implementation

//    private Element theNewElement = null;
//    private String theAttributeName = null;
//    private bool theDoctypeIsPresent = false;
//    private String theDoctypePublicId = null;
//    private String theDoctypeSystemId = null;
//    private String theDoctypeName = null;
//    private String thePITarget = null;
//    private Element theStack = null;
//    private Element theSaved = null;
//    private Element thePCDATA = null;
//    private int theEntity = 0;  // needs to support chars past U+FFFF

//    public void adup(char[] buff, int offset, int length) throws SAXException
//    {
//		if (theNewElement == null || theAttributeName == null) return;
//        theNewElement.setAttribute(theAttributeName, null, theAttributeName);
//        theAttributeName = null;
//    }

//    public void aname(char[] buff, int offset, int length) throws SAXException
//    {
//		if (theNewElement == null) return;
//        // Currently we don't rely on Schema to canonicalize
//        // attribute names.
//        theAttributeName = makeName(buff, offset, length).toLowerCase();
//        //		System.err.println("%% Attribute name " + theAttributeName);
//    }

//    public void aval(char[] buff, int offset, int length) throws SAXException
//    {
//		if (theNewElement == null || theAttributeName == null) return;
//        String value = new String(buff, offset, length);
//    //		System.err.println("%% Attribute value [" + value + "]");
//    value = expandEntities(value);
//    theNewElement.setAttribute(theAttributeName, null, value);
//		theAttributeName = null;
////		System.err.println("%% Aval done");
//		}

//// Expand entity references in attribute values selectively.
//// Currently we expand a reference iff it is properly terminated
//// with a semicolon.
//private String expandEntities(String src)
//{
//    int refStart = -1;
//    int len = src.length();
//    char[] dst = new char[len];
//    int dstlen = 0;
//    for (int i = 0; i < len; i++)
//    {
//        char ch = src.charAt(i);
//        dst[dstlen++] = ch;
//        //			System.err.print("i = " + i + ", d = " + dstlen + ", ch = [" + ch + "] ");
//        if (ch == '&' && refStart == -1)
//        {
//            // start of a ref excluding &
//            refStart = dstlen;
//            //				System.err.println("start of ref");
//        }
//        else if (refStart == -1)
//        {
//            // not in a ref
//            //				System.err.println("not in ref");
//        }
//        else if (Character.isLetter(ch) ||
//                Character.isDigit(ch) ||
//                ch == '#')
//        {
//            // valid entity char
//            //				System.err.println("valid");
//        }
//        else if (ch == ';')
//        {
//            // properly terminated ref
//            //				System.err.print("got [" + new String(dst, refStart, dstlen-refStart-1) + "]");
//            int ent = lookupEntity(dst, refStart, dstlen - refStart - 1);
//            //				System.err.println(" = " + ent);
//            if (ent > 0xFFFF)
//            {
//                ent -= 0x10000;
//                dst[refStart - 1] = (char)((ent >> 10) + 0xD800);
//                dst[refStart] = (char)((ent & 0x3FF) + 0xDC00);
//                dstlen = refStart + 1;
//            }
//            else if (ent != 0)
//            {
//                dst[refStart - 1] = (char)ent;
//                dstlen = refStart;
//            }
//            refStart = -1;
//        }
//        else
//        {
//            // improperly terminated ref
//            //				System.err.println("end of ref");
//            refStart = -1;
//        }
//    }
//    return new String(dst, 0, dstlen);
//}

//public void entity(char[] buff, int offset, int length) throws SAXException
//{
//    theEntity = lookupEntity(buff, offset, length);
//}

//// Process numeric character references,
//// deferring to the schema for named ones.
//private int lookupEntity(char[] buff, int offset, int length)
//{
//    int result = 0;
//    if (length < 1) return result;
//    //		System.err.println("%% Entity at " + offset + " " + length);
//    //		System.err.println("%% Got entity [" + new String(buff, offset, length) + "]");
//    if (buff[offset] == '#')
//    {
//        if (length > 1 && (buff[offset + 1] == 'x'
//                        || buff[offset + 1] == 'X'))
//        {
//            try
//            {
//                return Integer.parseInt(new String(buff, offset + 2, length - 2), 16);
//            }
//            catch (NumberFormatException e) { return 0; }
//        }
//        try
//        {
//            return Integer.parseInt(new String(buff, offset + 1, length - 1), 10);
//        }
//        catch (NumberFormatException e) { return 0; }
//    }
//    return theSchema.getEntity(new String(buff, offset, length));
//}

//public void eof(char[] buff, int offset, int length) throws SAXException
//{
//		if (virginStack) rectify(thePCDATA);
//		while (theStack.next() != null) {
//        pop();
//    }
//		if (!(theSchema.getURI().equals("")))
//			theContentHandler.endPrefixMapping(theSchema.getPrefix());
//    theContentHandler.endDocument();
//}

//public void etag(char[] buff, int offset, int length) throws SAXException
//{
//		if (etag_cdata(buff, offset, length)) return;
//    etag_basic(buff, offset, length);
//}

//private static char[] etagchars = { '<', '/', '>' };
//public boolean etag_cdata(char[] buff, int offset, int length) throws SAXException
//{
//    String currentName = theStack.name();
//		// If this is a CDATA element and the tag doesn't match,
//		// or isn't properly formed (junk after the name),
//		// restart CDATA mode and process the tag as characters.
//		if (CDATAElements && (theStack.flags() & Schema.F_CDATA) != 0) {
//        boolean realTag = (length == currentName.length());
//        if (realTag)
//        {
//            for (int i = 0; i < length; i++)
//            {
//                if (Character.toLowerCase(buff[offset + i]) != Character.toLowerCase(currentName.charAt(i)))
//                {
//                    realTag = false;
//                    break;
//                }
//            }
//        }
//        if (!realTag)
//        {
//            theContentHandler.characters(etagchars, 0, 2);
//            theContentHandler.characters(buff, offset, length);
//            theContentHandler.characters(etagchars, 2, 1);
//            theScanner.startCDATA();
//            return true;
//        }
//    }
//		return false;
//}

//public void etag_basic(char[] buff, int offset, int length) throws SAXException
//{
//    theNewElement = null;
//    String name;
//		if (length != 0) {
//        // Canonicalize case of name
//        name = makeName(buff, offset, length);
//        //			System.err.println("got etag [" + name + "]");
//        ElementType type = theSchema.getElementType(name);
//        if (type == null) return;   // mysterious end-tag
//        name = type.name();
//    }
//		else {
//        name = theStack.name();
//    }
//    //		System.err.println("%% Got end of " + name);

//    Element sp;
//    boolean inNoforce = false;
//		for (sp = theStack; sp != null; sp = sp.next()) {
//        if (sp.name().equals(name)) break;
//        if ((sp.flags() & Schema.F_NOFORCE) != 0) inNoforce = true;
//    }

//		if (sp == null) return;		// Ignore unknown etags
//		if (sp.next() == null || sp.next().next() == null) return;
//		if (inNoforce) {        // inside an F_NOFORCE element?
//        sp.preclose();      // preclose the matching element
//    }
//		else {          // restartably pop everything above us
//        while (theStack != sp)
//        {
//            restartablyPop();
//        }
//        pop();
//    }
//		// pop any preclosed elements now at the top
//		while (theStack.isPreclosed()) {
//        pop();
//    }
//    restart(null);
//}

//// Push restartables on the stack if possible
//// e is the next element to be started, if we know what it is
//private void restart(Element e) throws SAXException
//{
//		while (theSaved != null && theStack.canContain(theSaved) &&
//				(e == null || theSaved.canContain(e))) {
//        Element next = theSaved.next();
//        push(theSaved);
//        theSaved = next;
//    }
//}

//// Pop the stack irrevocably
//private void pop() throws SAXException
//{
//		if (theStack == null) return;       // empty stack
//    String name = theStack.name();
//    String localName = theStack.localName();
//    String namespace = theStack.namespace();
//		String prefix = prefixOf(name);

////		System.err.println("%% Popping " + name);
//		if (!namespaces) namespace = localName = "";
//		theContentHandler.endElement(namespace, localName, name);
//		if (foreign(prefix, namespace)) {
//			theContentHandler.endPrefixMapping(prefix);
////			System.err.println("%% Unmapping [" + prefix + "] for elements to " + namespace);
//			}
//Attributes atts = theStack.atts();
//		for (int i = atts.getLength() - 1; i >= 0; i--) {
//			String attNamespace = atts.getURI(i);
//String attPrefix = prefixOf(atts.getQName(i));
//			if (foreign(attPrefix, attNamespace)) {
//				theContentHandler.endPrefixMapping(attPrefix);
////			System.err.println("%% Unmapping [" + attPrefix + "] for attributes to " + attNamespace);
//				}
//}
//theStack = theStack.next();
//		}

//// Pop the stack restartably
//private void restartablyPop() throws SAXException
//{
//    Element popped = theStack;
//    pop();
//		if (restartElements && (popped.flags() & Schema.F_RESTART) != 0) {
//        popped.anonymize();
//        popped.setNext(theSaved);
//        theSaved = popped;
//    }
//}

//// Push element onto stack
//private boolean virginStack = true;
//private void push(Element e) throws SAXException
//{
//    String name = e.name();
//    String localName = e.localName();
//    String namespace = e.namespace();
//		String prefix = prefixOf(name);

////		System.err.println("%% Pushing " + name);
//e.clean();
//		if (!namespaces) namespace = localName = "";
//                if (virginStack && localName.equalsIgnoreCase(theDoctypeName)) {
//                    try {
//                        theEntityResolver.resolveEntity(theDoctypePublicId, theDoctypeSystemId);
//                    } catch (IOException ew) { }   // Can't be thrown for root I believe.
//}
//		if (foreign(prefix, namespace)) {
//			theContentHandler.startPrefixMapping(prefix, namespace);
////			System.err.println("%% Mapping [" + prefix + "] for elements to " + namespace);
//			}
//Attributes atts = e.atts();
//int len = atts.getLength();
//		for (int i = 0; i<len; i++) {
//			String attNamespace = atts.getURI(i);
//String attPrefix = prefixOf(atts.getQName(i));
//			if (foreign(attPrefix, attNamespace)) {
//				theContentHandler.startPrefixMapping(attPrefix, attNamespace);
////				System.err.println("%% Mapping [" + attPrefix + "] for attributes to " + attNamespace);
//				}
//}
//theContentHandler.startElement(namespace, localName, name, e.atts());
//		e.setNext(theStack);
//		theStack = e;
//		virginStack = false;
//		if (CDATAElements && (theStack.flags() & Schema.F_CDATA) != 0) {
//			theScanner.startCDATA();
//			}
//		}

//	// Get the prefix from a QName
//	private String prefixOf(String name)
//{
//    int i = name.indexOf(':');
//    String prefix = "";
//    if (i != -1) prefix = name.substring(0, i);
//    //		System.err.println("%% " + prefix + " is prefix of " + name);
//    return prefix;
//}

//// Return true if we have a foreign name
//private boolean foreign(String prefix, String namespace) {
////		System.err.print("%% Testing " + prefix + " and " + namespace + " for foreignness -- ");
//		boolean foreign = !(prefix.equals("") || namespace.equals("") ||
//			namespace.equals(theSchema.getURI()));
////		System.err.println(foreign);
//		return foreign;
//		}

/////**
//// * Parsing the complete XML Document Type Definition is way too complex,
//// * but for many simple cases we can extract something useful from it.
//// *
//// * doctypedecl  ::= '<!DOCTYPE' S Name (S ExternalID)? S? ('[' intSubset ']' S?)? '>'
//// *  DeclSep     ::= PEReference | S
//// *  intSubset   ::= (markupdecl | DeclSep)*
//// *  markupdecl  ::= elementdecl | AttlistDecl | EntityDecl | NotationDecl | PI | Comment
//// *  ExternalID  ::= 'SYSTEM' S SystemLiteral | 'PUBLIC' S PubidLiteral S SystemLiteral
//// */
////public void decl(char[] buff, int offset, int length) throws SAXException
////{
////    String s = new String(buff, offset, length);
////String name = null;
////String systemid = null;
////String publicid = null;
////String[] v = split(s);
////		if (v.length > 0 && "DOCTYPE".equalsIgnoreCase(v[0])) {
////			if (theDoctypeIsPresent) return;		// one doctype only!
////			theDoctypeIsPresent = true;
////			if (v.length > 1) {
////				name = v[1];
////				if (v.length>3 && "SYSTEM".equals(v[2])) {
////				systemid = v[3];
////				}
////			else if (v.length > 3 && "PUBLIC".equals(v[2])) {
////				publicid = v[3];
////				if (v.length > 4) {
////					systemid = v[4];
////					}
////				else {
////					systemid = "";
////					}
////                    }
////                }
////            }
////		publicid = trimquotes(publicid);
////systemid = trimquotes(systemid);
////		if (name != null) {
////			publicid = cleanPublicid(publicid);
////theLexicalHandler.startDTD(name, publicid, systemid);
////			theLexicalHandler.endDTD();
////			theDoctypeName = name;
////			theDoctypePublicId = publicid;
////		if (theScanner instanceof Locator) {    // Must resolve systemid
////                    theDoctypeSystemId  = ((Locator)theScanner).getSystemId();
////                    try {
////                        theDoctypeSystemId = new URL(new URL(theDoctypeSystemId), systemid).toString();
////                    } catch (Exception e) {}
////                }
////            }
////        }

////	// If the String is quoted, trim the quotes.
////	private static String trimquotes(String in)
////{
////    if (in == null) return in;
////    int length = in.length();
////    if (length == 0) return in;
////    char s = in.charAt(0);
////    char e = in.charAt(length - 1);
////    if (s == e && (s == '\'' || s == '"'))
////    {
////			in = in.substring(1, in.length() - 1);
////    }
////    return in;
////}

////// Split the supplied String into words or phrases seperated by spaces.
////// Recognises quotes around a phrase and doesn't split it.
////private static String[] split(String val) throws IllegalArgumentException
////{
////    val = val.trim();
////		if (val.length() == 0) {
////        return new String[0];
////    }
////		else {
////        ArrayList l = new ArrayList();
////        int s = 0;
////        int e = 0;
////        boolean sq = false; // single quote
////        boolean dq = false; // double quote
////        char lastc = 0;
////        int len = val.length();
////        for (e = 0; e < len; e++)
////        {
////            char c = val.charAt(e);
////            if (!dq && c == '\'' && lastc != '\\')
////            {
////                sq = !sq;
////                if (s < 0) s = e;
////            }
////            else if (!sq && c == '\"' && lastc != '\\')
////            {
////                dq = !dq;
////                if (s < 0) s = e;
////            }
////            else if (!sq && !dq)
////            {
////                if (Character.isWhitespace(c))
////                {
////                    if (s >= 0) l.add(val.substring(s, e));
////                    s = -1;
////                }
////                else if (s < 0 && c != ' ')
////                {
////                    s = e;
////                }
////            }
////            lastc = c;
////        }
////        l.add(val.substring(s, e));
////        return (String[])l.toArray(new String[0]);
////    }
////}

////// Replace junk in publicids with spaces
////private static String legal =
////    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-'()+,./:=?;!*#@$_%";

////private String cleanPublicid(String src)
////{
////    if (src == null) return null;
////    int len = src.length();
////    StringBuffer dst = new StringBuffer(len);
////    boolean suppressSpace = true;
////    for (int i = 0; i < len; i++)
////    {
////        char ch = src.charAt(i);
////        if (legal.indexOf(ch) != -1)
////        {   // legal but not whitespace
////            dst.append(ch);
////            suppressSpace = false;
////        }
////        else if (suppressSpace)
////        {   // normalizable whitespace or junk
////            ;
////        }
////        else
////        {
////            dst.append(' ');
////            suppressSpace = true;
////        }
////    }
////    //		System.err.println("%% Publicid [" + dst.toString().trim() + "]");
////    return dst.toString().trim();   // trim any final junk whitespace
////}


////public void gi(char[] buff, int offset, int length) throws SAXException
////{
////		if (theNewElement != null) return;
////    String name = makeName(buff, offset, length);
////		if (name == null) return;
////    ElementType type = theSchema.getElementType(name);
////		if (type == null) {
////        // Suppress unknown elements if ignore-bogons is on
////        if (ignoreBogons) return;
////        int bogonModel = bogonsEmpty ? Schema.M_EMPTY : Schema.M_ANY;
////        int bogonMemberOf = rootBogons ? Schema.M_ANY : (Schema.M_ANY & ~Schema.M_ROOT);
////        theSchema.elementType(name, bogonModel, bogonMemberOf, 0);
////        if (!rootBogons) theSchema.parent(name, theSchema.rootElementType().name());
////        type = theSchema.getElementType(name);
////    }

////    theNewElement = new Element(type, defaultAttributes);
//////		System.err.println("%% Got GI " + theNewElement.name());
////		}

////	public void cdsect(char[] buff, int offset, int length) throws SAXException
////{
////    theLexicalHandler.startCDATA();
////    pcdata(buff, offset, length);
////    theLexicalHandler.endCDATA();
////}
////public void pcdata(char[] buff, int offset, int length) throws SAXException
////{
////		if (length == 0) return;
////    boolean allWhite = true;
////		for (int i = 0; i < length; i++) {
////        if (!Character.isWhitespace(buff[offset + i]))
////        {
////            allWhite = false;
////        }
////    }
////		if (allWhite && !theStack.canContain(thePCDATA)) {
////        if (ignorableWhitespace)
////        {
////            theContentHandler.ignorableWhitespace(buff, offset, length);
////        }
////    }
////		else {
////        rectify(thePCDATA);
////        theContentHandler.characters(buff, offset, length);
////    }
////}

////public void pitarget(char[] buff, int offset, int length) throws SAXException
////{
////		if (theNewElement != null) return;
////    thePITarget = makeName(buff, offset, length).replace(':', '_');
////}

////public void pi(char[] buff, int offset, int length) throws SAXException
////{
////		if (theNewElement != null || thePITarget == null) return;
////		if ("xml".equalsIgnoreCase(thePITarget)) return;
//////		if (length > 0 && buff[length - 1] == '?') System.err.println("%% Removing ? from PI");
////		if (length > 0 && buff [length - 1] == '?') length--;   // remove trailing ?
////    theContentHandler.processingInstruction(thePITarget,

////            new String(buff, offset, length));
////		thePITarget = null;
////		}

////	public void stagc(char[] buff, int offset, int length) throws SAXException
////{
//////		System.err.println("%% Start-tag");
////		if (theNewElement == null) return;
////    rectify(theNewElement);
////		if (theStack.model() == Schema.M_EMPTY) {
////        // Force an immediate end tag
////        etag_basic(buff, offset, length);
////    }
////}

////public void stage(char[] buff, int offset, int length) throws SAXException
////{
//////		System.err.println("%% Empty-tag");
////		if (theNewElement == null) return;
////    rectify(theNewElement);
////    // Force an immediate end tag
////    etag_basic(buff, offset, length);
////}

////// Comment buffer is twice the size of the output buffer
////private char[] theCommentBuffer = new char[2000];
////public void cmnt(char[] buff, int offset, int length) throws SAXException
////{
////    theLexicalHandler.comment(buff, offset, length);
////}

////// Rectify the stack, pushing and popping as needed
////// so that the argument can be safely pushed
////private void rectify(Element e) throws SAXException
////{
////    Element sp;
////		while (true) {
////        for (sp = theStack; sp != null; sp = sp.next())
////        {
////            if (sp.canContain(e)) break;
////        }
////        if (sp != null) break;
////        ElementType parentType = e.parent();
////        if (parentType == null) break;
////        Element parent = new Element(parentType, defaultAttributes);
////        //			System.err.println("%% Ascending from " + e.name() + " to " + parent.name());
////        parent.setNext(e);
////        e = parent;
////    }
////		if (sp == null) return;		// don't know what to do
////		while (theStack != sp) {
////        if (theStack == null || theStack.next() == null ||
////            theStack.next().next() == null) break;
////        restartablyPop();
////    }
////		while (e != null) {
////        Element nexte = e.next();
////        if (!e.name().equals("<pcdata>")) push(e);
////        e = nexte;
////        restart(e);
////    }
////    theNewElement = null;
////}

////public int getEntity()
////{
////    return theEntity;
////}

////// Return the argument as a valid XML name
////// This no longer lowercases the result: we depend on Schema to
////// canonicalize case.
////private String makeName(char[] buff, int offset, int length)
////{
////    StringBuffer dst = new StringBuffer(length + 2);
////    boolean seenColon = false;
////    boolean start = true;
////    //		String src = new String(buff, offset, length); // DEBUG
////    for (; length-- > 0; offset++)
////    {
////        char ch = buff[offset];
////        if (Character.isLetter(ch) || ch == '_')
////        {
////            start = false;
////            dst.append(ch);
////        }
////        else if (Character.isDigit(ch) || ch == '-' || ch == '.')
////        {
////            if (start) dst.append('_');
////            start = false;
////            dst.append(ch);
////        }
////        else if (ch == ':' && !seenColon)
////        {
////            seenColon = true;
////            if (start) dst.append('_');
////            start = true;
////            dst.append(translateColons ? '_' : ch);
////        }
////    }
////    int dstLength = dst.length();
////    if (dstLength == 0 || dst.charAt(dstLength - 1) == ':') dst.append('_');
////    //		System.err.println("Made name \"" + dst + "\" from \"" + src + "\"");
////    return dst.toString().intern();
////}

////// Default LexicalHandler implementation

////public void comment(char[] ch, int start, int length) throws SAXException { }
////public void endCDATA() throws SAXException { }
////public void endDTD() throws SAXException { }
////public void endEntity(String name) throws SAXException { }
////public void startCDATA() throws SAXException { }
////public void startDTD(String name, String publicid, String systemid) throws SAXException { }
////public void startEntity(String name) throws SAXException { }



////    }

////}
