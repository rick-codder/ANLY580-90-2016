﻿using System;
using System.Linq;
using System.Text;
using System.Net;
using System.Windows;
using System.Collections;
using System.Threading.Tasks;
using System.Collections.Generic;
using Webscraper.Documents;
using Webscraper.Extractors;
using Webscraper.Saxy;
using Sax.Net;
using System.IO;

namespace Webscraper
{
    public class Program
    {
        static WebProxy prox = new WebProxy("http://nyc-proxy:8080");

        static NetworkCredential nc = new NetworkCredential("usi\\olayemiadejumo", "Junior12==00000");


        static void Main()
        {

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Extractor extractor = new ArticleExtractor();



    

            WebClient wb = new WebClient();


            prox.Credentials = System.Net.CredentialCache.DefaultCredentials;

            wb.Proxy = prox;




            var html = wb.DownloadString("https://www.forbes.com/sites/gordonkelly/2019/02/14/apple-new-iphone-8-7-upgrade-qualcomm-intel-iphone-xs-max-xr/#4610b8c55b67");


            //string rr = extractor.GetText(html);

            //Console.WriteLine(rr);




            HTMLHighlighter hh = HTMLHighlighter.NewExtractingInstance();

            Uri uri = new Uri("https://www.forbes.com/sites/gordonkelly/2019/02/14/apple-new-iphone-8-7-upgrade-qualcomm-intel-iphone-xs-max-xr/#4610b8c55b67");



            //StreamReader sr = new StreamReader(wb.OpenRead(uri));
            //Console.WriteLine(sr.ReadToEnd());

            hh.Process(uri, extractor);


            //InputSource IN = HTMLFetcher.Fetch(uri).ToInputSource();

            //SAXInput SX = new SAXInput(IN);

            //TextDocument doc = SX.GetTextDocument();

            //Console.WriteLine("Alow.... " + doc.GetContent());


            //Console.WriteLine("sssss-xxxx");

            //TextBlock tb = new TextBlock(new StringBuilder("yemi"));

            //var tb12 = (TextBlock) tb.Clone();

            //List<string> me = new List<string>();

            //me.Add("romp");
            //me.Add("romper");
            //me.Add("romperist");

            //Console.WriteLine(string.Join(",", me));


            //Console.WriteLine(tb.GetText());
            //Console.WriteLine(tb12.GetText());


            Console.ReadLine();

        }



    }


}
