﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections;
using System.Threading.Tasks;
using System.Collections.Generic;
using Webscraper.Documents;


namespace Webscraper
{
    public class Program
    {

        static void Main()
        {

            
            Console.WriteLine("sssss-xxxx");

            TextBlock tb = new TextBlock(new StringBuilder("yemi"));

            var tb12 = (TextBlock) tb.Clone();

            List<string> me = new List<string>();

            me.Add("romp");
            me.Add("romper");
            me.Add("romperist");

            Console.WriteLine(string.Join(",", me));


            Console.WriteLine(tb.GetText());
            Console.WriteLine(tb12.GetText());


            Console.ReadLine();

        }



    }


}
