﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Conditions;

namespace Webscraper.Labels
{

    public class DefaultLabels
    {
        public static string TITLE = "de.l3s.boilerpipe/TITLE";
        public static string ARTICLE_METADATA = "de.l3s.boilerpipe/ARTICLE_METADATA";
        public static string INDICATES_END_OF_TEXT = "de.l3s.boilerpipe/INDICATES_END_OF_TEXT";
        public static string MIGHT_BE_CONTENT = "de.l3s.boilerpipe/MIGHT_BE_CONTENT";
        public static string VERY_LIKELY_CONTENT = "de.l3s.boilerpipe/VERY_LIKELY_CONTENT";
        public static string STRICTLY_NOT_CONTENT = "de.l3s.boilerpipe/STRICTLY_NOT_CONTENT";
        public static string HR = "de.l3s.boilerpipe/HR";
        public static string LI = "de.l3s.boilerpipe/LI";
                      
        public static string HEADING = "de.l3s.boilerpipe/HEADING";
        public static string H1 = "de.l3s.boilerpipe/H1";
        public static string H2 = "de.l3s.boilerpipe/H2";
        public static string H3 = "de.l3s.boilerpipe/H3";

        public static string MARKUP_PREFIX = "<";

        private DefaultLabels()
        {
            // not to be instantiated
        }
    }

    public class ConditionalLabelAction : LabelAction
    {

        TextBlockCondition condition;

        public ConditionalLabelAction(TextBlockCondition condition, params string[] labels) : base(labels)
        {
            this.condition = condition;

        }

        public void AddTo(TextBlock tb)
        {
            if(condition.meetsCondition(tb))
            {
                AddLabelsTo(tb);
            }
        }

    }

    public class LabelAction
    {
        string[] labels;


        public LabelAction(params string[] labels)
        {
            this.labels = labels;
        }

        public void AddTo(TextBlock tb)
        {
            AddLabelsTo(tb);
        }

        protected void AddLabelsTo(TextBlock tb)
        {
            tb.AddLabels(labels);
        }

        public override string ToString()
        {
            return base.ToString() + "{" + string.Join(" ", labels) + "}";

        }
    }


    
}
