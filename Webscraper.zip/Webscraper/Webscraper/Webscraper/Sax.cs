﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax.Net.Helpers;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Exception;
using TagSoup.Net;
using HtmlAgilityPack;

namespace Webscraper.Saxy
{
    public class CommonTagActions
    {
        private CommonTagActions()
        {
        }

        public class Chained : TagAction
        {

            private TagAction t1;
            private TagAction t2;

            public Chained(TagAction t1, TagAction t2)
            {
                this.t1 = t1;
                this.t2 = t2;
            }

            public bool Start(HTMLContentHandler instance, String localName, String qName,
                IAttributes atts)
            {
                return t1.Start(instance, localName, qName, atts)
                    | t2.Start(instance, localName, qName, atts);
            }

            public bool End(HTMLContentHandler instance, String localName, String qName)

            {
                return t1.End(instance, localName, qName) | t2.End(instance, localName, qName);
            }

            public bool ChangesTagLevel()
            {
                return t1.ChangesTagLevel() || t2.ChangesTagLevel();
            }
        }

        /**
         * Marks this tag as "ignorable", i.e. all its inner content is silently skipped.
         */

        public class TA1 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
        String qName, IAttributes atts)
            {
                instance.inIgnorableElement++;
                return true;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                instance.inIgnorableElement--;
                return true;
            }

            public bool ChangesTagLevel()
            {
                return true;
            }


        }

        public static TagAction TA_IGNORABLE_ELEMENT = new TA1();




        /**
         * Marks this tag as "anchor" (this should usually only be set for the <code>&lt;A&gt;</code>
         * tag). Anchor tags may not be nested.
         * 
         * There is a bug in certain versions of NekoHTML which still allows nested tags. If boilerpipe
         * encounters such nestings, a SAXException is thrown.
         */


        public class TA2 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
     String qName, IAttributes atts)
            {
                if (instance.inAnchor++ > 0)
                {
                    // as nested A elements are not allowed per specification, we
                    // are probably reaching this branch due to a bug in the XML
                    // parser
                    Console.Error.WriteLine("Warning: SAX input contains nested A elements -- You have probably hit a bug in your HTML parser (e.g., NekoHTML bug #2909310). Please clean the HTML externally and feed it to boilerpipe again. Trying to recover somehow...");

                    End(instance, localName, qName);
                }
                if (instance.inIgnorableElement == 0)
                {
                    instance.AddWhitespaceIfNecessary();
                    instance.tokenBuffer.Append(HTMLContentHandler.ANCHOR_TEXT_START);
                    instance.tokenBuffer.Append(' ');
                    instance.sbLastWasWhitespace = true;
                }
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                if (--instance.inAnchor == 0)
                {
                    if (instance.inIgnorableElement == 0)
                    {
                        instance.AddWhitespaceIfNecessary();
                        instance.tokenBuffer.Append(HTMLContentHandler.ANCHOR_TEXT_END);
                        instance.tokenBuffer.Append(' ');
                        instance.sbLastWasWhitespace = true;
                    }
                }
                return false;
            }

            public bool ChangesTagLevel()
            {
                return true;
            }


        }
        public static TagAction TA_ANCHOR_TEXT = new TA2();


        /**
         * Marks this tag the body element (this should usually only be set for the
         * <code>&lt;BODY&gt;</code> tag).
         */

        public class TA3 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
                 String qName, IAttributes atts)
            {
                instance.FlushBlock();
                instance.inBody++;
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                instance.FlushBlock();
                instance.inBody--;
                return false;
            }

            public bool ChangesTagLevel()
            {
                return true;
            }


        }

        public static TagAction TA_BODY = new TA3();


        /**
         * Marks this tag a simple "inline" element, which generates whitespace, but no new block.
         */

        public class TA4 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
     String qName, IAttributes atts)
            {
                instance.AddWhitespaceIfNecessary();
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                instance.AddWhitespaceIfNecessary();
                return false;
            }

            public bool ChangesTagLevel()
            {
                return false;
            }



        }
        public static TagAction TA_INLINE_WHITESPACE = new TA4();



        /**
         * @deprecated Use {@link #TA_INLINE_WHITESPACE} instead
         */
        //@Deprecated
        //public static final TagAction TA_INLINE = TA_INLINE_WHITESPACE;

        /**
         * Marks this tag a simple "inline" element, which neither generates whitespace, nor a new block.
         */

        public class TA5 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
     String qName, IAttributes atts)
            {
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                return false;
            }

            public bool ChangesTagLevel()
            {
                return false;
            }


        }

        public static TagAction TA_INLINE_NO_WHITESPACE = new TA5();

        private static Regex PAT_FONT_SIZE = new Regex(@"([\\+\\-]?)([0-9])");

        /**
         * Explicitly marks this tag a simple "block-level" element, which always generates whitespace
         */

        public class TA6 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
      String qName, IAttributes atts)
            {
                return true;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                return true;
            }

            public bool ChangesTagLevel()
            {
                return true;
            }

        }

        public static TagAction TA_BLOCK_LEVEL = new TA6();


        /**
         * Special TagAction for the <code>&lt;FONT&gt;</code> tag, which keeps track of the absolute and
         * relative font size.
         */
        public class TA7 : TagAction
        {
            public bool Start(HTMLContentHandler instance, String localName,
     String qName, IAttributes atts)
            {

                String sizeAttr = atts.GetValue("size");
                if (sizeAttr != null)
                {
                    Match m = PAT_FONT_SIZE.Match(sizeAttr);
                    if (Regex.Match(sizeAttr, "^([\\+\\-] ?)([0 - 9])$").Success)
                    {
                        String rel = m.Groups[1].Value;
                        int val;

                        int.TryParse(m.Groups[2].Value, out val);
                        int size;
                        if (rel.Length == 0)
                        {
                            // absolute
                            size = val;
                        }
                        else
                        {
                            // relative
                            int prevSize;
                            if (instance.fontSizeStack.Any())
                            {
                                prevSize = 3;
                            }
                            else
                            {
                                prevSize = 3;
                                foreach (int? s in instance.fontSizeStack)
                                {
                                    if (s != null)
                                    {
                                        prevSize = (int)s;
                                        break;
                                    }
                                }
                            }
                            if (rel.ToCharArray().ElementAt(0) == '+')
                            {
                                size = prevSize + val;
                            }
                            else
                            {
                                size = prevSize - val;
                            }

                        }
                        instance.fontSizeStack.AddFirst(size);
                    }
                    else
                    {
                        instance.fontSizeStack.AddFirst(null);
                    }
                }
                else
                {
                    instance.fontSizeStack.AddFirst(null);
                }
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                instance.fontSizeStack.RemoveFirst();
                return false;
            }

            public bool ChangesTagLevel()
            {
                return false;
            }


        }

        public static TagAction TA_FONT = new TA7();


        /**
         * {@link CommonTagActions} for inline elements, which triggers some {@link LabelAction} on the
         * generated {@link TextBlock}.
         */
        public class InlineTagLabelAction : TagAction
        {

            private LabelAction action;

            public InlineTagLabelAction(LabelAction action)
            {
                this.action = action;
            }

            public bool Start(HTMLContentHandler instance, String localName,
                 String qName, IAttributes atts)
            {
                instance.AddWhitespaceIfNecessary();
                instance.AddLabelAction(action);
                return false;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                instance.AddWhitespaceIfNecessary();
                return false;
            }

            public bool ChangesTagLevel()
            {
                return false;
            }
        }

        /**
         * {@link CommonTagActions} for block-level elements, which triggers some {@link LabelAction} on
         * the generated {@link TextBlock}.
         */
        public class BlockTagLabelAction : TagAction
        {

            private LabelAction action;

            public BlockTagLabelAction(LabelAction action)
            {
                this.action = action;
            }

            public bool Start(HTMLContentHandler instance, String localName,
                 String qName, IAttributes atts)
            {
                instance.AddLabelAction(action);
                return true;
            }

            public bool End(HTMLContentHandler instance, String localName,
                 String qName)
            {
                return true;
            }

            public bool ChangesTagLevel()
            {
                return true;
            }
        }



    }

    public class DefaultTagActionMap : TagActionMap
    {

        /**
           * 
           */
        private static long serialVersionUID = 1L;

        public static TagActionMap INSTANCE = new DefaultTagActionMap();

        protected DefaultTagActionMap()
        {
            SetTagAction("STYLE", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("SCRIPT", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("OPTION", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("OBJECT", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("EMBED", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("APPLET", CommonTagActions.TA_IGNORABLE_ELEMENT);
            SetTagAction("LINK", CommonTagActions.TA_IGNORABLE_ELEMENT);

            SetTagAction("A", CommonTagActions.TA_ANCHOR_TEXT);
            SetTagAction("BODY", CommonTagActions.TA_BODY);

            SetTagAction("STRIKE", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("U", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("B", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("I", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("EM", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("STRONG", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("SPAN", CommonTagActions.TA_INLINE_NO_WHITESPACE);

            // New in 1.1 (especially to improve extraction quality from Wikipedia etc.)
            SetTagAction("SUP", CommonTagActions.TA_INLINE_NO_WHITESPACE);

            // New in 1.2
            SetTagAction("CODE", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("TT", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("SUB", CommonTagActions.TA_INLINE_NO_WHITESPACE);
            SetTagAction("VAR", CommonTagActions.TA_INLINE_NO_WHITESPACE);

            SetTagAction("ABBR", CommonTagActions.TA_INLINE_WHITESPACE);
            SetTagAction("ACRONYM", CommonTagActions.TA_INLINE_WHITESPACE);

            SetTagAction("FONT", CommonTagActions.TA_INLINE_NO_WHITESPACE); // could also use TA_FONT

            // added in 1.1.1
            SetTagAction("NOSCRIPT", CommonTagActions.TA_IGNORABLE_ELEMENT);

            // New in 1.3
            SetTagAction("LI", new CommonTagActions.BlockTagLabelAction(new LabelAction(DefaultLabels.LI)));
            SetTagAction("H1", new CommonTagActions.BlockTagLabelAction(new LabelAction(DefaultLabels.H1,
                DefaultLabels.HEADING)));
            SetTagAction("H2", new CommonTagActions.BlockTagLabelAction(new LabelAction(DefaultLabels.H2,
                DefaultLabels.HEADING)));
            SetTagAction("H3", new CommonTagActions.BlockTagLabelAction(new LabelAction(DefaultLabels.H3,
                DefaultLabels.HEADING)));
        }



    }

    public class HTMLContentHandler : DefaultHandler , IContentHandler
    {


        public readonly Dictionary<String, TagAction> tagActions;
        public String title = null;


        public static String ANCHOR_TEXT_START = "$\ue00a<";
        public static String ANCHOR_TEXT_END = ">\ue00a$";



        public StringBuilder tokenBuffer = new StringBuilder();
        public StringBuilder textBuffer = new StringBuilder();

        public int inBody = 0;
        public int inAnchor = 0;
        public int inIgnorableElement = 0;

        public int tagLevel = 0;
        public int blockTagLevel = -1;

        public bool sbLastWasWhitespace = false;
        public int textElementIdx = 0;

        public List<TextBlock> textBlocks = new List<TextBlock>();

        public String lastStartTag = null;
        public String lastEndTag = null;
        public Event? lastEvent = null;

        public int offsetBlocks = 0;
        public BitArray currentContainedTextElements = new BitArray(short.MaxValue);

        public bool flush = false;
        public bool inAnchorText = false;

        LinkedList<LinkedList<LabelAction>> labelStacks = new LinkedList<LinkedList<LabelAction>>();
        public LinkedList<int> fontSizeStack = new LinkedList<int>();

        /**
         * Recycles this instance.
         */
        public void Recycle()
        {


            tokenBuffer.Length = 0;
            textBuffer.Length = 0;

            inBody = 0;
            inAnchor = 0;
            inIgnorableElement = 0;
            sbLastWasWhitespace = false;
            textElementIdx = 0;

            textBlocks.Clear();

            lastStartTag = null;
            lastEndTag = null;
            lastEvent = null;

            offsetBlocks = 0;
            currentContainedTextElements.SetAll(false);

            flush = false;
            inAnchorText = false;
        }

        /**
         * Constructs a {@link BoilerpipeHTMLContentHandler} using the {@link DefaultTagActionMap}.
         */
        public HTMLContentHandler() : this(DefaultTagActionMap.INSTANCE)
        {

        }

        /**
         * Constructs a {@link BoilerpipeHTMLContentHandler} using the given {@link TagActionMap}.
         * 
         * @param tagActions The {@link TagActionMap} to use, e.g. {@link DefaultTagActionMap}.
         */
        public HTMLContentHandler(TagActionMap tagActions)
        {
            this.tagActions = tagActions;
        }


        public void EndDocument()
        {
            FlushBlock();
        }

        public void EndPrefixMapping(String prefix)
        {
        }

        public void IgnorableWhitespace(char[] ch, int start, int length)
        {
            if (!sbLastWasWhitespace)
            {
                textBuffer.Append(' ');
                tokenBuffer.Append(' ');
            }
            sbLastWasWhitespace = true;
        }


        public void ProcessingInstruction(String target, String data)
        {

        }

        public void SetDocumentLocator(ILocator locator)
        {
        }


        public void SkippedEntity(String name)
        {
        }


        public void StartDocument()
        {
        }

        public void StartPrefixMapping(String prefix, String uri)
        {
        }

        public void StartElement(String uri, String localName, String qName, IAttributes atts)
        {
            labelStacks.AddLast((LinkedList<LabelAction>)null);

            Console.WriteLine("loco - " + localName);
            //Console.WriteLine("loco - " + String.Join(",", tagActions.Keys));

            Console.ReadLine();

            TagAction ta;

            //= tagActions.Where(n => n.Key == localName).Select(n => n.Value).Single();
            if (tagActions.TryGetValue(localName, out ta))
            {
                if (ta.ChangesTagLevel())
                {
                    tagLevel++;
                }
                flush = ta.Start(this, localName, qName, atts) | flush;
            }
            else
            {
                tagLevel++;
                flush = true;
            }

            lastEvent = Event.START_TAG;
            lastStartTag = localName;
            Console.WriteLine("woop woop");
        }


        public void EndElement(String uri, String localName, String qName)
        {
            TagAction ta;
                //= tagActions.Where(n => n.Key == localName).Select(n => n.Value).Single();
            if (tagActions.TryGetValue(localName, out ta))
            {
                flush = ta.End(this, localName, qName) | flush;
            }
            else
            {
                flush = true;
            }

            if (ta == null || ta.ChangesTagLevel())
            {
                tagLevel--;
            }

            if (flush)
            {
                FlushBlock();
            }

            lastEvent = Event.END_TAG;
            lastEndTag = localName;

            labelStacks.RemoveLast();
        }

        public void Characters(char[] ch, int start, int length)
        {
            textElementIdx++;


            if (flush)
            {
                FlushBlock();
                flush = false;
            }

            if (inIgnorableElement != 0)
            {
                return;
            }

            char c;
            bool startWhitespace = false;
            bool endWhitespace = false;
            if (length == 0)
            {
                return;
            }

            int end = start + length;
            for (int i = start; i < end; i++)
            {

                if (Char.IsWhiteSpace(ch[i]))
                {
                    ch[i] = ' ';
                }
            }
            while (start < end)
            {
                c = ch[start];
                if (c == ' ')
                {
                    startWhitespace = true;
                    start++;
                    length--;
                }
                else
                {
                    break;
                }
            }
            while (length > 0)
            {
                c = ch[start + length - 1];
                if (c == ' ')
                {
                    endWhitespace = true;
                    length--;
                }
                else
                {
                    break;
                }
            }
            if (length == 0)
            {
                if (startWhitespace || endWhitespace)
                {
                    if (!sbLastWasWhitespace)
                    {
                        textBuffer.Append(' ');
                        tokenBuffer.Append(' ');
                    }
                    sbLastWasWhitespace = true;
                }
                else
                {
                    sbLastWasWhitespace = false;
                }
                lastEvent = Event.WHITESPACE;
                return;
            }
            if (startWhitespace)
            {
                if (!sbLastWasWhitespace)
                {
                    textBuffer.Append(' ');
                    tokenBuffer.Append(' ');
                }
            }

            if (blockTagLevel == -1)
            {
                blockTagLevel = tagLevel;
            }

            textBuffer.Append(ch, start, length);
            tokenBuffer.Append(ch, start, length);
            if (endWhitespace)
            {
                textBuffer.Append(' ');
                tokenBuffer.Append(' ');
            }

            sbLastWasWhitespace = endWhitespace;
            lastEvent = Event.CHARACTERS;

            currentContainedTextElements.Set(textElementIdx, true);
        }

        List<TextBlock> GetTextBlocks()
        {
            return textBlocks;
        }

        public void FlushBlock()
        {
            if (inBody == 0)
            {
                if ("TITLE".ToLower().Equals(lastStartTag) && inBody == 0)
                {
                    SetTitle(tokenBuffer.ToString().Trim());
                }
                textBuffer.Length = 0;
                tokenBuffer.Length = 0;
                return;
            }

            int length = tokenBuffer.Length;
            switch (length)
            {
                case 0:
                    return;
                case 1:
                    if (sbLastWasWhitespace)
                    {
                        textBuffer.Length = 0;
                        tokenBuffer.Length = 0;
                        return;
                    }
                    break;
            }
            String[] tokens = UnicodeTokenizer.tokenize(tokenBuffer.ToString());

            int numWords = 0;
            int numLinkedWords = 0;
            int numWrappedLines = 0;
            int currentLineLength = -1; // don't count the first space
            int maxLineLength = 80;
            int numTokens = 0;
            int numWordsCurrentLine = 0;

            foreach (String token in tokens)
            {
                if (ANCHOR_TEXT_START.Equals(token))
                {
                    inAnchorText = true;
                }
                else if (ANCHOR_TEXT_END.Equals(token))
                {
                    inAnchorText = false;
                }
                else if (IsWord(token))
                {
                    numTokens++;
                    numWords++;
                    numWordsCurrentLine++;
                    if (inAnchorText)
                    {
                        numLinkedWords++;
                    }
                    int tokenLength = token.Length;
                    currentLineLength += tokenLength + 1;
                    if (currentLineLength > maxLineLength)
                    {
                        numWrappedLines++;
                        currentLineLength = tokenLength;
                        numWordsCurrentLine = 1;
                    }
                }
                else
                {
                    numTokens++;
                }
            }
            if (numTokens == 0)
            {
                return;
            }
            int numWordsInWrappedLines;
            if (numWrappedLines == 0)
            {
                numWordsInWrappedLines = numWords;
                numWrappedLines = 1;
            }
            else
            {
                numWordsInWrappedLines = numWords - numWordsCurrentLine;
            }

            TextBlock tb =
                new TextBlock(textBuffer, currentContainedTextElements, numWords,
                    numLinkedWords, numWordsInWrappedLines, numWrappedLines, offsetBlocks);
            currentContainedTextElements = new BitArray(100);

            offsetBlocks++;

            textBuffer.Length = 0;
            tokenBuffer.Length = 0;

            tb.SetTagLevel(blockTagLevel);
            AddTextBlock(tb);
            blockTagLevel = -1;
        }

        protected void AddTextBlock(TextBlock tb)
        {

            foreach (int? l in fontSizeStack)
            {
                if (l != null)
                {
                    tb.AddLabel("font-" + l);
                    break;
                }
            }
            foreach (LinkedList<LabelAction> labelStack in labelStacks)
            {
                if (labelStack != null)
                {
                    foreach (LabelAction labels in labelStack)
                    {
                        if (labels != null)
                        {
                            labels.AddTo(tb);
                        }
                    }
                }
            }

            textBlocks.Add(tb);
        }

        public static Regex PAT_VALID_WORD_CHARACTER = new Regex("[\\p{L}\\p{Nd}\\p{Nl}\\p{No}]");

        public static bool IsWord(String token)
        {
            return PAT_VALID_WORD_CHARACTER.Match(token).Success;
        }

        public enum Event
        {
            START_TAG, END_TAG, CHARACTERS, WHITESPACE
        }

        public String GetTitle()
        {
            return title;
        }

        public void SetTitle(String s)
        {
            if (s == null || s.Length == 0)
            {
                return;
            }
            title = s;
        }


        public TextDocument ToTextDocument()
        {
            // just to be sure
            FlushBlock();

            return new TextDocument(GetTitle(), GetTextBlocks());
        }

        public void AddWhitespaceIfNecessary()
        {
            if (!sbLastWasWhitespace)
            {
                tokenBuffer.Append(' ');
                textBuffer.Append(' ');
                sbLastWasWhitespace = true;
            }
        }

        public void AddLabelAction(LabelAction la)
        {
            LinkedList<LabelAction> labelStack = labelStacks.Last();
            if (labelStack == null)
            {
                labelStack = new LinkedList<LabelAction>();
                labelStacks.RemoveLast();
                labelStacks.AddFirst(labelStack);
            }
            labelStack.AddLast(la);
        }



    }

    public class HTMLDocument
    {
        private Encoding charset;
        private byte[] data;

        public HTMLDocument(byte[] data, Encoding charset)
        {
            this.data = data;
            this.charset = charset;
            //Console.WriteLine("in here");

        }

        public HTMLDocument(String data)
        {
            Encoding cs = Encoding.UTF8;
            this.data = Encoding.UTF8.GetBytes(data);
            this.charset = cs;
        }

        public Encoding GetCharset()
        {
            return charset;
        }

        public byte[] GetData()
        {
            return data;
        }

        public InputSource ToInputSource()
        {
            InputSource IS = new InputSource(new MemoryStream(data));
            IS.Encoding = Encoding.UTF8;
            return IS;
        }



    }

    public class HTMLFetcher
    {
        private HTMLFetcher()
        {
        }

        private static Regex PAT_CHARSET = new Regex("charset=([^; ]+)$");


        public static HTMLDocument Fetch(Uri url)
        {

            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse res = (HttpWebResponse)req.GetResponse();

            WebClient wb = new WebClient();

            Stream stream = wb.OpenRead(url);


            string ct = res.ContentType; //wb.ResponseHeaders["Content-Type"];



            if (ct == null || !(ct.Equals("text/html") || ct.StartsWith("text/html;")))
            {
                throw new IOException("Unsupported content type: " + ct);
            }

            Encoding cs = Encoding.GetEncoding(1252); // Charset.forName("Cp1252");
            if (ct != null)
            {
                Match m = PAT_CHARSET.Match(ct); // PAT_CHARSET.matcher(ct);
                if (m.Success)
                {
                    String charset = m.Groups[1].Value;
                    try
                    {
                        cs = Encoding.GetEncoding(charset);
                    }
                    catch (System.Exception e)
                    {
                        Console.WriteLine("unsupported charsetexception");

                    }
                }
            }

            Stream IN = res.GetResponseStream(); // wb.OpenRead(url); // conn.getInputStream();

            Console.WriteLine(res.ContentType);


            String encoding = res.ContentEncoding; // conn.getContentEncoding();
            if (encoding != null)
            {
                if ("gzip".ToLower().Equals(encoding))
                {
                    IN = new GZipStream(IN, CompressionMode.Decompress);
                }
                else
                {
                    Console.WriteLine("WARN: unsupported Content-Encoding: " + encoding);
                }
            }

            MemoryStream bos = new MemoryStream();
            byte[] buf = new byte[4096];
            int r;
            //Console.WriteLine(buf.Length);
            //Console.WriteLine(IN.);
            //Console.ReadLine();

            while ((r = IN.ReadByte()) != -1)
            {
                bos.Write(buf, 0, r);
            }
            IN.Close();
            //Console.WriteLine("...out");
            byte[] data = bos.ToArray();

            return new HTMLDocument(data, cs);
        }





    }

    public class HTMLHighlighter
    {
        public Dictionary<String, HashSet<String>> tagWhitelist = null;

        /**
         * Creates a new {@link HTMLHighlighter}, which is set-up to return the full HTML text, with the
         * extracted text portion <b>highlighted</b>.
         */


        public static HTMLHighlighter NewHighlightingInstance()
        {
            return new HTMLHighlighter(false);
        }

        /**
         * Creates a new {@link HTMLHighlighter}, which is set-up to return only the extracted HTML text,
         * including enclosed markup.
         */
        public static HTMLHighlighter NewExtractingInstance()
        {
            return new HTMLHighlighter(true);
        }

        public HTMLHighlighter(bool extractHTML)
        {
            if (extractHTML)
            {
                SetOutputHighlightOnly(true);
                SetExtraStyleSheet("\n<style type=\"text/css\">\n" + "A:before { content:' '; } \n" //
                    + "A:after { content:' '; } \n" //
                    + "SPAN:before { content:' '; } \n" //
                    + "SPAN:after { content:' '; } \n" //
                    + "</style>\n");
                SetPreHighlight("");
                SetPostHighlight("");
            }
        }

        /**
         * Processes the given {@link TextDocument} and the original HTML text (as a String).
         * 
         * @param doc The processed {@link TextDocument}.
         * @param origHTML The original HTML document.
         * @return The highlighted HTML.
         * @throws BoilerpipeProcessingException
         */
        public String Process(TextDocument doc, String origHTML)

        {
            return Process(doc, new InputSource(new StringReader(origHTML)));
        }

        /**
         * Processes the given {@link TextDocument} and the original HTML text (as an {@link InputSource}
         * ).
         * 
         * @param doc The processed {@link TextDocument}.
         * @param is The original HTML document.
         * @return The highlighted HTML.
         * @throws BoilerpipeProcessingException
         */
        public String Process(TextDocument doc, InputSource IS)

        {
            Implementation implementation = new Implementation();
            implementation.Process(doc, IS);


            String html = implementation.html.ToString();
            if (outputHighlightOnly)
            {
                Match m;

                bool repeat = true;
                while (repeat)
                {
                    repeat = false;
                    m = PAT_TAG_NO_TEXT.Match(html);
                    if (m.Success)
                    {
                        repeat = true;
                        html = m.Result("");
                    }

                    m = PAT_SUPER_TAG.Match(html);
                    if (m.Success)
                    {
                        repeat = true;
                        html = m.Result(m.Groups[1].Value);
                    }
                }
            }

            return html;
        }

        private static Regex PAT_TAG_NO_TEXT = new Regex("<[^/][^>]*></[^>]*>");
        private static Regex PAT_SUPER_TAG = new Regex("^<[^>]*>(<.*?>)</[^>]*>$");

        /**
         * Fetches the given {@link URL} using {@link HTMLFetcher} and processes the retrieved HTML using
         * the specified {@link BoilerpipeExtractor}.
         * 
         * @param doc The processed {@link TextDocument}.
         * @param is The original HTML document.
         * @return The highlighted HTML.
         * @throws BoilerpipeProcessingException
         */
        public String Process(Uri url, Extractor extractor)
        {
            HTMLDocument htmlDoc = HTMLFetcher.Fetch(url);
            //Console.WriteLine("highlighter");

            TextDocument doc = new SAXInput(htmlDoc.ToInputSource()).GetTextDocument();
            Console.WriteLine("1");
            Console.WriteLine("highlighter");
            extractor.Process(doc);

            InputSource IS = htmlDoc.ToInputSource();


            return Process(doc, IS);

        }

        public bool outputHighlightOnly = false;
        public String extraStyleSheet = "\n<style type=\"text/css\">\n" + ".x-boilerpipe-mark1 {"
            + " text-decoration:none; " + "background-color: #ffff42 !important; "
            + "color: black !important; " + "display:inline !important; "
            + "visibility:visible !important; }\n" + //
            "</style>\n";
        public String preHighlight = "<span class=\"x-boilerpipe-mark1\">";
        public String postHighlight = "</span>";

        /**
         * If true, only HTML enclosed within highlighted content will be returned
         */
        public bool IsOutputHighlightOnly()
        {
            return outputHighlightOnly;
        }

        /**
         * Sets whether only HTML enclosed within highlighted content will be returned, or the whole HTML
         * document.
         */
        public void SetOutputHighlightOnly(bool outputHighlightOnly)
        {
            this.outputHighlightOnly = outputHighlightOnly;
        }

        /**
         * Returns the extra stylesheet definition that will be inserted in the HEAD element.
         * 
         * By default, this corresponds to a simple definition that marks text in class
         * "x-boilerpipe-mark1" as inline text with yellow background.
         */
        public String GetExtraStyleSheet()
        {
            return extraStyleSheet;
        }

        /**
         * Sets the extra stylesheet definition that will be inserted in the HEAD element.
         * 
         * To disable, set it to the empty string: ""
         * 
         * @param extraStyleSheet Plain HTML
         */
        public void SetExtraStyleSheet(String extraStyleSheet)
        {
            this.extraStyleSheet = extraStyleSheet;
        }

        /**
         * Returns the string that will be inserted before any highlighted HTML block.
         * 
         * By default, this corresponds to <code>&lt;span class=&qupt;x-boilerpipe-mark1&quot;&gt;</code>
         */
        public String GetPreHighlight()
        {
            return preHighlight;
        }

        /**
         * Sets the string that will be inserted prior to any highlighted HTML block.
         * 
         * To disable, set it to the empty string: ""
         */
        public void SetPreHighlight(String preHighlight)
        {
            this.preHighlight = preHighlight;
        }

        /**
         * Returns the string that will be inserted after any highlighted HTML block.
         * 
         * By default, this corresponds to <code>&lt;/span&gt;</code>
         */
        public String GetPostHighlight()
        {
            return postHighlight;
        }

        /**
         * Sets the string that will be inserted after any highlighted HTML block.
         * 
         * To disable, set it to the empty string: ""
         */
        public void SetPostHighlight(String postHighlight)
        {
            this.postHighlight = postHighlight;
        }

        public abstract class TagAction
        {
            public virtual void BeforeStart(Implementation instance, String localName)
            {
            }

            public virtual void AfterStart(Implementation instance, String localName)
            {
            }

            public virtual void BeforeEnd(Implementation instance, String localName)
            {
            }

            public virtual void AfterEnd(Implementation instance, String localName)
            {
            }
        }

        public class TagAction1 : TagAction
        {
            public override void BeforeStart(Implementation instance, String localName)
            {
                instance.inIgnorableElement++;
            }

            public override void AfterEnd(Implementation instance, String localName)
            {
                instance.inIgnorableElement--;
            }
        }

        public class TagAction2 : TagAction
        {
            public override void BeforeStart(Implementation instance, String localName)
            {
                instance.inIgnorableElement++;
            }

            public override void BeforeEnd(Implementation instance, String localName)
            {
                instance.html.Append(instance.hl.extraStyleSheet);
            }

            public override void AfterEnd(Implementation instance, String localName)
            {
                instance.inIgnorableElement--;
            }

        }
        public TagAction1 TA_IGNORABLE_ELEMENT = new TagAction1();

        private static TagAction2 TA_HEAD = new TagAction2();

        private static Dictionary<String, TagAction> TAG_ACTIONS = new Dictionary<String, TagAction>();

        public void TAG()
        {


            TAG_ACTIONS.Add("STYLE", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("SCRIPT", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("OPTION", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("NOSCRIPT", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("OBJECT", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("EMBED", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("APPLET", TA_IGNORABLE_ELEMENT);

            // NOTE: you might want to comment this out:
            TAG_ACTIONS.Add("LINK", TA_IGNORABLE_ELEMENT);

            TAG_ACTIONS.Add("HEAD", TA_HEAD);


        }

        public class Implementation : TagSoup.Net.Parser//, IContentHandler
        {
            public StringBuilder html = new StringBuilder();


            public int inIgnorableElement = 0;
            public int characterElementIdx = 0;
            public BitArray contentBitSet = new BitArray(100000);
            public HTMLHighlighter hl = new HTMLHighlighter(true);


            public Implementation() : base()
            {

                SetContentHandler(this);
            }

            public void SetContentHandler(IContentHandler implementation)
            {
                throw new NotImplementedException();
            }

            public void Process(TextDocument doc, InputSource IS)
            {
                foreach (TextBlock block in doc.GetTextBlocks())
                {
                    if (block.IsContent())
                    {
                        BitArray bs = block.GetContainedTextElements();
                        if (bs != null)
                        {
                            contentBitSet.Or(bs);
                        }
                    }
                }

                try
                {
                    Parse(IS);
                }
                catch (SAXException e)
                {
                    throw new WebscraperException(e);
                }
                catch (IOException e)
                {
                    throw new WebscraperException(e);
                }
            }

            public void EndDocument()
            {
            }

            public void EndPrefixMapping(String prefix)
            {
            }

            public void IgnorableWhitespace(char[] ch, int start, int length)
            {
            }

            public void ProcessingInstruction(String target, String data)
            {
            }

            public void SetDocumentLocator(ILocator locator)
            {
            }

            public void SkippedEntity(String name)
            {
            }

            public void StartDocument()
            {
            }

            public void StartElement(String uri, String localName, String qName, IAttributes atts)

            {
                TagAction ta = TAG_ACTIONS.Where(n => n.Key == localName).Select(n => n.Value).Single();
                if (ta != null)
                {
                    ta.BeforeStart(this, localName);
                }

                // HACK: remove existing highlight
                bool ignoreAttrs = false;
                if ("SPAN".ToLower().Equals(localName))
                {
                    String classVal = atts.GetValue("class");
                    if ("x-boilerpipe-mark1".Equals(classVal))
                    {
                        ignoreAttrs = true;
                    }
                }

                try
                {
                    if (inIgnorableElement == 0)
                    {
                        if (hl.outputHighlightOnly)
                        {
                            // boolean highlight = contentBitSet
                            // .get(characterElementIdx);

                            // if (!highlight) {
                            // return;
                            // }
                        }

                        HashSet<String> whitelistAttributes;
                        if (hl.tagWhitelist == null)
                        {
                            whitelistAttributes = null;
                        }
                        else
                        {
                            whitelistAttributes = hl.tagWhitelist.Where(n => n.Key == qName).Select(n => n.Value).Single();
                            if (whitelistAttributes == null)
                            {
                                // skip
                                return;
                            }
                        }

                        html.Append('<');
                        html.Append(qName);
                        if (!ignoreAttrs)
                        {
                            int numAtts = atts.Length;
                            for (int i = 0; i < numAtts; i++)
                            {
                                String attr = atts.GetQName(i);

                                if (whitelistAttributes != null && !whitelistAttributes.Contains(attr))
                                {
                                    // skip
                                    continue;
                                }

                                String value = atts.GetValue(i);
                                html.Append(' ');
                                html.Append(attr);
                                html.Append("=\"");
                                html.Append(XmlEncode(value));
                                html.Append("\"");
                            }
                        }
                        html.Append('>');
                    }
                }
                finally
                {
                    if (ta != null)
                    {
                        ta.AfterStart(this, localName);
                    }
                }
            }

            public new void EndElement(String uri, String localName, String qName)
            {
                TagAction ta = TAG_ACTIONS.Where(n => n.Key == localName).Select(n => n.Value).Single();
                if (ta != null)
                {
                    ta.BeforeEnd(this, localName);
                }

                try
                {
                    if (inIgnorableElement == 0)
                    {
                        if (hl.outputHighlightOnly)
                        {
                            // boolean highlight = contentBitSet
                            // .get(characterElementIdx);

                            // if (!highlight) {
                            // return;
                            // }
                        }

                        if (hl.tagWhitelist != null && !hl.tagWhitelist.ContainsKey(qName))
                        {
                            // skip
                            return;
                        }

                        html.Append("</");
                        html.Append(qName);
                        html.Append('>');
                    }
                }
                finally
                {
                    if (ta != null)
                    {
                        ta.AfterEnd(this, localName);
                    }
                }
            }

            public void Characters(char[] ch, int start, int length)
            {
                characterElementIdx++;
                if (inIgnorableElement == 0)
                {

                    bool highlight = contentBitSet.Get(characterElementIdx);

                    if (!highlight && hl.outputHighlightOnly)
                    {
                        return;
                    }

                    if (highlight)
                    {
                        html.Append(hl.preHighlight);
                    }
                    html.Append(XmlEncode(ch[1].ToString()));
                    if (highlight)
                    {
                        html.Append(hl.postHighlight);
                    }
                }
            }

            public void StartPrefixMapping(String prefix, String uri)
            {
            }

        }

        private static String XmlEncode(String IN)
        {
            if (IN == null)
            {
                return "";
            }
            char c;
            StringBuilder OUT = new StringBuilder(IN.Length);

            for (int i = 0; i < IN.Length; i++)
            {
                c = IN.ToCharArray().ElementAt(i);
                switch (c)
                {
                    case '<':
                        OUT.Append("&lt;");
                        break;
                    case '>':
                        OUT.Append("&gt;");
                        break;
                    case '&':
                        OUT.Append("&amp;");
                        break;
                    case '"':
                        OUT.Append("&quot;");
                        break;
                    default:
                        OUT.Append(c);
                        break;
                }
            }

            return OUT.ToString();
        }

        public Dictionary<String, HashSet<String>> GetTagWhitelist()
        {
            return tagWhitelist;
        }

        public void SetTagWhitelist(Dictionary<String, HashSet<String>> tagWhitelist)
        {
            this.tagWhitelist = tagWhitelist;
        }



    }

    //public class HTMLParser : TagSoup.Net.Parser, DocumentSource
    //{
    //private HTMLContentHandler contentHandler;

    //public HTMLParser() : this(new HTMLContentHandler())
    //{

    //}

    //public HTMLParser(HTMLContentHandler contentHandler) : base()
    //{

    //    SetContentHandler(contentHandler);


    //}



    //protected HTMLParser(bool ignore)
    //{
    //    //base(new HTMLConfiguration());
    //}

    //public void SetContentHandler(HTMLContentHandler contentHandler)
    //{
    //    this.contentHandler = contentHandler;
    //    base.ContentHandler = contentHandler;
    //    //(contentHandler);
    //}

    //public void SetContentHandler(IContentHandler contentHandler)
    //{
    //    this.contentHandler = null;
    //    base.ContentHandler = contentHandler;


    //}

    //public TextDocument ToTextDocument()
    //{
    //    return contentHandler.ToTextDocument();
    //}


    public class HTMLParser : IXmlReader
    {
        public bool GetFeature(string name)
        {
            throw new NotSupportedException();
        }

        public void SetFeature(string name, bool value)
        {
            throw new NotSupportedException();

        }

        public object GetProperty(string name)
        {
            throw new NotSupportedException();
        }

        public void SetProperty(string name, object value)
        {
            throw new NotSupportedException();
        }

        public void Parse(InputSource input)
        {
            var document = new HtmlDocument();
            if (input.Stream != null)
            {
                document.Load(input.Stream, input.Encoding);
            }
            else if (input.Reader != null)
            {
                document.Load(input.Reader);
            }
            else if (input.PublicId != null)
            {
                document.Load(input.PublicId);
            }
            else if (input.SystemId != null)
            {
                document.Load(input.SystemId);
            }

            ContentHandler.StartDocument();

            TraverseNode(document.DocumentNode);

            ContentHandler.EndDocument();
        }

        public void Parse(string systemId)
        {
            Parse(new InputSource(systemId));
        }

        public IEntityResolver EntityResolver { get; set; }
        public IDTDHandler DTDHandler { get; set; }
        public IContentHandler ContentHandler { get; set; } = new HTMLContentHandler();
        public IErrorHandler ErrorHandler { get; set; }

        private void TraverseNode(HtmlNode htmlNode)
        {
            if (htmlNode == null || htmlNode.NodeType == HtmlNodeType.Comment)
            {



                return;


            }

            var attributes = new Attributes();
            if (htmlNode.HasAttributes)
            { 
                foreach (HtmlAttribute attribute in htmlNode.Attributes)
                {
                    attributes.AddAttribute(null, htmlNode.Name, attribute.Name, null, attribute.Value);
                }
            }

            ContentHandler.StartElement(null, htmlNode.Name, htmlNode.Name, attributes);
            if (htmlNode.NodeType == HtmlNodeType.Text)
            {
                ContentHandler.Characters(htmlNode.InnerText.ToCharArray(), 0, htmlNode.InnerText.Length);
            }
            else if (htmlNode.HasChildNodes)
            {
                foreach (HtmlNode childNode in htmlNode.ChildNodes)
                {
                    TraverseNode(childNode);
                }
            }
            ContentHandler.EndElement(null, htmlNode.Name, htmlNode.Name);
        }

        public TextDocument ToTextDocument()
        {
            List<TextBlock> textBlocks = new List<TextBlock>();

            TextDocument text = new TextDocument(textBlocks);

            return text;
        }
    }



    public interface InputSourceable
    {
        InputSource ToInputSource();

    }

    public class ImageExtractor
    {
        public static ImageExtractor INSTANCE = new ImageExtractor();

        /**
         * Returns the singleton instance of {@link ImageExtractor}.
         * 
         * @return
         */
        public static ImageExtractor getInstance()
        {
            return INSTANCE;
        }

        public ImageExtractor()
        {
        }

        /**
         * Processes the given {@link TextDocument} and the original HTML text (as a String).
         * 
         * @param doc The processed {@link TextDocument}.
         * @param origHTML The original HTML document.
         * @return A List of enclosed {@link Image}s
         * @throws BoilerpipeProcessingException
         */
        public List<Image> Process(TextDocument doc, String origHTML)
        {
            return Process(doc, new InputSource(new StringReader(origHTML)));
        }

        /**
         * Processes the given {@link TextDocument} and the original HTML text (as an {@link InputSource}
         * ).
         * 
         * @param doc The processed {@link TextDocument}.
         * @param origHTML The original HTML document.
         * @return A List of enclosed {@link Image}s
         * @throws BoilerpipeProcessingException
         */
        public List<Image> Process(TextDocument doc, InputSource IS)
        {
            Implementation implementation = new Implementation();
            implementation.Process(doc, IS);

            return implementation.linksHighlight;
        }

        /**
         * Fetches the given {@link URL} using {@link HTMLFetcher} and processes the retrieved HTML using
         * the specified {@link BoilerpipeExtractor}.
         * 
         * @param doc The processed {@link TextDocument}.
         * @param is The original HTML document.
         * @return A List of enclosed {@link Image}s
         * @throws BoilerpipeProcessingException
         */
        public List<Image> Process(Uri url, Extractor extractor)
        {
            HTMLDocument htmlDoc = HTMLFetcher.Fetch(url);

            TextDocument doc = new SAXInput(htmlDoc.ToInputSource()).GetTextDocument();
            Console.WriteLine("4");
            extractor.Process(doc);

            InputSource IS = htmlDoc.ToInputSource();

            return Process(doc, IS);
        }

        public class Implementation : TagSoup.Net.Parser, IContentHandler
        {
            public List<Image> linksHighlight = new List<Image>();
            public List<Image> linksBuffer = new List<Image>();

            public int inIgnorableElement = 0;
            public int characterElementIdx = 0;
            public BitArray contentBitSet = new BitArray(10000);

            public bool inHighlight = false;

            public Implementation()
            {

                SetContentHandler(this);
            }

            public void SetContentHandler(IContentHandler contentHandler)
            {

                SetContentHandler(contentHandler);


            }

            public void Process(TextDocument doc, InputSource IS)
            {
                foreach (TextBlock block in doc.GetTextBlocks())
                {
                    if (block.IsContent())
                    {
                        BitArray bs = block.GetContainedTextElements();
                        if (bs != null)
                        {
                            contentBitSet.Or(bs);
                        }
                    }
                }

                try
                {
                    Parse(IS);
                }
                catch (SAXException e)
                {
                    throw new WebscraperException(e);
                }
                catch (IOException e)
                {
                    throw new WebscraperException(e);
                }
            }

            public new void EndDocument()
            {
            }

            public new void EndPrefixMapping(String prefix)
            {
            }

            public new void IgnorableWhitespace(char[] ch, int start, int length)
            {
            }

            public new void ProcessingInstruction(String target, String data)
            {
            }

            public void SetDocumentLocator(ILocator locator)
            {
            }

            public new void SkippedEntity(String name)
            {
            }

            public new void StartDocument()
            {
            }

            public new void StartElement(String uri, String localName, String qName, IAttributes atts)
            {
                TagAction ta = TAG_ACTIONS.Where(n => n.Key == localName).Select(n => n.Value).Single();
                if (ta != null)
                {
                    ta.BeforeStart(this, localName);
                }

                try
                {
                    if (inIgnorableElement == 0)
                    {
                        if (inHighlight && "IMG".ToLower().Equals(localName.ToLower()))
                        {
                            String src = atts.GetValue("src");
                            if (src != null && src.Length > 0)
                            {
                                linksBuffer.Add(new Image(src, atts.GetValue("width"), atts.GetValue("height"), atts
                                    .GetValue("alt")));
                            }
                        }
                    }
                }
                finally
                {
                    if (ta != null)
                    {
                        ta.AfterStart(this, localName);
                    }
                }
            }

            public void EndElement(String uri, String localName, String qName)
            {
                TagAction ta = TAG_ACTIONS.Where(n => n.Key == localName).Select(n => n.Value).Single();
                if (ta != null)
                {
                    ta.BeforeEnd(this, localName);
                }

                try
                {
                    if (inIgnorableElement == 0)
                    {
                        //
                    }
                }
                finally
                {
                    if (ta != null)
                    {
                        ta.AfterEnd(this, localName);
                    }
                }
            }

            public void Characters(char[] ch, int start, int length)
            {
                characterElementIdx++;
                if (inIgnorableElement == 0)
                {

                    bool highlight = contentBitSet.Get(characterElementIdx);
                    if (!highlight)
                    {
                        if (length == 0)
                        {
                            return;
                        }
                        bool justWhitespace = true;
                        for (int i = start; i < start + length; i++)
                        {
                            if (!Char.IsWhiteSpace(ch[i]))
                            {
                                justWhitespace = false;
                                break;
                            }
                        }
                        if (justWhitespace)
                        {
                            return;
                        }
                    }

                    inHighlight = highlight;
                    if (inHighlight)
                    {
                        linksHighlight.AddRange(linksBuffer);
                        linksBuffer.RemoveRange(0, linksBuffer.Count);
                    }
                }
            }

            public new void StartPrefixMapping(String prefix, String uri)
            {
            }

        }

        public class TagAction1 : TagAction
        {

            public override void BeforeStart(Implementation instance, String localName)
            {
                instance.inIgnorableElement++;
            }

            public override void AfterEnd(Implementation instance, String localName)
            {
                instance.inIgnorableElement--;
            }
        };

        public TagAction1 TA_IGNORABLE_ELEMENT = new TagAction1();



        public static Dictionary<String, TagAction> TAG_ACTIONS = new Dictionary<String, TagAction>();

        public void TAG()
        {

            TAG_ACTIONS.Add("STYLE", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("SCRIPT", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("OPTION", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("NOSCRIPT", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("EMBED", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("APPLET", TA_IGNORABLE_ELEMENT);
            TAG_ACTIONS.Add("LINK", TA_IGNORABLE_ELEMENT);

            TAG_ACTIONS.Add("HEAD", TA_IGNORABLE_ELEMENT);
        }

        public abstract class TagAction
        {
            public virtual void BeforeStart(Implementation instance, String localName)
            {
            }

            public virtual void AfterStart(Implementation instance, String localName)
            {
            }

            public virtual void BeforeEnd(Implementation instance, String localName)
            {
            }

            public virtual void AfterEnd(Implementation instance, String localName)
            {
            }
        }




    }

    public class MarkupTagAction : TagAction
    {

        private bool isBlockLevel;
        private LinkedList<List<String>> labelStack = new LinkedList<List<String>>();

        public MarkupTagAction(bool isBlockLevel)
        {
            this.isBlockLevel = isBlockLevel;
        }

        private static Regex PAT_NUM = new Regex("[0-9]+");

        public bool Start(HTMLContentHandler instance, String localName, String qName,
            IAttributes atts)
        {
            List<String> labels = new List<string>(5);
            labels.Add(DefaultLabels.MARKUP_PREFIX + localName);

            String classVal = atts.GetValue("class");

            if (classVal != null && classVal.Length > 0)
            {
                classVal = PAT_NUM.Replace(PAT_NUM.Match(classVal).Value, "#");
                classVal = classVal.Trim();
                String[] vals = classVal.Split(new string[] { "[ ]+" }, StringSplitOptions.None);
                labels.Add(DefaultLabels.MARKUP_PREFIX + "." + classVal.Replace(' ', '.'));
                if (vals.Length > 1)
                {
                    foreach (String s in vals)
                    {
                        labels.Add(DefaultLabels.MARKUP_PREFIX + "." + s);
                    }
                }
            }

            String id = atts.GetValue("id");
            if (id != null && id.Length > 0)
            {
                id = PAT_NUM.Replace(PAT_NUM.Match(id).Value, "#");
                labels.Add(DefaultLabels.MARKUP_PREFIX + "#" + id);
            }

            HashSet<String> ancestors = getAncestorLabels();
            List<String> labelsWithAncestors = new List<String>((ancestors.Count + 1) * labels.Count);

            foreach (String l in labels)
            {
                foreach (String an in ancestors)
                {
                    labelsWithAncestors.Add(an);
                    labelsWithAncestors.Add(an + " " + l);
                }
                labelsWithAncestors.Add(l);
            }
            string[] d;


            instance.AddLabelAction(new LabelAction(labelsWithAncestors.ToArray()));

            labelStack.AddLast(labels);

            return isBlockLevel;
        }

        public bool End(HTMLContentHandler instance, String localName, String qName)

        {

            labelStack.RemoveLast();
            return isBlockLevel;
        }

        public bool ChangesTagLevel()
        {
            return isBlockLevel;
        }

        private HashSet<String> getAncestorLabels()
        {
            HashSet<String> set = new HashSet<String>();
            foreach (List<String> labels in labelStack)
            {
                if (labels == null)
                {
                    continue;
                }
                foreach (var s in labels)
                {
                    set.Add(s);
                }

            }
            return set;
        }




    }

    public class SAXInput : Input
    {
        private InputSource IS;

        /**
         * Creates a new instance of {@link BoilerpipeSAXInput} for the given {@link InputSource}.
         * 
         * @param is
         * @throws SAXException
         */
        public SAXInput(InputSource IS)
        {
            this.IS = IS;
        }

        /**
         * Retrieves the {@link TextDocument} using a default HTML parser.
         */
        public TextDocument GetTextDocument()
        {

            return GetTextDocument(new HTMLParser());
        }

        /**
         * Retrieves the {@link TextDocument} using the given HTML parser.
         * 
         * @param parser The parser used to transform the input into boilerpipe's internal representation.
         * @return The retrieved {@link TextDocument}
         * @throws BoilerpipeProcessingException
         */
        public TextDocument GetTextDocument(HTMLParser parser)

        {
            try
            {
                Console.WriteLine("saxxx xx fifth");
                parser.Parse(IS);

            }
            catch (IOException e)
            {
                throw new WebscraperException(e);
            }
            catch (SAXException e)
            {
                throw new WebscraperException(e);
            }

            return parser.ToTextDocument();
        }


    }

    public interface TagAction
    {
        bool Start(HTMLContentHandler instance, String localName,
           String qName, IAttributes atts);

        bool End(HTMLContentHandler instance, String localName,
             String qName);

        bool ChangesTagLevel();
    }

    public class TagActionMap : Dictionary<string, TagAction>
    {
        private static long serialVersionUID = 1L;

        /**
         * Sets a particular {@link TagAction} for a given tag. Any existing TagAction for that tag will
         * be removed and overwritten.
         * 
         * @param tag The tag (will be stored internally 1. as it is, 2. lower-case, 3. upper-case)
         * @param action The {@link TagAction}
         */
        protected void SetTagAction(String tag, TagAction action)
        {


            //Dictionary<string, TagAction> ta = new Dictionary<string, TagAction>();

            this[tag.ToUpperInvariant()] = action;
            this[tag.ToLowerInvariant()] = action;
            this[tag] = action;
        }

        /**
         * Adds a particular {@link TagAction} for a given tag. If a TagAction already exists for that
         * tag, a chained action, consisting of the previous and the new {@link TagAction} is created.
         * 
         * @param tag The tag (will be stored internally 1. as it is, 2. lower-case, 3. upper-case)
         * @param action The {@link TagAction}
         */
        protected void AddTagAction(String tag, TagAction action)
        {

            //Dictionary<string, TagAction> ta = new Dictionary<string, TagAction>();


            TagAction previousAction;
            //= ta.Where(n => n.Key.ToLower() == tag.ToLower()).Select(n => n.Value).Single();
            if (TryGetValue(tag, out previousAction))
            {
                SetTagAction(tag, action);
            }
            else
            {
                SetTagAction(tag, new CommonTagActions.Chained(previousAction, action));
            }
        }
    }
}
