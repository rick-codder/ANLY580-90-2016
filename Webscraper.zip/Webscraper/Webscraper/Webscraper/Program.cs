﻿using System;
using System.Linq;
using System.Text;
using System.Net;
using System.Windows;
using System.Collections;
using System.Threading.Tasks;
using System.Collections.Generic;
using Webscraper.Documents;
using Webscraper.Extractors;
using Webscraper.Saxy;

namespace Webscraper
{
    public class Program
    {

        static void Main()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Extractor extractor = new ArticleExtractor();



            WebClient wb = new WebClient();


            var html = wb.DownloadString("https://www.forbes.com/sites/gordonkelly/2019/02/14/apple-new-iphone-8-7-upgrade-qualcomm-intel-iphone-xs-max-xr/#4610b8c55b67");


             string rr = extractor.GetText(html);

            Console.WriteLine(rr);




            //HTMLHighlighter hh = HTMLHighlighter.NewHighlightingInstance();

            //Uri uri = new Uri("https://www.forbes.com/sites/gordonkelly/2019/02/14/apple-new-iphone-8-7-upgrade-qualcomm-intel-iphone-xs-max-xr/#4610b8c55b67");


            //hh.Process(uri, extractor);


            
            //Console.WriteLine("sssss-xxxx");

            //TextBlock tb = new TextBlock(new StringBuilder("yemi"));

            //var tb12 = (TextBlock) tb.Clone();

            //List<string> me = new List<string>();

            //me.Add("romp");
            //me.Add("romper");
            //me.Add("romperist");

            //Console.WriteLine(string.Join(",", me));


            //Console.WriteLine(tb.GetText());
            //Console.WriteLine(tb12.GetText());


            Console.ReadLine();

        }



    }


}
