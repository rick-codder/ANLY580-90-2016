﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Labels;
using Webscraper.Exception;
using Webscraper.Filters;
using TagSoup.Net;


namespace Webscraper
{
    public interface Extractor : Filter
    {


        String GetText(String html);

        String GetText(InputSource inputSource);

        String GetText(TextReader r);

        String GetText(TextDocument doc);



    }
}
