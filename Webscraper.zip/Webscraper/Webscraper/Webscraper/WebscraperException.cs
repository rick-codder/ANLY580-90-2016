﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Webscraper.Exception
{
    class WebscraperException : System.Exception
    {
        private static long serialVersionUID = 1L;

        public WebscraperException() : base()
        {
        }

        public WebscraperException(String message) : base(message)
        {
        }

        public WebscraperException(System.Exception exception) : base(exception.Message)
        {
        }



    }
}
