﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;

using System.Security.Cryptography.X509Certificates;

namespace APiConnect
{


    public partial class Program
    {

        public static async Task<string> TidalPostURL<TResult>(string param, string filePath)
        {
            try
            {
                HttpResponseMessage httpMsg = new HttpResponseMessage();

                WebRequestHandler requestHandler = new WebRequestHandler();
                HttpClient client = new HttpClient(requestHandler);

                requestHandler.Credentials = nc;


               

                List<KeyValuePair<string, string>> urlList = new List<KeyValuePair<string, string>>();

                urlList.Add(new KeyValuePair<string, string>("data", param));

                FormUrlEncodedContent urlContent = new FormUrlEncodedContent(urlList);

                urlContent.Headers.Clear();
                urlContent.Headers.Add("Content-Type", "application/x-www-form-urlencoded");

                httpMsg = await client.PostAsync(urlo, urlContent);

                string strResult = await httpMsg.Content.ReadAsStringAsync();

                File.WriteAllText(filePath, strResult);

                //Console.WriteLine(strResult);

                return strResult;

            }
            catch (Exception e)
            {
                return e.Message;
                //Console.WriteLine(e.Message);
            }

        }


        public partial class MUREXToMCDB
        {

            //static string environment;

            static string date = Pdate;

            static string jobDateTidal = PjobDateTidal;

            static string jobDate = PjobDate;


            static bool rec;

            static Excel.Application xlApp;

            static Excel.Workbook xlWbk;

            static string StagingFilePath = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\staging.xml";

            static string StandardizationFilePath = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\standardization.xml";

            static string excelData;

            static string database = Pdatabase;



            static DataTable dt = new DataTable();

            static string runDate;//="2018-12-13 00:39:11.730";// "2018/10/10 9:40:00";




            static DictionaryEXT<string, List<string>> emData = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> marketData = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> prType = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> Cntpty = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> murexMcdb = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> dataMart = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> typology = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> msusa = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> mcm = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> recon = new DictionaryEXT<string, List<string>>();
            static DictionaryEXT<string, List<string>> TimingTable = new DictionaryEXT<string, List<string>>();


            static List<DictionaryEXT<string, List<string>>> dicList = new List<DictionaryEXT<string, List<string>>>();

            static List<DictionaryEXT<string, List<string>>> dicEMDM = new List<DictionaryEXT<string, List<string>>>();

            static string mailTo;
            static string mailCC;
            static string outBody;
            static string outAddress;

            static string productiondateasstring = "productiondateasstring='" + jobDateTidal + "'";

            static string manualIntervention = "10) Manual Intervention: Started some Staging and Standardization jobs manually to address data issues.";
            //static string manualIntervention = "10) Manual Intervention:\nStarted the bulk process staging jobs manually.Necessary till automation is decided on, Per Thiru.";
            //static string manualIntervention = "10) Manual Intervention: •	Started the bulk process staging jobs manually. Necessary till automation is decided on, Per Thiru.";


            static string UrlPayload_STG = PUrlPayload_STG;
            static string UrlPayload_STD = PUrlPayload_STD;

            //"(parentname='Standardize Murex Transactions and Legs' OR parentname='Standardize Murex Schedules' OR parentname='Standardize Murex Collaterals' OR parentname='Standardize Ref Data' OR parentname='Standardize Murex Transactions - Risk OR jobname='400 Run SSIS - Murex P&L') "


                            //"(parentname='100 Standardize Murex Transactions and Legs' OR parentname='200 Standardize Murex Schedules' OR parentname='300 Standardize Murex Collaterals') "


            public static void SQLToFile()
            {


                SqlConnection sqlConn = new SqlConnection();

                sqlConn.ConnectionString = "Data Source=" + database + ";Initial Catalog=mcoredb_archive;" + "Integrated Security=SSPI;";



                sqlConn.Open();

                string sqlFile = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SQL\MUREX OTCTRANSACTION SELECT STATEMENT.sql");

                SqlCommand sqlCmd = new SqlCommand(sqlFile);

                sqlCmd.CommandTimeout = 100000;

                sqlCmd.Connection = sqlConn;

                SqlDataReader sqlreader = sqlCmd.ExecuteReader();

                using (StreamWriter rd = new StreamWriter(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SQL\resultset.csv"))
                {
                    rd.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31},{32},{33},{34},{35},{36},{37},{38},{39},{40},{41},{42},{43},{44},{45},{46},{47},{48},{49},{50},{51},{52},{53},{54}",
    sqlreader.GetName(0), sqlreader.GetName(1), sqlreader.GetName(2), sqlreader.GetName(3), sqlreader.GetName(4), sqlreader.GetName(5), sqlreader.GetName(6), sqlreader.GetName(7), sqlreader.GetName(8), sqlreader.GetName(9), sqlreader.GetName(10), sqlreader.GetName(11), sqlreader.GetName(12), sqlreader.GetName(13), sqlreader.GetName(14), sqlreader.GetName(15), sqlreader.GetName(16), sqlreader.GetName(17), sqlreader.GetName(18), sqlreader.GetName(19), sqlreader.GetName(20), sqlreader.GetName(21), sqlreader.GetName(22), sqlreader.GetName(23), sqlreader.GetName(24), sqlreader.GetName(25), sqlreader.GetName(26), sqlreader.GetName(27), sqlreader.GetName(28), sqlreader.GetName(29), sqlreader.GetName(30), sqlreader.GetName(31), sqlreader.GetName(32), sqlreader.GetName(33), sqlreader.GetName(34), sqlreader.GetName(35), sqlreader.GetName(36), sqlreader.GetName(37), sqlreader.GetName(38), sqlreader.GetName(39), sqlreader.GetName(40), sqlreader.GetName(41), sqlreader.GetName(42), sqlreader.GetName(43), sqlreader.GetName(44), sqlreader.GetName(45), sqlreader.GetName(46), sqlreader.GetName(47), sqlreader.GetName(48), sqlreader.GetName(49), sqlreader.GetName(50), sqlreader.GetName(51), sqlreader.GetName(52), sqlreader.GetName(53), sqlreader.GetName(54)
                        );

                    while (sqlreader.Read())
                    {

                        rd.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31},{32},{33},{34},{35},{36},{37},{38},{39},{40},{41},{42},{43},{44},{45},{46},{47},{48},{49},{50},{51},{52},{53},{54}",
    sqlreader[0], sqlreader[1], sqlreader[2], sqlreader[3], sqlreader[4], sqlreader[5], sqlreader[6], sqlreader[7], sqlreader[8], sqlreader[9], sqlreader[10], sqlreader[11], sqlreader[12], sqlreader[13], sqlreader[14], sqlreader[15], sqlreader[16], sqlreader[17], sqlreader[18], sqlreader[19], sqlreader[20], sqlreader[21], sqlreader[22], sqlreader[23], sqlreader[24], sqlreader[25], sqlreader[26], sqlreader[27], sqlreader[28], sqlreader[29], sqlreader[30], sqlreader[31], sqlreader[32], sqlreader[33], sqlreader[34], sqlreader[35], sqlreader[36], sqlreader[37], sqlreader[38], sqlreader[39], sqlreader[40], sqlreader[41], sqlreader[42], sqlreader[43], sqlreader[44], sqlreader[45], sqlreader[46], sqlreader[47], sqlreader[48], sqlreader[49], sqlreader[50], sqlreader[51], sqlreader[52], sqlreader[53], sqlreader[54]
                            );


                    }
                }

                tTimer.Stop();

            }

            public static async void RunAsync()
            {


                DateTime startTime = System.DateTime.Now;
                Console.WriteLine("..{0}", startTime.ToLongTimeString().Replace("PM", ""));

                if (environment != "ci")
                {
                    Console.WriteLine("Now posting and retrieving xml response....\n");

                    string stg = await TidalPostURL<string>(UrlPayload_STG, StagingFilePath);
                    Console.WriteLine(stg);


                    string std = await TidalPostURL<string>(UrlPayload_STD, StandardizationFilePath);
                    Console.WriteLine(std);

                    Console.WriteLine("Now deserializing....\n");

                    Deserialize_STD(StandardizationFilePath);

                    Deserialize_STG(StagingFilePath);
                }

                Console.WriteLine("Now getting data from SQL database....\n");
                sqlData();

                SetDictNames();

                TableDuration();

                ModifyDicList();

                StartExcel();


                CopyPreviousDay();

                ClearCells();


                Console.WriteLine("Now loading SQL data into Excel Workbook....\n");
                SqlToExcel();


                Console.WriteLine("Now publishing to HTML....\n");
                ExcelSheetHTML();

                Console.WriteLine("Now loading into Outlook....\n");
                OutlookMail();

                Console.WriteLine("Rundate.... {0}", runDate);

                if (environment == "uat")
                {
                    MCDBToMCDV.SLAProcessing();
                }


                DateTime EndTime = DateTime.Now;
                int rem = 0;
                double RunTime = (EndTime - startTime).TotalSeconds <= 60 ? (EndTime - startTime).TotalSeconds : Math.DivRem((int)(EndTime - startTime).TotalSeconds, 60, out rem);

                //CloseExcel();


                tTimer.Stop();

                if ((EndTime - startTime).TotalSeconds <= 60)
                {
                    Console.WriteLine("Done!.... in {0}secs", RunTime);
                }
                else
                {
                    Console.WriteLine("Done!.... in {0}mins {1}secs", RunTime, rem);
                }

            }

            public static void StartExcel()
            {

                xlApp = MxlApp;//new Excel.Application();

                xlWbk = MxlWbk;//xlApp.Workbooks.Open(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\masterSheetFinal.xlsx");

            }

            public static void CloseExcel()
            {
                //xlWbk.Save();

                //xlWbk.Close();

                xlApp.Quit();

            }


            public static void TableDuration()
            {
                List<string> header = new List<string>();
                header.Add("Time");
                TimingTable.Add("Process", header);

                List<string> totalPStg = new List<string>();
                totalPStg.Add(TotalPeriodStaging);
                TimingTable.Add("Total period for staging", totalPStg);

                List<string> totalEStg = new List<string>();
                totalEStg.Add(TotalExecutionStaging);
                TimingTable.Add("Execution time for staging", totalEStg);

                //List<string> STD10 = new List<string>();
                //STD10.Add(Murex10);
                //TimingTable.Add("Execution time for 010 - Murex Trades to MCDB", STD10);

                List<string> STD15 = new List<string>();
                STD15.Add(MUrex15);
                TimingTable.Add("Standardization jobs", STD15);


            }



            public static void ClearCells()
            {
                switch(environment)
                {
                    case "uat":
                        Excel.Worksheet xlWksht = xlWbk.Worksheets["master"];

                        Excel.Worksheet xlWksht_EMDM = xlWbk.Worksheets["sub"];

                        xlWksht_EMDM.Range["A2:B65"].Clear();

                        xlWksht.Range["A100:D300"].Clear();

                        xlWksht_EMDM.Cells[1, 1].Value = jobDate;

                        xlWbk.Save();
                        break;
                    case "prod":
                        Excel.Worksheet xlWksht1 = xlWbk.Worksheets["master"];

                        Excel.Worksheet xlWksht_EMDM1 = xlWbk.Worksheets["sub"];

                        xlWksht_EMDM1.Range["A2:B65"].Clear();

                        xlWksht1.Range["A159:D400"].Clear();

                        xlWksht_EMDM1.Cells[1, 1].Value = jobDate;

                        xlWbk.Save();
                        break;

                }

            }

            public static void SetDictNames()
            {

                emData.Desc = "";
                emData.Name = "emData";

                prType.Desc = "2) Product Type - " + (prType.Count - 1).ToString() + " rows";
                prType.Name = "PrType";

                Cntpty.Desc = "3) Unspecified Counterparties (No CPAccountID)";
                Cntpty.Name = "Cntpty";

                murexMcdb.Desc = "4) Murex Staging Counterparties not in MCDB";
                murexMcdb.Name = "murexMcdb";

                dataMart.Desc = "1) EM Data Mart Staging table:";
                dataMart.Name = "dataMart";

                typology.Desc = "5) Typology - " + (typology.Count - 1).ToString() + " rows";
                typology.Name = "typology";

                msusa.Desc = "6) Impact/GMI breakdown:";
                msusa.Name = "msusa";

                mcm.Desc = "";
                mcm.Name = "mcm";

                marketData.Desc = "8) Market DM data";
                marketData.Name = "MarketData";


                recon.Desc = "7) Reconciliation between Murex and MCDB:";
                recon.Name = "Recon";

                TimingTable.Desc = "9) Timing";

            }

            public static void ModifyDicList()
            {

                int i = 0;
                foreach (var item in dicList)
                {
                    Console.WriteLine(i + " " + item.Name);
                    i++;

                }



                if (mcm.Count > 1)
                {

                    msusa.Add(mcm.ElementAt(1).Key, mcm.ElementAt(1).Value);
                }

                dicList.Remove(mcm);
                dicList.Remove(emData);
                dicList.Remove(dataMart);

                if (environment == "prod")
                {
                    dicList.Remove(marketData);

                }

                dicList.Add(TimingTable);

                dicEMDM.Add(dataMart);
                dicEMDM.Add(emData);

                
                //foreach(var item in dicList)
                //{
                //    Console.WriteLine(item.Name);

                //}
                //Console.ReadLine();


            }

            public static void CopyPreviousDay()
            {

                Excel.Worksheet xlWsht = xlWbk.Worksheets["sub"];

                Excel.Range xlRangeDest = xlWsht.Range["D1:E65"];

                if (xlWsht.Cells[1, 1].value != DateTime.Parse(jobDate))
                {
                    xlWsht.Range["A1:B65"].Copy(xlRangeDest);

                    xlWbk.Save();
                }

            }


            public static void SqlToExcel()
            {

                Excel.Worksheet xlWksht = xlWbk.Worksheets["master"];

                Excel.Worksheet xlWksht_EMDM = xlWbk.Worksheets["sub"];

                //string xlrange = xlWksht.UsedRange.Cells.ToString();


                //Excel.Range xlRange = xlWksht.Range[xlWksht.Cells[1, 1], xlWksht.Cells[2, 2]];


                //xlWksht.Cells[xlWksht.Cells[84,1],xlWksht.Cells[100,10]].Clear();


                int ct = 1;
                foreach (var item in dicEMDM)
                {

                    try
                    {

                        xlWksht.Cells[ct + 4, 1].Value = item.Desc;
                        xlWksht.Cells[ct + 4, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                        xlWksht.Cells[ct + 4, 1].Characters.Font.Bold = true;



                        for (int i = 0; i < item.Count; i++)
                        {

                            xlWksht_EMDM.Cells[i + ct + 1, 1].Borders.Color = ConsoleColor.Black;
                            xlWksht_EMDM.Cells[i + ct + 1, 2].Borders.Color = ConsoleColor.Black;
                            xlWksht_EMDM.Cells[i + ct + 1, 1].Value = item.ElementAt(i).Key;
                            Console.WriteLine(item.ElementAt(i).Key);
                            xlWksht_EMDM.Cells[i + ct + 1, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(0));
                        }

                        ct += item.Count + 1;
                        Console.WriteLine(ct);

                    }
                    catch (Exception e)
                    {

                        Console.WriteLine(e.Message);

                    }

                }



                switch (environment)
                {
                    case "uat":
                        int cnt = 101;
                        foreach (var item in dicList)
                        {
                            try
                            {

                                switch (item.Name)
                                {
                                    case "msusa":
                                        Console.WriteLine("MSUSA now processing...");


                                        xlWksht.Cells[cnt + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 2].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 3].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));


                                        for (int i = 0; i < item.Count; i++)
                                        {

                                            xlWksht.Cells[i + cnt + 3, 1].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 2].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 3].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 1].Value = item.ElementAt(i).Key;
                                            Console.WriteLine(item.ElementAt(i).Key);
                                            xlWksht.Cells[i + cnt + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(0));
                                            xlWksht.Cells[i + cnt + 3, 3].Value = item.ElementAt(i).Value.ElementAt(1);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(1)?.ToString());
                                        }

                                        //xlWksht.Cells[cnt - item.Count, 1].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cnt - item.Count, 2].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cnt - item.Count, 3].Characters.Font.Bold = true;

                                        cnt += item.Count + 3;
                                        Console.WriteLine(cnt);
                                        break;
                                    case "Recon":
                                        Console.WriteLine("Recon now processing...");


                                        xlWksht.Cells[cnt + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 2].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 3].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 4].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));

                                        for (int i = 0; i < item.Count; i++)
                                        {

                                            xlWksht.Cells[i + cnt + 3, 1].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 2].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 3].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cnt + 3, 4].Borders.Color = ConsoleColor.Black;

                                            xlWksht.Cells[i + cnt + 3, 1].Value = item.ElementAt(i).Key;
                                            Console.WriteLine(item.ElementAt(i).Key);


                                            xlWksht.Cells[i + cnt + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(0));

                                            xlWksht.Cells[i + cnt + 3, 3].Value = item.ElementAt(i).Value.ElementAt(1);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(1)?.ToString());

                                            switch (item.ElementAt(i).Value.ElementAt(2))
                                            {
                                                case "PASSED":
                                                    xlWksht.Cells[i + cnt + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkGreen);
                                                    xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;
                                                case "FAILED":
                                                    xlWksht.Cells[i + cnt + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                                                    xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;
                                                default:
                                                    xlWksht.Cells[i + cnt + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    //xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                                                    xlWksht.Cells[i + cnt + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;


                                            }



                                            xlWksht.Cells[i + cnt + 3, 2].NumberFormat = "0";
                                            xlWksht.Cells[i + cnt + 3, 3].NumberFormat = "0";

                                        }

                                        //xlWksht.Cells[cnt - item.Count, 1].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cnt - item.Count, 2].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cnt - item.Count, 3].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cnt - item.Count, 4].Characters.Font.Bold = true;

                                        cnt += item.Count + 3;
                                        Console.WriteLine(cnt);
                                        break;
                                    default:
                                        xlWksht.Cells[cnt + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cnt + 3, 2].Characters.Font.Bold = true;

                                        xlWksht.Cells[cnt + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cnt + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));


                                        for (int i = 0; i < item.Count; i++)
                                        {
                                            if (item.Count == 1)
                                            {

                                                xlWksht.Cells[cnt + 1, 1].Value = item.Desc + ": None";
                                                xlWksht.Cells[cnt + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                                                xlWksht.Cells[cnt + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                                            }

                                            else
                                            {

                                                xlWksht.Cells[i + cnt + 3, 1].Borders.Color = ConsoleColor.Black;
                                                xlWksht.Cells[i + cnt + 3, 2].Borders.Color = ConsoleColor.Black;
                                                xlWksht.Cells[i + cnt + 3, 1].Value = item.ElementAt(i).Key;
                                                xlWksht.Cells[i + cnt + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                                xlWksht.Cells[i + cnt + 3, 2].NumberFormat = "0";

                                            }


                                        }

                                        cnt += item.Count + 3;
                                        Console.WriteLine(cnt);
                                        break;


                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message + " " + item.Name);
                            }

                        }

                        xlWksht.Cells[cnt + 1, 1].Value = "Manual Intervention:";
                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cnt + 1, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cnt + 1, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cnt + 1, 2], xlWksht.Cells[cnt + 1, 4]].Merge();
                        xlWksht.Cells[cnt + 1, 2].WrapText = true;
                        xlWksht.Cells[cnt + 1, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 1, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWksht.Cells[cnt + 2, 1].Value = "Incident:";
                        xlWksht.Cells[cnt + 2, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cnt + 2, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 2, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cnt + 2, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cnt + 2, 2], xlWksht.Cells[cnt + 2, 4]].Merge();
                        xlWksht.Cells[cnt + 2, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 2, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWksht.Cells[cnt + 3, 1].Value = "Comment:";
                        xlWksht.Cells[cnt + 3, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cnt + 3, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 3, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cnt + 3, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cnt + 3, 2], xlWksht.Cells[cnt + 3, 4]].Merge();
                        xlWksht.Cells[cnt + 3, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cnt + 3, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        //xlWksht.Cells[cnt + 4, 1].Value = "Resolution:";
                        //xlWksht.Cells[cnt + 4, 1].Characters.Font.Bold = true;
                        //xlWksht.Cells[cnt + 4, 1].Borders.Color = ConsoleColor.Black;
                        //xlWksht.Cells[cnt + 4, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        //xlWksht.Cells[cnt + 4, 2].Value = "n/a";
                        //xlWksht.Cells[cnt + 4, 2].Borders.Color = ConsoleColor.Black;
                        //xlWksht.Cells[cnt + 4, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWbk.Save();
                        break;

                    case "prod":
                        int cut = 3;

                        xlWksht.Cells[cut, 1].Value = "1) Incident & Resolution";
                        xlWksht.Cells[cut, 1].Characters.Font.Bold = true;
                        //xlWksht.Cells[cut + 1, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cut + 1, 1].Value = "Manual Intervention:";
                        xlWksht.Cells[cut + 1, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cut + 1, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cut + 1, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cut + 1, 2], xlWksht.Cells[cut + 1, 4]].Merge();
                        xlWksht.Cells[cut + 1, 2].WrapText = true;
                        xlWksht.Cells[cut + 1, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 1, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWksht.Cells[cut + 2, 1].Value = "Incident:";
                        xlWksht.Cells[cut + 2, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cut + 2, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 2, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cut + 2, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cut + 2, 2], xlWksht.Cells[cut + 2, 4]].Merge();
                        xlWksht.Cells[cut + 2, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 2, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWksht.Cells[cut + 3, 1].Value = "Cause:";
                        xlWksht.Cells[cut + 3, 1].Characters.Font.Bold = true;
                        xlWksht.Cells[cut + 3, 1].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 3, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        xlWksht.Cells[cut + 3, 2].Value = "n/a";
                        xlWksht.Range[xlWksht.Cells[cut + 3, 2], xlWksht.Cells[cut + 3, 4]].Merge();
                        xlWksht.Cells[cut + 3, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[cut + 3, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        cut = 160;
                        foreach (var item in dicList)
                        {
                            try
                            {

                                switch (item.Name)
                                {
                                    case "msusa":
                                        Console.WriteLine("MSUSA now processing...");


                                        xlWksht.Cells[cut + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 2].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 3].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));


                                        for (int i = 0; i < item.Count; i++)
                                        {

                                            xlWksht.Cells[i + cut + 3, 1].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 2].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 3].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 1].Value = item.ElementAt(i).Key;
                                            Console.WriteLine(item.ElementAt(i).Key);
                                            xlWksht.Cells[i + cut + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(0));
                                            xlWksht.Cells[i + cut + 3, 3].Value = item.ElementAt(i).Value.ElementAt(1);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(1)?.ToString());
                                        }

                                        //xlWksht.Cells[cut - item.Count, 1].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cut - item.Count, 2].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cut - item.Count, 3].Characters.Font.Bold = true;

                                        cut += item.Count + 3;
                                        Console.WriteLine(cut);
                                        break;
                                    case "Recon":
                                        Console.WriteLine("Recon now processing...");
                                        int prv = cut;
                                        cut = 54;
                                        xlWksht.Cells[cut + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 2].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 3].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 4].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));

                                        for (int i = 0; i < item.Count; i++)
                                        {

                                            xlWksht.Cells[i + cut + 3, 1].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 2].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 3].Borders.Color = ConsoleColor.Black;
                                            xlWksht.Cells[i + cut + 3, 4].Borders.Color = ConsoleColor.Black;

                                            xlWksht.Cells[i + cut + 3, 1].Value = item.ElementAt(i).Key;
                                            Console.WriteLine(item.ElementAt(i).Key);


                                            xlWksht.Cells[i + cut + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(0));

                                            xlWksht.Cells[i + cut + 3, 3].Value = item.ElementAt(i).Value.ElementAt(1);
                                            Console.WriteLine(item.ElementAt(i).Value.ElementAt(1)?.ToString());

                                            switch (item.ElementAt(i).Value.ElementAt(2))
                                            {
                                                case "PASSED":
                                                    xlWksht.Cells[i + cut + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    xlWksht.Cells[i + cut + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkGreen);
                                                    xlWksht.Cells[i + cut + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;
                                                case "FAILED":
                                                    xlWksht.Cells[i + cut + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    xlWksht.Cells[i + cut + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkRed);
                                                    xlWksht.Cells[i + cut + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;
                                                default:
                                                    xlWksht.Cells[i + cut + 3, 4].Value = item.ElementAt(i).Value.ElementAt(2);
                                                    //xlWksht.Cells[i + cut + 3, 4].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                                                    xlWksht.Cells[i + cut + 3, 4].Characters.Font.Bold = true;
                                                    Console.WriteLine(item.ElementAt(i).Value.ElementAt(2)?.ToString());
                                                    break;


                                            }



                                            xlWksht.Cells[i + cut + 3, 2].NumberFormat = "0";
                                            xlWksht.Cells[i + cut + 3, 3].NumberFormat = "0";

                                        }

                                        //xlWksht.Cells[cut - item.Count, 1].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cut - item.Count, 2].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cut - item.Count, 3].Characters.Font.Bold = true;
                                        //xlWksht.Cells[cut - item.Count, 4].Characters.Font.Bold = true;

                                        cut = prv + item.Count;
                                        Console.WriteLine(cut);
                                        break;
                                    default:
                                        xlWksht.Cells[cut + 1, 1].Value = item.Desc;
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                                        xlWksht.Cells[cut + 1, 1].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Characters.Font.Bold = true;
                                        xlWksht.Cells[cut + 3, 2].Characters.Font.Bold = true;

                                        xlWksht.Cells[cut + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                                        xlWksht.Cells[cut + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));


                                        for (int i = 0; i < item.Count; i++)
                                        {
                                            if (item.Count == 1)
                                            {

                                                xlWksht.Cells[cut + 1, 1].Value = item.Desc + ": None";
                                                xlWksht.Cells[cut + 3, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                                                xlWksht.Cells[cut + 3, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                                            }

                                            else
                                            {

                                                xlWksht.Cells[i + cut + 3, 1].Borders.Color = ConsoleColor.Black;
                                                xlWksht.Cells[i + cut + 3, 2].Borders.Color = ConsoleColor.Black;
                                                xlWksht.Cells[i + cut + 3, 1].Value = item.ElementAt(i).Key;
                                                xlWksht.Cells[i + cut + 3, 2].Value = item.ElementAt(i).Value.ElementAt(0);
                                                xlWksht.Cells[i + cut + 3, 2].NumberFormat = "0";

                                            }


                                        }

                                        cut += item.Count + 3;
                                        Console.WriteLine(cut);
                                        break;


                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message + " " + item.Name);
                            }

                        }



                        //xlWksht.Cells[cnt + 4, 1].Value = "Resolution:";
                        //xlWksht.Cells[cnt + 4, 1].Characters.Font.Bold = true;
                        //xlWksht.Cells[cnt + 4, 1].Borders.Color = ConsoleColor.Black;
                        //xlWksht.Cells[cnt + 4, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);

                        //xlWksht.Cells[cnt + 4, 2].Value = "n/a";
                        //xlWksht.Cells[cnt + 4, 2].Borders.Color = ConsoleColor.Black;
                        //xlWksht.Cells[cnt + 4, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);

                        xlWbk.Save();
                        break;


                }



            }

            public static void ExcelSheetHTML()
            {


                string htmfile = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\xlsDap.htm";

                xlWbk.PublishObjects.Add(Excel.XlSourceType.xlSourceSheet,
                    htmfile,
                    "master",
                     Excel.XlFileFormat.xlHtml
                    ).Publish(true);


                FileStream fs = File.OpenRead(htmfile);

                StreamReader sr = new StreamReader(fs);


                excelData = sr.ReadToEnd();

                //Console.WriteLine(excelData);

                xlWbk.Save();

                //xlWbk.Close();

                //xlApp.Quit();

                fs.Close();



                //File.Delete(htmfile);


            }

            public static void GetMailDetails(string inputString, string fileName="emails")
            {
                try
                {

                    Outlook.Application outApp = new Outlook.Application();

                    Outlook.MailItem mail = outApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;


                    var outSentBox = outApp.GetNamespace("MAPI").Session.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderSentMail);

                    Outlook.Items items = outSentBox.Items;

                    IEnumerable<Microsoft.Office.Interop.Outlook.MailItem> mailFound;

                    if (inputString == null)

                    {
                        mailFound = outSentBox.Items.
                          OfType<Outlook.MailItem>().
                          Where(m => m.Subject.Contains("RE: Murex to MCDB UAT Update: 11/12 Status")).Select(m => m);
                    }
                    else
                    {
                        mailFound = outSentBox.Items.
                          OfType<Outlook.MailItem>().
                          Where(m => m.Subject.Contains(inputString)).Select(m => m);
                    }

                    


                    Outlook.Recipients outrecp = mailFound.Last().Recipients;

                    outBody = mailFound.Last().HTMLBody;

                    outAddress = null;

                    foreach (Outlook.Recipient item in outrecp)
                    {

                        Outlook.PropertyAccessor outPa = item.PropertyAccessor;
                        outAddress += outPa.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001E").ToString() + ";";


                    }

                    Console.WriteLine(outAddress);

                    File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\" + fileName +".txt", outAddress);



                    mailTo = outAddress.Substring(0, 201);

                    mailCC = outAddress.Substring(201);

                    Console.WriteLine("mailTo\n\n..{0}", mailTo);

                    Console.WriteLine("mailCC\n\n..{0}", mailCC);
                    Console.WriteLine(outAddress);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                }



            }

            public static void OutlookMail()
            {
                try
                {

                    Outlook.Application outApp = new Outlook.Application();

                    Outlook.MailItem mail = outApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;

                    outAddress = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\emails.txt");

                    mailTo = outAddress.Substring(0, 173);

                    mailCC = outAddress.Substring(173);

                    Console.WriteLine("mailTo\n\n..{0}", mailTo);

                    Console.WriteLine("mailCC\n\n..{0}", mailCC);
                    Console.WriteLine(outAddress);

                    //GetMailDetails();

                    if (environment == "prod")
                    {
                        mail.To = "joe.miller@mizuhogroup.com;";

                        mail.CC =
                    "jim.jenkinson@mizuhogroup.com;David.Marks@mizuhogroup.com;David.Mcintyre@mizuhogroup.com;Thir.Valliappan@mizuhogroup.com;" +
                    "Daniel.Davidson@mizuhogroup.com;Srinivasa.Seelam@mizuhogroup.com;Luca.Leonte@mizuhogroup.com";
                    }
                    else
                    {
                        mail.To = mailTo;

                        mail.CC = mailCC;
                    }

                    MailMessage mailMsg = new MailMessage();

                    mailMsg.IsBodyHtml = true;

                    mail.Subject = "RE: Murex to MCDB " + environment.ToUpper() + " Update: " + date + " Status";


                    mail.HTMLBody = excelData.Replace("align=center", "align=left"); // $"<table style='border:1px solid black; border-collapse:collapse'><tr><td>{mailMsg.Body}<td></tr></table>";

                    mail.Display();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);


                }
            }


            public static void sqlData()
            {
                try
                {


                    SqlConnection sqlConn = new SqlConnection();

                    sqlConn.ConnectionString = "Data Source=" + database + ";Initial Catalog=mcoredb_archive;" + "Integrated Security=SSPI;";



                    sqlConn.Open();

                    string sqlFile = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SQL\@SELECT EM & STAGE COUNTS revised.sql");

                    SqlCommand sqlCmd = new SqlCommand(sqlFile);

                    sqlCmd.CommandTimeout = 100000;

                    sqlCmd.Connection = sqlConn;

                    sqlCmd.Parameters.Add(new SqlParameter() { Value = DateTime.Parse(runDate), ParameterName = "@dt", DbType = DbType.DateTime });

                    sqlCmd.Parameters.Add(new SqlParameter() { Value = DateTime.Parse(jobDate), ParameterName = "@jobdt", DbType = DbType.DateTime });

                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                    bool sqlbool = true;

                    Console.WriteLine();



                    dicList.Add(emData);
                    dicList.Add(prType);
                    dicList.Add(Cntpty);
                    dicList.Add(murexMcdb);
                    dicList.Add(dataMart);
                    dicList.Add(typology);
                    dicList.Add(msusa);
                    dicList.Add(mcm);
                    dicList.Add(recon);
                    dicList.Add(marketData);





                    int i = 0;

                    while (sqlbool)
                    {

                        if (sqlReader.FieldCount == 2)
                        {
                            Console.WriteLine($"{sqlReader.GetName(0)},{sqlReader.GetName(1)}");
                            List<string> listVal = new List<string>();
                            listVal.Add(sqlReader.GetName(1).Trim());
                            dicList[i].Add(sqlReader.GetName(0).Trim(), listVal);



                        }
                        else if (sqlReader.FieldCount == 4)
                        {
                            Console.WriteLine($"{sqlReader.GetName(0)},{sqlReader.GetName(1)},{sqlReader.GetName(2)},{sqlReader.GetName(3)}");
                            List<string> listVal = new List<string>();
                            listVal.Add(sqlReader.GetName(1).Trim());
                            listVal.Add(sqlReader.GetName(2).Trim());
                            listVal.Add(sqlReader.GetName(3).Trim());
                            dicList[i].Add(sqlReader.GetName(0).Trim(), listVal);

                        }
                        else
                        {
                            Console.WriteLine($"{sqlReader.GetName(0)},{sqlReader.GetName(1)},{sqlReader.GetName(2)}");
                            List<string> listVal = new List<string>();
                            listVal.Add(sqlReader.GetName(1).Trim());
                            listVal.Add(sqlReader.GetName(2).Trim());
                            dicList[i].Add(sqlReader.GetName(0).Trim(), listVal);
                        }

                        while (sqlReader.Read())
                        {
                            if (sqlReader.FieldCount == 2)
                            {
                                Console.WriteLine($"{sqlReader[0]},{sqlReader[1]}");
                                List<string> listVal = new List<string>();
                                listVal.Add(sqlReader[1].ToString().Trim());
                                dicList[i].Add(sqlReader[0].ToString().Trim(), listVal);
                            }
                            else if (sqlReader.FieldCount == 4)
                            {
                                Console.WriteLine($"{sqlReader[0]},{sqlReader[1]},{sqlReader[2]},{sqlReader[3]}");
                                List<string> listVal = new List<string>();
                                listVal.Add(sqlReader[1].ToString().Trim());
                                listVal.Add(sqlReader[2].ToString().Trim());
                                listVal.Add(sqlReader[3].ToString().Trim());
                                dicList[i].Add(sqlReader[0].ToString().Trim(), listVal);
                            }
                            else
                            {
                                Console.WriteLine($"{sqlReader[0]},{sqlReader[1]},{sqlReader[2]}");
                                List<string> listVal = new List<string>();
                                listVal.Add(sqlReader[1].ToString().Trim());
                                listVal.Add(sqlReader[2].ToString().Trim());
                                dicList[i].Add(sqlReader[0].ToString().Trim(), listVal);
                            }


                        }

                        // Console.WriteLine("==================================================\n");
                        i++;
                        sqlbool = sqlReader.NextResult();
                    }

                    //sqlReader.Close();

                    //sqlConn.Close();



                    //Console.WriteLine( msusa.ElementAt(1));
                    //Console.WriteLine(mcm.ElementAt(1).Key);
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);

                }
            }





            public static void XMLres()
            {
                string requestXml = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\dxml.xml");

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://tidaluatweb:8080/api/tes-6.2/post");
                request.Credentials = nc;

                byte[] bytes;



                request.Method = "POST";
                var requestStream = request.GetRequestStream();

                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                Console.WriteLine(response.StatusCode);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();


                    Console.WriteLine(responseStr);

                }

            }


            public static void GetSSLCertificate()
            {
                try
                {


                    X509Store certificateStore = new X509Store(StoreName.My, StoreLocation.CurrentUser);

                    certificateStore.Open(OpenFlags.ReadOnly);

                    X509CertificateCollection certificateCollection = certificateStore.Certificates;

                    Console.WriteLine("{0},{1}", StoreLocation.CurrentUser.ToString(), StoreName.Root.ToString());

                    foreach (X509Certificate certificate in certificateCollection)
                    {

                        if (certificate.Subject.ToLower().Contains("olayemiadejumo@usi.mizuho-sc.com".ToLower()))
                        {
                            certDL = certificate;
                            Console.WriteLine(certificate.Subject.ToString());
                            Console.WriteLine("\n");

                        }

                    }

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);


                }
            }
        }

    }
}
