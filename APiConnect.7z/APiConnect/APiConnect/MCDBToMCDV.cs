﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;

using System.Security.Cryptography.X509Certificates;

namespace APiConnect
{
    public partial class Program
    {

        public partial class MCDBToMCDV
        {
            static string excelData;

            static string mailTo;
            static string mailCC;
            static string outBody;
            static string outAddress;

            static string pLoad_STD = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<entry xmlns='http://purl.org/atom/ns#'>" +
                "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
                    "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" + "<queryCondition>adhoc='N' AND " +
        "(jobname = 'Standardize Murex Collaterals' OR jobname = 'Standardize Murex Ref Data' OR jobname = 'Standardize Murex Transactions and Legs' OR jobname = 'Standardize Murex Schedules' OR  jobname = 'Standardize Murex Risk' OR (parentname = 'Standardize Murex trades to MCDB' AND childrencount=0)) "
                         + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
                    "<orderBy></orderBy>" +
                    "<firstRow></firstRow>" +
                    "<numRows></numRows>" +
                    "<changedOnly></changedOnly>" +
                    "<expandAll></expandAll>" +
                    "<nodeList></nodeList>" +
                    "<queryDate></queryDate>" +
                "</tes:JobRun.getList>" +
            "</entry>";

            static string pLoad_STG = "<?xml version='1.0' encoding='UTF-8'?>" +
"<entry xmlns='http://purl.org/atom/ns#'>" +
    "<tes:JobRun.getList xmlns:tes='http://www.tidalsoftware.com/client/tesservlet'>" +
        "<selectColumns>id,alias,jobname,parentname,productiondate,productiondateasstring,actualstarttimeasstring,actualstarttime,duration,reruns,estimatedduration,statuschangetime,lastchangetime,adhoc</selectColumns>" + "<queryCondition>adhoc='N' AND " +
"(jobname = 'Stage Murex Collateral' OR jobname = 'Stage Murex Ref Data' OR jobname = 'Stage Murex Transactions' OR jobname = 'Stage Murex Schedules' OR  jobname = 'Stage Murex Risk' OR  jobname = 'Stage Murex Market Data' ) "
             + "AND productiondateasstring='" + PjobDateTidal + "'</queryCondition>" +
        "<orderBy></orderBy>" +
        "<firstRow></firstRow>" +
        "<numRows></numRows>" +
        "<changedOnly></changedOnly>" +
        "<expandAll></expandAll>" +
        "<nodeList></nodeList>" +
        "<queryDate></queryDate>" +
    "</tes:JobRun.getList>" +
"</entry>";

            static Excel.Application xlApp;

            static Excel.Workbook xlWbk;

            static string SLA_STD = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SLA_STANDARDIZED.xml";

            static string SLA_STG  = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SLA_STAGING.xml";

            static string database = databaseCollateral;

            static DictionaryEXT<string, List<string>> collateralData = new DictionaryEXT<string, List<string>>();

            public static async void SLAProcessing()
            {
                try
                {
                    DateTime startTime = System.DateTime.Now;

                    Console.WriteLine("Now posting and retrieving xml response....\n");

                    string cl_std = await TidalPostURL<string>(pLoad_STD, SLA_STD);

                    string cl_stg = await TidalPostURL<string>(pLoad_STG, SLA_STG);

                    Console.WriteLine(cl_std);

                    Console.WriteLine(cl_stg);

                    Console.WriteLine("Now deserializing....\n");
                    Deserialize_SLA(SLA_STD);

                    Deserialize_SLA(SLA_STG);

                    Console.WriteLine("Now getting data from SQL database....\n");
                    //sqlData();

                    //SetDictNames();

                    //StartExcel();


                    //ClearCells();

                    //SqlToExcel();

                    //Console.WriteLine("Now loading SQL data into Excel Workbook....\n");
                    //SqlToExcel();


                    //Console.WriteLine("Now publishing to HTML....\n");
                    //ExcelSheetHTML();

                    //Console.WriteLine("Now loading into Outlook....\n");
                    //OutlookMail();

                    //Console.WriteLine("Rundate.... {0}", runDate);

                    //CloseExcel();


                    DateTime EndTime = DateTime.Now;
                    int rem = 0;
                    double RunTime = (EndTime - startTime).TotalSeconds <= 60 ? (EndTime - startTime).TotalSeconds : Math.DivRem((int)(EndTime - startTime).TotalSeconds, 60, out rem);



                    tTimer.Stop();

                    if ((EndTime - startTime).TotalSeconds <= 60)
                    {
                        Console.WriteLine("Done!.... in {0}secs", RunTime);
                    }
                    else
                    {
                        Console.WriteLine("Done!.... in {0}mins {1}secs", RunTime, rem);
                    }
                }
                finally
                {
                    if (MxlApp != null)
                    {
                        //MxlWbk.Close()


                    }
                }

            }

            public static void StartExcel()
            {

                xlApp = MxlApp;//new Excel.Application();

                xlWbk = MxlWbk;//xlApp.Workbooks.Open(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\masterSheetFinal.xlsx");

            }

            public static void CloseExcel()
            {

                if (MxlApp != null)
                {
                    //MxlWbk.Close();

                    MxlApp.Quit();

                    xlApp.Quit();


                    Console.WriteLine("Yes");

                }

            }





            public static void sqlData()
            {
                try
                {


                    SqlConnection sqlConn = new SqlConnection();

                    sqlConn.ConnectionString = "Data Source=" + database + ";Initial Catalog=mcoredb;" + "Integrated Security=SSPI;";



                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(
                        @"--DECLARE  @jobdt DATE = '20181127'
DECLARE @T1 TABLE([TABLE NAME] VARCHAR(50), [ROWS INSERTED] VARCHAR(100), [ROWS UPDATED] VARCHAR(100))
INSERT @T1
SELECT 'COLL_DETAIL', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.COLL_DETAIL WHERE COLL_DATE = @jobdt
UNION
SELECT 'COLL_POSITION', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.TLM_COLLATERALPOSITIONS WHERE RECORDDATE = @jobdt
UNION
SELECT 'DAILY_ACCRUAL', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.TLM_DAILYACCRUALS WHERE DAILYACCRUALDATE = @jobdt
UNION
SELECT 'MOVEMENTS', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.MOVEMENTS WHERE TRADEDATE = @jobdt
UNION
SELECT 'MARGINCALLS', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.MARGINCALLS WHERE VALUATIONDATE = @jobdt
UNION
SELECT 'ENTITYCREDITRATINGS', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.ENTITYCREDITRATINGS WHERE COB_DATE = @jobdt
UNION
SELECT 'RATING_THRESHOLD_MTA', COUNT(*), 'N/A' TIDALUAT FROM mcoredb.DBO.RATING_THRESHOLD_MTA WHERE COB_DATE = @jobdt

SELECT* FROM @T1"

                        );

                    sqlCmd.CommandTimeout = 100000;

                    sqlCmd.Connection = sqlConn;

                    sqlCmd.Parameters.Add(new SqlParameter() { Value = DateTime.Parse(PjobDate), ParameterName = "@jobdt", DbType = DbType.DateTime });

                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                    bool sqlbool = true;

                    Console.WriteLine();

                    int i = 0;

                    while (sqlbool)
                    {


                        Console.WriteLine($"{sqlReader.GetName(0)},{sqlReader.GetName(1)},{sqlReader.GetName(2)}");
                        List<string> listVal = new List<string>();
                        listVal.Add(sqlReader.GetName(1).Trim());
                        listVal.Add(sqlReader.GetName(2).Trim());
                        collateralData.Add(sqlReader.GetName(0).Trim(), listVal);


                        while (sqlReader.Read())
                        {

                            Console.WriteLine($"{sqlReader[0]},{sqlReader[1]},{sqlReader[2]}");
                            List<string> listVal1 = new List<string>();
                            listVal1.Add(sqlReader[1].ToString().Trim());
                            listVal1.Add(sqlReader[2].ToString().Trim());
                            collateralData.Add(sqlReader[0].ToString().Trim(), listVal1);



                        }

                        // Console.WriteLine("==================================================\n");
                        i++;
                        sqlbool = sqlReader.NextResult();
                    }

                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);

                }
            }

            public static void SetDictNames()
            {

                collateralData.Desc = "Collateral Processing for " + Pdate + " " + environment.ToUpper();
                collateralData.Name = "colData";
            }


            public static void ClearCells()
            {

                Excel.Worksheet xlWksht_BToV = xlWbk.Worksheets["BToV"];

                xlWksht_BToV.Range["A2:C65"].Clear();

                xlWbk.Save();


            }

            public static void SqlToExcel()
            {

                Excel.Worksheet xlWksht_BToV = xlWbk.Worksheets["BToV"];

                //string xlrange = xlWksht.UsedRange.Cells.ToString();


                //Excel.Range xlRange = xlWksht.Range[xlWksht.Cells[1, 1], xlWksht.Cells[2, 2]];


                //xlWksht.Cells[xlWksht.Cells[84,1],xlWksht.Cells[100,10]].Clear();


                int ct = 1;
                xlWksht_BToV.Cells[ct, 1].Value = collateralData.Desc;
                xlWksht_BToV.Cells[ct, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                xlWksht_BToV.Cells[ct, 1].Characters.Font.Bold = true;

                xlWksht_BToV.Cells[ct + 1, 1].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 1, 2].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 1, 3].Characters.Font.Bold = true;

                xlWksht_BToV.Cells[ct + 1, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                xlWksht_BToV.Cells[ct + 1, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                xlWksht_BToV.Cells[ct + 1, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 225, 242));
                

                for (int i = 0; i < collateralData.Count; i++)
                {

                    xlWksht_BToV.Cells[i + ct + 1, 1].Borders.Color = ConsoleColor.Black;
                    xlWksht_BToV.Cells[i + ct + 1, 2].Borders.Color = ConsoleColor.Black;
                    xlWksht_BToV.Cells[i + ct + 1, 3].Borders.Color = ConsoleColor.Black;

                    xlWksht_BToV.Cells[i + ct + 1, 1].Value = collateralData.ElementAt(i).Key;
                    Console.WriteLine(collateralData.ElementAt(i).Key);
                    xlWksht_BToV.Cells[i + ct + 1, 2].Value = collateralData.ElementAt(i).Value.ElementAt(0);
                    Console.WriteLine(collateralData.ElementAt(i).Value.ElementAt(0));
                    xlWksht_BToV.Cells[i + ct + 1, 3].Value = collateralData.ElementAt(i).Value.ElementAt(1);
                    Console.WriteLine(collateralData.ElementAt(i).Value.ElementAt(1));
                    xlWksht_BToV.Cells[i + ct + 1, 3].HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
                }

                ct += collateralData.Count + 2;
                //1
                xlWksht_BToV.Cells[ct + 1, 1].Value = "Total Runtime:";
                xlWksht_BToV.Cells[ct + 1, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                xlWksht_BToV.Cells[ct + 1, 1].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 1, 1].Borders.Color = ConsoleColor.Black;

                xlWksht_BToV.Cells[ct + 1, 2].Value = CollateralDuration;
                //xlWksht_BToV.Cells[ct + 1, 2].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 1, 2].Borders.Color = ConsoleColor.Black;

                //2
                xlWksht_BToV.Cells[ct + 2, 1].Value = "Manual Intervention:";
                xlWksht_BToV.Cells[ct + 2, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                xlWksht_BToV.Cells[ct + 2, 1].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 2, 1].Borders.Color = ConsoleColor.Black;

                xlWksht_BToV.Cells[ct + 2, 2].Value = "N/A";
                //xlWksht_BToV.Cells[ct + 2, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                //xlWksht_BToV.Cells[ct + 2, 2].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 2, 2].Borders.Color = ConsoleColor.Black;

                //3
                xlWksht_BToV.Cells[ct + 3, 1].Value = "Incident:";
                xlWksht_BToV.Cells[ct + 3, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                xlWksht_BToV.Cells[ct + 3, 1].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 3, 1].Borders.Color = ConsoleColor.Black;

                xlWksht_BToV.Cells[ct + 3, 2].Value = "N/A";
                //xlWksht_BToV.Cells[ct + 1, 2].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 3, 2].Borders.Color = ConsoleColor.Black;

                //4
                xlWksht_BToV.Cells[ct + 4, 1].Value = "Resolution:";
                xlWksht_BToV.Cells[ct + 4, 1].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                xlWksht_BToV.Cells[ct + 4, 1].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 4, 1].Borders.Color = ConsoleColor.Black;

                xlWksht_BToV.Cells[ct + 4, 2].Value = "N/A";
                //xlWksht_BToV.Cells[ct + 2, 2].Characters.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                //xlWksht_BToV.Cells[ct + 2, 2].Characters.Font.Bold = true;
                xlWksht_BToV.Cells[ct + 4, 2].Borders.Color = ConsoleColor.Black;


                Console.WriteLine(ct);


                xlWbk.Save();

                //xlApp.Quit();



            }

            public static void ExcelSheetHTML()
            {


                string htmfile = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\xlsDapCollat.htm";

                xlWbk.PublishObjects.Add(Excel.XlSourceType.xlSourceSheet,
                    htmfile,
                    "BToV",
                     Excel.XlFileFormat.xlHtml
                    ).Publish(true);


                FileStream fs = File.OpenRead(htmfile);

                StreamReader sr = new StreamReader(fs);


                excelData = sr.ReadToEnd();

                //Console.WriteLine(excelData);

                xlWbk.Save();

                xlWbk.Close();

                xlApp.Quit();

                fs.Close();



                //File.Delete(htmfile);


            }


            public static void GetMailDetails()
            {
                try
                {

                    Outlook.Application outApp = new Outlook.Application();

                    Outlook.MailItem mail = outApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;


                    var outSentBox = outApp.GetNamespace("MAPI").Session.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox);

                    Outlook.Items items = outSentBox.Items;

                    var mailFound = outSentBox.Items.
                        OfType<Outlook.MailItem>().
                        Where(m => m.Subject.Contains("UAT MCDB to MCDV 11/28")).Select(m => m);

                    Outlook.Recipients outrecp = mailFound.Last().Recipients;

                    outBody = mailFound.Last().HTMLBody;

                    outAddress = null;

                    foreach (Outlook.Recipient item in outrecp)
                    {

                        Outlook.PropertyAccessor outPa = item.PropertyAccessor;
                        outAddress += outPa.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x39FE001E").ToString() + ";";


                    }


                    Console.WriteLine(outAddress);

                    File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\emailsCollateral.txt", outAddress);



                    mailTo = outAddress.Substring(0, 201);

                    mailCC = outAddress.Substring(201);

                    Console.WriteLine("mailTo\n\n..{0}", mailTo);

                    Console.WriteLine("mailCC\n\n..{0}", mailCC);
                    Console.WriteLine(outAddress);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                }



            }

            public static void OutlookMail()
            {
                try
                {



                    Outlook.Application outApp = new Outlook.Application();

                    Outlook.MailItem mail = outApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;

                    //GetMailDetails();

                    outAddress = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\emailsCollateral.txt");

                    mailTo = outAddress.Substring(0, 121);

                    mailCC = outAddress.Substring(121);

                    Console.WriteLine("mailTo\n\n..{0}", mailTo);

                    Console.WriteLine("mailCC\n\n..{0}", mailCC);
                    Console.WriteLine(outAddress);

                    mail.To = mailTo;

                    mail.CC = mailCC;

                    MailMessage mailMsg = new MailMessage();

                    mailMsg.IsBodyHtml = true;

                    mail.Subject = "RE: MCDB to MCDV " + environment.ToUpper() + " Update: " + Pdate + " Status";


                    mail.HTMLBody = excelData.Replace("align=center", "align=TopLeft").Replace(
                         @"< tr height = 20 style = 'height:15.0pt' >
  < td height = 20 class=xl6322744 width = 284 style='height:15.0pt;width:213pt'>Collateral
       Processing for 11/28 UAT</td>",
                          @"< tr height = 0 style = 'height:0.0pt' >
  < td height = 20 class=xl6322744 width = 284 style='height:0.0pt;width:213pt'>Collateral
       Processing for 11/28 UAT</td>?");

                    mail.Display();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);


                }
            }



        }

    }
}
