﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
using System.Runtime.Serialization.Formatters.Binary;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;

namespace APiConnect
{
    class DictionaryEXT<TKey, TValue> : Dictionary<TKey, TValue>
    {
        public string Name { get; set; }

        public string Desc { get; set; }

    }

    public partial class Program
    {


        public partial class MUREXToMCDB
        {


            public static string strdJobs { get; set; }

            public static string stagingJobs { get; set; }

            public static string TotalPeriodStaging { get; set; }

            public static string TotalExecutionStaging { get; set; }

            public static string Murex10 { get; set; }

            public static string MUrex15 { get; set; }

            public static void Deserialize_STD(string filePath)
            {

                Console.WriteLine("Reading serialized file now...");



                BinaryFormatter bf = new BinaryFormatter();
                byte[] b = System.Text.Encoding.UTF8.GetBytes(UrlPayload_STD);
                MemoryStream ms = new MemoryStream(b);

                //instanc of the xmlserializer specifying type and namespace
                XmlSerializer serializer = new XmlSerializer(typeof(feed));


                //fielstream is needed to read the XML document
                FileStream fs = new FileStream(filePath, FileMode.Open);

                StreamReader sr = new StreamReader(fs);

                //Console.WriteLine(sr.ReadToEnd());




                XmlReader reader = XmlReader.Create(fs);

                //object variable of the type to be deserialized
                feed Standardization;





                Standardization = (feed)serializer.Deserialize(reader);


                fs.Close();


                DateTime[] dtList = new DateTime[Standardization.entry.Length * 2];
                int i = 0;
                int duration = 0;
                foreach (var item in Standardization.entry.OrderBy((m) => m.jobrun.jobname))
                {

                    Console.WriteLine("i is... {0}", i.ToString());
                    duration += item.jobrun.duration;

                    dtList[i] = item.jobrun.starttime;
                    i++;
                    dtList[i] = item.jobrun.endtime;
                    i++;

                    Console.WriteLine(
                    "id - " + item.id + "...alias - " + item.jobrun.alias + ".....start time - " + item.jobrun.starttime + ".....end time - " + item.jobrun.endtime + ".....jobname - " + item.jobrun.jobname + "... DURATION - " + item.jobrun.duration
                    //i.Description
                    );

                    strdJobs += item.id + "...  " + item.jobrun.alias + "   ....." + item.jobrun.jobname + "\n";


                }
                DateTime filedtMin;
                DateTime filedtMax;
                int dtDiff;

                filedtMin = Standardization.entry.Where(m => m.jobrun.jobname ==
                "200 Run SSIS - Standardize Murex Collateral Exposures to MCDB").Select(m => m.jobrun.starttime).AsEnumerable().Min() - TimeSpan.FromSeconds(600.0);
                filedtMax = dtList.AsEnumerable().Max();


                Console.WriteLine("This is the min date for Standardization jobs.... {0}", filedtMin);
                Console.WriteLine("The duration for the Standardization jobs is.... {0}", duration);

                runDate = filedtMin.ToString();

                Console.WriteLine("The RUNDATETIME is.... {0}", runDate);

                int rem;

                int remin;

                int Murex = Math.DivRem(duration, 60, out rem);

                int hour = Math.DivRem(Murex, 60, out remin);

                MUrex15 = hour.ToString() + "h:" + remin.ToString() + "m:" + rem.ToString() + "s";

                File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\Standardize Jobs.csv", strdJobs);


            }

            public static void Deserialize_STG(string filePath)
            {

                Console.WriteLine("Reading serialized file now...");



                BinaryFormatter bf = new BinaryFormatter();
                byte[] b = System.Text.Encoding.UTF8.GetBytes(UrlPayload_STG);
                MemoryStream ms = new MemoryStream(b);

                //instanc of the xmlserializer specifying type and namespace
                XmlSerializer serializer = new XmlSerializer(typeof(feed));


                //fielstream is needed to read the XML document
                FileStream fs = new FileStream(filePath, FileMode.Open);

                StreamReader sr = new StreamReader(fs);

                //Console.WriteLine(sr.ReadToEnd());




                XmlReader reader = XmlReader.Create(fs);

                //object variable of the type to be deserialized
                feed Staging;





                Staging = (feed)serializer.Deserialize(reader);


                fs.Close();

                //Console.WriteLine("{0}.... date",Staging.modified);
            
                string file = null;

                DateTime[] dtList = new DateTime[Staging.entry.Length * 2];

                string[] jobList = null;

                switch (environment)
                {
                    case "uat":
                        jobList = new string[] { "32059", "25619", "25620", "25621", "25623", "25625", "25627", "33630", "45130", "33464", "43480", "42639", "25628", "25629", "25630", "25631", "25635", "25637", "32629", "32663", "32666", "32667" };
                        break;
                    case "dev":
                        jobList = new string[] { "25619", "25620", "25621", "25623", "25625", "25627", "25628", "25629", "25630", "25631", "25635", "25637", "32059", "32629", "32663", "32666", "32667", "33464", "33630", "42639", "43480" };
                        break;
                    case "sit":
                        jobList = new string[] { "25619", "25620", "25621", "25623", "25625", "25627", "25628", "25629", "25630", "25631", "25635", "25637", "32059", "32629", "32663", "32666", "32667", "33464", "33630", "42639", "43480" };
                        break;
                    case "prod":
                        jobList = new string[] { "25619", "25620", "25621", "25623", "25625", "45130", "25627", "25628", "25629", "25630", "25631", "25635", "25637", "32059", "32629", "32663", "32666", "32667", "33464", "33630", "42639", "43480" };
                        break;
                    default:
                        Console.WriteLine("Check that you set the environment correctly");
                        break;

                }


                //write out the properties of the object
                int i = 0;
                int duration = 0;
                foreach (var item in Staging.entry.OrderBy(n => n.jobrun.starttime/*.jobname.Substring(15)*/))
                {

                    //if (jobList.Contains(item.jobrun.alias))
                    //{

                        Console.WriteLine("i is... {0}", i.ToString());
                        duration += item.jobrun.duration;

                        dtList[i] = item.jobrun.starttime;
                        i++;
                        dtList[i] = item.jobrun.endtime;
                        i++;

                        Console.WriteLine(
                        "id - " + item.id + "...alias - " + item.jobrun.alias + ".....start time - " + item.jobrun.starttime + ".....end time - " + item.jobrun.endtime + ".....jobname - " + item.jobrun.jobname +
                        "... duration - " + item.jobrun.duration
                        //i.Description
                        );

                        stagingJobs += item.id + " .." + item.jobrun.alias  + " ..start - " + item.jobrun.starttime
                            + " ..end - " + item.jobrun.endtime +" .." + item.jobrun.jobname + "\n";

                    //}


                }
                DateTime filedtMin;
                DateTime filedtMax;
                int dtDiff;

                filedtMin = dtList.AsEnumerable().Min();
                filedtMax = dtList.AsEnumerable().Max();

                dtDiff = (int)(filedtMax - filedtMin).TotalSeconds;

                File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\Staging Jobs.csv", stagingJobs);


                int rem;

                int remin;

                int Murex = Math.DivRem(duration, 60, out rem);

                int hour = Math.DivRem(Murex, 60, out remin);

                TotalExecutionStaging = hour.ToString() + "h:" + remin.ToString() + "m:" + rem.ToString() + "s";


                int rem2;

                int remin2;

                int Murex2 = Math.DivRem(dtDiff, 60, out rem2);

                int hour2 = Math.DivRem(Murex2, 60, out remin2);

                TotalPeriodStaging = hour2.ToString() + "h:" + remin2.ToString() + "m:" + rem2.ToString() + "s";

                //Console.WriteLine("{0}..... total execution", TotalExecutionStaging);
                Console.WriteLine("{0}..... earliest time - {1}........ latest time - {2}.......\n {3}........\n timespan", dtDiff, filedtMin, filedtMax, TotalPeriodStaging);
            }
        }
    }

}
