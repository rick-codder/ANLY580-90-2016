﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;
namespace APiConnect
{
    public partial class Program
    {

        static DictionaryEXT<string, List<string>> SLAdataobj = new DictionaryEXT<string, List<string>>();

        static string excelData;

        public static void Tester()
        {
            SqlConnection sqlConn = new SqlConnection();

            sqlConn.ConnectionString = "Data Source=MCOUSQMCDB;Initial Catalog=mcoredb;Integrated Security=SSPI;";

            sqlConn.Open();

            //string sqlFile = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SQL\TIDAL JOB SLA.sql");
            string cmd = "SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'DBO' AND TABLE_TYPE = 'BASE TABLE' AND TABLE_NAME NOT LIKE '%MSSQL_%' ORDER BY TABLE_NAME";

            SqlCommand sqlCmd = new SqlCommand(cmd);

            sqlCmd.CommandTimeout = 100000;

            sqlCmd.Connection = sqlConn;

            sqlCmd.Parameters.Add(new SqlParameter() { Value = DateTime.Parse(PjobDate), ParameterName = "@Date", DbType = DbType.DateTime });

            SqlDataReader sqlReader = sqlCmd.ExecuteReader();

            for(int i = 0; i < sqlReader.FieldCount; i++)
            {
                Console.WriteLine(sqlReader.GetName(i));

            }



        }


        public static void SLAMain()
        {
            StartExcel();

            Console.WriteLine("Now accessing database....\n");
            SLAData();


            Console.WriteLine("Now loading into Excel....\n");
            SqlToExcelSLA();


            Console.WriteLine("Now publishing to HTML....\n");
            ExcelSheetHTML();

            Console.WriteLine("Now loading into Outlook....\n");
            OutlookMail();

            //CloseExcel();


            System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
            foreach (System.Diagnostics.Process p in process)
            {

                p.Kill();

            }

        }



        public static void ExcelSheetHTML()
        {


            string htmfile = @"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\DOCUMENTS\xlsDap.htm";

            MxlWbk.PublishObjects.Add(Excel.XlSourceType.xlSourceSheet,
                htmfile,
                "master",
                 Excel.XlFileFormat.xlHtml
                ).Publish(true);


            FileStream fs = File.OpenRead(htmfile);

            StreamReader sr = new StreamReader(fs);


            excelData = sr.ReadToEnd();

            MxlWbk.Save();

            fs.Close();

        }


        public static void OutlookMail()
        {
            try
            {

                Outlook.Application outApp = new Outlook.Application();

                Outlook.MailItem mail = outApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;


                mail.To = "joe.miller@mizuhogroup.com;";

                mail.CC =
            "jim.jenkinson@mizuhogroup.com;David.Marks@mizuhogroup.com;David.Mcintyre@mizuhogroup.com;Thir.Valliappan@mizuhogroup.com;" +
            "Daniel.Davidson@mizuhogroup.com;Srinivasa.Seelam@mizuhogroup.com;Luca.Leonte@mizuhogroup.com";


                MailMessage mailMsg = new MailMessage();

                mailMsg.IsBodyHtml = true;

                mail.Subject = "RE: Murex to MCDB " + environment.ToUpper() + " Update: " + Pdate + " Status";


                mail.HTMLBody = excelData.Replace("align=center", "align=left"); // $"<table style='border:1px solid black; border-collapse:collapse'><tr><td>{mailMsg.Body}<td></tr></table>";

                mail.Display();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);


            }
        }

        public static void SqlToExcelSLA()
        {

            Excel.Worksheet xlWksht = MxlWbk.Worksheets["master"];


            int ct = 9;
            foreach (var item in SLAdataobj.Skip(1))
            {

                try
                {
                    //for (int i = 1; i < SLAdataobj.Count; i++)
                    //{

                        xlWksht.Cells[ct + 1, 1].Borders.Color = ConsoleColor.Red;
                        xlWksht.Cells[ct + 1, 2].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[ct + 1, 3].Borders.Color = ConsoleColor.Red;
                        xlWksht.Cells[ct + 1, 4].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[ct + 1, 5].Borders.Color = ConsoleColor.Red;
                        xlWksht.Cells[ct + 1, 6].Borders.Color = ConsoleColor.Black;
                        xlWksht.Cells[ct + 1, 7].Borders.Color = ConsoleColor.Red;
                        xlWksht.Cells[ct + 1, 8].Borders.Color = ConsoleColor.Black;

                        xlWksht.Cells[ct + 1, 1].Value = item.Value.ElementAt(1);
                        xlWksht.Cells[ct + 1, 2].Value = item.Value.ElementAt(2);
                        xlWksht.Cells[ct + 1, 3].Value = item.Value.ElementAt(3);
                        xlWksht.Cells[ct + 1, 4].Value = item.Value.ElementAt(4);
                        xlWksht.Cells[ct + 1, 5].Value = item.Value.ElementAt(5);
                        xlWksht.Cells[ct + 1, 6].Value = item.Value.ElementAt(6).Replace("1/1/1900 12:00:00 AM", "");
                        xlWksht.Cells[ct + 1, 7].Value = item.Value.ElementAt(7);
                        xlWksht.Cells[ct + 1, 8].Value = item.Value.ElementAt(8);


                        Console.WriteLine(item.Value.ElementAt(1));
                        Console.WriteLine(item.Value.ElementAt(2));
                        Console.WriteLine(item.Value.ElementAt(3));
                        Console.WriteLine(item.Value.ElementAt(4));
                        Console.WriteLine(item.Value.ElementAt(5));
                        Console.WriteLine(item.Value.ElementAt(6));
                        Console.WriteLine(item.Value.ElementAt(6));
                        Console.WriteLine(item.Value.ElementAt(7));
                        Console.WriteLine(item.Value.ElementAt(8));

                    ct += 1;


                    //}
                }
                catch (Exception e)
                {
                    Console.WriteLine($"The error is {e.Message}");
                }
            }
        }


        public static void SLAData()
        {
            try
            {


                SqlConnection sqlConn = new SqlConnection();

                sqlConn.ConnectionString = "Data Source=MCOPSQTIDB;Initial Catalog=Admiral62;Integrated Security=SSPI;";



                sqlConn.Open();

                string sqlFile = File.ReadAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\SQL\TIDAL JOB SLA.sql");

                SqlCommand sqlCmd = new SqlCommand(sqlFile);

                sqlCmd.CommandTimeout = 100000;

                sqlCmd.Connection = sqlConn;

                sqlCmd.Parameters.Add(new SqlParameter() { Value = DateTime.Parse(PjobDate), ParameterName = "@Date", DbType = DbType.DateTime });

                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                bool sqlbool = true;

                Console.WriteLine();


                int i = 0;

                while (sqlbool)
                {


                    //Console.WriteLine($"{sqlReader.GetName(0)},{sqlReader.GetName(1)},{sqlReader.GetName(2)},{sqlReader.GetName(3)},{sqlReader.GetName(4)},{sqlReader.GetName(5)},{sqlReader.GetName(6)},{sqlReader.GetName(7)},{sqlReader.GetName(8)},{sqlReader.GetName(9)}");
                    List<string> listValheader = new List<string>();
                    listValheader.Add(sqlReader.GetName(1).Trim());
                    listValheader.Add(sqlReader.GetName(2).Trim());
                    listValheader.Add(sqlReader.GetName(3).Trim());
                    listValheader.Add(sqlReader.GetName(4).Trim());
                    listValheader.Add(sqlReader.GetName(5).Trim());
                    listValheader.Add(sqlReader.GetName(6).Trim());
                    listValheader.Add(sqlReader.GetName(7).Trim());
                    listValheader.Add(sqlReader.GetName(8).Trim());
                    listValheader.Add(sqlReader.GetName(9).Trim());
                    SLAdataobj.Add(sqlReader.GetName(0).Trim(), listValheader);


                    while (sqlReader.Read())
                    {

                        //Console.WriteLine($"{sqlReader[0]},{sqlReader[1]},{sqlReader[2]},{sqlReader[3]},{sqlReader[4]},{sqlReader[5]},{sqlReader[6]},{sqlReader[7]},{sqlReader[8]},{sqlReader[9]}");
                        List<string> listValdata = new List<string>();
                        listValdata.Add(sqlReader[1].ToString().Trim());
                        listValdata.Add(sqlReader[2].ToString().Trim());
                        listValdata.Add(sqlReader[3].ToString().Trim());
                        listValdata.Add(sqlReader[4].ToString().Trim());
                        listValdata.Add(sqlReader[5].ToString().Trim());
                        listValdata.Add(sqlReader[6].ToString().Trim());
                        listValdata.Add(sqlReader[7].ToString().Trim());
                        listValdata.Add(sqlReader[8].ToString().Trim());
                        listValdata.Add(sqlReader[9].ToString().Trim());
                        SLAdataobj.Add(sqlReader[0].ToString().Trim(), listValdata);



                    }

                    // Console.WriteLine("==================================================\n");
                    i++;
                    sqlbool = sqlReader.NextResult();
                }

                //sqlReader.Close();

                //sqlConn.Close();



                //Console.WriteLine( msusa.ElementAt(1));
                //Console.WriteLine(mcm.ElementAt(1).Key);
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);

            }
        }















    }
}
