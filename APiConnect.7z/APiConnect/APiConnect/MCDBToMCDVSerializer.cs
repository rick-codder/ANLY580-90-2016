﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using SHDocVw;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using VB = Microsoft.VisualBasic;
using System.Runtime.Serialization.Formatters.Binary;
//using System.Net.Http.Headers;
//using System.Web.Services.Protocols;


namespace APiConnect
{
    public partial class Program
    {

        public partial class MCDBToMCDV
        {

            public static string CollateralJobs { get; set; }


            public static string CollateralDuration { get; set; }

            static string runDate;// "2018/10/10 9:40:00";

            public static void Deserialize_SLA(string filePath)
            {

                Console.WriteLine("Reading serialized file now...");



                //BinaryFormatter bf = new BinaryFormatter();
                //byte[] b = System.Text.Encoding.UTF8.GetBytes(UrlPayload_STD);
                //MemoryStream ms = new MemoryStream(b);

                //instanc of the xmlserializer specifying type and namespace
                XmlSerializer serializer = new XmlSerializer(typeof(feed));


                //fielstream is needed to read the XML document
                FileStream fs = new FileStream(filePath, FileMode.Open);

                StreamReader sr = new StreamReader(fs);

                //Console.WriteLine(sr.ReadToEnd());




                XmlReader reader = XmlReader.Create(fs);

                //object variable of the type to be deserialized
                feed collateralProcessing;





                collateralProcessing = (feed)serializer.Deserialize(reader);


                fs.Close();


                DateTime[] dtList = new DateTime[12];
                int i = 0;
                int duration = 0;
                foreach (var item in collateralProcessing.entry.OrderBy((m) => m.jobrun.jobname))
                {

                    Console.WriteLine("i is... {0}", i.ToString());
                    duration += item.jobrun.duration;

                    dtList[i] = item.jobrun.starttime;
                    i++;
                    dtList[i] = item.jobrun.endtime;
                    i++;

                    Console.WriteLine(
                    "id - " + item.id + "...alias - " + item.jobrun.alias + ".....start time - " + item.jobrun.starttime + ".....end time - " + item.jobrun.endtime + ".....jobname - " + item.jobrun.jobname + "... DURATION - " + item.jobrun.duration
                    //i.Description
                    );

                    CollateralJobs += item.id + "...  " + item.jobrun.alias + "   ....." + item.jobrun.jobname + "\n";


                }
                DateTime filedtMin;
                DateTime filedtMax;
                int dtDiff;

                filedtMin = dtList.AsEnumerable().Min();
                filedtMax = dtList.AsEnumerable().Max();

                Console.WriteLine("This is the min date for Standardization jobs.... {0}", filedtMin);
                Console.WriteLine("The duration for the Standardization jobs is.... {0}", duration);

                runDate = filedtMin.ToString();

                Console.WriteLine("The RUNDATETIME is.... {0}", runDate);

                int rem;

                int remin;

                int Murex = Math.DivRem(duration, 60, out rem);

                int hour = Math.DivRem(Murex, 60, out remin);

                CollateralDuration = hour.ToString() + "h:" + remin.ToString() + "m:" + rem.ToString() + "s";

                File.WriteAllText(@"\\fnyipw01\HOB_CORP_Home\olayemiadejumo\AppSense\Desktop\Collateral Processing Jobs.csv", CollateralJobs);


            }
        }

    }
}
