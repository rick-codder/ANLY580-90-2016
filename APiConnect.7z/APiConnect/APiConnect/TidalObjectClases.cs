﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APiConnect
{


    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://purl.org/atom/ns#")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://purl.org/atom/ns#", IsNullable = false)]
    public partial class feed
    {

        private string titleField;

        private feedCategory[] categoryField;

        private feedGenerator generatorField;

        private System.DateTime modifiedField;

        private feedEntry[] entryField;

        private decimal versionField;

        /// <remarks/>
        public string title
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("category")]
        public feedCategory[] category
        {
            get
            {
                return this.categoryField;
            }
            set
            {
                this.categoryField = value;
            }
        }

        /// <remarks/>
        public feedGenerator generator
        {
            get
            {
                return this.generatorField;
            }
            set
            {
                this.generatorField = value;
            }
        }

        /// <remarks/>
        public System.DateTime modified
        {
            get
            {
                return this.modifiedField;
            }
            set
            {
                this.modifiedField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("entry")]
        public feedEntry[] entry
        {
            get
            {
                return this.entryField;
            }
            set
            {
                this.entryField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://purl.org/atom/ns#")]
    public partial class feedCategory
    {

        private string termField;

        private string schemeField;

        private string labelField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string term
        {
            get
            {
                return this.termField;
            }
            set
            {
                this.termField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string scheme
        {
            get
            {
                return this.schemeField;
            }
            set
            {
                this.schemeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string label
        {
            get
            {
                return this.labelField;
            }
            set
            {
                this.labelField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://purl.org/atom/ns#")]
    public partial class feedGenerator
    {

        private string uriField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string uri
        {
            get
            {
                return this.uriField;
            }
            set
            {
                this.uriField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://purl.org/atom/ns#")]
    public partial class feedEntry
    {

        private uint idField;

        private uint titleField;

        private feedEntryCategory[] categoryField;

        private string sourceField;

        private jobrun jobrunField;

        /// <remarks/>
        public uint id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public uint title
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("category")]
        public feedEntryCategory[] category
        {
            get
            {
                return this.categoryField;
            }
            set
            {
                this.categoryField = value;
            }
        }

        /// <remarks/>
        public string source
        {
            get
            {
                return this.sourceField;
            }
            set
            {
                this.sourceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://www.tidalsoftware.com/client/tesservlet")]
        public jobrun jobrun
        {
            get
            {
                return this.jobrunField;
            }
            set
            {
                this.jobrunField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://purl.org/atom/ns#")]
    public partial class feedEntryCategory
    {

        private string termField;

        private string schemeField;

        private string labelField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string term
        {
            get
            {
                return this.termField;
            }
            set
            {
                this.termField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string scheme
        {
            get
            {
                return this.schemeField;
            }
            set
            {
                this.schemeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string label
        {
            get
            {
                return this.labelField;
            }
            set
            {
                this.labelField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.tidalsoftware.com/client/tesservlet")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://www.tidalsoftware.com/client/tesservlet", IsNullable = true)]
    public partial class jobrun
    {

        private string parentnameField;

        private string jobnameField;

        private string aliasField;

        private ulong actualstarttimeasstringField;

        private uint idField;

        private string statusnameField;

        private string productiondateField;

        private ulong productiondateasstringField;

        private string actualstarttimeField;

        private System.DateTime starttimeField;

        private System.DateTime actualendtimeField;

        private string statuschangetimeField;

        private int estimateddurationField;

        private byte rerunsField;

        private int durationField;

        private string lastchangetimeField;

        private System.DateTime expectedSLAField;

        private TimeSpan breachField;



        /// <remarks/>
        public string parentname
        {
            get
            {
                return this.parentnameField;
            }
            set
            {
                this.parentnameField = value;
            }
        }


        /// <remarks/>
        public string alias
        {
            get
            {
                return this.aliasField;
            }
            set
            {
                this.aliasField = value;
            }
        }
        /// <remarks/>
        public string jobname
        {
            get
            {
                return this.jobnameField;
            }
            set
            {
                this.jobnameField = value;
            }
        }

        public string statusname
        {
            get
            {
                return this.statusname;
            }
            set
            {
                this.statusnameField = value;
            }
        }

        /// <remarks/>
        public ulong actualstarttimeasstring
        {
            get
            {
                return this.actualstarttimeasstringField;
            }
            set
            {
                this.actualstarttimeasstringField = value;
            }
        }

        /// <remarks/>
        public uint id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string productiondate
        {
            get
            {
                return this.productiondateField;
            }
            set
            {
                this.productiondateField = value;
            }
        }

        /// <remarks/>
        public ulong productiondateasstring
        {
            get
            {
                return this.productiondateasstringField;
            }
            set
            {
                this.productiondateasstringField = value;
            }
        }

        /// <remarks/>
        public string actualstarttime
        {
            get
            {
                return this.actualstarttimeField;
            }
            set
            {
                this.actualstarttimeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime starttime
        {
            get
            {
                return System.DateTime.Parse(actualstarttime == null ? System.DateTime.MinValue.ToString() : actualstarttime.Replace("-", "/").Replace("T", " ").Remove(19, 24 - 19));
            }
            set
            {
                this.starttimeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime endtime
        {
            get
            {
                return starttime + TimeSpan.FromSeconds(duration);
            }
            set
            {
                this.actualendtimeField = value;
            }
        }



        /// <remarks/>
        public string statuschangetime
        {
            get
            {
                return this.statuschangetimeField;
            }
            set
            {
                this.statuschangetimeField = value;
            }
        }

        /// <remarks/>
        public int estimatedduration
        {
            get
            {
                return this.estimateddurationField;
            }
            set
            {
                this.estimateddurationField = value;
            }
        }

        /// <remarks/>
        public byte reruns
        {
            get
            {
                return this.rerunsField;
            }
            set
            {
                this.rerunsField = value;
            }
        }

        /// <remarks/>
        public int duration
        {
            get
            {
                return this.durationField;
            }
            set
            {
                this.durationField = value;
            }
        }

        /// <remarks/>
        public string lastchangetime
        {
            get
            {
                return this.lastchangetimeField;
            }
            set
            {
                this.lastchangetimeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime expectedSLA
        {
            get
            {
                if (jobname == "Standardize Murex Collaterals")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(22);
                }
                else if (jobname == "Standardize Murex Ref Data")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(22);
                }
                else if (jobname == "Standardize Murex Schedules")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(22);
                }
                else if (jobname == "Standardize Murex Transactions and Legs")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(22);
                }
                else if (jobname == "400 Run SSIS - Murex P&L")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(24);
                }
                else if (jobname == "Standardize Murex Risk")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(10);
                }
                else if (jobname == "Stage Murex Ref Data")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(17);
                }
                else if (jobname == "Stage Murex Market Data")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(16);
                }
                else if (jobname == "Stage Murex Transactions")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(20);
                }
                else if (jobname == "Stage Murex Collateral")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(20);
                }
                else if (jobname == "Stage Murex PnL")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(21);
                }
                else if (jobname == "Stage Murex Risk")
                {
                    return expectedSLAField = DateTime.Now.Date.AddDays(-1) + TimeSpan.FromHours(21);
                }
                return expectedSLAField = DateTime.Now.Date.AddDays(-1);
            }
            set
            {
            }

        }

        public string Breach
        {
            get
            {
                int rem;

                int remin;

                int Murex = Math.DivRem((int)(endtime - expectedSLAField).TotalSeconds, 60, out rem);

                int hour = Math.DivRem(Murex, 60, out remin);

                string finalStr = hour.ToString() + "h:" + remin.ToString() + "m:" + rem.ToString() + "s";

                return finalStr;
            }
            set
            {
            }
        }




    }









}
