﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.XmlConfiguration;
using System.Configuration;
using Sax.Net;
using Sax;
using System.IO;
using System.IO.Compression;
using System.Net;
using Webscraper.Documents;
using Webscraper.Saxy;
using Webscraper.Filters;
using Webscraper.Exception;
using TagSoup.Net;

namespace Webscraper.Extractors
{

    public abstract class ExtractorBase : Extractor
    {

        /**
  * Extracts text from the HTML code given as a String.
  * 
  * @param html The HTML code as a String.
  * @return The extracted text.

  */
        public String GetText(String html)
        {
            try
            {
                Console.WriteLine("string get text");
                return GetText(new SAXInput(new InputSource(new StringReader(html)))
                    .GetTextDocument());


            }
            catch (SAXException e)
            {
                throw new WebscraperException(e);
            }
        }

        /**
         * Extracts text from the HTML code available from the given {@link InputSource}.
         * 
         * @param is The InputSource containing the HTML
         * @return The extracted text.
         */
        public String GetText(InputSource IS)
        {
            try
            {
                Console.WriteLine("2");
                return GetText(new SAXInput(IS).GetTextDocument());
            }
            catch (SAXException e)
            {
                throw new WebscraperException(e);
            }
        }

        /**
         * Extracts text from the HTML code available from the given {@link URL}. NOTE: This method is
         * mainly to be used for show case purposes. If you are going to crawl the Web, consider using
         * {@link #getText(InputSource)} instead.
         * 
         * @param url The URL pointing to the HTML code.
         * @return The extracted text.
         */
        public String GetText(Uri url)
        {
            try
            {
                Console.WriteLine("2 - fetch");
                return GetText(HTMLFetcher.Fetch(url).ToInputSource());
            }
            catch (IOException e)
            {
                throw new WebscraperException(e);
            }
        }

        /**
         * Extracts text from the HTML code available from the given {@link Reader}.
         * 
         * @param r The Reader containing the HTML
         * @return The extracted text.
         */
        public String GetText(TextReader r)
        {
            Console.WriteLine("2 - textreader");
            return GetText(new InputSource(r));
        }

        /**
         * Extracts text from the given {@link TextDocument} object.
         * 
         * @param doc The {@link TextDocument}.
         * @return The extracted text.
         */

        public abstract bool Process(TextDocument doc);


        public String GetText(TextDocument doc)
        {
            //Process(doc);

            return doc.GetContent();
        }



    }

    public class ArticleExtractor : ExtractorBase
    {
        public static ArticleExtractor INSTANCE = new ArticleExtractor();

        /**d
         * Returns the singleton instance for {@link ArticleExtractor}.
         */
        public static ArticleExtractor GetInstance()
        {
            return INSTANCE;
        }

        public override bool Process(TextDocument doc)
        {
            return

            TerminatingBlocksFinder.INSTANCE.Process(doc)
           | ClassScavenger.INSTANCE.Process(doc)
           | new DocumentTitleMatchClassifier(doc.GetTitle()).Process(doc)
           | NumWordsRulesClassifier.INSTANCE.Process(doc)
           | IgnoreBlocksAfterContentFilter.DEFAULT_INSTANCE.Process(doc)
           | TrailingHeadlineToFilter.INSTANCE.Process(doc)
           | BlockProximityFusion.MAX_DISTANCE_1.Process(doc)
           | BlockFilter.INSTANCE.Process(doc)
           | BlockProximityFusion.MAX_DISTANCE_1_SAME_TAGLEVEL.Process(doc)
           | KeepLargestBlockFilter.INSTANCE_EXPAND_TO_SAME_TAGLEVEL_MIN_WORDS.Process(doc)
           | ExpandTitleToContentFilter.INSTANCE.Process(doc)
           | LargeBlockSameTagLevelToContentFilter.INSTANCE.Process(doc)
           | ListAtEndFilter.INSTANCE.Process(doc);

        }




    }

    public class GenericExtractor : ExtractorBase
    {
        public static readonly GenericExtractor INSTANCE = new GenericExtractor();

        public override bool Process(TextDocument doc)
        {
            return SimpleBlockFusionProcessor.INSTANCE.Process(doc)
                | BlockProximityFusion.MAX_DISTANCE_1.Process(doc)
                | DensityRulesClassifier.INSTANCE.Process(doc);

        }




    }

}
