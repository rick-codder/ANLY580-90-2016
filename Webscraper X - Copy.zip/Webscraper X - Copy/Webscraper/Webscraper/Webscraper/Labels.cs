﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Webscraper.Documents;
using Webscraper.Conditions;

namespace Webscraper.Labels
{

    public class DefaultLabels
    {
        public const string TITLE = "re.webscraper/TITLE";
        public const string ARTICLE_METADATA = "re.webscraper/ARTICLE_METADATA";
        public const string INDICATES_END_OF_TEXT = "re.webscraper/INDICATES_END_OF_TEXT";
        public const string MIGHT_BE_CONTENT = "re.webscraper/MIGHT_BE_CONTENT";
        public const string VERY_LIKELY_CONTENT = "re.webscraper/VERY_LIKELY_CONTENT";
        public const string STRICTLY_NOT_CONTENT = "re.webscraper/STRICTLY_NOT_CONTENT";
        public const string HR = "re.webscraper/HR";
        public const string LI = "re.webscraper/LI";
                
        public const string HEADING = "re.webscraper/HEADING";
        public const string H1 = "re.webscraper/H1";
        public const string H2 = "re.webscraper/H2";
        public const string H3 = "re.webscraper/H3";

        public static string MARKUP_PREFIX = "<";

        private DefaultLabels()
        {
            // not to be instantiated
        }
    }

    public class ConditionalLabelAction : LabelAction
    {

        TextBlockCondition condition;

        public ConditionalLabelAction(TextBlockCondition condition, params string[] labels) : base(labels)
        {
            this.condition = condition;

        }

        public void AddTo(TextBlock tb)
        {
            if(condition.meetsCondition(tb))
            {
                AddLabelsTo(tb);
            }
        }

    }

    public class LabelAction
    {
        string[] labels;


        public LabelAction(params string[] labels)
        {

            this.labels = labels;
        }

        public void AddTo(TextBlock tb)
        {
            AddLabelsTo(tb);
        }

        protected void AddLabelsTo(TextBlock tb)
        {
            tb.AddLabels(labels);
        }

        public override string ToString()
        {
            return base.ToString() + "{" + string.Join(" ", labels) + "}";

        }
    }


    
}
